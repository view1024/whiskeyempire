// v4.3 画面確認：node v43.js <fresh|mid|late> <H> [shots=1] [fs=m|l]
const { chromium } = require('playwright');
const path = require('path');
const STATE = function (mode) {
  if (_offlineGate) closeOfflineModal(); closeM();
  Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose();
  _mktOff = true;
  if (mode === 'fresh') { prodInvalidate(); rall(); return; }
  const late = mode === 'late';
  G.dl = late ? 5 : 3; G.cash = late ? 5e11 : 8e7; G.te = late ? 5e12 : 5e8; G.reputation = late ? 260 : 60;
  G.stats.shipped = late ? 150000 : 2500; G.stats.orders = late ? 120 : 22;
  FD.forEach((f, i) => { G.fac[f.id].p = true; G.fac[f.id].l = (late ? [48, 46, 49, 45, 40, 38] : [24, 22, 26, 21, 18, 14])[i]; });
  G.branch.malting = 1; G.branch.fermentation = 0; G.branch.distillation = late ? 1 : null;
  G.uw = WL.slice(0, late ? 40 : 14).map(w => w.id);
  const mk = (c, s, age) => { const l = makeLot(caskType(c), caskSize(s)); l.age = age; l.L = l.L0 * Math.pow(0.984, age); return l; };
  G.lots = [mk('sherry', 'hogshead', 12.4), mk('bourbon', 'hogshead', 9.1), mk('bourbon', 'quarter', 4.6), mk('wine', 'barrel', 2.2), mk('bourbon', 'butt', 7.8), mk('sherry', 'hogshead', 0.4)];
  const nl = late ? whSlots() - 6 : 10;
  for (let i = 0; i < nl; i++) G.lots.push(mk('bourbon', 'hogshead', 1 + (i % 25) * 1.1));
  G.tank = late ? tankCap() * 0.7 : 1800;
  const t = productSpec('glenlivid').target;
  invAdd('glenlivid', 140, 9, 1.05, t); invAdd('jack_d', 60, 5, 1.0, productSpec('jack_d').target); invAdd('johnnie_em', 25, 12, 1.1, productSpec('johnnie_em').target);
  if (late) { invAdd('hibikue', 80, 17, 1.12, productSpec('hibikue') ? productSpec('hibikue').target : t); }
  G.orders = [];
  for (let i = 0; i < boardSize(); i++) { const o = ordGenerate(); if (o) G.orders.push(o); }
  if (G.orders[0]) { G.orders[0].reserve = true; G.orders[0].accepted = false; }
  G.rel.local = { lv: 2, done: 9 }; G.rel.bar = { lv: 1, done: 4 };
  G.shipLog = { glenlivid: { t: Date.now(), maxAge: 9 }, jack_d: { t: Date.now(), maxAge: 5 } };
  G.bq = [{ id: 'q_x', pid: 'glenlivid', n: 300, done: 120, moved: 120, age: 9, q: 1.05, fl: t, blend: null, oid: null }];
  G.blendHistory = [{ t: Date.now(), target: 'classic_blend', score: 0.82, n: 120 }];
  G.lots[0].name = 'はじまりの一樽'; G.lots[1].fin = { from: 'bourbon', at: 8 };
  G.chap.seed = true; checkChapters();
  prodInvalidate(); rall();
};
(async () => {
  const mode = process.argv[2] || 'mid';
  const H = Number(process.argv[3] || 667);
  const shots = (process.argv[4] || '1') === '1';
  const fs = process.argv[5] || 'm';
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: H }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !m.text().includes('ERR_FAILED')) errors.push(m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1200);
  await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(500);
  await page.evaluate(`(${STATE.toString()})(${JSON.stringify(mode)})`);
  if (fs === 'l') await page.evaluate(() => { opt().fs = 'l'; applyOpt(); rall(); });
  await page.waitForTimeout(600);
  await page.evaluate(() => { _celebQ = []; celebClose(); closeM(); document.querySelectorAll('.toast').forEach(t => t.classList.remove('on')); });
  await page.waitForTimeout(300);
  const res = {};
  for (const t of ['td', 'tb', 'tcel', 'tsale']) {
    await page.evaluate(t => switchTab(t), t);
    await page.waitForTimeout(300);
    res[t] = await page.evaluate(t => { const el = document.getElementById(t); return { ch: el.clientHeight, sh: el.scrollHeight, over: el.scrollHeight - el.clientHeight, blocks: [...el.children].filter(e => e.getClientRects().length).map(e => (e.id || e.className).slice(0, 12) + ':' + Math.round(e.getBoundingClientRect().height)).join(' ') }; }, t);
    if (shots) await page.screenshot({ path: `v43_${mode}_${H}_${t}${fs === 'l' ? '_L' : ''}.png` });
  }
  for (const t of Object.keys(res)) console.log(mode, H, fs, t, 'over=' + res[t].over, `(${res[t].sh}/${res[t].ch})`, res[t].blocks);
  console.log('ERRORS:', errors.length ? errors.join('\n') : 'none');
  await browser.close();
})();
