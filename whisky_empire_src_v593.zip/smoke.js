// 起動・各タブ・コンソールエラーの確認
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 375, height: 740 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1500);
  const tabs = ['td', 'tb', 'tcel', 'tsale', 'te', 'tp'];
  for (const t of tabs) {
    await page.click(`#nav .nb[data-tab="${t}"]`);
    await page.waitForTimeout(400);
    await page.screenshot({ path: `shot_${t}.png`, fullPage: false });
  }
  const st = await page.evaluate(() => ({ cash: G.cash, lots: G.lots.length, orders: G.orders.map(o => [o.cid, o.kind, o.pid, o.minAge, o.qty]), uw: G.uw, ver: G.ver, fresh: G.fresh }));
  console.log(JSON.stringify(st));
  console.log('ERRORS:', errors.length ? errors.join('\n') : 'none');
  await browser.close();
})();
