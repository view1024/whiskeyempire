exec(open('gen_ft50.py').read().replace("open('functest50.js','w').write(s)","pass"))
import os
exec(open('functest51_fix.py').read())
if os.path.exists('functest51_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest51_add.js').read()+s[a:]
open('functest51.js','w').write(s)
