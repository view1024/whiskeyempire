# v5.9 の生成（try で包む前）まで → v5.9.2 の書き換え → 追加 → try で包む
s59=open('gen_ft59.py').read()
exec(s59[:s59.rindex("exec(src[cut:]")])
exec(open('functest592_fix.py').read())
if os.path.exists('functest592_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest592_add.js').read()+s[a:]
exec(src[cut:].replace("open('functest55.js','w').write(s)","pass"))
open('functest592.js','w').write(s)
