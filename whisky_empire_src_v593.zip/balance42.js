// 簡易ボットで25日分を1時間刻みに進め、Tier到達日を確認する
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext()).newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1500);
  await page.evaluate(()=>{_mktOff=true;titleStart(false);});
  await page.waitForTimeout(600);
  const log = await page.evaluate((__DAYS__) => {
    if (_offlineGate) closeOfflineModal(); closeM(); if(typeof TUTS!=="undefined"){Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}}
    toast = () => {}; celebrate = () => {}; sndPurchase = sndUpgrade = sndTierUp = sndQuest = sndError = () => {};
    let off = 0; const realNow = Date.now.bind(Date); Date.now = () => realNow() + off;
    const out = []; const H = 3600000;
    G.auto.fill.on = true;
    const DAYS=__DAYS__;let act={up:0,del:0};const daily=[];
    for (let h = 0; h < 24 * DAYS; h++) {
      // プレイヤーの行動（1日3回だけ能動的に動く想定: 8時・13時・21時）
      const hod = h % 24; const active = hod === 8 || hod === 13 || hod === 21;
      if (active) {
        for (let k = 0; k < 40; k++) tap();
        // 施設: 購入→律速工程→熟成庫→ボトリングの順で強化
        let guard = 0;
        const saving = G.dl < DL.length && tierReqStatus(G.dl + 1).filter(o => !o.money).every(o => o.ok || o.label.includes('年以上'));
        while (!saving && guard++ < 200) {
          const cand = [];
          FD.forEach(f => { if (isUL(f.id) && !G.fac[f.id].p) cand.push({ c: fpc(f.id), fn: () => purFac(f.id) }); });
          FD.forEach(f => { if (brPending(f.id)) brChoose(f.id, ['malting','mashing','fermentation'].includes(f.id) ? 1 : f.id === 'maturation' ? 1 : f.id === 'bottling' ? 1 : 0); });
          const fl = prodFlows(); let bn = fl.bottleneck >= 0 ? STAGES[fl.bottleneck].fac : null;
          if (!bn) { const st = STAGES.filter(s => G.fac[s.fac].p).sort((a, b) => G.fac[a.fac].l - G.fac[b.fac].l)[0]; bn = st ? st.fac : 'malting'; }
          const targets = [bn, 'maturation', 'bottling'];
          targets.forEach(id => { if (G.fac[id].p && G.fac[id].l < facMaxLv() && !brPending(id)) cand.push({ c: fuc(id) * (id === bn ? 1 : 1.5), real: fuc(id), fn: () => upgFac(id) }); });
          if (G.cl < tapMaxLv()) cand.push({ c: cuc() * 3, real: cuc(), fn: upgClick });
          cand.sort((a, b) => a.c - b.c);
          const best = cand[0]; if (!best) break;
          const need = best.real || best.c; if (G.cash < need * 1.02) break;
          best.fn(); closeM(); act.up++;
        }
        // 注文: 予約を受ける→瓶詰め→納品
        const rq0 = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 99, n: 0 };
        const prot0 = new Set(G.lots.slice().sort((x, y) => y.age - x.age).slice(0, rq0.n + 2).map(l => l.id));
        const pvOk = o => { const ids = lotsFor(o.pid).filter(l => !prot0.has(l.id) && l.age >= o.minAge).map(l => l.id); return botPreview(o.pid, o.qty, 'manual', ids, o.minAge).ok; };
        G.orders.slice().forEach(o => { const feas = o.kind==='product' ? (pvOk(o) || ordMatch(o).ok) : ordMatch(o).ok;
          if (o.reserve && !o.accepted) { if (feas) ordAccept(o.id); else ordDismiss(o.id); }
          else if (!o.reserve && !feas && o.kind !== 'product') ordDismiss(o.id);
          else if (!o.reserve && o.kind === 'product' && !feas && o.minAge > maxStockAge()) ordDismiss(o.id); });
        const rqp = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 99, n: 0 };
        const prot = new Set(G.lots.slice().sort((x, y) => y.age - x.age).slice(0, rqp.n + 2).map(l => l.id));
        G.orders.forEach(o => {
          if (o.kind === 'product' && !ordMatch(o).ok) { const ids = lotsFor(o.pid).filter(l => !prot.has(l.id) && l.age >= o.minAge).map(l => l.id); const pv = botPreview(o.pid, o.qty, 'manual', ids, o.minAge); if (pv.ok) botStart(o.pid, o.qty, 'manual', ids, { minAge: o.minAge }); }
        });
        G.orders.slice().forEach(o => { const m = ordMatch(o);
          if (o.kind === 'cask' && m.ok) { const rq = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 99, n: 0 }; const cnt = G.lots.filter(l => l.age >= rq.age).length; const young = m.lots.filter(l => l.age < rq.age).sort((a, b) => lotValue(b) - lotValue(a))[0]; if (young) { if (ordDeliver(o.id, young.id)) act.del++; return; } if (cnt - 1 < rq.n + 2) { ordDismiss(o.id); return; } }
          if (m.ok && (!o.reserve || o.accepted)) { if(ordDeliver(o.id, m.lot ? m.lot.id : null))act.del++; } });
        // 若い樽(3年以上・倉庫の半分超過分)を瓶詰めして直販 → Tier条件用に年代を残す
        const keepAge = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 25, n: 0 };
        const sorted = G.lots.slice().sort((a, b) => a.age - b.age);
        const protect = new Set(G.lots.slice().sort((a, b) => b.age - a.age).slice(0, keepAge.n + 6).map(l => l.id));
        const spare = sorted.filter(l => l.age >= 3 && !protect.has(l.id)).slice(0, Math.max(0, G.lots.length - Math.floor(whSlots() * 0.6)));
        spare.forEach(l => { const ps = lotProducts(l).sort((a, b) => priceUnit(b, l.age, l.q, lotFlavor(l)) - priceUnit(a, l.age, l.q, lotFlavor(l))); if (ps[0] && G.bq.length < 15) { const n = Math.floor(l.L / 0.7); botStart(ps[0], n, 'manual', [l.id]); } });
        G.bottles.slice().forEach(r => { const keep = 30; if (invTotal(r.pid) > keep) spotSell(r.id, Math.min(r.n, invTotal(r.pid) - keep), true); });
        // 地域パスポート
        Object.keys(REGIONS).forEach(id => { if (!G.regions[id] && G.cash > REGIONS[id].cost * 3) purchaseRegion(id); });
        REGIONS_EX.forEach(r => { if (!G.regionsEx.includes(r.id) && G.dl >= r.unlockTier && G.cash > r.cost * 3) buyExRegion(r.id); });
        // 品評会
        COMPETITIONS.forEach(c => { const row = G.bottles.filter(r => r.n >= 6).sort((a, b) => compExpected(b) - compExpected(a))[0]; if (row && G.reputation >= c.unlockRep && G.cash > c.entryCost * 3 && !(Date.now() < (G.compCooldowns[c.id] || 0)) && compExpected(row) >= c.qualThreshold) enterComp(c.id, row.id); });
        closeM();
        if (canUpgDist()) { const t = G.dl + 1; doUpgDist(tierCost(t), t); out.push({ day: +(h / 24).toFixed(2), ev: 'Tier' + t, cash: G.cash }); }
      }
      // 時間を1時間進める
      off += H; prodTick(H); lotTick(H); botTick(H); ordAutoTick(); ordExpireTick(Date.now()); ordSpawnTick(Date.now()); tickActiveEvent(); checkChapters(); _celebQ=[]; generateDailyMissions(); tickDailyMissions(); if(G.reputation>0&&!psk('ps_rep_decay'))G.reputation=Math.max(0,G.reputation-0.05);
      if (h % 24 === 23) { daily.push({up:act.up,del:act.del,dl:G.dl}); act={up:0,del:0}; }
      if (h % 24 === 23 && ((h+1)/24)%5===0) out.push({ day: (h + 1) / 24, dl: G.dl, cash: Math.round(G.cash), te: Math.round(G.te), nm: Math.round(prodFlows().newmake), lots: G.lots.length + '/' + whSlots(), maxAge: +G.stats.maxAge.toFixed(1), shipped: G.stats.shipped, orders: G.stats.orders, rep: Math.round(G.reputation), c12: G.lots.filter(l=>l.age>=12).length, ages: G.lots.map(l=>Math.floor(l.age)).sort((a,b)=>b-a).slice(0,14).join(','), rels: CUSTOMERS.map(c=>(G.rel[c.id]||{}).lv||0).join(''), uw: G.uw.length, req: G.dl < 5 ? tierReqStatus(G.dl + 1).map(o => (o.ok ? '✓' : '✗') + o.label.slice(0, 6)).join(' ') : '' });
    }
    let gap=0,maxGap=0,prevDl=1;daily.forEach(d=>{if(d.up===0&&d.del===0&&d.dl===prevDl)gap++;else gap=0;prevDl=d.dl;maxGap=Math.max(maxGap,gap);});
    out.push({maxIdleDays:maxGap,barleyCost:Math.round(G.stats.barleyCost||0),barleyKg:Math.round(G.stats.barleyKg||0),te:Math.round(G.te),starved:!barleyOK()});
    return out;
  }, Number(process.argv[2]||90));
  log.forEach(x => console.log(JSON.stringify(x)));
  console.log('errors', errs);
  await browser.close();
})();
