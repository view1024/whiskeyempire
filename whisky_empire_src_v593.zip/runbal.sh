#!/bin/bash
# usage: runbal.sh N  -> runs N bots in parallel, prints tier days
N=${1:-10}
for i in $(seq 1 $N); do (node balance42.js 100 2>&1 | grep -o '"day":[0-9.]*,"ev":"Tier[0-9]"' | sed 's/"day":\([0-9.]*\),"ev":"\(Tier[0-9]\)"/\2=\1/' | tr '\n' ' '; node -e "" ; echo) > /tmp/claude-0/bal_$i.txt & done
wait
cat /tmp/claude-0/bal_*.txt
