exec(open('gen_ft45.py').read().replace("open('functest45.js','w').write(s)","pass"))
import os
exec(open('functest46_fix.py').read())
if os.path.exists('functest46_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest46_add.js').read()+s[a:]
open('functest46.js','w').write(s)
