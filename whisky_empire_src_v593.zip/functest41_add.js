  // ================= v4.1 追加テスト =================
  // ---------- 初回チュートリアル ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    const init = await page.evaluate(() => ({ q: G.tut.q.slice(), run: _tut && _tut.id, fill: G.auto.fill.on, spot: G.auto.spot.on, ver: G.ver }));
    rec(31, '新規開始: schema8・自動樽詰め/自動直販ON・初回案内が始まる', init.ver === 8 && init.fill && init.spot && init.run === 'first', JSON.stringify(init));
    const t0 = Date.now(); let taps = 0; let firstSaleTaps = null, firstSaleSec = null;
    for (let k = 0; k < 14; k++) {
      const info = await page.evaluate(() => _tut ? { do: !!(tutStep() && tutStep().do) } : null);
      if (!info) break;
      await page.waitForTimeout(350);
      if (info.do) {
        const box = await page.evaluate(() => { const el = tutEl(tutStep()); if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
        if (box) { await page.mouse.click(box.x, box.y); taps++; } else await page.waitForTimeout(1600);
      } else { await page.mouse.click(195, 90); taps++; }
      await page.waitForTimeout(500);
      if (firstSaleTaps === null && await page.evaluate(() => G.stats.orders >= 1)) { firstSaleTaps = taps; firstSaleSec = (Date.now() - t0) / 1000; }
    }
    const end = await page.evaluate(() => ({ done: !!G.tut.done.first, rewarded: !!G.tut.rewarded, orders: G.stats.orders, malt: facLv('malting'), coach: document.getElementById('coach').classList.contains('h'), daily: feat('daily') }));
    rec(32, '初回案内: 5タップ以内・60秒以内に最初の売上／完了で報酬・デイリー解放', firstSaleTaps !== null && firstSaleTaps <= 5 && firstSaleSec <= 60 && end.done && end.rewarded && end.malt >= 1 && end.coach && end.daily, JSON.stringify({ firstSaleTaps, firstSaleSec, end }));
    // 再読込で再表示しない・もう一度見るで再生
    await page.evaluate(() => save());
    await page.reload(); await page.waitForTimeout(1500);
    const again = await page.evaluate(() => ({ run: _tut && _tut.id, done: !!G.tut.done.first }));
    await page.evaluate(() => tutStart('first', true));
    await page.waitForTimeout(400);
    const replay = await page.evaluate(() => ({ run: _tut && _tut.id, next: getComputedStyle(document.getElementById('cNext')).visibility }));
    await page.evaluate(() => tutEnd(false));
    rec(33, '完了済みの案内は再読込で出ない・ヒント帳から再生できる（操作手順も次へで進める）', !again.run && again.done && replay.run === 'first' && replay.next === 'visible', JSON.stringify({ again, replay }));
    if (errors.length) rec('E6', 'チュートリアルテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- スキップで進行不能にならない ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    await page.click('#cBub [data-act="tutSkip"]');
    await page.waitForTimeout(300);
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, coach: document.getElementById('coach').classList.contains('h'), rewarded: !!G.tut.rewarded, next: !!document.querySelector('#nextCard [data-act]') }));
    await page.click('#nextCard [data-act]');
    await page.waitForTimeout(300);
    const r2 = await page.evaluate(() => ({ tab: document.querySelector('.tab.on').id, bq: G.bq.length, orders: G.stats.orders }));
    rec(34, 'スキップしても操作できる・「次の1手」から最初の注文を処理できる', r.done && r.coach && !r.rewarded && r.next && (r2.bq >= 1 || r2.orders >= 1), JSON.stringify({ r, r2 }));
    if (errors.length) rec('E7', 'スキップテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- ロジック（v4.1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      if (_offlineGate) closeOfflineModal(); closeM();
      // #35 コンボ廃止
      const base = cv(); const c0 = G.cash; let bad = 0;
      for (let i = 0; i < 60; i++) { const b = G.cash; tap(null); const d = G.cash - b; if (!(Math.abs(d - base) < 1e-6 || Math.abs(d - base * 100) < 1e-6)) bad++; }
      T(35, 'タップ収益は連打しても一定（×1 か クリティカル×100 のみ）', bad === 0 && typeof comboMul === 'undefined', 'bad=' + bad);
      // #36 注文の年数条件を守って詰める
      G.uw = ['glenlivid']; G.lots = []; G.bq = []; G.bottles = [];
      const l8 = makeLot(caskType('bourbon'), caskSize('hogshead')); l8.age = 8.5; l8.L = 100;
      const l11 = makeLot(caskType('bourbon'), caskSize('hogshead')); l11.age = 11.2; l11.L = 100;
      G.lots.push(l8, l11);
      const o = { id: 'o_t36', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 10, qty: 20, rq: 20, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 };
      G.orders = [o];
      const ok36 = ordFulfill('o_t36');
      const usedOld = l11.L < 100 && Math.abs(l8.L - 100) < 1e-9;
      botTick(3600000 * 5); const del = ordAutoTick();
      T(36, '「詰めて納品」は注文の年数以上の樽だけを使い、完了で自動納品', ok36 && usedOld && del === 1 && G.orders.length === 0 && G.stats.orders >= 1, JSON.stringify({ ok36, usedOld, del, left: G.orders.length }));
      // #37 自動直販は注文ボードの分を売らない
      G.orders = [{ id: 'o_t37', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 80, rq: 80, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; invAdd('glenlivid', 100, 9, 1, productSpec('glenlivid').target);
      G.auto.spot.on = true; G.auto.spot.defKeep = 50;
      autoSpotTick();
      T(37, '自動直販は注文に必要な本数を残す（残す本数50・注文80 → 80本残る）', invTotal('glenlivid') === 80, invTotal('glenlivid'));
      // #38 オフライン中に瓶詰めが終わった注文は自動納品
      G.orders = [{ id: 'o_t38', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 30, rq: 30, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; G.bq = [];
      const l9 = makeLot(caskType('bourbon'), caskSize('hogshead')); l9.age = 9; l9.L = 200; G.lots = [l9];
      ordFulfill('o_t38');
      const o0 = G.stats.orders;
      G.ls = Date.now() - 3 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      T(38, 'オフライン中に瓶詰めが終わった注文を自動納品', G.stats.orders === o0 + 1 && !G.orders.some(x => x.id === 'o_t38'), 'orders ' + o0 + '→' + G.stats.orders);
      // #39 段階的解放
      G.dl = 1; G.reputation = 0; G.stats.awardsWon = 0; G.awards = []; G.fac.distillation.p = false; G.tank = 0; G.te = 0; G.recipeOwned = ['golden_promise', 'soft_spring', 'distillery', 'unpeated'];
      const f1 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips1 = document.querySelectorAll('#sellChips .chip').length;
      switchTab('tcel'); const blend1 = document.getElementById('blendWrap').style.display;
      G.dl = 3; G.fac.distillation.p = true; G.te = 1e9; rall();
      const f2 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips2 = document.querySelectorAll('#sellChips .chip').length;
      const locks = [...document.querySelectorAll('#fl .lk, #fl .frow')].filter(e => e.textContent.includes('🔒')).length;
      T(39, '使えない機能は非表示（Tier1: 売るの切替2つ・ブレンド非表示）→ 条件達成で表示', f1.every(x => !x) && chips1 === 2 && blend1 === 'none' && f2.join() === 'true,true,true,true,true,false,true' && chips2 === 5 && locks === 0, JSON.stringify({ f1, f2, chips1, chips2, blend1 }));
      // #40 v7→v8 の移行
      const v7 = JSON.parse(JSON.stringify(G)); v7.ver = 7; delete v7.tut; delete v7.shipLog; delete v7.encSeen; v7.auto.fill.on = false; v7.auto.spot.on = false; v7.dl = 2; v7.cw = { glenlivid: 30 };
      const m = parseSave(v7);
      T(40, 'v4.0（schema7）からの移行: 自動設定は維持・更新案内3枚・解放済み機能の案内は出さない', m.ver === 8 && !m.auto.fill.on && !m.auto.spot.on && m.tut.q.join() === 'upd' && m.tut.seed && m.shipLog.glenlivid && TUTS.upd.steps.length === 3, JSON.stringify({ ver: m.ver, tut: m.tut, auto: m.auto }));
      G = m; tutCheck();
      T('40b', 'seed処理: 条件を満たしている解放案内は既読になる', G.tut.done.u_t2 && G.tut.done.u_still && !G.tut.seed, JSON.stringify(G.tut.done));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E8', 'v4.1ロジックテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- v7 セーブのバックアップ ----------
  {
    const v7 = { ver: 7, cash: 5000, te: 9000, dl: 1, uw: ['glenlivid'], lots: [], bottles: [], orders: [], auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: false, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('y')){sessionStorage.setItem('y','1');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v7))});}`;
    const { page, errors } = await newPage(browser, pre, true);
    await page.waitForTimeout(1500);
    const r = await page.evaluate(() => ({ bk: localStorage.getItem('we_v4_bak7:guest'), run: _tut && _tut.id, ver: G.ver, fill: G.auto.fill.on }));
    rec(41, 'v4.0セーブの読込: 移行前をバックアップ・更新案内が出る', !!r.bk && JSON.parse(r.bk).ver === 7 && r.run === 'upd' && r.ver === 8 && !r.fill, JSON.stringify({ bk: !!r.bk, run: r.run, ver: r.ver }));
    await page.screenshot({ path: 'shot_upd.png' });
    if (errors.length) rec('E9', 'v7読込テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 情報量 ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      const out = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te']) {
        switchTab(t); await new Promise(r => setTimeout(r, 150));
        const el = document.getElementById(t);
        const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let chars = 0, n;
        while (n = w.nextNode()) { const p = n.parentElement; if (!p || p.getClientRects().length === 0) continue; chars += n.textContent.replace(/\s/g, '').length; }
        out.push({ t, chars, screens: +(el.scrollHeight / el.clientHeight).toFixed(2) });
      }
      const chrome = ['hdr', 'nav'].map(id => document.getElementById(id).getBoundingClientRect().height).reduce((a, b) => a + b, 0);
      return { out, chrome };
    });
    const ok = r.out.every(x => x.chars <= 300 && x.screens <= 1.05) && r.chrome <= 104;
    rec(42, '開始直後: 主要5タブが各300字以下・1画面以内、常時表示が約100px', ok, JSON.stringify(r));
    if (errors.length) rec('E10', '情報量テスト中のエラー', false, errors.join(' | '));
  }
