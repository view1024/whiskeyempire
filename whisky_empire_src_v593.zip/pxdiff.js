// 2つの HTML を同じ条件で描画し、画面を画素単位で比べる（v4.6.3：最小化で見た目が変わらないことの確認）
// usage: node pxdiff.js A.html B.html [outdir]
// 時刻・乱数を固定し、アニメーションを止めてから、各タブ×テーマ×状態を撮影する。
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const { PNG } = require('pngjs');
const [A, B, OUT = 'pxdiff_out'] = process.argv.slice(2);
const STATE = fs.readFileSync('v43.js', 'utf8').match(/const STATE = (function \(mode\) \{[\s\S]*?\n\});/)[1];
fs.mkdirSync(OUT, { recursive: true });
const SEED = `(()=>{let s=12345;Math.random=()=>{s=(s*1103515245+12345)%2147483648;return s/2147483648;};})();`;
const FREEZE = '*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}';

async function shoot(browser, file, mode, theme, hour) {
  const ctx = await browser.newContext({ viewport: { width: 393, height: 760 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.clock.install({ time: new Date('2026-09-29T12:00:00+09:00') });
  await page.addInitScript(SEED);
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.clock.pauseAt(new Date('2026-09-29T12:00:01+09:00'));
  await page.goto('file://' + path.resolve(file));
  await page.clock.runFor(1500);
  await page.addStyleTag({ content: FREEZE });
  await page.evaluate(() => { titleStart(false); });
  await page.clock.runFor(300);
  if (mode !== 'fresh') await page.evaluate(`(${STATE})(${JSON.stringify(mode)})`);
  await page.evaluate(([theme, hour]) => { celebrate = () => {}; _celebQ = []; celebClose(); toast = () => {}; const tt = document.getElementById('toast'); if (tt) tt.classList.remove('on'); if (typeof _tut !== 'undefined' && _tut) { _tut = null; tutHide(); } if (_offlineGate) closeOfflineModal(); closeM(); opt().theme = theme; applyOpt(); if (hour !== undefined) { const o = sceneTime; window.sceneTime = h => o(h === undefined ? hour : h); } _vis && _vis.list && _vis.list.forEach(v => { const e = document.getElementById(v.id); if (e) e.remove(); }); }, [theme, hour]);
  const shots = {}, styles = {};
  const STY = () => { const P = ['display', 'position', 'top', 'left', 'right', 'bottom', 'width', 'height', 'margin', 'padding', 'border', 'border-radius', 'color', 'background-color', 'background-image', 'background-size', 'background-position', 'opacity', 'visibility', 'font-family', 'font-size', 'font-weight', 'line-height', 'letter-spacing', 'text-align', 'white-space', 'overflow', 'z-index', 'transform', 'filter', 'box-shadow', 'text-shadow', 'flex', 'flex-direction', 'justify-content', 'align-items', 'gap', 'grid-template-columns', 'pointer-events', 'cursor', 'content', 'backdrop-filter', 'outline', 'text-overflow', 'min-height', 'max-width'];
    const h = str => { let x = 0; for (let i = 0; i < str.length; i++) x = (x * 31 + str.charCodeAt(i)) | 0; return x; };
    return [...document.querySelectorAll('body *')].map(e => { const parts = []; for (const ps of [null, '::before', '::after']) { const cs = getComputedStyle(e, ps); if (ps && (!cs.content || cs.content === 'none')) continue; for (const p of P) { const v = cs.getPropertyValue(p); parts.push((ps || '') + p + ':' + (v.length > 80 ? 'h' + h(v) : v)); } } return e.tagName + '#' + e.id + '.' + (typeof e.className === 'string' ? e.className : '') + '|' + parts.join(';'); }); };
  const views = [['td'], ['tb'], ['tcel'], ['tsale', 'ord'], ['tsale', 'bot'], ['te', 'w'], ['te', 'r'], ['tp']];
  for (const [t, sub] of views) {
    await page.evaluate(([t, sub]) => { switchTab(t); if (t === 'tsale') { _ui.sellTab = sub; rShip(); } if (t === 'te') { _ui.encTab = sub; renc(); } document.getElementById(t).scrollTop = 0; }, [t, sub]);
    await page.clock.runFor(1000);
    shots[t + (sub ? '_' + sub : '')] = await page.screenshot(); styles[t + (sub ? '_' + sub : '')] = await page.evaluate(STY);
  }
  // 小窓（中央の読み物・決算書）
  await page.evaluate(() => { switchTab('td'); openHgModal(); }); await page.clock.runFor(1000); shots.modal_hg = await page.screenshot(); styles.modal_hg = await page.evaluate(STY);
  await page.evaluate(() => { closeM(); openTierModal(); }); await page.clock.runFor(1000); shots.modal_tier = await page.screenshot(); styles.modal_tier = await page.evaluate(STY);
  await ctx.close();
  return { shots, styles, errors };
}

(async () => {
  const browser = await chromium.launch(); const rows = []; let bad = 0;
  const propDiff = {};
  for (const [mode, hour] of [['fresh'], ['mid'], ['late'], ['mid', 22], ['mid', 7], ['mid', 17]]) for (const theme of ['dark', 'light']) {
    const a = await shoot(browser, A, mode, theme, hour), b = await shoot(browser, B, mode, theme, hour);
    console.error('done', mode, hour, theme);
    for (const k of Object.keys(a.styles)) {
      const sa = a.styles[k], sb = b.styles[k];
      if (sa.length !== sb.length) { propDiff['<element count> ' + k] = (propDiff['<element count> ' + k] || 0) + 1; continue; }
      for (let i = 0; i < sa.length; i++) if (sa[i] !== sb[i]) {
        const pa = sa[i].split(';'), pb = new Set(sb[i].split(';'));
        for (const x of pa) if (!pb.has(x)) { const key = sa[i].split('|')[0].slice(0, 60) + ' ' + x.split(':')[0]; propDiff[key] = (propDiff[key] || 0) + 1; }
      }
    }
    for (const k of Object.keys(a.shots)) {
      const pa = PNG.sync.read(a.shots[k]), pb = PNG.sync.read(b.shots[k]);
      let diff = 0;
      if (pa.width !== pb.width || pa.height !== pb.height) diff = -1;
      else for (let i = 0; i < pa.data.length; i += 4) if (Math.abs(pa.data[i] - pb.data[i]) + Math.abs(pa.data[i + 1] - pb.data[i + 1]) + Math.abs(pa.data[i + 2] - pb.data[i + 2]) > 6) diff++;
      const id = `${mode}${hour === undefined ? '' : '@' + hour}_${theme}_${k}`;
      if (diff !== 0) { bad++; fs.writeFileSync(`${OUT}/${id}_A.png`, a.shots[k]); fs.writeFileSync(`${OUT}/${id}_B.png`, b.shots[k]); }
      rows.push({ id, diff });
    }
    if (a.errors.length || b.errors.length) rows.push({ id: `${mode}_${theme}_errors`, A: a.errors, B: b.errors });
  }
  await browser.close();
  console.log(JSON.stringify(rows.filter(r => r.diff !== 0)));
  console.log('STYLE DIFFS (element prop -> count):', JSON.stringify(propDiff, null, 1));
  console.log(`${rows.filter(r => r.diff === 0).length}/${rows.filter(r => 'diff' in r).length} identical, differing=${bad}`);
})();
