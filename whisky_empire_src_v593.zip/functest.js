// 詳細設計書 第10章 テスト観点の自動確認
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve('whisky_empire.html');

async function newPage(browser, preload) {
  const ctx = await browser.newContext({ viewport: { width: 360, height: 740 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  if (preload) await page.addInitScript(preload);
  await page.goto(FILE);
  await page.waitForTimeout(1200);
  return { page, errors, ctx };
}

(async () => {
  const browser = await chromium.launch();
  const results = [];
  const rec = (id, name, ok, detail) => { results.push({ id, name, ok, detail }); };

  // ---------- 新規ゲームでの計算テスト ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: detail === undefined ? '' : String(detail) });
      const near = (a, b, eps) => Math.abs(a - b) <= (eps || 1e-6) * Math.max(1, Math.abs(b));
      if (_offlineGate) closeOfflineModal();
      closeM();
      // #1 製麦Lv1のみ
      G.fac.malting.l = 1; prodInvalidate();
      let f = prodFlows();
      T(1, '製麦Lv1のみ: newmake0・ti=300×0.9(既定の大麦)×$6=$1,620/時', f.newmake === 0 && near(ti(), 1620), 'newmake=' + f.newmake + ' ti=' + ti());
      // #2 4工程Lv3
      ['malting', 'mashing', 'fermentation', 'distillation'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 3; });
      prodInvalidate(); f = prodFlows();
      const capOk = near(f.cap[0], 388.8) && near(f.cap[1], 374.4) && near(f.cap[2], 331.2) && near(f.cap[3], 288);
      T(2, '4工程Lv3: cap・newmake・律速・余剰', capOk && near(f.newmake, 288) && f.bottleneck === 3 && near(f.s[0], 14.4) && near(f.s[1], 43.2) && near(f.s[2], 43.2), JSON.stringify({ cap: f.cap, nm: f.newmake, bn: f.bottleneck, s: f.s }));
      // #3 強化後にキャッシュ破棄
      G.cash = 1e9; const before = prodFlows().cap[3];
      upgFac('distillation');
      T(3, '強化でキャッシュ破棄・能力上昇', prodFlows().cap[3] > before && G.fac.distillation.l === 4, before + '→' + prodFlows().cap[3]);
      // #4 タンク溢れ
      G.tank = tankCap() - 1; const te0 = G.te;
      prodTick(3600000);
      T(4, 'タンク溢れ分を外販・tank=tankCap', near(G.tank, tankCap()) && G.te > te0, 'tank=' + G.tank + ' cap=' + tankCap());
      // #5 樽詰め拒否
      const n0 = G.lots.length;
      G.tank = 0; const r1 = fillCask('bourbon', 'hogshead', true);
      G.tank = 1000; const cash = G.cash; G.cash = 0; const r2 = fillCask('bourbon', 'hogshead', true); G.cash = cash;
      const slots = whSlots(); const saved = G.lots.slice();
      while (G.lots.length < slots) G.lots.push(makeLot(caskType('bourbon'), caskSize('hogshead')));
      const r3 = fillCask('bourbon', 'hogshead', true);
      G.lots = saved;
      T(5, '樽詰めの拒否（タンク不足・資金不足・満杯）', !r1 && !r2 && !r3 && G.lots.length === n0, [r1, r2, r3].join(','));
      // #6 #7 熟成
      const hog = makeLot(caskType('bourbon'), caskSize('hogshead')); lotAdvance(hog, 86400000);
      T(6, 'ホグスヘッド1日: age+1.0・L×0.984', near(hog.age, 1) && near(hog.L, 250 * 0.984), hog.age + ' ' + hog.L);
      const qc = makeLot(caskType('bourbon'), caskSize('quarter')); lotAdvance(qc, 86400000);
      T(7, 'クォーター1日: age+2.0・L×0.975', near(qc.age, 2) && near(qc.L, 50 * 0.975), qc.age + ' ' + qc.L);
      // #8 風味（シェリー樽）
      const sh = makeLot(caskType('sherry'), caskSize('hogshead')); const b0 = sh.fl0.fruity;
      sh.age = 6; const f6 = lotFlavor(sh).fruity - b0; sh.age = 12; const f12 = lotFlavor(sh).fruity - b0; sh.age = 20; const f20 = lotFlavor(sh).fruity - b0;
      T(8, 'シェリー樽の加算 6/12/20年 = 50%/100%/100%', near(f6, 10) && near(f12, 20) && near(f20, 20), [f6, f12, f20].join('/'));
      // #9 混ぜて瓶詰め
      G.uw = ['glenlivid']; G.lots = [];
      const a = makeLot(caskType('bourbon'), caskSize('hogshead')); a.age = 8.5; a.q = 1.0; a.L = 70;
      const b = makeLot(caskType('sherry'), caskSize('hogshead')); b.age = 10.2; b.q = 1.1; b.L = 70;
      G.lots.push(a, b);
      const pv = botPreview('glenlivid', 200, 'young');
      T(9, '8年+10年を混ぜる: 表記8年・品質は量で加重平均', pv.ok && pv.age === 8 && near(pv.q, 1.05, 1e-3), JSON.stringify({ ok: pv.ok, age: pv.age, q: pv.q, reason: pv.reason }));
      // #10 バーボン銘柄はシェリー樽不可
      G.uw.push('jack_d');
      const onlySherry = [b];
      G.lots = onlySherry;
      T(10, 'バーボン銘柄はシェリー樽の原酒を使えない', lotsFor('jack_d').length === 0, lotsFor('jack_d').length);
      // #11 ★3 一致度
      G.uw.push('macallen');
      const lo = makeLot(caskType('bourbon'), caskSize('hogshead')); lo.age = 20; lo.fl0 = { smoky: 100, fruity: 0, spicy: 0, sweet: 0, floral: 100 };
      G.lots = [lo];
      T(11, '★3銘柄は一致度0.5未満を除外', lotsFor('macallen').length === 0 && flavorMatch(lotFlavor(lo), productSpec('macallen').target) < 0.5, flavorMatch(lotFlavor(lo), productSpec('macallen').target).toFixed(3));
      // #12 単価
      const t = productSpec('glenlivid').target;
      // 一致度0.5になる風味: 平均差17.5
      const fl = {}; FL_KEYS.forEach(k => fl[k] = t[k]); fl.floral = t.floral - 87.5;
      const m = flavorMatch(fl, t); const u = priceUnit('glenlivid', 8, 1.0, fl);
      const expect = 100 * 8 / 3 * 1.0 * (0.7 + 0.6 * m) * distMult() * saleMult() * repMult();
      T(12, 'Glenvivid 8年・q1・一致0.5 ≈ $267', near(m, 0.5, 1e-3) && near(u, 266.67, 1e-3) && near(u, expect), 'm=' + m.toFixed(3) + ' unit=' + u.toFixed(2));
      // #13 注文の到着と上限
      G.orders = []; G.orderClock = Date.now() - 1;
      const n1 = ordSpawnTick(Date.now());
      G.orderClock = Date.now() - BALANCE.ORDER_INTERVAL_MS * 10;
      ordSpawnTick(Date.now());
      T(13, '90分ごと1件・ボード上限で停止', n1 === 1 && G.orders.length === boardSize() && G.orderClock > Date.now(), 'n1=' + n1 + ' len=' + G.orders.length + '/' + boardSize());
      // #14 在庫不足で納品拒否
      G.bottles = [];
      const o14 = { id: 'o_t14', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o14]; const c14 = G.cash;
      const d14 = ordDeliver('o_t14');
      T(14, '在庫不足の納品は拒否・状態不変', !d14 && G.orders.length === 1 && G.cash === c14, d14);
      // 正常納品
      invAdd('glenlivid', 12, 9, 1.0, t);
      const rep0 = G.reputation, sh0 = G.stats.shipped;
      const d14b = ordDeliver('o_t14');
      T('14b', '在庫十分なら納品: 資金・評判・出荷・関係', d14b && G.orders.length === 0 && G.reputation > rep0 && G.stats.shipped === sh0 + 10 && G.rel.local.done >= 1 && invTotal('glenlivid') === 2, 'rep ' + rep0 + '→' + G.reputation);
      // #15 予約の期限切れ
      const rr = G.reputation; const dn = G.rel.local.done;
      G.orders = [
        { id: 'o_r1', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: true, createdAt: 0, dueAt: Date.now() - 1 },
        { id: 'o_r2', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: false, createdAt: 0, dueAt: Date.now() - 1 },
      ];
      const ex = ordExpireTick(Date.now());
      T(15, '受注済み予約の期限切れだけ罰', ex.failed === 1 && ex.expired === 1 && G.reputation < rr && G.rel.local.done === Math.max(0, dn - 3), JSON.stringify(ex) + ' rep ' + rr + '→' + G.reputation);
      // #16 コレクター
      const y17 = makeLot(caskType('bourbon'), caskSize('hogshead')); y17.age = 17.5;
      const y19 = makeLot(caskType('bourbon'), caskSize('hogshead')); y19.age = 19;
      G.lots = [y17, y19];
      const oc = { id: 'o_c', cid: 'collector', kind: 'cask', minAge: 18, qty: 1, mult: 3, reserve: false, accepted: false, createdAt: 0, dueAt: Date.now() + 3600000 };
      const mc = ordMatch(oc);
      T(16, 'コレクター注文は18年未満の樽を選べない', mc.lots.length === 1 && mc.lots[0] === y19 && ordMatch(oc, y17.id).ok === false, mc.lots.length);
      // #17 分岐未選択
      G.fac.malting.l = 10; G.branch.malting = null; G.dl = 2;
      const pend = brPending('malting'); const lvb = G.fac.malting.l;
      upgFac('malting'); closeM();
      const blocked = G.fac.malting.l === lvb;
      brChoose('malting', 1);
      T(17, 'Lv10で分岐未選択なら強化不可・選択で能力×1.2', pend && blocked && G.branch.malting === 1 && near(stageCap(0), 300 * Math.pow(1.2, 9) * 1.2 * rcpMods().cap[0]), 'pend=' + pend + ' blocked=' + blocked);
      G.dl = 1;
      // #18 Tier条件
      G.stats.shipped = 0; G.reputation = 0; G.lots = []; G.cash = 0;
      const s0 = tierReqStatus(2).filter(o => o.ok).length;
      G.stats.shipped = 300; G.reputation = 15;
      for (let i = 0; i < 5; i++) { const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 3.2; G.lots.push(l); }
      const s1 = tierReqStatus(2).filter(o => o.ok).length; const can1 = canUpgDist();
      G.cash = tierCost(2) + 10;
      const can2 = canUpgDist();
      G.bottles = []; invAdd('glenlivid', 5, 8, 1, t);
      doUpgDist(tierCost(2), 2);
      T(18, 'Tier条件が順にok・全達成で昇格・在庫は残る', s0 === 0 && s1 === 3 && !can1 && can2 && G.dl === 2 && G.lots.length === 5 && invTotal('glenlivid') === 5, [s0, s1, can1, can2, G.dl].join(','));
      // #19 ブレンド
      G.dl = 3; G.lots = [];
      const l1 = makeLot(caskType('sherry'), caskSize('hogshead')); l1.age = 10;
      const l2 = makeLot(caskType('bourbon'), caskSize('hogshead')); l2.age = 8;
      G.lots.push(l1, l2);
      const bh0 = (G.blendHistory || []).length; const L0 = l1.L + l2.L; const bq0 = G.bq.length;
      const ok19 = blendStart('classic_blend', [{ lotId: l1.id, L: 100 }, { lotId: l2.id, L: 100 }]);
      const L1 = G.lots.reduce((a, l) => a + l.L, 0);
      chkT();
      T(19, 'ブレンドで原酒が減り履歴記録・称号「初仕込み」', ok19 && Math.abs(L0 - L1 - 200) < 1e-6 && G.blendHistory.length === bh0 + 1 && G.bq.length === bq0 + 1 && G.tl.includes('t19'), 'ok=' + ok19 + ' used=' + (L0 - L1));
      // #20 品評会（期待値）
      const row = { pid: 'glenlivid', age: 8, q: 1.05, fl: {} };
      FL_KEYS.forEach(k => row.fl[k] = t[k]); row.fl.floral = t.floral - 35; // 一致度0.8
      G.reputation = 0; G.prestige.skills = {};
      const e = compExpected(row);
      T(20, '地域品評会: 8年・q1.05・一致0.8 ⇒ 0.656点（合格0.6超）', Math.abs(e - 0.6556) < 0.001, e.toFixed(4));
      // 実出品
      G.bottles = []; invAdd('glenlivid', 10, 12, 1.2, t); G.cash = 1e7; G.compCooldowns = {};
      const res = enterComp('local_award', G.bottles[0].id);
      T('20b', '出品で6本消費・結果と講評3件・クールダウン1日', res && invTotal('glenlivid') === 4 && res.judges.length === 3 && Math.abs((G.compCooldowns.local_award - Date.now()) - 86400000) < 5000, res ? ('win=' + res.win + ' S=' + res.S.toFixed(3)) : 'null');
      closeM();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E1', '計算テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- オフライン ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const setup = () => {
        if (_offlineGate) closeOfflineModal(); closeM();
        ['malting', 'mashing', 'fermentation', 'distillation', 'maturation', 'bottling'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 5; });
        G.lots = []; G.tank = 0; G.cash = 1e7; G.auto.fill.on = false; prodInvalidate();
      };
      // #21 10時間
      setup();
      const lot = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot);
      const nm = prodFlows().newmake;
      G.ls = Date.now() - 10 * 3600000;
      offline();
      const exp21 = 10 / 24;
      T(21, '10時間不在: 熟成10時間分・生産8時間分', Math.abs(lot.age - exp21) < 1e-3 && Math.abs(G.tank - Math.min(tankCap(), nm * 8)) < 1e-3, 'age=' + lot.age.toFixed(4) + ' tank=' + G.tank.toFixed(1) + ' nm*8=' + (nm * 8).toFixed(1));
      // #22 100時間
      setup();
      const lot2 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot2);
      G.ls = Date.now() - 100 * 3600000;
      const t0 = performance.now(); offline(); const dt = performance.now() - t0;
      T(22, '100時間不在: 熟成72時間分・1秒以内', Math.abs(lot2.age - 3) < 1e-3 && dt < 1000, 'age=' + lot2.age.toFixed(4) + ' ms=' + dt.toFixed(1));
      // #23 自動樽詰め
      setup(); G.auto.fill.on = true; G.auto.fill.cask = 'bourbon'; G.auto.fill.size = 'quarter';
      G.ls = Date.now() - 4 * 3600000;
      offline();
      const ages = G.lots.map(l => l.age).sort((a, b) => b - a);
      const f = prodFlows();
      T(23, '自動樽詰め4時間: 先に詰めた樽ほど年数が大きい', G.lots.length > 1 && ages[0] > ages[ages.length - 1] && ages[0] <= 4 / 24 * 2 + 1e-9, 'lots=' + G.lots.length + ' ages=' + ages.slice(0, 3).map(a => a.toFixed(3)).join(','));
      // #24 同時発火で1回だけ
      setup();
      const lot3 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot3);
      G.ls = Date.now() - 2 * 3600000;
      offline(); offline(); window.dispatchEvent(new Event('focus')); document.dispatchEvent(new Event('visibilitychange'));
      T(24, '複数経路の同時発火でも補正1回', Math.abs(lot3.age - 2 / 24) < 1e-3, 'age=' + lot3.age.toFixed(5));
      if (_offlineGate) closeOfflineModal();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E2', 'オフラインテスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 移行 ----------
  const V6 = {
    cash: 123456789, te: 987654321, tt: 5000, dl: 3, cl: 7,
    fac: { malting: { l: 25, p: true }, mashing: { l: 22, p: true }, fermentation: { l: 20, p: true }, distillation: { l: 18, p: true }, maturation: { l: 15, p: true }, bottling: { l: 12, p: true } },
    uw: ['glenlivid', 'jameston', 'jack_d', 'johnnie_em'], cw: { glenlivid: 120, jack_d: 50 },
    am: { glenlivid: true }, inv: { glenlivid: 7, jack_d: 3 }, regions: { scotland: true }, tl: ['t1', 't9'],
    ls: Date.now() - 30 * 60000, ver: 6, dbgMul: 1,
    rawMaterials: { grain: 'optic', water: 'soft_spring', yeast: 'distillery', peat: 'unpeated' },
    casks: [{ id: 'cask_1', type: 'sherry', size: 'hogshead', whiskyId: 'glenlivid', litresFilled: 240, createdAt: Date.now() - 86400000, agingYears: 0.02, qualityMod: 1.3, sold: false },
            { id: 'cask_2', type: 'bourbon', size: 'barrel', whiskyId: 'jack_d', litresFilled: 190, createdAt: Date.now(), agingYears: 0.001, qualityMod: 0.7, sold: false }],
    channels: { active: ['dtc', 'on_trade', 'retail'], autoSellChannel: 'on_trade' },
    reputation: 42, awards: ['local_award'], compCooldowns: { local_award: Date.now() + 5 * 86400000 },
    prestige: { level: 1, bonus: 1.1, skillPoints: 1, skills: { ps_passive: 1, ps_am_slot: 1 }, legacyWhiskies: ['lw_genesis'], totalRuns: 1 },
    mg: { malting: { nextAt: 0, bonusUntil: 0, bonusMult: 1 } }, cut: {}, _cutBonus: 1, facByBrand: {}, wCd: { glenlivid: 0 },
    story: { unlocked: ['ep1'], seenNew: ['ep1'] }, daily: { date: '', missions: [], allCleared: false }, questDone: ['q_tap10']
  };
  {
    const pre = `localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(V6))});`;
    const { page, errors } = await newPage(browser, `if(!sessionStorage.getItem('x')){sessionStorage.setItem('x','1');${pre}}`);
    await page.waitForTimeout(600);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const bk = localStorage.getItem('we_v4_bak6:guest');
      const mig = G.lots.filter(l => l.src === 'migrated');
      const sherry = mig.find(l => l.cask === 'sherry');
      const ok = G.ver === 7 && G.dl === 3 && G.cash >= 123456789 && G.fac.malting.l === 25 && G.fac.malting.p
        && mig.length === 2 && sherry && Math.abs(sherry.L - 240) < 1 && sherry.q === 1.3 && mig.find(l => l.cask === 'bourbon').q === 0.8
        && invTotal('glenlivid') === 7 && invTotal('jack_d') === 3 && G.bottles.find(b => b.pid === 'glenlivid').age === 8
        && G.rel.local.lv === 1 && G.rel.bar.lv === 1 && G.rel.retail.lv === 1 && G.rel.dutyfree.lv === 0
        && G.recipe.grain === 'optic' && G.recipeOwned.includes('optic')
        && G.prestige.skills.ps_capacity === 1 && G.prestige.skills.ps_order_slot === 1 && !G.prestige.skills.ps_passive
        && G.compCooldowns.local_award <= Date.now() + 86400000 + 1000
        && G.stats.shipped === 170 && G.stats.awardsWon === 1
        && G.lots.filter(l => l.src === 'starter').length === 3 && G.orders.length >= 1
        && !('mg' in G) && !('casks' in G) && !('inv' in G) && !('channels' in G) && !('am' in G) && !('_cutBonus' in G)
        && !!bk && JSON.parse(bk).ver === 6 && G.tl.includes('t9') && G.migratedFrom === 6;
      T(25, 'v3.8.0セーブの移行（樽・在庫・チャネル・レシピ・スキル・待ち時間・バックアップ）', ok, JSON.stringify({ ver: G.ver, lots: G.lots.map(l => l.src + ':' + l.cask + ':' + l.L.toFixed(0) + ':' + l.q), inv: G.bottles.map(b => b.pid + ':' + b.n + ':' + b.age), rel: G.rel, rc: G.recipe.grain, sk: G.prestige.skills, st: G.stats, bk: !!bk }));
      const modalShown = !$('mo').classList.contains('h') && /生まれ変わり|おかえり/.test($('mc2').textContent);
      T('25b', '移行結果（またはおかえり）モーダルが出る', modalShown, $('mc2').textContent.slice(0, 30));
      // #26 再読込で不変
      save();
      const snap = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      load();
      const snap2 = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      postLoadInit();
      T(26, '移行済みデータの再読込で変化なし（初期在庫も重複しない）', snap === snap2 && G.lots.filter(l => l.src === 'starter').length === 3, snap === snap2);
      // #27 壊れたインポート
      const before = JSON.stringify(G.stats);
      importSave(); $('ioText').value = '@@@broken@@@'; ioApplyAction();
      const ok27a = JSON.stringify(G.stats) === before;
      importSave(); $('ioText').value = btoa(unescape(encodeURIComponent(JSON.stringify({ ver: 99 })))); ioApplyAction();
      const ok27b = JSON.stringify(G.stats) === before && G.ver === 7;
      closeM();
      T(27, '壊れた・新しすぎるセーブのインポートは拒否', ok27a && ok27b, ok27a + ',' + ok27b);
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    await page.screenshot({ path: 'shot_migrate.png' });
    if (errors.length) rec('E3', '移行テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 削除確認・画面 ----------
  {
    const fs = require('fs');
    const src = fs.readFileSync('whisky_empire.html', 'utf8');
    const leftovers = ['G.mg', 'craft(', 'autoSellTick', 'channelMult', 'openMiniGame', 'mgModal'].filter(w => src.includes(w));
    rec(28, '削除対象の文字列がコードに残っていない', leftovers.length === 0, leftovers.join(','));
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      if (_offlineGate) closeOfflineModal(); closeM();
      const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 150));
        const el = document.getElementById(t);
        res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth });
      }
      const navWrap = [...document.querySelectorAll('#nav .nb')].some(b => b.getBoundingClientRect().height > 70);
      return { res, navWrap };
    });
    const bad = r.res.filter(x => x.over > 1 || x.doc > 1);
    rec(29, '幅360pxで横スクロールなし・ナビが折り返さない', bad.length === 0 && !r.navWrap, JSON.stringify(r));
    if (errors.length) rec('E4', '画面テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 実プレイの通し（UI操作） ----------
  {
    const { page, errors } = await newPage(browser);
    await page.evaluate(() => { if (_offlineGate) closeOfflineModal(); closeM(); });
    // 1. 熟成タブで瓶詰め（初期在庫のシェリー8年 → Glenvivid）
    await page.click('#nav .nb[data-tab="tcel"]');
    await page.click('[data-act="botOpen"]');
    await page.waitForTimeout(200);
    const pv = await page.evaluate(() => ({ pid: _ui.bot.pid, n: _ui.bot.n, need: G.orders.filter(o=>o.pid==='glenlivid').reduce((a,o)=>a+o.qty,0), pv: $('botPv').textContent }));
    await page.click('#botGoBtn');
    await page.evaluate(() => { botTick(3600000 * (Math.ceil(botQueueBottles() / botRate()) + 1)); }); // 完了まで進める
    const inv = await page.evaluate(() => invTotal('glenlivid'));
    // 2. 出荷タブで納品
    await page.click('#nav .nb[data-tab="tsale"]');
    await page.waitForTimeout(200);
    const canDeliver = await page.$$eval('[data-act="ordOpen"]:not([disabled])', b => b.length);
    let delivered = false;
    if (canDeliver) {
      await page.click('[data-act="ordOpen"]:not([disabled])');
      await page.waitForTimeout(150);
      await page.click('#mo [data-act="ordGo"]');
      delivered = await page.evaluate(() => G.stats.orders >= 1 && G.cash > 0);
    }
    rec(30, 'UI操作の通し: 瓶詰め→在庫→納品', pv.pid === 'glenlivid' && pv.n === pv.need && inv >= pv.n && delivered, JSON.stringify({ pv, inv, canDeliver, delivered }));
    await page.screenshot({ path: 'shot_after_deliver.png' });
    // 3. 製造タブで購入・強化（UI）
    await page.evaluate(() => { G.cash = 1e6; rall(); });
    await page.click('#nav .nb[data-tab="tb"]');
    await page.click('#fl button[data-act="upg"][data-id="malting"]');
    await page.click('#mo [data-act="upgFac"]');
    const mlv = await page.evaluate(() => G.fac.malting.l);
    rec('30b', 'UI操作: 施設強化モーダルから強化', mlv === 1, mlv);
    await page.screenshot({ path: 'shot_make2.png', fullPage: false });
    if (errors.length) rec('E5', '通しテスト中のエラー', false, errors.join(' | '));
  }

  await browser.close();
  let pass = 0;
  results.forEach(x => { if (x.ok) pass++; console.log((x.ok ? 'PASS' : 'FAIL') + ' #' + x.id + ' ' + x.name + (x.ok ? '' : '  → ' + x.detail)); });
  console.log(`\n${pass}/${results.length} passed`);
  require('fs').writeFileSync('test_results.json', JSON.stringify(results, null, 1));
})();
