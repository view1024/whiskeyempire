// ============================================================
// v4.9 職人の演出：倉庫の景色・タップの反応と差し入れ・日誌の職人の出来事（タイムラプスは v4.9.1 で廃止）
//  - 演出は結果に影響しない（差し入れは v5.4 で廃止）
// ============================================================
const V49={SCENE_CASKS:4,SCENE_WORKERS:3,CARE_XP:2};
const WOOD=['#c69a62','#b98a55','#ab7b49','#9c6c3f','#8d5e36','#7f512e','#704527','#623a21','#55301b','#4a2815'];
const OWNER={id:'owner',nm:'あなた',seed:7,tr:'proud',lv:0}; // 配置先は G.ownerAt（v5.0）

// ---------- 倉庫の景色（v5.0 熟成庫の棚：全部の樽を1段6樽で並べ、上の通路に待機の人が出る） ----------
const SH={W:360,CW:60,RH:62,AISLE:52,SC:2};
let _scene={anims:[],sig:'',tap:0};
// 目標に近い樽（職人の台詞に使う）
function sceneCasks(){
  return G.lots.filter(l=>lotGoalEta(l)>0).sort((a,b)=>lotGoalEta(a)-lotGoalEta(b)).slice(0,V49.SCENE_CASKS);
}
function shelfLots(){return G.lots.slice().sort((a,b)=>b.age-a.age);}
// 通路に出る人：配置されていない「あなた」と待機の職人
function shelfAisle(){return (G.ownerAt?[]:[OWNER]).concat(staffList().filter(s=>!s.at));}
// 倉庫に出ている人：樽の担当＋通路
function sceneWorkers(){
  const onLot=[OWNER].concat(staffList()).filter(w=>{const a=placeOf(w);return a&&a.k==='lot';});
  return onLot.concat(shelfAisle());
}
// 動作（v5.0 配置先で決める）：夜は見回り。樽はテイスティングか叩いて点検、製麦室は掃除、糖化槽はかき混ぜ、
// 発酵槽は記録、蒸留器は点検、ボトリングは瓶運び。待機は掃除。研修中は本を読む
function workerAct(w,night){
  if(w!==OWNER&&staffTraining(w))return 'read';
  if(night)return 'lamp';
  const k=placeKind(w);
  if(k==='lot')return ((w.seed||1)%2)?'taste':'knock';
  return {malting:'sweep',mashing:'stir',fermentation:'read',distillation:'knock',bottling:'carry'}[k]||(w===OWNER?'taste':'sweep');
}
// workerSvg・pxCaskGrid は n21_px.js（ドット絵）。棚では1ドット＝2単位で描く
// 絵の文字列は作り置きする（樽84・人17でも描き直しを軽くするため）
const _pxCache=new Map();
function pxCached(k,f){let v=_pxCache.get(k);if(v===undefined){if(_pxCache.size>800)_pxCache.clear();v=f();_pxCache.set(k,v);}return v;}
function pxCaskAt(x,base,l,sc){
  const st=lotAgeStep(l);
  const inner=pxCached('c|'+l.size+'|'+st+'|'+l.cask+'|'+sc,()=>{const d=PX_CASK_DIM[l.size]||PX_CASK_DIM.hogshead,n=WOOD[st],g=pxCaskGrid(d[0],d[1]);
    return pxSvg(g,{w:n,v:pxMix(n,'#000000',.22),M:st>=6?'#8a4a2a':'#6a6a6a',T:PX_CT[l.cask]||'#6a6a6a'},Math.round(-sc/2*d[0]),Math.round(-sc*d[1]),sc);});
  return `<g transform="translate(${x} ${base})">${inner}</g>`;
}
// 人のドット絵を拡大率 sc で置く（x,y は足元）。o.hit：押せる（通路の人）、o.walk=false：歩かない、o.flip：左向き
function pxWorkerAt(w,x,y,act,sc,o){
  o=o||{};
  const inner=pxCached('w|'+w.id+'|'+(w.seed||0)+'|'+act,()=>workerSvg(w,20,60,act).replace(' data-act="wkTap"','').replace(/ role="button" aria-label="[^"]*"/,'').replace('class="wk" data-sid="'+w.id+'"','class="wkx"').replace('<rect x="-8" y="-8" width="56" height="70" fill="transparent"/>',''));
  const k=sc/3,tf=`translate(${x} ${y}) scale(${o.flip?-k:k} ${k}) translate(-20 -60)`;
  const hit=o.hit?`<rect x="${x-26}" y="${y-54}" width="52" height="56" fill="transparent"/>`:'';
  return `<g class="wk${o.hit?'':' wkn'}" data-sid="${w.id}" data-pose="${act}"${o.walk===false?' data-walk="0"':''}${o.hit?` data-act="wkTap" role="button" aria-label="${escapeHtml(wName(w))}"`:''}>${hit}<g transform="${tf}">${inner}</g></g>`;
}
function fmtShort(ms){if(!(ms>0))return '';const m=Math.ceil(ms/60000);if(m>=1440)return Math.floor(m/1440)+'日';if(m>=60)return Math.floor(m/60)+'時間';return m+'分';}
// v5.0.1 札は経過年数。節目に届いてから12時間は金の札で節目の年数（「8年」）
function shelfLabel(l){return lotDoneRecent(l)?l.gd+'年':fmtAge(l.age);}
function shelfLblCls(l){return lotDoneRecent(l)?' dn':l.age<V51.SELL_AGE?' yg':'';}
function sceneHtml(){
  const lots=shelfLots();const n=lots.length;const slots=whSlots();
  if(!n&&!slots)return '';
  const night=sceneTime()==='night';
  const empty=Math.max(0,slots-n),rem=n%6,showE=Math.min(empty,rem?6-rem:6),more=empty-showE;
  const rows=Math.max(1,Math.ceil((n+showE)/6));
  const aisle=shelfAisle();const AH=aisle.length?SH.AISLE:0;const H=AH+rows*SH.RH;
  const pct=v=>(v*100).toFixed(2)+'%';
  let svg=`<svg class="wsv" viewBox="0 0 ${SH.W} ${H}" shape-rendering="crispEdges">`;
  let lbl='';
  // 通路
  if(AH){
    svg+=`<rect x="0" y="${AH-6}" width="${SH.W}" height="6" fill="rgba(0,0,0,.35)"/><rect x="0" y="${AH-6}" width="${SH.W}" height="1" fill="rgba(255,220,160,.16)"/>`;
    aisle.forEach((w,i)=>{const x=Math.round((i+1)*SH.W/(aisle.length+1));svg+=pxWorkerAt(w,x,AH-6,workerAct(w,night),SH.SC,{hit:true});});
  }
  // 棚板
  for(let r=0;r<rows;r++){const y0=AH+r*SH.RH;svg+=`<rect x="0" y="${y0+SH.RH-8}" width="${SH.W}" height="6" fill="#5a3d24"/><rect x="0" y="${y0+SH.RH-8}" width="${SH.W}" height="1" fill="#8a6440"/><rect x="0" y="${y0+SH.RH-2}" width="${SH.W}" height="2" fill="rgba(0,0,0,.35)"/>`;}
  const hl=_hl?new Set(_hl.ids):null; // v5.5.1 注文に使える樽の🧾の印はやめた（樽を押すと吹き出しの先頭に出る）
  lots.forEach((l,i)=>{
    const x0=(i%6)*SH.CW,y0=AH+Math.floor(i/6)*SH.RH,base=y0+SH.RH-8;
    const w=placeWho('lot',l.id);const p=Math.max(0,Math.min(1,lotPct(l)/100));
    svg+=`<g class="wcask${lotDoneRecent(l)?' wdone':''}${hl&&hl.has(l.id)?' whl':''}" data-act="wkCask" data-id="${l.id}" data-lot="${l.id}" role="button" aria-label="${escapeHtml(lotShort(l)+' '+fmtAge(l.age)+(l.goal>0?' '+l.goal+'年まで'+fmtRemain(lotGoalEta(l)):'')+(w?' 担当'+wName(w):''))}">
      <rect x="${x0}" y="${y0}" width="${SH.CW}" height="${SH.RH}" fill="transparent"/>
      <rect class="wglow" x="${x0+2}" y="${y0+2}" width="${SH.CW-4}" height="${SH.RH-10}" fill="none" stroke="#e8b94a" stroke-width="2"/>
      <rect x="${x0+4}" y="${y0+19}" width="36" height="3" fill="rgba(0,0,0,.55)"/><rect x="${x0+4}" y="${y0+19}" width="${Math.round(36*p)}" height="3" fill="#d8a03a" data-lgg="${l.id}"/>
      ${pxCaskAt(x0+20,base,l,SH.SC)}${w?pxWorkerAt(w,x0+44,base,workerAct(w,night),SH.SC,{walk:false}):''}
      <path class="pmk" d="M${x0+24} ${y0+26}h12l-6 6z" fill="#ffd66b"/></g>`;
    lbl+=`<span class="wsl${shelfLblCls(l)}" style="left:${pct((x0+22)/SH.W)};top:${pct((y0+1)/H)}">${l.name?'★':''}<b data-wse="${l.id}">${shelfLabel(l)}</b></span>`;
  });
  for(let j=0;j<showE;j++){const i=n+j,x0=(i%6)*SH.CW,y0=AH+Math.floor(i/6)*SH.RH;
    svg+=`<rect x="${x0+8}" y="${y0+SH.RH-32}" width="${SH.CW-16}" height="22" fill="none" stroke="rgba(255,235,200,.28)" stroke-dasharray="3 3"/>`;
    lbl+=`<span class="wsl e" style="left:${pct((x0+SH.CW/2)/SH.W)};top:${pct((y0+SH.RH-30)/H)}">空き</span>`;}
  svg+='</svg>';
  return `<div class="wscene${night?' night':''}" id="wScene"><div class="wscr" id="wScroll"><div class="wshelf" id="wShelf">${svg}${lbl}<div class="wbub h" id="wBub"></div></div>${more>0?`<div class="wmore"><span>空き あと${more}樽</span></div>`:''}</div></div>`;
}
function sceneSig(){return [_hl?_hl.oid+_hl.ids.length:'',ordSig(),G.lots.length,whSlots(),shelfLots().map(l=>l.id+':'+lotAgeStep(l)+':'+l.size+':'+(l.name?1:0)+(lotDoneRecent(l)?'d':'')).join(','),sceneWorkers().map(w=>w.id+':'+placeKey(placeOf(w))+':'+(w!==OWNER&&staffTraining(w))).join(','),sceneTime()==='night',lowMotion()].join('|');}
function sceneMount(){
  sceneStop();
  const box=$('whScene');if(!box)return;
  setHtml(box,sceneHtml());_scene.sig=sceneSig();
  sceneStart();
}
function sceneStop(){_scene.anims.forEach(a=>{try{a.cancel();}catch(e){}});_scene.anims=[];}
// sceneStart・pxAnimateIn は n21_px.js
// 動きは、そのタブを開いている間だけ（設備の行は造る、瓶詰めは売る、棚は寝かせる）
function scenePlay(){
  const cur=document.hidden?'':curTabId();
  const f=a=>{const on=(a._tab||'tcel')===cur;try{if(on&&a.playState==='paused')a.play();else if(!on&&a.playState==='running')a.pause();}catch(e){}};
  _scene.anims.forEach(f);if(typeof _pxs!=='undefined')_pxs.forEach(e=>e.anims.forEach(f));
}
function sceneLight(){
  const root=$('wScene');if(!root)return;
  if(_scene.sig!==sceneSig()){sceneMount();return;}
  root.querySelectorAll('[data-wse]').forEach(el=>{const l=G.lots.find(x=>x.id===el.dataset.wse);if(l){const t=shelfLabel(l);if(el.textContent!==t)el.textContent=t;const p=el.parentNode,c='wsl'+shelfLblCls(l)+(p.classList.contains('e')?' e':'');if(p.className!==c)p.className=c;}});
  root.querySelectorAll('[data-lgg]').forEach(el=>{const l=G.lots.find(x=>x.id===el.dataset.lgg);if(l)el.setAttribute('width',Math.round(36*Math.max(0,Math.min(1,lotPct(l)/100))));});
  scenePlay();
}

// ---------- タップの反応と差し入れ ----------
const WK_POST_LINES={
  lot:['この樽は、あと{eta}で{goal}年になります。','香りが少し丸くなってきました。いい育ち方です。','栓のまわりに、甘い香りが出てきました。'],
  malting:['今年の大麦は粒がそろっています。','麦を返して、芽の伸びをそろえています。'],
  mashing:['お湯の温度、ぴったりです。','麦汁が甘くなってきました。'],
  fermentation:['泡の具合を記録しています。','酵母がよく働いています。'],
  distillation:['蒸留器の火加減、今日もいい感じです。','銅の釜が、よく歌っています。'],
  bottling:['ラベル、まっすぐ貼れました。','木箱に藁を詰めて、割れないようにしています。'],
  none:['配置先をください。何でもやります。']
};
const WK_TRAIT_LINES={calm:'……（静かにうなずいた）',cheer:'今日もいい日になりそうですね！',neat:'倉庫の床、少しだけ磨いておきました。',curious:'この樽、どんな味になるんでしょうね。',proud:'熟成は急がせない。それが決まりです。',dream:'いつか、この蒸留所の酒が世界一になりますように。'};
const OWNER_LINES=['樽の声に耳をすませる。','ゆっくりでいい。時間が酒を育てる。','次に節目を迎えるのは、あの樽だ。'];
function wkLine(w){
  _scene.tap++;
  const l=sceneCasks()[0];const fill=t=>t.replace('{eta}',l?fmtRemain(lotGoalEta(l)):'少し').replace('{goal}',l?l.goal:'次の節目');
  if(w===OWNER)return fill(OWNER_LINES[_scene.tap%OWNER_LINES.length]);
  if(staffTraining(w))return '研修中です。戻ったら、もっと上手くやります。';
  const L=WK_POST_LINES[placeKind(w)]||WK_POST_LINES.none;
  return _scene.tap%3===2?(WK_TRAIT_LINES[w.tr]||L[0]):fill(L[_scene.tap%L.length]);
}
// 吹き出しを、押したものの上（入らなければ下）に出す
function bubShow(html,el){
  const bub=$('wBub'),sh=$('wShelf');if(!bub||!sh)return;
  bub.innerHTML=html;bub.classList.remove('h');
  const r=sh.getBoundingClientRect(),g=el.getBoundingClientRect();
  const bw=bub.offsetWidth||200;bub.style.left=Math.max(4,Math.min(r.width-bw-4,g.left-r.left+g.width/2-bw/2))+'px';
  // v5.0.1 画面の下半分の樽は上に、上半分の樽は下に出す（タブ全体でスクロールするため）
  // 入りきる側に出す。両方入らなければ広い側（画面の下半分の樽は上が広い）
  const hgt=bub.offsetHeight,vh=window.innerHeight||640;
  const hd=document.querySelector('.tab.on>.thead'),nv=$('nav');
  const top0=hd?hd.getBoundingClientRect().bottom:0,bot0=nv?nv.getBoundingClientRect().top:vh;
  const up=g.top-top0,dn=bot0-g.bottom;
  const above=up>=hgt?(dn<hgt||g.top+g.height/2>vh/2):up>dn;
  // 見出しとタブの間に収める（収まらないときは樽に重ねる）
  let vt=above?g.top-hgt+8:g.bottom-6;if(hgt<=bot0-top0-8)vt=Math.max(top0+4,Math.min(bot0-hgt-4,vt));
  bub.style.top=(vt-r.top)+'px';
  try{bub.scrollIntoView({block:'nearest'});}catch(e){}
}
function wkBtns(w){
  return `<div class="wbb"><button type="button" class="sb2" data-act="pmStart" data-sid="${w.id}">移動</button></div>`;
}
function wkHead(w){const at=placeOf(w);return `<b>${escapeHtml(wName(w))}</b> <span class="sm">${w!==OWNER?'Lv'+w.lv+' ・ ':''}${escapeHtml(placeName(at))}${at?' '+placeMultTxt(placeMult(w,at)):''}${w!==OWNER&&placeIdleWhy(w)?' ・ '+placeIdleWhy(w):''}</span>`;}
function wkTap(sid,el){
  const w=placeById(sid);if(!w)return;
  if(_pm){if(_pm.sid!==w.id)pmStart(w);return;}
  bubShow(`${wkHead(w)}<div>${escapeHtml(wkLine(w))}</div>${wkBtns(w)}`,el);
  if(!lowMotion()&&el.animate){try{el.querySelector('.wkb').animate([{transform:'translateY(0)'},{transform:'translateY(-4px)'},{transform:'translateY(0)'}],{duration:320,easing:'ease-out'});}catch(e){}}
}
// 棚の樽を押す：叩く音と、樽の様子・担当（配置モードの間は、そこへ配置する）
function caskKnock(id,el){
  const l=G.lots.find(x=>x.id===id);if(!l)return;
  if(_pm){pmTry({k:'lot',id});return;}
  try{_tone(140,0.06,'triangle',0.2,0);_tone(95,0.08,'sine',0.15,0.01);}catch(e){}
  const w=placeWho('lot',id);
  const info=`${fmtAge(l.age)}${lotFillAgo(l)}${l.goal>0&&lotGoalEta(l)>0?' ・ '+l.goal+'年まで あと'+fmtRemain(lotGoalEta(l)):''} ・ 残り${Math.round(lotPct(l))}%`;
  const who=w?`<div class="wbw">${wkHead(w)}<div>${escapeHtml(wkLine(w))}</div></div>`:'';
  bubShow(`<b>${escapeHtml(lotShort(l))}</b><div>${info}</div>${lotSellHtml(l)}${who}<div class="wbb"><button type="button" class="sb2 gh" data-act="lotInfo" data-id="${l.id}">詳細</button>${lotPidBtn(l)}<button type="button" class="sb2" data-act="placePickC" data-k="lot" data-id="${l.id}">${w?'担当を変える':'職人を呼ぶ'}</button>${w?`<button type="button" class="sb2 gh" data-act="pmStart" data-sid="${w.id}">移動</button>`:''}</div>`,el);
}
// 詰めてからの実際の日数（v4.7 より前の樽は記録がないので出さない）
function lotFillAgo(l){if(!(l.at>0)||l.src==='starter')return '';const ms=Date.now()-l.at;if(!(ms>=0))return '';const d=Math.floor(ms/86400000);return '（詰めてから'+(d>=1?d+'日':Math.max(1,Math.floor(ms/3600000))+'時間')+'）';}
function bubClose(){const b=$('wBub');if(b)b.classList.add('h');}

// ---------- 倉庫日誌：職人の出来事 ----------
const JNL_WORK={lot:'担当の樽の栓を確かめて回った',malting:'麦を返して芽をそろえていた',mashing:'糖化槽の温度を見張っていた',fermentation:'発酵の泡を記録していた',distillation:'蒸留器の銅を磨いていた',bottling:'出荷の木箱に藁を詰めた',none:'倉庫の掃除を手伝っていた'};
function staffJnl(s,k){
  const c=jnlCur();if(!Array.isArray(c.staff))c.staff=[];
  const t={hire:s&&s.nm+'が蒸留所に加わった',lv:s&&s.nm+'が Lv'+s.lv+' になった',train:s&&s.nm+'が研修から戻った',fire:s&&s.nm+'が蒸留所を去った',idle:s&&s.nm+'の担当の樽がなくなり、待機に戻った',care:s&&s.nm+'に差し入れをした',off:'給与が払えず、職人が休業した'}[k];
  if(!t)return;
  if(c.staff.length<5)c.staff.push(t);else c.staff[4]=t;
}
// 日誌を締めるときに、その日の職人の様子を1行足す
function jnlStaffLine(d){const L=staffList();if(!L.length)return '';const s=L[jnlHash(d+'s')%L.length];return s.nm+'は'+(JNL_WORK[placeKind(s)]||JNL_WORK.none)+'。';}

// ---------- data-act と毎秒の処理 ----------
function extAct49(act,b,id){
  switch(act){
    case 'wkTap': wkTap(b.dataset.sid,b); return true;
    case 'wkCask': caskKnock(id,b); return true;
  }
  return false;
}
document.addEventListener('click',e=>{const b=$('wBub');if(b&&!b.classList.contains('h')&&!e.target.closest('#wBub [data-act]')&&!e.target.closest('[data-act="wkTap"]')&&!e.target.closest('[data-act="wkCask"]'))b.classList.add('h');});
function v49Tick(){try{sceneLight();}catch(e){console.warn('v49Tick',e);}}
document.addEventListener('visibilitychange',()=>{try{scenePlay();}catch(e){}});

TUTS.u_scene={name:'倉庫の景色',cond:()=>tutBase()&&G.lots.length>0&&staffOn(),steps:[
  {tab:'tcel',sel:'#whScene',text:'職人を押すと話しかけられ、<b>移動</b>で配置を変えられます。'}]};
