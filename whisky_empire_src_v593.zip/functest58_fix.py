# v5.8 の変更に合わせて v5.7 までのテストを置き換える
# #145：⚙️の BGM は クラシック／ケルト／なし（環境音楽は廃止。ケルトもクラシックと同じ演奏の仕組み）
R2("opt().bgmMode = 'ambient'; applyOpt(); o.ambient = [_bgm.mode, !!_bgm.timer, !_bgmc.timer];", "opt().bgmMode = 'celtic'; applyOpt(); o.ambient = [_bgm.mode, !!_bgmc.timer, _bgmc.mode === 'celtic' && BGM_CELTIC.length === 5];")
R2("r.ambient.join() === 'ambient,true,true' && r.off)) && r.ui;", "r.ambient.join() === 'celtic,true,true' && r.off)) && r.ui;")
R2("同時に鳴る音は16まで・⚙️で環境音楽となしに切り替わる', ok, JSON.stringify(r));", "同時に鳴る音は16まで・⚙️でケルト（v5.8）となしに切り替わる', ok, JSON.stringify(r));")
# #49：名樽は愛好会が1.2倍で買い取る（v5.8 蔵出しの記録 caskLog は廃止。名前は棚の札の★と吹き出しに出る）
R2("G.lots = [n1, n2]; lotName(n1.id, 'はじまりの一樽'); trackNamed();", "G.lots = [n1, n2]; lotName(n1.id, 'はじまりの一樽');")
R2("ordDeliver('o_s', null); trackNamed();\n      T(49, '名樽：名前を付けると愛好会が1.2倍で買い取り、蔵出しで記録に残る', m.lot === n1 && Math.abs(ratio - 1.2) < 1e-6 && G.stats.named === 1 && G.stats.limited === lim0 + 1 && G.caskLog.length === 1 && G.caskLog[0].name === 'はじまりの一樽', JSON.stringify({ ratio, log: G.caskLog }));",
   "ordDeliver('o_s', null);\n      T(49, '名樽：名前を付けると愛好会が1.2倍で買い取る（v5.8 蔵出しの記録は廃止）', m.lot === n1 && Math.abs(ratio - 1.2) < 1e-6 && G.stats.named === 1 && G.stats.limited === lim0 + 1 && G.caskLog === undefined, JSON.stringify({ ratio, log: G.caskLog }));")
# #160：図鑑のアイコンは7つ（v5.8「記録」を廃止）
R2("for (const k of ['fin', 'w', 't', 'g', 'j', 'f', 's', 'r']) { document.getElementById('ei_' + k).click(); await new Promise(r => setTimeout(r, 40)); const p = document.getElementById('ep_' + k); pages[k] = !!p && p.getClientRects().length > 0 && p.textContent.trim().length > 0 && mo.classList.contains('h') && ['fin', 'w', 't', 'g', 'j', 'f', 's', 'r'].filter(",
   "for (const k of ['fin', 'w', 't', 'g', 'j', 'f', 's']) { document.getElementById('ei_' + k).click(); await new Promise(r => setTimeout(r, 40)); const p = document.getElementById('ep_' + k); pages[k] = !!p && p.getClientRects().length > 0 && p.textContent.trim().length > 0 && mo.classList.contains('h') && ['fin', 'w', 't', 'g', 'j', 'f', 's'].filter(")
R2("document.getElementById('ei_r').click(); o.r = document.getElementById('caskHist').textContent.includes('はじまりの一樽') && document.getElementById('blendHist').children.length >= 1;",
   "o.r = !document.getElementById('ei_r') && !document.getElementById('ep_r') && !document.getElementById('caskHist');")
R2("const ok = r.lbs === '決算書,銘柄,称号,創業地,日誌,設備,物語,記録' && r.rows === 1 && r.cols === 8 &&", "const ok = r.lbs === '決算書,銘柄,称号,創業地,日誌,設備,物語' && r.rows === 1 && r.cols === 7 &&")
R2("rec(160, '図鑑（v5.5.1）：入口は1行に8つのアイコン（決算書・銘柄・称号・創業地・日誌・設備・物語・記録）で、", "rec(160, '図鑑（v5.8）：入口は1行に7つのアイコン（決算書・銘柄・称号・創業地・日誌・設備・物語。「記録」は廃止）で、")
R2("創業地は気候ごとの記録・記録は名樽とブレンド・種類の絞り込みは折り返す', ok,", "創業地は気候ごとの記録・種類の絞り込みは折り返す', ok,")
