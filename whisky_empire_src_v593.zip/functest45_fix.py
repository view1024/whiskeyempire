# v4.5 の変更に合わせて v4.4 までのテストを置き換える
for a,b in [("G.ver === 10 && G.dl === 3","G.ver === 11 && G.dl === 3"),("G.stats) === before && G.ver === 10;","G.stats) === before && G.ver === 11;"),
            ("'新規開始: schema10・","'新規開始: schema11・"),("init.ver === 10","init.ver === 11"),("m.ver === 10 &&","m.ver === 11 &&"),
            ("r.ver === 10 && !r.fill","r.ver === 11 && !r.fill"),("r.ver === 10 && r.se","r.ver === 11 && r.se"),
            ("schema10へ移行（サイロ満タン・色ダーク）', ","schema11へ移行（サイロ満タン・色ダーク）', "),("r.mig.ver === 10 &&","r.mig.ver === 11 &&")]:
    assert a in s, a
    s=s.replace(a,b)
R2("      const base = cv(); const c0 = G.cash; let bad = 0;","      const base = tapValue(); const c0 = G.cash; let bad = 0;")
R2("      const base = cv(); const c0 = G.cash; for (let i = 0; i < 1000; i++) tap(null);","      const base = tapValue(); const c0 = G.cash; for (let i = 0; i < 1000; i++) tap(null);")
R2("rec(72, 'タップ：クリティカル廃止（1,000回で常に基本額×回数）・基本額は1.5倍'","rec(72, 'タップ：クリティカル廃止（1,000回で常に1回の額×回数）・基本額は1.5倍'")
# #63 アイコン列：お知らせ → 決算書
R2("switchTab('td'); pushNews('テスト1'); pushNews('テスト2'); rdistLight();","switchTab('td'); G.hs.fin = -1; acctEnsure(); if (!G.acct.hist.length) { const now = Date.now(); _acctClock = () => now + 40 * 864e5; acctEnsure(); _acctClock = () => Date.now(); } G.hs.fin = null; rdistLight();")
R2("'tier=' + tok + '/' + ts.length, 'news=' + _newsUnread];","'tier=' + tok + '/' + ts.length, 'fin=新'];")
R2("['tier', '昇格の条件'], ['news', 'お知らせ']]","['tier', '昇格の条件'], ['fin', '決算書']]")
R2("const newsAfter = document.querySelector('#hi_news .hib') ? document.querySelector('#hi_news .hib').textContent : '';","const newsAfter = document.querySelector('#hi_fin .hib') ? document.querySelector('#hi_fin .hib').textContent : '';")
R2("rec(63, 'ホーム：章・デイリー・市場・Tier・お知らせはアイコン＋バッジ","rec(63, 'ホーム：章・デイリー・市場・Tier・決算書はアイコン＋バッジ")
# #66 最初の来客の説明はトースト要素で確認
R2("const r0 = Math.random; Math.random = () => 0.5; visitorTick(); Math.random = r0;","window._tl = []; const _t0 = toast; toast = function (m, d) { _tl.push(m); return _t0(m, d); }; const r0 = Math.random; Math.random = () => 0.5; visitorTick(); Math.random = r0;")
R2("const toastTxt = _news.map(n => n.t).join('|');","const toastTxt = _tl.join('|');")
# #60b 倉庫は枠の中の格子がスクロール
R2("const w = document.getElementById('whSummary'); w.scrollTop = 1e6;","const w = document.querySelector('#whSummary .whgw'); w.scrollTop = 1e6;")
R2("casks: document.querySelectorAll('#whSummary .ck').length }; });","casks: document.querySelectorAll('#whSummary .ck2:not(.em)').length }; });")
