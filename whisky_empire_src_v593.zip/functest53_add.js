  // ================= v5.3 追加テスト =================
  // ---------- #148 ハウスモルト：3年以上のどの樽も瓶詰めできる・25銘柄に詰められる樽では銘柄が先・注文・図鑑・品評会の対象外・保存して読み直しても残る ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const mk = (cask, age) => { const l = { id: uid('l'), cask, size: 'barrel', L0: 200, L: 200, age, fl0: { ...BASE_FLAVOR }, q: 1, at: Date.now() }; G.lots.push(l); return l; };
      G.uw = ['glenlivid', 'jameston', 'jack_d']; G.bq = []; G.orders = []; G.cash = 1e9;
      const sp = productSpec('house'); o.spec = [sp.name, sp.minAge, sp.casks, sp.house, Math.abs(sp.base - 100 * V53.HOUSE_RATE) < 1e-9];
      o.fm = Math.abs(priceUnit('house', 5, 1, { smoky: 99, fruity: 0, spicy: 0, sweet: 0, floral: 0 }) - priceUnit('house', 5, 1, BASE_FLAVOR)) < 1e-9;
      const L = { b39: mk('bourbon', 3.9), s5: mk('sherry', 5), b2: mk('bourbon', 2), b85: mk('bourbon', 8.5), s85: mk('sherry', 8.5) };
      o.plan = Object.fromEntries(Object.entries(L).map(([k, l]) => { const p = lotBotPlan(l); return [k, p ? p.pid : null]; }));
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 60));
      o.bub = {}; let none = 0;
      for (const [k, l] of Object.entries(L)) { const c = document.querySelector(`#wScene .wcask[data-id="${l.id}"]`); caskKnock(l.id, c); const h = $('wBub').innerHTML; if (/詰められる銘柄がありません/.test(h)) none++; o.bub[k] = [/data-r="stock"/.test(h), /ハウスモルト/.test(h), /class="wnx/.test(h)]; }
      o.none = none;
      // 瓶詰め → 在庫 → 直販（図鑑・販売数に数えない）
      const cw0 = JSON.stringify(G.cw), sl0 = Object.keys(G.shipLog || {}).length, sh0 = G.stats.shipped;
      o.route = lotRoute(L.s5.id, 'stock'); const q = G.bq.find(x => x.pid === 'house'); o.bq = !!q;
      for (let i = 0; i < 500 && G.bq.length; i++) botTick(3600000);
      const row = G.bottles.find(x => x.pid === 'house'); o.row = row ? row.n : 0;
      spotSell(row.id, 10, true); o.ship = [JSON.stringify(G.cw) === cw0, Object.keys(G.shipLog || {}).length === sl0, G.stats.shipped - sh0];
      // 品評会・注文
      row.n = Math.max(row.n, 20); openCompModal(COMPETITIONS[0].id); o.comp = !document.querySelector(`#mc2 [data-act="compGo"][data-row="${row.id}"]`); closeM();
      G.reputation = 9999; o.enter = enterComp(COMPETITIONS[0].id, row.id) === null;
      let hp = 0; for (let i = 0; i < 300; i++) { const a = ordGenerate(); if (a && (a.pid === 'house' || a.tp === 'ハウス')) hp++; } o.ord = hp;
      // 瓶詰めの小窓：ハウスモルトは最後・説明
      openBottleModal(null); const opts = [...document.querySelectorAll('#mc2 [data-in="botPid"] option')].map(x => x.value); o.botOpts = opts[opts.length - 1] === 'house';
      _ui.bot.pid = 'house'; renderBottleModal(true); o.botNote = /注文・品評会には使えません/.test($('mc2').textContent); closeM();
      // 保存して読み直す
      const st = sanitize(JSON.parse(JSON.stringify(G))); o.load = [st.bottles.some(x => x.pid === 'house'), !('house' in st.cw), !('house' in st.shipLog)];
      return o;
    });
    const ok = r.spec.join() === 'ハウスモルト,3,,true,true' && r.fm && r.plan.b39 === 'house' && r.plan.s5 === 'house' && r.plan.b2 === null && r.plan.b85 === 'jack_d' && r.plan.s85 === 'jameston'
      && r.none === 0 && r.bub.b39.join() === 'true,true,true' && r.bub.s5.join() === 'true,true,true' && r.bub.b2.join() === 'false,false,true' && r.bub.b85.join() === 'true,false,false'
      && r.route && r.bq && r.row > 200 && r.ship.join() === 'true,true,10' && r.comp && r.enter && r.ord === 0 && r.botOpts && r.botNote && r.load.join() === 'true,true,true';
    rec(148, 'ハウスモルト：3年以上のどの樽も瓶詰めできる（風味は問わない・単価は Glen Corran の8割）・25銘柄に詰められる樽では銘柄を選ぶ・「詰められる銘柄がありません」が出ない・図鑑と販売数に数えない・品評会と注文の対象外・瓶詰めの小窓では最後・保存して読み直しても残る', ok, JSON.stringify(r));
    if (errors.length) rec('E98', 'ハウスモルトのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #149 次の銘柄：年数・樽の種類・解禁の理由と時間・「n年で知らせる」で節目がその年数になる・樽の小窓にも出る ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const mk = (cask, age) => { const l = { id: uid('l'), cask, size: 'barrel', L0: 200, L: 200, age, fl0: { ...BASE_FLAVOR }, q: 1, at: Date.now() }; G.lots.push(l); return l; };
      G.uw = ['glenlivid', 'jameston', 'jack_d'];
      const b39 = mk('bourbon', 3.9), s5 = mk('sherry', 5), b2 = mk('bourbon', 2), b85 = mk('bourbon', 8.5);
      const n1 = nextBrand(b39); o.b39 = [n1.kind, n1.pid, n1.yr, Math.abs(n1.eta - lotEtaAge(b39, 4)) < 1, !n1.cask];
      const n2 = nextBrand(s5); o.s5 = [n2.kind, n2.yr, n2.pid === 'glenlivid' || n2.pid === 'jameston', n2.cask ? n2.cask.pid : null];
      const n3 = nextBrand(b2); o.b2 = [n3.kind, n3.pid, n3.yr];
      o.b85 = nextBrandHtml(b85) === '';
      G.uw = ['jack_d']; const n4 = nextBrand(s5); o.lock = [n4.kind, n4.pid]; G.uw = ['glenlivid', 'jameston', 'jack_d'];
      // 吹き出し：理由と時間・3年未満も並べる
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 60));
      const knock = l => { caskKnock(l.id, document.querySelector(`#wScene .wcask[data-id="${l.id}"]`)); return $('wBub'); };
      let b = knock(s5); o.s5txt = [/次の銘柄/.test(b.textContent), /バーボン樽の原酒だけ/.test(b.textContent), /✓ 8年で知らせます/.test(b.textContent)];
      b = knock(b2); o.b2txt = [/3年で売れます/.test(b.textContent), /Hollow Creek/.test(b.textContent)];
      b = knock(b39); const btn = b.querySelector('[data-act="lotNotify"]'); o.btn = btn ? btn.dataset.v : null; btn.click(); await new Promise(r => setTimeout(r, 40));
      o.goal = b39.goal; o.on = /✓ 4年で知らせます/.test($('wBub').textContent);
      // 4年になると節目として届く
      lotAdvance(b39, lotEtaAge(b39, 4) + 60000); o.done = [b39.gd, b39.goal];
      // 樽の小窓
      openLotModal(s5.id); o.modal = [!!document.querySelector('#mc2 .wnx'), /ハウスモルトのみ/.test($('mc2').textContent)];
      openLotModal(b2.id); o.m2 = /ハウスモルトは3年から/.test($('mc2').textContent);
      document.querySelector('#mc2 [data-act="lotNotify"]').click(); await new Promise(r => setTimeout(r, 40)); o.mgoal = [b2.goal, !$('mo').classList.contains('h'), /✓ 4年で知らせます/.test($('mc2').textContent)];
      closeM(); return o;
    });
    const ok = r.b39.join() === 'age,jack_d,4,true,true' && r.s5[0] === 'age' && r.s5[1] === 8 && r.s5[2] && r.s5[3] === 'jack_d' && r.b2.join() === 'age,jack_d,4' && r.b85 && r.lock.join() === 'lock,glenlivid'
      && r.s5txt.join() === 'true,true,true' && r.b2txt.join() === 'true,true' && r.btn === '4' && r.goal === 4 && r.on && r.done[0] === 4 && r.modal.join() === 'true,true' && r.m2 && r.mgoal.join() === '4,true,true';
    rec(149, '次の銘柄：一番早く詰められる銘柄と、あと何時間か（3.9年のバーボン樽→Hollow Creek 4年）・バーボン樽以外は「バーボン樽の原酒だけ」と理由・解禁前の銘柄は条件・節目がすでにその年数なら「✓」・3年未満も並べる・「4年で知らせる」でその年数が次の節目になり、届くと知らせる・樽の小窓にも出る', ok, JSON.stringify(r));
    if (errors.length) rec('E99', '次の銘柄のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #150 BGM：ボレロを加えた6曲・各曲が目標の長さ（±20%）・一巡約28分・同時に鳴る音は16まで・ボレロは小太鼓が最後まで続き、後半ほど大きい ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      o.order = BGM_PIECES.map(p => p.id).join();
      o.len = BGM_PIECES.map((p, i) => { const d = bgmDur(i) / 60; return [p.id, +d.toFixed(2), p.min, Math.abs(d - p.min) <= p.min * 0.2]; });
      o.total = +(BGM_PIECES.reduce((a, p, i) => a + bgmDur(i), 0) / 60).toFixed(1);
      // その時刻に鳴っている音（発音中＋余韻）の最大
      o.poly = BGM_PIECES.map((p, i) => { const N = bgmLoad(i); let mx = 0; N.forEach((n, j) => { let c = 0; for (let k = Math.max(0, j - 600); k < N.length && N[k][0] <= n[0]; k++) { const m = N[k]; if (m[0] + m[1] + BGM_TAIL[m[4]] > n[0]) c++; } if (c > mx) mx = c; }); return mx; });
      const bi = BGM_PIECES.findIndex(p => p.id === 'bolero'); const B = bgmLoad(bi); const sp = 60 / 66; const dur = bgmDur(bi);
      const sn = B.filter(n => n[4] === 5).map(n => n[0]); let gap = 0; sn.forEach((t, j) => { if (j) gap = Math.max(gap, t - sn[j - 1]); });
      o.snare = [sn.length, +(dur - sn[sn.length - 1]).toFixed(2), +(gap / sp).toFixed(2)];
      o.ins = [...new Set(B.map(n => n[4]))].sort().join('');
      o.titles = BGM_PIECES.map(p => p.t + '／' + p.c);
      // 主題の8回それぞれを音にして大きさ（RMS）を測る
      const rms = async (b0, b1) => { const s0 = b0 * sp, s1 = b1 * sp; const ctx = new OfflineAudioContext(1, Math.ceil((s1 - s0 + 1) * 8000), 8000); const save = _bgm.master; const m = ctx.createGain(); m.gain.value = 0.22; m.connect(ctx.destination); _bgm.master = m; _bgmNoise = null;
        B.filter(n => n[0] >= s0 && n[0] < s1).forEach(n => bgmPlay(ctx, n[4], n[2], n[0] - s0, n[1], n[3]));
        const buf = await ctx.startRendering(); _bgm.master = save; _bgmNoise = null; const d = buf.getChannelData(0); let ss = 0, pk = 0; for (let k = 0; k < d.length; k++) { ss += d[k] * d[k]; pk = Math.max(pk, Math.abs(d[k])); } return [Math.sqrt(ss / d.length), pk]; };
      o.rms = []; o.peak = 0; for (let k = 0; k < 8; k++) { const [v, p] = await rms(6 + 48 * k, 54 + 48 * k); o.rms.push(+v.toFixed(4)); o.peak = Math.max(o.peak, p); }
      _bgmc.i = bi; o.now = bgmNowTxt();
      return o;
    });
    const h1 = r.rms.slice(0, 4).reduce((a, b) => a + b, 0), h2 = r.rms.slice(4).reduce((a, b) => a + b, 0);
    const ok = r.order === 'bach846,joy,gym1,canon,elise,bolero' && r.len.every(x => x[3]) && r.total >= 25 && r.total <= 31 && r.poly.every(x => x <= 16)
      && r.snare[0] > 1500 && r.snare[1] < 4 && r.snare[2] <= 1.01 && r.ins === '123456' && r.rms[7] > r.rms[0] * 1.5 && h2 > h1 && r.peak < 0.9
      && r.titles.filter(t => /編曲|（2回）/.test(t)).length === 6 && /ボレロ/.test(r.now) && /ラヴェル/.test(r.now);
    rec(150, 'BGM：ボレロ（主題による編曲）を最後に加えた6曲・各曲が目標の長さ±20%（ボレロ約6.5分・ほか4〜5分）・一巡25〜31分・同時に鳴る音は16まで・ボレロは小太鼓が最後まで続き（間は1拍以内）、音色6種、後半ほど大きい・音割れしない', ok, JSON.stringify(r));
    if (errors.length) rec('E100', 'BGMのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
