  // ================= v4.4 追加テスト =================
  // ---------- #71 設定の選択表示 ----------
  {
    const { page, errors, ctx } = await page43(667);
    await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } switchTab('tp'); });
    const keys = await page.evaluate(() => [...document.querySelectorAll('#optBox [data-act="optSet"]')].map(b => b.dataset.k + '|' + b.dataset.v));
    const bad = [];
    for (const kv of keys) {
      const [k, v] = kv.split('|');
      await page.click(`#optBox [data-k="${k}"][data-v="${v}"]`); await page.waitForTimeout(120);
      const r = await page.evaluate(([k, v]) => { const b = document.querySelector(`#optBox [data-k="${k}"][data-v="${v}"]`); const sib = [...document.querySelectorAll(`#optBox [data-k="${k}"]`)].filter(x => x !== b); return { on: b.classList.contains('on') && b.getAttribute('aria-pressed') === 'true' && b.textContent.startsWith('✓'), others: sib.every(x => !x.classList.contains('on') && x.getAttribute('aria-pressed') === 'false'), bg: getComputedStyle(b).backgroundColor, bg2: sib[0] ? getComputedStyle(sib[0]).backgroundColor : '' }; }, [k, v]);
      if (!r.on || !r.others || r.bg === r.bg2) bad.push(kv + JSON.stringify(r));
    }
    await page.evaluate(() => { opt().theme = 'dark'; opt().motion = 'std'; applyOpt(); });
    rec(71, '設定：どの項目も押した直後に選択表示（塗りつぶし・✓・aria-pressed）が切り替わる', keys.length >= 14 && bad.length === 0, JSON.stringify({ n: keys.length, bad: bad.slice(0, 3) }));
    if (errors.length) rec('E30', '設定テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #72-73 クリティカル廃止・歯車・図鑑 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const base = cv(); const c0 = G.cash; for (let i = 0; i < 1000; i++) tap(null);
      const gear = document.getElementById('btnGear').textContent.trim();
      switchTab('te'); _ui.encTab = 'w'; renc();
      const cards = document.getElementById('wg').textContent;
      return { gain: G.cash - c0, expect: base * 1000, base, tapBase: BALANCE.TAP_BASE, crit: typeof BALANCE.CRIT_CHANCE, gear, glass: cards.includes('🥃'), q: cards.includes('❓'), n: document.querySelectorAll('#wg .wc').length };
    });
    rec(72, 'タップ：クリティカル廃止（1,000回で常に基本額×回数）・基本額は1.5倍', Math.abs(r.gain - r.expect) < 1e-6 && r.tapBase === 4.5 && r.crit === 'undefined', JSON.stringify(r));
    rec(73, 'ヘッダーの歯車は絵文字・図鑑のカードにグラスや色の絵文字がない', r.gear === '⚙️' && !r.glass && !r.q && r.n === 25, JSON.stringify(r));
    if (errors.length) rec('E31', '小修正テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #74 タブの印 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const bd = () => ['td', 'tb', 'tcel', 'tsale'].map(t => t + '=' + document.getElementById('bd_' + t).textContent + (document.querySelector(`#nav .nb[data-tab="${t}"]`).classList.contains('att') ? '*' : '')).join(' ');
      G.tut.q = []; updNavBadges(); const m1 = tabMarks(); const s1 = bd();
      const exp = t => { const x = m1[t]; return x.u ? '!' : x.n ? String(x.n) : ''; };
      const match = ['td', 'tb', 'tcel', 'tsale'].every(t => document.getElementById('bd_' + t).textContent === exp(t));
      // 何もできない状態：印なし
      G.orders = []; G.bq = []; G.cash = 0; G.branch.mashing = 0; G.branch.distillation = 0; G.branch.maturation = 0; G.branch.bottling = 0; G.auto.fill.on = true; G.hs.casks = CASK_TYPES.map(t => t.id).concat(CASK_SIZES.map(z => z.id)); G.lots = G.lots.slice(0, 3); prodInvalidate(); updNavBadges(); const s2 = bd();
      // 大麦切れ：造るに「!」
      barleyState().kg = 0; prodInvalidate(); updNavBadges(); const s3 = bd();
      const noSlotCount = !/tcel=\d/.test(s2);
      return { s1, match, s2, s3, noSlotCount };
    });
    rec(74, 'タブの印：件数は操作候補と一致・待つだけなら印なし（空き枠数は出さない）・大麦切れで造るに「!」', r.match && r.s2 === 'td= tb= tcel= tsale=' && /tb=!\*/.test(r.s3) && r.noSlotCount, JSON.stringify(r));
    if (errors.length) rec('E32', 'タブの印テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #75-76 大麦 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = {};
      o.start = { kg: barleyState().kg, cap: barleyCap(), auto: barleyState().auto };
      G.fac.malting.l = 1; G.cash = 100000; prodInvalidate();
      const f = prodFlows(); const pr = barleyPrice(); const c0 = G.cash, s0 = G.stats.barleyCost;
      prodTick(3600000);
      o.hour = { use: f.p[0], cost: G.stats.barleyCost - s0, expCost: f.p[0] * pr, net: G.cash - c0, expNet: f.surplusPh * getEventMult('passive') - f.p[0] * pr, kg: barleyState().kg };
      barleyState().auto = false; barleyState().kg = f.p[0] / 2; prodInvalidate(); const t0 = G.cash; prodTick(3600000);
      o.half = { gain: G.cash - t0, exp: f.surplusPh * getEventMult('passive') / 2, kg: barleyState().kg, ok: barleyOK(), p0: prodFlows().p[0] };
      barleyState().auto = true; G.cash = 1e6; barleyState().kg = barleyCap(); G.ls = Date.now() - 12 * 3600000; const s1 = G.stats.barleyCost; offline();
      o.off = { cost: G.stats.barleyCost - s1, exp: f.p[0] * BALANCE.OFFLINE_CAP_H * pr, modal: document.getElementById('mc2').textContent.includes('原料費') };
      if (_offlineGate) closeOfflineModal();
      barleyState().auto = false; barleyState().kg = 0; G.cash = 1e6; G.ls = Date.now() - 5 * 3600000; offline();
      o.stop = document.getElementById('mc2').textContent.includes('大麦が切れて止まっていた時間');
      if (_offlineGate) closeOfflineModal();
      const s = JSON.parse(JSON.stringify(G)); s.ver = 9; delete s.barley; s.opt = { fs: 'm', money: 'en', se: 0, bgm: 0, vib: true, tk: 'mid' };
      const g = parseSave(s); o.mig = { ver: g.ver, barley: g.barley, theme: g.opt.theme, motion: g.opt.motion };
      return o;
    });
    const h = r.hour;
    rec(75, '大麦：製麦した量だけ消費し原料費を払う・在庫が半分なら生産も半分・在庫切れで製麦が止まる', r.start.kg === r.start.cap && r.start.auto && Math.abs(h.cost - h.expCost) < 0.01 && Math.abs(h.net - h.expNet) < 0.01 && Math.abs(r.half.gain - r.half.exp) < 0.01 && !r.half.ok && r.half.p0 === 0, JSON.stringify(r));
    rec(76, '大麦：放置は最大8時間分を消費して報告に原料費を出す・在庫切れの停止時間を報告・schema10へ移行（サイロ満タン・色ダーク）', Math.abs(r.off.cost - r.off.exp) / r.off.exp < 0.01 && r.off.modal && r.stop && r.mig.ver === 10 && r.mig.barley.kg === null && r.mig.barley.auto === true && r.mig.theme === 'dark' && r.mig.motion === 'std', JSON.stringify(r));
    if (errors.length) rec('E33', '大麦テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #77-78 案内 ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { _mktOff = true; window._tutSw = 0; const o = switchTab; switchTab = function (id) { if (new Error().stack.includes('tutShow')) window._tutSw++; return o(id); }; });
    await page.evaluate(() => titleStart(false)); await page.waitForTimeout(1200);
    const tabs = [];
    for (let k = 0; k < 16; k++) {
      const st = await page.evaluate(() => _tut ? { i: _tut.i, tab: document.querySelector('.tab.on').id } : null);
      if (!st) break; tabs.push(st.tab);
      const box = await page.evaluate(() => { const s = tutStep(); const el = s && s.sel ? tutEl(s) : null; if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, do: !!s.do }; });
      if (box && box.do) await page.mouse.click(box.x, box.y); else await page.click('#cNext');
      await page.waitForTimeout(450);
    }
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, sw: window._tutSw, malt: facLv('malting'), orders: G.stats.orders }));
    rec(77, 'はじめての案内：案内がタブを切り替えない（ナビはプレイヤーが押す）・ホーム→売る→造るの順・最後まで進む', r.done && r.sw === 0 && r.malt >= 1 && r.orders >= 1 && tabs[0] === 'td' && tabs.includes('tsale') && tabs[tabs.length - 1] === 'tb', JSON.stringify({ r, tabs: tabs.join('>') }));
    await page.waitForTimeout(2500);
    const w = await page.evaluate(() => ({ q: G.tut.q.slice(), cel: document.getElementById('bd_tcel').textContent, run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    await page.click('#nav .nb[data-tab="tcel"]'); await page.waitForTimeout(900);
    const w2 = await page.evaluate(() => ({ run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    rec(78, '後から出る案内：別のタブにいる間はナビに「新」を付けて待ち、そのタブを開くと始まる', w.q.includes('u_age') && w.cel === '新' && w.run !== 'u_age' && w2.run === 'u_age' && w2.tab === 'tcel', JSON.stringify({ w, w2 }));
    if (errors.length) rec('E34', '案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #79 動き ----------
  {
    const { page, errors, ctx } = await page43(667, 'reduce', 'mid');
    const r = await page.evaluate(async () => {
      switchTab('tb'); await new Promise(r => setTimeout(r, 200));
      const band = document.querySelector('#lineView .pflow.run .pband'); const an = band ? getComputedStyle(band).animationName : 'none';
      const dur = band ? getComputedStyle(band).animationDuration : '';
      G.tut.q = []; updNavBadges(); const att = document.querySelector('#nav .nb.att'); const aan = att ? getComputedStyle(att, '::after').animationName : 'none';
      let conf = null; const oc = celebrate; celebrate({ icon: '🎉', title: 't', sub: '' }); await new Promise(r => setTimeout(r, 100)); conf = document.querySelectorAll('#celebrate .conf i').length; _celebQ = []; celebClose();
      return { an, dur, aan, conf, low: lowMotion() };
    });
    rec(79, '動き：「視差効果を減らす」でも生産ラインの矢印とタブの印はゆっくり動き、紙吹雪は出ない', r.an === 'pflow' && parseFloat(r.dur) >= 1 && r.aan === 'attPulse' && r.conf === 0 && r.low, JSON.stringify(r));
    if (errors.length) rec('E35', '動きテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #80 色（コントラスト）と1画面 ----------
  {
    const out = {}; let overs = [];
    for (const th of ['dark', 'light']) {
      const { page, errors, ctx } = await page43(667, null, 'mid');
      const r = await page.evaluate(async th => {
        opt().theme = th; applyOpt(); _celebQ = []; celebClose(); closeM();
        const parse = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
        const lum = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
        const bgOf = el => { let e = el; while (e) { const cs = getComputedStyle(e); if (cs.backgroundImage && cs.backgroundImage !== 'none') return null; const c = parse(cs.backgroundColor); if (c && c.a >= 0.9) return c; e = e.parentElement; } return parse(getComputedStyle(document.body).backgroundColor); };
        const low = []; let n = 0; const over = {};
        for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
          switchTab(t); await new Promise(r => setTimeout(r, 150)); _celebQ = []; celebClose();
          const el = document.getElementById(t); if (['td', 'tb', 'tcel', 'tsale'].includes(t)) over[t] = el.scrollHeight - el.clientHeight;
          const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let x;
          while (x = w.nextNode()) {
            const p = x.parentElement; if (!p || !x.textContent.trim() || p.getClientRects().length === 0 || p.closest('#stage') || p.closest('button:disabled') || p.closest('.lk') || p.closest('.ca')) continue;
            const cs = getComputedStyle(p); if (parseFloat(cs.opacity) < 1) continue;
            const fg = parse(cs.color); const bg = bgOf(p); if (!fg || !bg) continue; n++;
            const L1 = lum(fg), L2 = lum(bg); const cr = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
            if (cr < 4.5) low.push(t + ':' + cr.toFixed(2) + ':' + x.textContent.trim().slice(0, 10));
          }
        }
        return { n, low: low.slice(0, 10), nLow: low.length, over, theme: document.documentElement.dataset.theme };
      }, th);
      out[th] = r; Object.entries(r.over).forEach(([t, v]) => { if (v > 0) overs.push(th + ':' + t + '+' + v); });
      if (errors.length) rec('E36', '色テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    rec(80, '色：ダーク・ライトとも全タブの文字のコントラスト4.5以上（ライトでも4タブは1画面）', out.dark.nLow === 0 && out.light.nLow === 0 && out.light.theme === 'light' && out.dark.n > 200 && out.light.n > 200 && overs.length === 0, JSON.stringify({ dark: { n: out.dark.n, low: out.dark.low }, light: { n: out.light.n, low: out.light.low }, overs }));
  }
  // ---------- #81 樽の選択欄 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.fac.distillation.p = true; prodInvalidate(); switchTab('tcel'); rCellar();
      const picks = [...document.querySelectorAll('#fillBox .fpick')].map(b => b.textContent.replace(/\s+/g, ''));
      const newBefore = document.querySelectorAll('#fillBox .fnew').length;
      G.te = 2e7; rCellar(); updNavBadges();
      const newAfter = document.querySelectorAll('#fillBox .fpick.new').length; const mark = document.getElementById('bd_tcel').textContent;
      document.querySelector('#fillBox [data-act="fillPickT"]').click(); await new Promise(r => setTimeout(r, 50));
      const cards = document.querySelectorAll('#mc2 .ccard').length; const locked = document.querySelectorAll('#mc2 .ccard.lk').length;
      document.querySelector('#mc2 .ccard[data-id="sherry"]').click(); await new Promise(r => setTimeout(r, 50));
      rCellar(); updNavBadges();
      return { picks, newBefore, newAfter, mark, cards, locked, cask: G.auto.fill.cask, newGone: document.querySelectorAll('#fillBox .fpick.new').length, mark2: document.getElementById('bd_tcel').textContent };
    });
    rec(81, '樽詰め：「樽の種類▾」「サイズ▾」の選択欄・解禁でNEWとタブの印・カードで選べる', r.picks.length === 2 && r.picks.every(p => p.includes('▾')) && r.newBefore === 0 && r.newAfter >= 1 && r.mark !== '' && r.cards === 5 && r.locked >= 1 && r.cask === 'sherry' && r.newGone === 0, JSON.stringify(r));
    if (errors.length) rec('E37', '樽選択テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
