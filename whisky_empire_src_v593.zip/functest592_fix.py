# v5.9.2 の変更に合わせて v5.9.1 までのテストを置き換える
# #75：サイロが24時間分になり（v5.9.2）Lv1 でも上限が最低の2,400kgを超えるので、測る前に満タンにする（減った分だけ買い足すことを確かめる）
R2("      G.fac.malting.l = 1; G.cash = 100000; prodInvalidate();\n      const f = prodFlows(); const pr = barleyPrice(); const c0 = G.cash, s0 = G.stats.barleyCost;",
   "      G.fac.malting.l = 1; G.cash = 100000; prodInvalidate(); barleyState().kg = barleyCap();\n      const f = prodFlows(); const pr = barleyPrice(); const c0 = G.cash, s0 = G.stats.barleyCost;")
# #147：自動の樽詰めの「+n樽」と自動直販の「+金額」は出さない（v5.9.2）
R2("rec(147, '手触り：Lvアップで「+%」と行の光・ボトルネック解消で「新酒 +%」と流れの加速・樽詰めで棚の樽が落ちる・自動の樽詰め／瓶詰め／直販は1.5秒にまとめて1回・",
   "rec(147, '手触り：Lvアップで「+%」と行の光・ボトルネック解消で「新酒 +%」と流れの加速・樽詰めで棚の樽が落ちる・自動の樽詰めの「+n樽」と自動直販の「+金額」は出さない（v5.9.2）・瓶詰めは1.5秒にまとめて1回・")
R2("o.pill = ft().filter(t => t === '+3樽').length === 1; await clear();", "o.pill = ft().filter(t => /樽$/.test(t)).length === 0; await clear();")
R2("o.autoSale = ft().filter(t => t === '+' + fmt(v1 + v2)).length === 1; await clear();", "o.autoSale = ft().filter(t => t.startsWith('+$')).length === 0 && !document.querySelector('#hc.fxgl'); await clear();")
