# v4.6 の変更に合わせて v4.5 までのテストを置き換える
R2("switchTab('td'); G.hs.fin = -1; acctEnsure(); if (!G.acct.hist.length) { const now = Date.now(); _acctClock = () => now + 40 * 864e5; acctEnsure(); _acctClock = () => Date.now(); } G.hs.fin = null; rdistLight();","switchTab('td'); G.hg = { n: 2, got: 2, used: 0 }; rdistLight();")
R2("'tier=' + tok + '/' + ts.length, 'fin=新'];","'tier=' + tok + '/' + ts.length, 'hg=2/3'];")
R2("['tier', '昇格の条件'], ['fin', '決算書']]","['tier', '昇格の条件'], ['hg', '熟成の砂時計']]")
R2("const newsAfter = document.querySelector('#hi_fin .hib') ? document.querySelector('#hi_fin .hib').textContent : '';","const newsAfter = '';")
R2("rec(63, 'ホーム：章・デイリー・市場・Tier・決算書はアイコン＋バッジ","rec(63, 'ホーム：章・デイリー・市場・Tier・砂時計はアイコン＋バッジ")
R2("r.hi.includes('hi_fin') && !r.hi.includes('hi_news')","r.hi.includes('hi_hg') && !r.hi.includes('hi_fin') && !r.hi.includes('hi_news')")
# #90 決算書は図鑑の記録から開く（「新」の印はなし）
R2("""      G.hs.fin = null; switchTab('td'); rdistLight();
      const badge = document.querySelector('#hi_fin .hib') ? document.querySelector('#hi_fin .hib').textContent : '';
      document.getElementById('hi_fin').click(); await new Promise(r => setTimeout(r, 80));""","""      switchTab('te'); _ui.encTab = 'r'; renc(); const badge = document.querySelector('#recList .frec') ? '記録' : '';
      document.querySelector('#recList .frec').click(); await new Promise(r => setTimeout(r, 80));""")
R2("closeM(); rdistLight(); o.badgeAfter = document.querySelector('#hi_fin .hib') ? document.querySelector('#hi_fin .hib').textContent : '';","closeM(); o.badgeAfter = document.getElementById('hi_fin') ? 'x' : '';")
R2("r.badge === '新' && r.title &&","r.badge === '記録' && r.title &&")
R2("rec(90, '決算書の画面：PL・BS・CFを切り替えてボックス図（左右の合計が一致・高さが金額に比例）と数字の表・月の切替・前の月が確定すると「新」'","rec(90, '決算書の画面：図鑑の「記録」から開き、PL・BS・CFを切り替えてボックス図（左右の合計が一致・高さが金額に比例）と数字の表・月の切替'")
R2("rec(33, '完了済みの案内は再読込で出ない・ヒント帳から再生できる（操作手順も次へで進める）', !again.run && again.done","rec(33, '完了済みの案内は再読込で出ない・ヒント帳から再生できる（操作手順も次へで進める）', (!again.run || !TUTS_DONE_BEFORE.includes(again.run)) && again.done")
s=s.replace("  // ================= v4.1 追加テスト =================","  const TUTS_DONE_BEFORE = ['first', 'u_age', 'u_barley', 'u44', 'u45', 'u46', 'u_cel45', 'u_line43', 'u43'];\n  // ================= v4.1 追加テスト =================",1)
R2("G.ls = Date.now() - 12 * 3600000; const s1 = G.stats.barleyCost; offline();","G.ls = Date.now() - 30 * 3600000; const s1 = G.stats.barleyCost; offline();")
R2("rec(76, '大麦：放置は最大8時間分を消費して","rec(76, '大麦：放置は最大24時間分を消費して")
R2("const txt = el.textContent; const expect = '試飲 +' + fmt(cv() * 15);","const txt = el.textContent; const expect = '試飲 +' + fmt(cv() * 15); const tp = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); const onTop = el.contains(tp);")
R2("overlap: !(r.right <= bb.left || r.left >= bb.right || r.bottom <= bb.top || r.top >= bb.bottom),","overlap: !onTop,")
R2("rec(66, '見学のお客さん：吹き出しに「何者か」と報酬額を表示・樽の押せる範囲と重ならない・初回だけ説明が出る'","rec(66, '見学のお客さん：吹き出しに「何者か」と報酬額を表示・樽より手前に出て押せる・初回だけ説明が出る'")
R2("o.bqTxt = document.querySelector('#bqBox .bmat') ? document.querySelector('#bqBox .bmat').textContent : '';","o.bqTxt = document.querySelector('#bqBox .plv') ? document.querySelector('#bqBox .plv').textContent : '';")
s=s.replace("      // #1 製麦Lv1のみ\n","      if (G.randomEvent) G.randomEvent.active = null; // 偶発イベントの倍率を外す\n      // #1 製麦Lv1のみ\n",1)
