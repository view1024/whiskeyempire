exec(open('gen_ft52.py').read().replace("open('functest52.js','w').write(s)","pass"))
import os
exec(open('functest53_fix.py').read())
if os.path.exists('functest53_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest53_add.js').read()+s[a:]
open('functest53.js','w').write(s)
