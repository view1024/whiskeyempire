exec(open('gen_ft49.py').read().replace("open('functest49.js','w').write(s)","pass"))
import os
exec(open('functest50_fix.py').read())
if os.path.exists('functest50_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest50_add.js').read()+s[a:]
open('functest50.js','w').write(s)
