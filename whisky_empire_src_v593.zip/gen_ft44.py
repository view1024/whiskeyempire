exec(open('gen_ft43.py').read().replace("open('functest43.js','w').write(s)","pass"))
import os
if os.path.exists('functest44_fix.py'): exec(open('functest44_fix.py').read())
if os.path.exists('functest44_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest44_add.js').read()+s[a:]
open('functest44.js','w').write(s)
