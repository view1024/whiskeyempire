#!/usr/bin/env python3
"""v3.8.0 の whisky_empire.html から現行版を組み立てる。
行番号は v3.8.0 のもの（1始まり・両端含む）。

v4.6.3 から、連結後に buildtool.js で次の後処理を行う（事前に `npm install` が必要）。
  1. DEAD_FUNCS の関数を本体 <script> から除去 → whisky_empire.dev.html（読める開発版）
  2. 本体 JS を terser、本体 CSS を csso で最小化 → whisky_empire.html（配布版）
  `python3 assemble.py --no-min` なら後処理をせず、連結結果をそのまま whisky_empire.html に書く。
"""
import io, sys, base64, subprocess, os

ORIG = 'orig.html'
OUT = 'whisky_empire.html'
L = open(ORIG, encoding='utf-8').read().split('\n')

def rng(a, b):
    return '\n'.join(L[a-1:b])

def mod(name):
    return open(name, encoding='utf-8').read().rstrip('\n')

def patch(text, old, new, count=1):
    if old not in text:
        sys.exit('PATCH NOT FOUND: ' + old[:80])
    return text.replace(old, new, count)

# ---------------- HTML ----------------
import re as _re
NEW_CSS = r"""
/* ===== v4 追加 ===== */
#tcel.on{padding:12px;display:block}
.nb{font-size:10px;padding:9px 2px;gap:2px}
.nb .ic{font-size:20px}
.sc{cursor:pointer}
.card{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:10px 12px;margin-bottom:8px}
.card.hl{border-color:var(--gold)}
.card.warn{border-left:3px solid var(--amber)}
.row{display:flex;align-items:center;gap:8px}
.row.sb{justify-content:space-between}
.tt{font-family:var(--fd);font-size:14px;font-weight:700;color:var(--cream)}
.sm{font-family:var(--fm);font-size:11px;color:var(--muted);line-height:1.5}
.vv{font-family:var(--fm);font-size:13px;color:var(--gold2);font-weight:600;white-space:nowrap}
.sb2{background:var(--gb);border:none;border-radius:6px;padding:6px 10px;font-family:var(--fm);font-size:11px;font-weight:600;color:#1a1208;cursor:pointer;white-space:nowrap}
.sb2.gh{background:var(--bg3);color:var(--text2);border:1px solid var(--border)}
.sb2:disabled{background:var(--bg3);color:var(--muted);border:1px solid var(--border);cursor:default;opacity:.6}
.btn-ok:disabled{background:var(--bg3);color:var(--muted);border:1px solid var(--border)}
.bar{height:6px;background:var(--bg3);border-radius:3px;overflow:hidden;margin-top:4px}
.bar>i{display:block;height:100%;background:linear-gradient(90deg,var(--amber),var(--gold2));border-radius:3px;transition:width .4s}
.line{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:8px 0 6px}
.stg{background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:8px 4px 6px;text-align:center;position:relative;min-width:0;cursor:pointer}
.stg.bn{border-color:var(--red);box-shadow:0 0 0 1px var(--red) inset}
.stg .ic2{font-size:18px;line-height:1.2}
.stg .nm{font-family:var(--fm);font-size:10px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.stg .cp{font-family:var(--fm);font-size:11px;color:var(--gold2);font-weight:600}
.stg .sp2{font-family:var(--fm);font-size:9px;color:var(--muted)}
.stg .bnt{position:absolute;top:-7px;left:50%;transform:translateX(-50%);background:var(--red);color:#fff;font-family:var(--fm);font-size:9px;border-radius:3px;padding:0 5px}
@media(max-width:360px){.line{grid-template-columns:repeat(2,1fr);row-gap:12px}}
.chips{display:flex;gap:6px;overflow-x:auto;padding:2px 0 6px;margin-bottom:6px}
.chip{flex-shrink:0;background:var(--bg3);border:1px solid var(--border);border-radius:14px;padding:4px 10px;font-family:var(--fm);font-size:11px;color:var(--muted);cursor:pointer;white-space:nowrap}
.chip.on{background:var(--amber);border-color:var(--gold);color:#1a1208;font-weight:600}
.badge{display:inline-block;font-family:var(--fm);font-size:9px;border-radius:3px;padding:1px 5px;margin-left:4px;vertical-align:middle;font-weight:600}
.b-res{background:var(--gold);color:#1a1208}.b-str{border:1px solid var(--amber);color:var(--amber)}.b-ok{background:var(--green);color:#fff}
.halert{display:flex;gap:6px;flex-wrap:wrap;flex-shrink:0}
.halert:empty{display:none}
.ha{background:var(--bg3);border:1px solid var(--amber);border-radius:12px;padding:3px 9px;font-family:var(--fm);font-size:10px;color:var(--amber);cursor:pointer;white-space:nowrap}
select.sel{background:var(--bg3);border:1px solid var(--border);border-radius:6px;color:var(--text);font-family:var(--fm);font-size:12px;padding:7px;width:100%;min-width:0}
input[type=range]{width:100%;accent-color:var(--gold)}
.flt{position:relative}
.tc{text-align:center}
"""
SCENE_B64 = base64.b64encode(open('bg_scene.webp','rb').read()).decode()
CSS41 = open('n0_css41.css', encoding='utf-8').read() + open('n0_css42.css', encoding='utf-8').read() + open('n0_css43.css', encoding='utf-8').read() + open('n0_css44.css', encoding='utf-8').read() + open('n0_css45.css', encoding='utf-8').read() + open('n0_css46.css', encoding='utf-8').read() + open('n0_css47.css', encoding='utf-8').read() + open('n0_css48.css', encoding='utf-8').read() + open('n0_css49.css', encoding='utf-8').read() + open('n0_css50.css', encoding='utf-8').read() + open('n0_css51.css', encoding='utf-8').read() + open('n0_css52.css', encoding='utf-8').read() + open('n0_css53.css', encoding='utf-8').read() + open('n0_css54.css', encoding='utf-8').read() + open('n0_css55.css', encoding='utf-8').read() + open('n0_css56.css', encoding='utf-8').read() + open('n0_css57.css', encoding='utf-8').read() + open('n0_css59.css', encoding='utf-8').read() + '.scene{background-image:url(data:image/webp;base64,'+SCENE_B64+')}\n' + ''.join('.tabbg.bg-%s{background-image:url(data:image/webp;base64,%s)}\n'%(k,base64.b64encode(open(f,'rb').read()).decode()) for k,f in [('tb','bg_make.webp'),('tcel','bg_age.webp'),('tsale','bg_sell.webp')])
head = rng(1, 230)
head = patch(head, '.f14{font-size:14px}</style>', '.f14{font-size:14px}' + NEW_CSS + CSS41 + '</style>')
img = _re.search(r'<img id="bottleImg"[^>]*>', L[255]).group(0)
# v4.4.2 タップする画像を樽に差し替え（白い余白を除いた透過WebP）
img = '<img id="bottleImg" src="data:image/webp;base64,'+base64.b64encode(open('barrel.webp','rb').read()).decode()+'" alt="樽（タップ）" draggable="false">'
body = open('n0_body.html', encoding='utf-8').read().replace('{{BARREL_IMG}}', img)
tail = rng(399, 439)
OLD_MG = rng(418, 424)
assert 'mgModal' in OLD_MG
tail = patch(tail, OLD_MG + '\n', '')
html = head + '\n' + body + '\n' + tail

# ---------------- SCRIPT ----------------
parts = []
K = lambda a, b: parts.append(rng(a, b))
M = lambda n: parts.append(mod(n))

K(440, 496)          # <script> 'use strict' RAW_MATERIALS PEAT_LEVELS
K(502, 532)          # CASK_TYPES CASK_SIZES BLEND_TARGETS
# v5.8 販売地域・輸出市場（v5.6 で買う画面を廃止）は、保存に残る分の倍率だけを持つ（名前・説明・費用は外す）
parts.append("const REGIONS_EX=[{id:'taiwan',mult:2.2},{id:'china',mult:2.5},{id:'france',mult:2.0},{id:'india',mult:2.8},{id:'australia',mult:1.8},{id:'global',mult:3.5}];")
K(551, 557)          # COMPETITIONS
M('n1_constants.js') # BALANCE + v4 定数（558-585を置換）
consts = rng(586, 607)
for ln in ['const COMBO_WINDOW_MS=3000;\n','const COMBO_MUL_MAX=10.0;\n','const COMBO_MAX=1000;\n','const CRIT_CHANCE_100=0.005;\n','const CRIT_CHANCE_1000=0.001;\n','const CRIT_CHANCE_10000=0.0001;\n','let comboCount=0;\n','let comboLastAt=0;\n']:
    consts = patch(consts, ln, '')
consts = consts[:consts.index('const COMBO_STAGES=[')] + consts[consts.index('];', consts.index('const COMBO_STAGES=['))+3:]
consts = patch(consts, 'let comboTimer=null;', '')
parts.append(consts)
dlb = rng(609, 635)  # DL tierBonus distMult saleMult dm
# v5.6 販売地域・輸出市場の倍率がなくなった分、Tier4・Tier5 の昇格費を下げる（ボットで Tier5 の日数を v5.4 に合わせた）
dlb = patch(dlb, 'unlock:25000000,', 'unlock:20000000,')    # v5.7 製造費・熟成費・法人税で手元の現金が減る分を下げた
dlb = patch(dlb, 'unlock:160000000,', 'unlock:67000000,')   # v5.6 $96M → v5.7 $67M
dlb = patch(dlb, 'unlock:1100000000,', 'unlock:300000000,') # v5.6 $550M → v5.7 $300M
parts.append(dlb)
K(665, 669)          # cuc
K(685, 712)          # facMaxLv tapMaxLv fuc fpc isUL
M('n2_core.js')      # 713-761 を置換
aud = rng(767, 791)
aud = patch(aud, 'if(!_soundOn)return null;', 'if(!_soundOn||(!seVol()&&!bgmVol()))return null;')
aud = patch(aud, 'g.gain.setValueAtTime(vol||0.18,', 'g.gain.setValueAtTime((vol||0.18)*seVol(),')
parts.append(aud)
K(1485, 1504)        # sndTap
K(1511, 1578)        # snd* toggleSound showFT（sndCombo・コンボ演出は削除）
M('n2b_tap.js')      # v4.1 tap
fm = rng(1795, 1813)
fm = patch(fm, 'function fmt(n){', 'function fmtEn(n){')
fm = patch(fm, "if(n<0)return'-'+fmt(-n);", "if(n<0)return'-'+fmtEn(-n);")
fm = patch(fm, "if(n>=1e12)return'$'+(n/1e12).toFixed(2)+'兆';", "if(n>=1e21)return'$'+n.toExponential(2).replace('e+','e');if(n>=1e18)return'$'+(n/1e18).toFixed(2)+'Qi';if(n>=1e15)return'$'+(n/1e15).toFixed(2)+'Qa';if(n>=1e12)return'$'+(n/1e12).toFixed(2)+'T';")
parts.append(fm)
K(1819, 1821)
parts.append("const REGIONS={scotland:{mult:1.5},ireland:{mult:1.5},usa:{mult:1.75},japan:{mult:2.0}};")  # v5.8 倍率だけ（1822〜1831 を置換）
K(1832, 2047)        # FD WL TT UNLOCK_REQ FAC_UPG G $ escapeHtml
M('n3_state.js')     # defState sanitize migrateV7 load
K(2188, 2192)        # storageKey
save_block = rng(2232, 2275)
save_block = patch(save_block, 'function save(){', 'function save(){\n  if(_noSave)return;')
parts.append(save_block)
misc = rng(2376, 2476)
misc = patch(misc, '<span>・ 同時製造 ${d.slots}銘柄</span>', '<span>・ 注文枠 ${3+i}件</span>')
parts.append(misc)
M('n4a_daily.js')
K(2506, 2506)
M('n4b_events.js')
story = rng(2523, 2580)
story = patch(story, 'unlock:g=>(g.casks&&g.casks.length>=1),', 'unlock:g=>((g.stats&&g.stats.filled)||0)>=1,')
parts.append(story)
M('n4c_skills.js')
lg = rng(2594, 2777)  # LEGACY REP_RANKS TICKER（v5.8 使っていない QUESTS 2778〜2784 は外す）
# v5.5 評判の段階は称号と紛れない言い方に
for o, n in [("label:'見習い蒸留家'", "label:'無名'"), ("label:'地元の職人'", "label:'地元で知られる'"), ("label:'評判の蒸留家'", "label:'評判が広がる'"), ("label:'地域の名匠'", "label:'地域で有名'"), ("label:'全国区の名声'", "label:'全国で有名'"), ("label:'伝説の蒸留家'", "label:'世界で有名'")]:
    lg = patch(lg, o, n)
parts.append(lg)
M('n5_patch.js')
daily = rng(2785, 2867)
daily = patch(daily, "        changeRep(30,'デイリー全達成ボーナス');", "        changeRep(30,'デイリー全達成ボーナス');hgAdd(V51.HG.daily.k,'デイリー全達成','daily');")
daily = patch(daily, 'target=Math.round(ti()*2)||5000;', 'target=Math.max(5000,Math.round(ti()*4));')
daily = patch(daily, "'+Math.min(m.progress,m.target)+'/'+m.target+'", "'+(m.id==='dm_earn'?fmt(Math.min(m.progress,m.target))+'/'+fmt(m.target):Math.floor(Math.min(m.progress,m.target))+'/'+m.target)+'")
daily = patch(daily, ".replace('N本',target+'本');", ".replace('N本',target+'本').replace('N件',target+'件').replace('N樽',target+'樽');")
parts.append(daily)
M('n6a_eventmult.js')
K(2878, 2889)        # tryTriggerRandomEvent
M('n6b_applyevent.js')
tk = rng(2901, 3067)
tk = patch(tk, 'function initTicker(){', 'function initTicker_old(){')
tk = patch(tk, 'function nextTicker(){', 'function nextTicker_old(){')
# v5.4 イベントの帯をやめる（n26_v54.js にホームのアイコンと小窓で作り直し）
tk = patch(tk, 'function showEventBanner(ev){', 'function showEventBanner_old(ev){')
tk = patch(tk, 'function handleEventChoice(idx){', 'function handleEventChoice_old(idx){')
tk = patch(tk, 'function dismissEvent(){', 'function dismissEvent_old(){')
tk = patch(tk, "  mo.classList.remove('h');\n  renderStoryPanel();", "  mc2.innerHTML+='<button type=\"button\" class=\"btn-cancel\" style=\"width:100%;margin-top:14px\" data-act=\"closeM\">閉じる</button>';\n  mo.classList.add('ctr');mo.classList.remove('h');\n  renderStoryPanel();")
parts.append(tk)
M('n7_prestige.js')
K(3184, 3223)        # checkQuests updateQuestPanel chkUnlocks
M('n8_offline.js')
hdr = rng(3285, 3299)
hdr = patch(hdr, "function updHdr(){$('hc').textContent=fmt(G.cash);}", "function updHdr(){updHdrExtra();}")
hdr = patch(hdr, 'function gTitle(){', 'function gTitle_old(){')  # v5.5 最後に得た称号（n27_v55.js）
parts.append(hdr)
K(3311, 3382)        # rTapVisuals
rg = rng(3500, 3603)
rg = patch(rg, '<div class="fs" style="line-height:1.5;font-size:11px;color:var(--text2);margin-top:4px">${escapeHtml(r.desc)}</div>', '<div class="fs" style="color:var(--gold)">単価 ×${r.mult}</div>')
rg = patch(rg, "  G.cash-=r.cost;\n  sndPurchase();", "  pay(r.cost,'sga','rg');\n  sndPurchase();")
parts.append(rg)
# rprof は n9_ui.js へ移設（v4.1）
M('n12_content.js')
M('n13a_infra.js')
M('n13b_game.js')
M('n9_ui.js')
M('n14_ui43.js')
M('n15_barley.js')
M('n16_v45.js')
M('n17_v46.js')
M('n11_tut.js')
M('n18_v47.js')      # v4.7 砂時計・熟成の目標・倉庫日誌（TUTS を使うので n11 の後）
M('n19_v48.js')      # v4.8 職人の採用・配置と人件費
M('n20_v49.js')      # v4.9 倉庫の景色・差し入れ・日誌の職人の出来事
M('n21_px.js')       # v4.9.1 ドット絵スプライト（workerSvg・caskSvg・sceneStart）
M('n22_v50.js')      # v5.0 職人の配置（設備か樽に1人ずつ）・棚・配置モード
M('n23_v51.js')      # v5.1 売り方（3年以上の樽）・注文と倉庫をつなぐ
M('n24_v52.js')      # v5.2 樽タップの小人・予約の取り消し・BGM（クラシック）・手触り
M('n25_v53.js')      # v5.3 ハウスモルト・次の銘柄の案内
M('n26_v54.js')      # v5.4 トースト・イベントのアイコン・廃止の整理
M('n27_v55.js')      # v5.5 小人を試飲会に・試飲代の段階・称号の整理
M('n28_v56.js')      # v5.6 創業地・図鑑の創業地・再創業のボタン
M('n29_v57.js')      # v5.7 製造費・熟成費・法人税・借入
M('n30_v58.js')      # v5.8 BGM ケルト5曲（ABC 譜の読み取り・ハープ・フィドル・ホイッスル・バウロン）
M('n31_v59.js')      # v5.9 売るの統合・行の形の統一・小人の空き席
io_block = rng(4417, 4524)
io_block = patch(io_block, "  if(_offlineGate){closeOfflineModal();return;} // 復帰モーダルは専用クローズで_offlineGateを解除\n  $('mo').classList.add('h');", "  if(_offlineGate){closeOfflineModal();return;} // 復帰モーダルは専用クローズで_offlineGateを解除\n  $('mo').classList.add('h');$('mo').classList.remove('ctr');")
io_block = patch(io_block, "    data=btoa(unescape(encodeURIComponent(JSON.stringify(G))));", "    data=encodeCode(JSON.stringify(G));")
io_block = patch(io_block, "    obj=JSON.parse(decodeURIComponent(escape(atob(ta.value.trim()))));\n  }catch(e){toast('インポート失敗: 形式が不正です',3000);return;}", "    obj=decodeCode(ta.value.trim());\n  }catch(e){toast('インポート失敗: '+(e&&e.message&&/コード/.test(e.message)?e.message:'形式が不正です'),3500);return;}")
io_block = patch(io_block, "  G=sanitize(migrate(obj));\n", "  try{G=parseSave(obj);}catch(err){toast('インポート失敗: '+err.message,3000);return;}\n  _noSave=false;_loadError=null;postLoadInit();prodInvalidate();\n")
parts.append(io_block)
toastb = rng(4548, 4556)
toastb = patch(toastb, 'function toast(msg,dur=2200){', 'function toast_old(msg,dur=2200){')  # v5.4 n26_v54.js で豆知識の帯の下に出す形に
parts.append(toastb)
M('n10_events.js')
K(4662, 4726)        # initLiff hideLoading
tailb = rng(4816, 4856)
tailb = patch(tailb, "window.addEventListener('beforeunload',()=>{markActive();save();});", "window.addEventListener('beforeunload',()=>{markActive();save();diagLog('beforeunload');});")
tailb = patch(tailb, "window.addEventListener('pagehide',()=>{markActive();save();});", "window.addEventListener('pagehide',()=>{markActive();save();diagLog('pagehide');});")
tailb = patch(tailb, "window.addEventListener('blur',()=>{markActive();try{save();}catch(_){}});", "window.addEventListener('blur',()=>{markActive();try{save();}catch(_){}diagLog('blur');});")
tailb = patch(tailb, "  if(document.hidden){\n    markActive();\n    save();", "  if(document.hidden){\n    markActive();\n    save();diagLog('hidden');")
parts.append(tailb)

script = '\n'.join(parts)
# v4.7 放置の報告に「節目の年数になった樽」
script = patch(script, "  if(info.milestones&&info.milestones.length)h+=row('節目に達した原酒'", "  if(info.goals>0)h+=row('節目の年数になった樽',info.goals+'樽','var(--gold2)');\n  if(info.wage>0)h+=row('職人の給与','−'+fmt(info.wage),'var(--amber)');\n  if(info.offH>0.05)h+=row('職人が休業していた時間',fmtDuration(info.offH*3600000),'var(--red)');\n  if(info.milestones&&info.milestones.length)h+=row('節目に達した原酒'")
RENAME = {"Imperial Reserve":"Empire Reserve","Glenvivid":"Glen Corran","Glenfinddoch":"Strathmoy","Johnnie Emerald":"Kestrel Mark","Chávas Régal":"Royal Thistle","Glenmoran":"Ben Aird","Highgate Dark":"Skerrvik","Talisco":"Carraig Dubh","Laphrogue":"Port Innis","Ardmock":"Kilnamara","MacKallen":"Glen Sherran","Balvenix":"Drumcairn","Dalvista":"Castle Brae","Hamileston":"Kilbrenn","Rashmill":"Glenarra","Jack Davalo's":"Hollow Creek","Baker's Wax":"Red Seal Wheat","Buffalo Creeks":"Limestone Ridge","Pappy Van Crinkle":"Old Lantern 23","Kawasaki":"Kiri no Sato","Kokushu":"Mori no Kaze","Hibikue":"Wago","Nikkyo Pure":"Kitakaze","Suntoria Toki":"Hikari","Crown Morale":"Maple Line"}
for o,n in RENAME.items():
    script = script.replace(o, n)

out = html + '\n' + script

# v4.6.3 未使用の関数（deadcode.js で検出。orig.html の行範囲に含まれるもの。モジュール内のものはソースから削除済み）
DEAD_FUNCS = ['openHistModal', 'gTitle_old', 'cuc', 'rRegions', 'purchaseRegion', 'nextTicker_old', 'initTicker_old', 'showEventBanner_old', 'handleEventChoice_old', 'dismissEvent_old', 'toast_old', 'sndAuction', 'toggleSound',
              'getPrestigeSkillEffect', 'applyPrestigeSkills', 'currentRegion', 'exRegionMult',
              'checkQuests', 'updateQuestPanel']  # v5.8 クエスト（v4.1 から空）

# v5.8 未使用の CSS のクラス（画面にもコードにも出てこない：v3 のコンボ・クリティカル、旧ホーム、見学ツアー、設備の一覧など）。
# これらだけを指す規則を本体の <style> から除く（buildtool.js の stripCss。使い始めるとビルドが止まる）
DEAD_CSS = ['barrel-section', 'bgr', 'bnt', 'cash-lbl', 'cfold', 'ci', 'combo-lv1', 'combo-lv2', 'combo-lv3', 'combo-lv4', 'cprice', 'crit-flash', 'crit-ring', 'dist-upgrade', 'du-info', 'du-name', 'du-next', 'event-active', 'f12', 'f13', 'f14', 'fcho', 'fn', 'frec', 'frow', 'ic2', 'lock-badge', 'logo', 'mb10', 'mb6', 'mb8', 'mi', 'nextc', 'nextul', 'nk', 'nwr', 'ox', 'pass', 'pdot', 'pfx', 'qrow', 'say', 'seat', 'seats', 'sflow', 'shead', 'smoke', 'sp2', 'stbar', 'stg', 'sv', 'tapcap', 'tier-card', 'tour-info', 'tour-row', 'ub2', 'uc2', 'ud', 'ug2', 'ut2', 'wb', 'wlk', 'wsc', 'wsn', 'wsp']

if '--no-min' in sys.argv:
    open(OUT, 'w', encoding='utf-8').write(out)
    print('written', OUT, len(out.encode('utf-8')), 'bytes (no post-process)')
else:
    RAW = 'whisky_empire.raw.html'
    open(RAW, 'w', encoding='utf-8').write(out)
    subprocess.run(['node', 'buildtool.js', 'post', RAW, 'whisky_empire.dev.html', OUT, ','.join(DEAD_FUNCS), ','.join(DEAD_CSS)], check=True)
    os.remove(RAW)
    print('written', OUT, os.path.getsize(OUT), 'bytes / dev', os.path.getsize('whisky_empire.dev.html'), 'bytes')
