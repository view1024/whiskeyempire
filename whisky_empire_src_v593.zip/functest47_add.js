  // ================= v4.7 追加テスト =================
  // ---------- #106 砂時計：5個まで・1日4個まで・手段ごとに1日1個・日付で戻る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.hg = { n: 0, got: 0, used: 0 }; hgDay();
      const src = [hgAdd(1, 'l', 'login'), hgAdd(1, 'l', 'login'), hgAdd(1, 'd', 'daily'), hgAdd(1, 'd', 'daily'), hgAdd(1, 'm', 'ms'), hgAdd(1, 'm', 'ms')];
      G.hg.n = 5; const uses = []; for (let i = 0; i < 5; i++) { G.ls = Date.now(); uses.push(hgUse()); if (_offlineGate) closeOfflineModal(); }
      const afterUse = { n: G.hg.n, useDay: G.hg.useDay, left: hgLeftToday() };
      openHgModal(); const t = document.getElementById('mc2').textContent; const btn = document.querySelector('#mc2 [data-act="hgUse"]').disabled; closeM();
      off = 24 * 3600000; G.ls = rn() + off; const d2 = { left: hgLeftToday(), src: JSON.stringify(G.hg.src), again: hgAdd(1, 'l', 'login') };
      Date.now = rn;
      return { src, uses, afterUse, t: t.includes('今日使える数') && t.includes('今日の手に入れ方'), btn, d2, max: V47.HG_MAX, hgMs: V46.HG_MS };
    });
    const ok = r.src.join() === 'true,false,true,false,true,false' && r.uses.join() === 'true,true,true,true,false' && r.afterUse.n === 1 && r.afterUse.useDay === 4 && r.afterUse.left === 0 && r.t && r.btn && r.d2.left === 4 && r.d2.again === true && r.max === 5 && r.hgMs === 3600000;
    rec(106, '砂時計：1個1時間のまま・5個まで・1日4個まで使える・手段（ログイン・デイリー・熟成の節目）ごとに1日1個・日付が替わると戻る', ok, JSON.stringify(r));
    if (errors.length) rec('E57', '砂時計（v4.7）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #107 熟成の目標：25/50/75/100%・完成で次の節目へ・進み方によらず同じ・熟成の速さは不変 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const ct = caskType('bourbon'), sz = caskSize('hogshead');
      const mk = () => makeLot(ct, sz, { c: 0 });
      const a = mk(), b = mk(); lotGoalInit(a); lotGoalInit(b);
      const g0 = [a.goal, a.gs, lotGoalPct(a)];
      const rate = agingRate(a); const Y = BALANCE.GAME_YEAR_MS / rate; // 1年ぶんの時間
      const goals0 = G.stats.goals || 0; G.hg.src.ms = 0; const hg0 = G.hg.n;
      _goalUI = [];
      // a：1時間刻みで3.2年ぶん / b：一度に3.2年ぶん
      const steps = Math.ceil(3.2 * Y / 3600000); for (let i = 0; i < steps; i++) lotAdvance(a, 3200 * Y / steps / 1000 * 1000 / 3200 * 3.2 > 0 ? 3.2 * Y / steps : 0);
      const qs = _goalUI.filter(x => x.id === a.id).map(x => x.q); _goalUI = [];
      lotAdvance(b, 3.2 * Y); const qb = _goalUI.filter(x => x.id === b.id).map(x => x.q);
      const res = { g0, qs, qb, a: [a.goal, a.gd, +a.gs.toFixed(3), !!a.gt, +a.age.toFixed(4)], b: [b.goal, b.gd, +b.gs.toFixed(3), +b.age.toFixed(4)], goals: (G.stats.goals || 0) - goals0, hg: G.hg.n - hg0, jnl: jnlCur().done.slice(-2).map(d => d.g) };
      // 熟成の速さは目標の有無で変わらない
      const c = mk(), d = mk(); delete d.goal; c.goal = 0; lotAdvance(c, 5 * Y); lotAdvance(d, 5 * Y);
      res.same = Math.abs(c.age - d.age) < 1e-9 && Math.abs(c.age - 5) < 1e-6;
      res.eta = Math.round(lotGoalEta(a) / 3600000); res.etaExp = Math.round((8 - a.age) / rate * 24);
      return res;
    });
    const ok = r.g0.join() === '3,0,0' && r.qs.join() === '0.25,0.5,0.75,1' && r.qb.join() === '1' && r.a[0] === 8 && r.a[1] === 3 && r.a[2] === 3 && r.a[3] && r.b[0] === 8 && r.b[1] === 3 && Math.abs(r.a[4] - r.b[3]) < 1e-3 && r.goals === 2 && r.hg >= 0 && r.hg <= 1 && r.jnl.join() === '3,3' && r.same && Math.abs(r.eta - r.etaExp) <= 1;
    rec(107, '熟成の目標：新しい樽は3年が目標・25/50/75/100%で演出・届くと次の節目（8年）へ・毎秒でも一度でも同じ結果・日誌に記録・熟成の速さは変わらない', ok, JSON.stringify(r));
    if (errors.length) rec('E58', '熟成の目標テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #108 樽のマス：色つや10段階・目標の輪・完成の印・小窓で目標を変える・次の目標までの時間 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('tcel');
      const l0 = G.lots[0], l1 = G.lots[1]; l0.age = 0.5; l0.goal = 3; l0.gs = 0; l1.age = 10.2; l1.goal = 12; l1.gs = 8; l1.gd = 8; l1.gt = Date.now();
      rCellar(); await new Promise(r => setTimeout(r, 50));
      const c0 = document.querySelector(`#whSummary .ck2[data-id="${l0.id}"]`), c1 = document.querySelector(`#whSummary .ck2[data-id="${l1.id}"]`);
      const o = { cls0: c0.className, cls1: c1.className, gp1: c1.querySelector('.cgr').style.getPropertyValue('--gp'), done: !!c1.querySelector('.gdn'), ca0: c0.querySelector('.ca').textContent, bg: getComputedStyle(c1).backgroundImage.includes('gradient'), next: (document.querySelector('[data-lnext]') || {}).textContent };
      openLotModal(l0.id); const mt = document.getElementById('mc2').textContent; o.modal = mt.includes('熟成の目標'); o.noDup = ![...document.querySelectorAll('#mc2 .msl')].some(e => e.textContent === '次の節目');
      const chip = [...document.querySelectorAll('#mc2 [data-act="lotGoal"]')].find(b => b.dataset.v === '8'); chip.click(); await new Promise(r => setTimeout(r, 50));
      o.setGoal = [l0.goal, +l0.gs.toFixed(2)]; closeM();
      return o;
    });
    const ok = /\bag0\b/.test(r.cls0) && /\bag4\b/.test(r.cls1) && /gdone/.test(r.cls1) && Math.abs(parseFloat(r.gp1) - 55) < 1 && r.done && r.ca0 === '0.5/3年' && r.bg && /次の目標まで あと/.test(r.next) && r.modal && r.noDup && r.setGoal[0] === 8 && r.setGoal[1] === 0.5;
    rec(108, '樽のマス：年数で色つやが10段階に変わる・左上の輪が目標までの進み具合・届いた樽に「完成」・小窓で目標を選べる・倉庫の見出しに次の目標までの時間', ok, JSON.stringify(r));
    if (errors.length) rec('E59', '樽のマステスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #109 倉庫日誌：日付が替わると前の日を1件記録・14日分・寝かせるの先頭に「新」・開くと既読・保存しても同じ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.jnl = { cur: null, list: [] }; jnlRoll(); const f0 = G.stats.filled;
      G.stats.filled += 3; G.stats.bottled += 120; G.stats.orders += 2; G.te += 5000; jnlAdd('angel', 1.5);
      const rolledSame = jnlRoll();
      off = 24 * 3600000; const rolled = jnlRoll(); const e = G.jnl.list[0];
      for (let i = 2; i <= 20; i++) { off = i * 24 * 3600000; jnlRoll(); }
      const len = G.jnl.list.length; Date.now = rn; G.ls = rn(); if (_offlineGate) closeOfflineModal();
      switchTab('tcel'); rCellar(); const card = document.getElementById('celJnl'); const newMark = card.textContent.includes('新');
      card.querySelector('.jnl').click(); await new Promise(r => setTimeout(r, 60)); const modal = document.getElementById('mc2').textContent; closeM(); rCellar();
      const newAfter = document.getElementById('celJnl').textContent.includes('新');
      const s2 = sanitize(JSON.parse(JSON.stringify(G))); const same = JSON.stringify(s2.jnl.list) === JSON.stringify(G.jnl.list);
      return { rolledSame, rolled, e: { fill: e.fill, btl: e.btl, ord: e.ord, earn: e.earn, angel: e.angel }, len, newMark, modal: modal.includes('倉庫日誌') && modal.includes('今日のここまで'), newAfter, same };
    });
    const ok = !r.rolledSame && r.rolled && r.e.fill === 3 && r.e.btl === 120 && r.e.ord === 2 && r.e.earn === 5000 && Math.abs(r.e.angel - 1.5) < 1e-9 && r.len === 14 && r.newMark && r.modal && !r.newAfter && r.same;
    rec(109, '倉庫日誌：日付が替わると前の日の出来事（詰めた樽・瓶・納品・売上・天使の分け前）を1件記録・14日分・寝かせるの先頭に「新」・開くと既読・保存しても同じ', ok, JSON.stringify(r));
    if (errors.length) rec('E60', '倉庫日誌テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #110 v4.6（schema11）からの移行・ログインボーナス・放置の報告・変更点の案内 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const old = JSON.parse(JSON.stringify(G)); old.ver = 11; old.lots.forEach(l => { delete l.goal; delete l.gs; delete l.gd; delete l.gt; }); old.hg = { n: 2, got: 4, used: 2 }; delete old.jnl; old.hs.new47 = undefined; delete old.tut.done.u47;
      const m = parseSave(old);
      const o = { ver: m.ver, goals: m.lots.every(l => typeof l.goal === 'number' && l.gs === l.age), g1: m.lots.map(l => [l.age, l.goal]).slice(0, 2), hg: m.hg.n === 2 && m.hg.day === '' && m.hg.src.login === 0, jnl: Array.isArray(m.jnl.list), new47: m.hs.new47 };
      G = m; o.tut = TUTS.u47.cond();
      G.tut.done.u47 = true; G.hs.new47 = 1;
      // ログインボーナス（案内が済んでいてタイトルの後・小窓なし）
      closeM(); G.hg.src.login = 0; G.hg.day = dayKey(); const n0 = G.hg.n; const lb = loginBonus(); const lb2 = loginBonus(); o.login = [lb, lb2, G.hg.n - n0];
      // 放置の報告に「熟成の目標に届いた樽」
      const l = G.lots[0]; l.goal = l.age + 0.2; l.gs = l.age - 0.1; G.ls = Date.now() - 10 * 3600000; offline();
      o.rep = document.getElementById('mc2').textContent.includes('熟成の目標に届いた樽'); if (_offlineGate) closeOfflineModal();
      return o;
    });
    const ok = r.ver === SCHEMA && r.goals && r.hg && r.jnl && r.new47 === 0 && r.tut && r.login.join() === 'true,false,1' && r.rep;
    rec(110, 'v4.6（schema11）からの移行：樽に目標・砂時計の日ごとの記録・日誌を用意・変更点の案内／ログインボーナスは1日1回／放置の報告に目標に届いた樽', ok, JSON.stringify(r));
    if (errors.length) rec('E61', '移行テスト（v4.7）中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
