// 詳細設計書 第10章 テスト観点の自動確認
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve('whisky_empire.html');

async function newPage(browser, preload, keepTut) {
  const ctx = await browser.newContext({ viewport: { width: 360, height: 740 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  if (preload) await page.addInitScript(preload);
  await page.goto(FILE);
  await page.waitForTimeout(1200);
  await page.evaluate(() => { _mktOff = true; if (typeof titleStart === 'function') titleStart(false); });
  await page.waitForTimeout(800);
  if (!keepTut) await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose(); });
  return { page, errors, ctx };
}

(async () => {
  const browser = await chromium.launch();
  const results = [];
  const rec = (id, name, ok, detail) => { results.push({ id, name, ok, detail }); };

  // ---------- 新規ゲームでの計算テスト ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: detail === undefined ? '' : String(detail) });
      const near = (a, b, eps) => Math.abs(a - b) <= (eps || 1e-6) * Math.max(1, Math.abs(b));
      if (_offlineGate) closeOfflineModal();
      closeM();
      // #1 製麦Lv1のみ
      G.fac.malting.l = 1; prodInvalidate();
      let f = prodFlows();
      T(1, '製麦Lv1のみ: newmake0・ti=300×0.9(既定の大麦)×$6=$1,620/時', f.newmake === 0 && near(ti(), 1620), 'newmake=' + f.newmake + ' ti=' + ti());
      // #2 4工程Lv3
      ['malting', 'mashing', 'fermentation', 'distillation'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 3; });
      prodInvalidate(); f = prodFlows();
      const capOk = near(f.cap[0], 388.8) && near(f.cap[1], 374.4) && near(f.cap[2], 331.2) && near(f.cap[3], 288);
      T(2, '4工程Lv3: cap・newmake・律速・余剰', capOk && near(f.newmake, 288) && f.bottleneck === 3 && near(f.s[0], 14.4) && near(f.s[1], 43.2) && near(f.s[2], 43.2), JSON.stringify({ cap: f.cap, nm: f.newmake, bn: f.bottleneck, s: f.s }));
      // #3 強化後にキャッシュ破棄
      G.cash = 1e9; const before = prodFlows().cap[3];
      upgFac('distillation');
      T(3, '強化でキャッシュ破棄・能力上昇', prodFlows().cap[3] > before && G.fac.distillation.l === 4, before + '→' + prodFlows().cap[3]);
      // #4 タンク溢れ
      G.tank = tankCap() - 1; const te0 = G.te;
      prodTick(3600000);
      T(4, 'タンク溢れ分を外販・tank=tankCap', near(G.tank, tankCap()) && G.te > te0, 'tank=' + G.tank + ' cap=' + tankCap());
      // #5 樽詰め拒否
      const n0 = G.lots.length;
      G.tank = 0; const r1 = fillCask('bourbon', 'hogshead', true);
      G.tank = 1000; const cash = G.cash; G.cash = 0; const r2 = fillCask('bourbon', 'hogshead', true); G.cash = cash;
      const slots = whSlots(); const saved = G.lots.slice();
      while (G.lots.length < slots) G.lots.push(makeLot(caskType('bourbon'), caskSize('hogshead')));
      const r3 = fillCask('bourbon', 'hogshead', true);
      G.lots = saved;
      T(5, '樽詰めの拒否（タンク不足・資金不足・満杯）', !r1 && !r2 && !r3 && G.lots.length === n0, [r1, r2, r3].join(','));
      // #6 #7 熟成
      const hog = makeLot(caskType('bourbon'), caskSize('hogshead')); lotAdvance(hog, 86400000);
      T(6, 'ホグスヘッド1日: age+1.0・L×0.984', near(hog.age, 1) && near(hog.L, 250 * 0.984), hog.age + ' ' + hog.L);
      const qc = makeLot(caskType('bourbon'), caskSize('quarter')); lotAdvance(qc, 86400000);
      T(7, 'クォーター1日: age+2.0・L×0.975', near(qc.age, 2) && near(qc.L, 50 * 0.975), qc.age + ' ' + qc.L);
      // #8 風味（シェリー樽）
      const sh = makeLot(caskType('sherry'), caskSize('hogshead')); const b0 = sh.fl0.fruity;
      sh.age = 6; const f6 = lotFlavor(sh).fruity - b0; sh.age = 12; const f12 = lotFlavor(sh).fruity - b0; sh.age = 20; const f20 = lotFlavor(sh).fruity - b0;
      T(8, 'シェリー樽の加算 6/12/20年 = 50%/100%/100%', near(f6, 10) && near(f12, 20) && near(f20, 20), [f6, f12, f20].join('/'));
      // #9 混ぜて瓶詰め
      G.uw = ['glenlivid']; G.lots = [];
      const a = makeLot(caskType('bourbon'), caskSize('hogshead')); a.age = 8.5; a.q = 1.0; a.L = 70;
      const b = makeLot(caskType('sherry'), caskSize('hogshead')); b.age = 10.2; b.q = 1.1; b.L = 70;
      G.lots.push(a, b);
      const pv = botPreview('glenlivid', 200, 'young');
      T(9, '8年+10年を混ぜる: 表記8年・品質は量で加重平均', pv.ok && pv.age === 8 && near(pv.q, 1.05, 1e-3), JSON.stringify({ ok: pv.ok, age: pv.age, q: pv.q, reason: pv.reason }));
      // #10 バーボン銘柄はシェリー樽不可
      G.uw.push('jack_d');
      const onlySherry = [b];
      G.lots = onlySherry;
      T(10, 'バーボン銘柄はシェリー樽の原酒を使えない', lotsFor('jack_d').length === 0, lotsFor('jack_d').length);
      // #11 ★3 一致度
      G.uw.push('macallen');
      const lo = makeLot(caskType('bourbon'), caskSize('hogshead')); lo.age = 20; lo.fl0 = { smoky: 100, fruity: 0, spicy: 0, sweet: 0, floral: 100 };
      G.lots = [lo];
      T(11, '★3銘柄は一致度0.5未満を除外', lotsFor('macallen').length === 0 && flavorMatch(lotFlavor(lo), productSpec('macallen').target) < 0.5, flavorMatch(lotFlavor(lo), productSpec('macallen').target).toFixed(3));
      // #12 単価
      const t = productSpec('glenlivid').target;
      // 一致度0.5になる風味: 平均差17.5
      const fl = {}; FL_KEYS.forEach(k => fl[k] = t[k]); fl.floral = t.floral - 87.5;
      const m = flavorMatch(fl, t); const u = priceUnit('glenlivid', 8, 1.0, fl);
      const expect = 100 * 8 / 3 * 1.0 * (0.7 + 0.6 * m) * distMult() * saleMult() * repMult();
      T(12, 'Glenvivid 8年・q1・一致0.5 ≈ $267', near(m, 0.5, 1e-3) && near(u, 266.67, 1e-3) && near(u, expect), 'm=' + m.toFixed(3) + ' unit=' + u.toFixed(2));
      // #13 注文の到着と上限
      G.orders = []; G.orderClock = Date.now() - 1;
      const n1 = ordSpawnTick(Date.now());
      G.orderClock = Date.now() - BALANCE.ORDER_INTERVAL_MS * 10;
      ordSpawnTick(Date.now());
      T(13, '90分ごと1件・ボード上限で停止', n1 === 1 && G.orders.length === boardSize() && G.orderClock > Date.now(), 'n1=' + n1 + ' len=' + G.orders.length + '/' + boardSize());
      // #14 在庫不足で納品拒否
      G.bottles = [];
      const o14 = { id: 'o_t14', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o14]; const c14 = G.cash;
      const d14 = ordDeliver('o_t14');
      T(14, '在庫不足の納品は拒否・状態不変', !d14 && G.orders.length === 1 && G.cash === c14, d14);
      // 正常納品
      invAdd('glenlivid', 12, 9, 1.0, t);
      const rep0 = G.reputation, sh0 = G.stats.shipped;
      const d14b = ordDeliver('o_t14');
      T('14b', '在庫十分なら納品: 資金・評判・出荷・関係', d14b && G.orders.length === 0 && G.reputation > rep0 && G.stats.shipped === sh0 + 10 && G.rel.local.done >= 1 && invTotal('glenlivid') === 2, 'rep ' + rep0 + '→' + G.reputation);
      // #15 予約の期限切れ
      const rr = G.reputation; const dn = G.rel.local.done;
      G.orders = [
        { id: 'o_r1', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: true, createdAt: 0, dueAt: Date.now() - 1 },
        { id: 'o_r2', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: false, createdAt: 0, dueAt: Date.now() - 1 },
      ];
      const ex = ordExpireTick(Date.now());
      T(15, '受注済み予約の期限切れだけ罰', ex.failed === 1 && ex.expired === 1 && G.reputation < rr && G.rel.local.done === Math.max(0, dn - 3), JSON.stringify(ex) + ' rep ' + rr + '→' + G.reputation);
      // #16 コレクター
      const y17 = makeLot(caskType('bourbon'), caskSize('hogshead')); y17.age = 17.5;
      const y19 = makeLot(caskType('bourbon'), caskSize('hogshead')); y19.age = 19;
      G.lots = [y17, y19];
      const oc = { id: 'o_c', cid: 'collector', kind: 'cask', minAge: 18, qty: 1, mult: 3, reserve: false, accepted: false, createdAt: 0, dueAt: Date.now() + 3600000 };
      const mc = ordMatch(oc);
      T(16, 'コレクター注文は18年未満の樽を選べない', mc.lots.length === 1 && mc.lots[0] === y19 && ordMatch(oc, y17.id).ok === false, mc.lots.length);
      // #17 分岐未選択
      G.fac.malting.l = 10; G.branch.malting = null; G.dl = 2;
      const pend = brPending('malting'); const lvb = G.fac.malting.l;
      upgFac('malting'); closeM();
      const blocked = G.fac.malting.l === lvb;
      brChoose('malting', 1);
      T(17, 'Lv10で分岐未選択なら強化不可・選択で能力×1.2', pend && blocked && G.branch.malting === 1 && near(stageCap(0), 300 * Math.pow(1.2, 9) * 1.2 * rcpMods().cap[0]), 'pend=' + pend + ' blocked=' + blocked);
      G.dl = 1;
      // #18 Tier条件
      G.stats.shipped = 0; G.reputation = 0; G.lots = []; G.cash = 0;
      const s0 = tierReqStatus(2).filter(o => o.ok).length;
      G.stats.shipped = 300; G.reputation = 15;
      for (let i = 0; i < 5; i++) { const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 3.2; G.lots.push(l); }
      const s1 = tierReqStatus(2).filter(o => o.ok).length; const can1 = canUpgDist();
      G.cash = tierCost(2) + 10;
      const can2 = canUpgDist();
      G.bottles = []; invAdd('glenlivid', 5, 8, 1, t);
      doUpgDist(tierCost(2), 2);
      T(18, 'Tier条件が順にok・全達成で昇格・在庫は残る', s0 === 0 && s1 === 3 && !can1 && can2 && G.dl === 2 && G.lots.length === 5 && invTotal('glenlivid') === 5, [s0, s1, can1, can2, G.dl].join(','));
      // #19 ブレンド
      G.dl = 3; G.lots = [];
      const l1 = makeLot(caskType('sherry'), caskSize('hogshead')); l1.age = 10;
      const l2 = makeLot(caskType('bourbon'), caskSize('hogshead')); l2.age = 8;
      G.lots.push(l1, l2);
      const bh0 = (G.blendHistory || []).length; const L0 = l1.L + l2.L; const bq0 = G.bq.length;
      const ok19 = blendStart('classic_blend', [{ lotId: l1.id, L: 100 }, { lotId: l2.id, L: 100 }]);
      const L1 = G.lots.reduce((a, l) => a + l.L, 0);
      chkT();
      T(19, 'ブレンドで原酒が減り履歴記録・称号「初仕込み」', ok19 && Math.abs(L0 - L1 - 200) < 1e-6 && G.blendHistory.length === bh0 + 1 && G.bq.length === bq0 + 1 && G.tl.includes('t19'), 'ok=' + ok19 + ' used=' + (L0 - L1));
      // #20 品評会（期待値）
      const row = { pid: 'glenlivid', age: 8, q: 1.05, fl: {} };
      FL_KEYS.forEach(k => row.fl[k] = t[k]); row.fl.floral = t.floral - 35; // 一致度0.8
      G.reputation = 0; G.prestige.skills = {};
      const e = compExpected(row);
      T(20, '地域品評会: 8年・q1.05・一致0.8 ⇒ 0.656点（合格0.6超）', Math.abs(e - 0.6556) < 0.001, e.toFixed(4));
      // 実出品
      G.bottles = []; invAdd('glenlivid', 10, 12, 1.2, t); G.cash = 1e7; G.compCooldowns = {};
      const res = enterComp('local_award', G.bottles[0].id);
      T('20b', '出品で6本消費・結果と講評3件・クールダウン1日', res && invTotal('glenlivid') === 4 && res.judges.length === 3 && Math.abs((G.compCooldowns.local_award - Date.now()) - 86400000) < 5000, res ? ('win=' + res.win + ' S=' + res.S.toFixed(3)) : 'null');
      closeM();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E1', '計算テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- オフライン ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const setup = () => {
        if (_offlineGate) closeOfflineModal(); closeM();
        ['malting', 'mashing', 'fermentation', 'distillation', 'maturation', 'bottling'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 5; });
        G.lots = []; G.tank = 0; G.cash = 1e7; G.auto.fill.on = false; prodInvalidate();
      };
      // #21 10時間
      setup();
      const lot = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot);
      const nm = prodFlows().newmake;
      G.ls = Date.now() - 10 * 3600000;
      offline();
      const exp21 = 10 / 24;
      T(21, '10時間不在: 熟成10時間分・生産8時間分', Math.abs(lot.age - exp21) < 1e-3 && Math.abs(G.tank - Math.min(tankCap(), nm * 8)) < 1e-3, 'age=' + lot.age.toFixed(4) + ' tank=' + G.tank.toFixed(1) + ' nm*8=' + (nm * 8).toFixed(1));
      // #22 100時間
      setup();
      const lot2 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot2);
      G.ls = Date.now() - 100 * 3600000;
      const t0 = performance.now(); offline(); const dt = performance.now() - t0;
      T(22, '100時間不在: 熟成72時間分・1秒以内', Math.abs(lot2.age - 3) < 1e-3 && dt < 1000, 'age=' + lot2.age.toFixed(4) + ' ms=' + dt.toFixed(1));
      // #23 自動樽詰め
      setup(); G.auto.fill.on = true; G.auto.fill.cask = 'bourbon'; G.auto.fill.size = 'quarter';
      G.ls = Date.now() - 4 * 3600000;
      offline();
      const ages = G.lots.map(l => l.age).sort((a, b) => b - a);
      const f = prodFlows();
      T(23, '自動樽詰め4時間: 先に詰めた樽ほど年数が大きい', G.lots.length > 1 && ages[0] > ages[ages.length - 1] && ages[0] <= 4 / 24 * 2 + 1e-9, 'lots=' + G.lots.length + ' ages=' + ages.slice(0, 3).map(a => a.toFixed(3)).join(','));
      // #24 同時発火で1回だけ
      setup();
      const lot3 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot3);
      G.ls = Date.now() - 2 * 3600000;
      offline(); offline(); window.dispatchEvent(new Event('focus')); document.dispatchEvent(new Event('visibilitychange'));
      T(24, '複数経路の同時発火でも補正1回', Math.abs(lot3.age - 2 / 24) < 1e-3, 'age=' + lot3.age.toFixed(5));
      if (_offlineGate) closeOfflineModal();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E2', 'オフラインテスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 移行 ----------
  const V6 = {
    cash: 123456789, te: 987654321, tt: 5000, dl: 3, cl: 7,
    fac: { malting: { l: 25, p: true }, mashing: { l: 22, p: true }, fermentation: { l: 20, p: true }, distillation: { l: 18, p: true }, maturation: { l: 15, p: true }, bottling: { l: 12, p: true } },
    uw: ['glenlivid', 'jameston', 'jack_d', 'johnnie_em'], cw: { glenlivid: 120, jack_d: 50 },
    am: { glenlivid: true }, inv: { glenlivid: 7, jack_d: 3 }, regions: { scotland: true }, tl: ['t1', 't9'],
    ls: Date.now() - 30 * 60000, ver: 6, dbgMul: 1,
    rawMaterials: { grain: 'optic', water: 'soft_spring', yeast: 'distillery', peat: 'unpeated' },
    casks: [{ id: 'cask_1', type: 'sherry', size: 'hogshead', whiskyId: 'glenlivid', litresFilled: 240, createdAt: Date.now() - 86400000, agingYears: 0.02, qualityMod: 1.3, sold: false },
            { id: 'cask_2', type: 'bourbon', size: 'barrel', whiskyId: 'jack_d', litresFilled: 190, createdAt: Date.now(), agingYears: 0.001, qualityMod: 0.7, sold: false }],
    channels: { active: ['dtc', 'on_trade', 'retail'], autoSellChannel: 'on_trade' },
    reputation: 42, awards: ['local_award'], compCooldowns: { local_award: Date.now() + 5 * 86400000 },
    prestige: { level: 1, bonus: 1.1, skillPoints: 1, skills: { ps_passive: 1, ps_am_slot: 1 }, legacyWhiskies: ['lw_genesis'], totalRuns: 1 },
    mg: { malting: { nextAt: 0, bonusUntil: 0, bonusMult: 1 } }, cut: {}, _cutBonus: 1, facByBrand: {}, wCd: { glenlivid: 0 },
    story: { unlocked: ['ep1'], seenNew: ['ep1'] }, daily: { date: '', missions: [], allCleared: false }, questDone: ['q_tap10']
  };
  {
    const pre = `localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(V6))});`;
    const { page, errors } = await newPage(browser, `if(!sessionStorage.getItem('x')){sessionStorage.setItem('x','1');${pre}}`, true);
    await page.waitForTimeout(600);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const bk = localStorage.getItem('we_v4_bak6:guest');
      const mig = G.lots.filter(l => l.src === 'migrated');
      const sherry = mig.find(l => l.cask === 'sherry');
      const ok = G.ver === 10 && G.dl === 3 && G.cash >= 123456789 && G.fac.malting.l === 25 && G.fac.malting.p
        && mig.length === 2 && sherry && Math.abs(sherry.L - 240) < 1 && sherry.q === 1.3 && mig.find(l => l.cask === 'bourbon').q === 0.8
        && invTotal('glenlivid') === 7 && invTotal('jack_d') === 3 && G.bottles.find(b => b.pid === 'glenlivid').age === 8
        && G.rel.local.lv === 1 && G.rel.bar.lv === 1 && G.rel.retail.lv === 1 && G.rel.dutyfree.lv === 0
        && G.recipe.grain === 'optic' && G.recipeOwned.includes('optic')
        && G.prestige.skills.ps_capacity === 1 && G.prestige.skills.ps_order_slot === 1 && !G.prestige.skills.ps_passive
        && G.compCooldowns.local_award <= Date.now() + 86400000 + 1000
        && G.stats.shipped === 170 && G.stats.awardsWon === 1
        && G.lots.filter(l => l.src === 'starter').length === 3 && G.orders.length >= 1
        && !('mg' in G) && !('casks' in G) && !('inv' in G) && !('channels' in G) && !('am' in G) && !('_cutBonus' in G)
        && !!bk && JSON.parse(bk).ver === 6 && G.tl.includes('t9') && G.migratedFrom === 6;
      T('25c', 'v3移行ユーザーは更新案内を待機・自動樽詰めと自動直販はON', G.tut.q.includes('upd') && !G.tut.done.first && G.auto.fill.on && G.auto.spot.on, JSON.stringify(G.tut));
      T(25, 'v3.8.0セーブの移行（樽・在庫・チャネル・レシピ・スキル・待ち時間・バックアップ）', ok, JSON.stringify({ ver: G.ver, lots: G.lots.map(l => l.src + ':' + l.cask + ':' + l.L.toFixed(0) + ':' + l.q), inv: G.bottles.map(b => b.pid + ':' + b.n + ':' + b.age), rel: G.rel, rc: G.recipe.grain, sk: G.prestige.skills, st: G.stats, bk: !!bk }));
      const modalShown = !$('mo').classList.contains('h') && /生まれ変わり|おかえり/.test($('mc2').textContent);
      T('25b', '移行結果（またはおかえり）モーダルが出る', modalShown, $('mc2').textContent.slice(0, 30));
      // #26 再読込で不変
      save();
      const snap = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      load();
      const snap2 = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      postLoadInit();
      T(26, '移行済みデータの再読込で変化なし（初期在庫も重複しない）', snap === snap2 && G.lots.filter(l => l.src === 'starter').length === 3, snap === snap2);
      // #27 壊れたインポート
      const before = JSON.stringify(G.stats);
      importSave(); $('ioText').value = '@@@broken@@@'; ioApplyAction();
      const ok27a = JSON.stringify(G.stats) === before;
      importSave(); $('ioText').value = btoa(unescape(encodeURIComponent(JSON.stringify({ ver: 99 })))); ioApplyAction();
      const ok27b = JSON.stringify(G.stats) === before && G.ver === 10;
      closeM();
      T(27, '壊れた・新しすぎるセーブのインポートは拒否', ok27a && ok27b, ok27a + ',' + ok27b);
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    await page.screenshot({ path: 'shot_migrate.png' });
    if (errors.length) rec('E3', '移行テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 削除確認・画面 ----------
  {
    const fs = require('fs');
    const src = fs.readFileSync('whisky_empire.html', 'utf8');
    const leftovers = ['G.mg', 'craft(', 'autoSellTick', 'channelMult', 'openMiniGame', 'mgModal', 'comboCount', 'COMBO_', 'comboMul', 'CRIT_CHANCE_10000', 'comboMeter', 'id="questPanel"', 'Glenvivid', 'Johnnie Emerald', 'Davalo', 'Kawasaki'].filter(w => src.includes(w));
    rec(28, '削除対象（ミニゲーム・コンボ・ティッカー・クエスト表示）がコードに残っていない', leftovers.length === 0, leftovers.join(','));
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      if (_offlineGate) closeOfflineModal(); closeM();
      const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 150));
        const el = document.getElementById(t);
        res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth });
      }
      const navWrap = [...document.querySelectorAll('#nav .nb')].some(b => b.getBoundingClientRect().height > 70);
      return { res, navWrap };
    });
    const bad = r.res.filter(x => x.over > 1 || x.doc > 1);
    rec(29, '幅360pxで横スクロールなし・ナビが折り返さない', bad.length === 0 && !r.navWrap, JSON.stringify(r));
    if (errors.length) rec('E4', '画面テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 実プレイの通し（UI操作） ----------
  {
    const { page, errors } = await newPage(browser);
    await page.evaluate(() => { if (_offlineGate) closeOfflineModal(); closeM(); });
    // 1. 売るタブで「詰めて納品」→ 瓶詰め完了 → 自動納品
    await page.click('#nav .nb[data-tab="tsale"]');
    await page.waitForTimeout(200);
    const o0 = await page.evaluate(() => { const o = G.orders.find(x => ordFulfillPlan(x).ok); return o ? { id: o.id, qty: o.qty } : null; });
    await page.click(`[data-act="ordFill"][data-id="${o0.id}"]`);
    const q = await page.evaluate(id => ({ bq: G.bq.length, oid: G.bq[0] && G.bq[0].oid, auto: G.orders.find(o => o.id === id).autoDel, card: document.getElementById('orderBoard').textContent.includes('瓶詰め中') }), o0.id);
    await page.evaluate(() => { botTick(3600000 * (Math.ceil(botQueueBottles() / botRate()) + 1)); ordAutoTick(); rall(); });
    const after = await page.evaluate(id => ({ gone: !G.orders.some(o => o.id === id), orders: G.stats.orders, cash: G.cash, shipped: G.stats.shipped }), o0.id);
    rec(30, 'UI操作: 「詰めて納品」1回で瓶詰め→完了後に自動納品', q.bq === 1 && q.oid === o0.id && q.auto && q.card && after.gone && after.orders === 1 && after.shipped === o0.qty, JSON.stringify({ o0, q, after }));
    await page.screenshot({ path: 'shot_after_deliver.png' });
    // 2. 造るタブの一覧のボタンで直接強化
    await page.evaluate(() => { G.cash = 1e6; rall(); });
    await page.click('#nav .nb[data-tab="tb"]');
    await page.click('#lineView [data-act="facUp"][data-id="malting"]');
    const mlv = await page.evaluate(() => G.fac.malting.l);
    rec('30b', 'UI操作: 生産ラインのボタン1回で強化', mlv === 1, mlv);
    await page.screenshot({ path: 'shot_make2.png', fullPage: false });
    if (errors.length) rec('E5', '通しテスト中のエラー', false, errors.join(' | '));
  }

  // ================= v4.1 追加テスト =================
  // ---------- 初回チュートリアル ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    const init = await page.evaluate(() => ({ q: G.tut.q.slice(), run: _tut && _tut.id, fill: G.auto.fill.on, spot: G.auto.spot.on, ver: G.ver }));
    rec(31, '新規開始: schema10・自動樽詰め/自動直販ON・初回案内が始まる', init.ver === 10 && init.fill && init.spot && init.run === 'first', JSON.stringify(init));
    const t0 = Date.now(); let taps = 0; let firstSaleTaps = null, firstSaleSec = null;
    for (let k = 0; k < 14; k++) {
      const info = await page.evaluate(() => _tut ? { do: !!(tutStep() && tutStep().do) } : null);
      if (!info) break;
      await page.waitForTimeout(350);
      if (info.do) {
        const box = await page.evaluate(() => { const el = tutEl(tutStep()); if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
        if (box) { await page.mouse.click(box.x, box.y); taps++; } else await page.waitForTimeout(1600);
      } else { await page.mouse.click(195, 90); taps++; }
      await page.waitForTimeout(500);
      if (firstSaleTaps === null && await page.evaluate(() => G.stats.orders >= 1)) { firstSaleTaps = taps; firstSaleSec = (Date.now() - t0) / 1000; }
    }
    const end = await page.evaluate(() => ({ done: !!G.tut.done.first, rewarded: !!G.tut.rewarded, orders: G.stats.orders, malt: facLv('malting'), coach: document.getElementById('coach').classList.contains('h'), daily: feat('daily') }));
    rec(32, '初回案内: 7タップ以内（樽3回を含む）・60秒以内に最初の売上／完了で報酬・デイリー解放', firstSaleTaps !== null && firstSaleTaps <= 7 && firstSaleSec <= 60 && end.done && end.rewarded && end.malt >= 1 && end.coach && end.daily, JSON.stringify({ firstSaleTaps, firstSaleSec, end }));
    // 再読込で再表示しない・もう一度見るで再生
    await page.evaluate(() => save());
    await page.reload(); await page.waitForTimeout(1500);
    const again = await page.evaluate(() => ({ run: _tut && _tut.id, done: !!G.tut.done.first }));
    await page.evaluate(() => tutStart('first', true));
    await page.waitForTimeout(400);
    const replay = await page.evaluate(() => ({ run: _tut && _tut.id, next: getComputedStyle(document.getElementById('cNext')).visibility }));
    await page.evaluate(() => tutEnd(false));
    rec(33, '完了済みの案内は再読込で出ない・ヒント帳から再生できる（操作手順も次へで進める）', !again.run && again.done && replay.run === 'first' && replay.next === 'visible', JSON.stringify({ again, replay }));
    if (errors.length) rec('E6', 'チュートリアルテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- スキップで進行不能にならない ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    await page.click('#cBub [data-act="tutSkip"]');
    await page.waitForTimeout(300);
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, coach: document.getElementById('coach').classList.contains('h'), rewarded: !!G.tut.rewarded, next: document.getElementById('bd_tsale').textContent !== '' }));
    await page.click('#nav .nb[data-tab="tsale"]'); await page.waitForTimeout(300);
    await page.click('#orderBoard [data-act="ordFill"], #orderBoard [data-act="ordGo"]');
    await page.waitForTimeout(300);
    const r2 = await page.evaluate(() => ({ tab: document.querySelector('.tab.on').id, bq: G.bq.length, orders: G.stats.orders }));
    rec(34, 'スキップしても操作できる・印の付いた「売る」から最初の注文を処理できる', r.done && r.coach && !r.rewarded && r.next && (r2.bq >= 1 || r2.orders >= 1), JSON.stringify({ r, r2 }));
    if (errors.length) rec('E7', 'スキップテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- ロジック（v4.1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      if (_offlineGate) closeOfflineModal(); closeM();
      // #35 コンボ廃止
      const base = cv(); const c0 = G.cash; let bad = 0;
      for (let i = 0; i < 60; i++) { const b = G.cash; tap(null); const d = G.cash - b; if (!(Math.abs(d - base) < 1e-6 || Math.abs(d - base * 100) < 1e-6)) bad++; }
      T(35, 'タップ収益は連打しても一定（×1 か クリティカル×100 のみ）', bad === 0 && typeof comboMul === 'undefined', 'bad=' + bad);
      // #36 注文の年数条件を守って詰める
      G.uw = ['glenlivid']; G.lots = []; G.bq = []; G.bottles = [];
      const l8 = makeLot(caskType('bourbon'), caskSize('hogshead')); l8.age = 8.5; l8.L = 100;
      const l11 = makeLot(caskType('bourbon'), caskSize('hogshead')); l11.age = 11.2; l11.L = 100;
      G.lots.push(l8, l11);
      const o = { id: 'o_t36', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 10, qty: 20, rq: 20, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 };
      G.orders = [o];
      const ok36 = ordFulfill('o_t36');
      const usedOld = l11.L < 100 && Math.abs(l8.L - 100) < 1e-9;
      botTick(3600000 * 5); const del = ordAutoTick();
      T(36, '「詰めて納品」は注文の年数以上の樽だけを使い、完了で自動納品', ok36 && usedOld && del === 1 && G.orders.length === 0 && G.stats.orders >= 1, JSON.stringify({ ok36, usedOld, del, left: G.orders.length }));
      // #37 自動直販は注文ボードの分を売らない
      G.orders = [{ id: 'o_t37', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 80, rq: 80, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; invAdd('glenlivid', 100, 9, 1, productSpec('glenlivid').target);
      G.auto.spot.on = true; G.auto.spot.defKeep = 50;
      autoSpotTick();
      T(37, '自動直販は注文に必要な本数を残す（残す本数50・注文80 → 80本残る）', invTotal('glenlivid') === 80, invTotal('glenlivid'));
      // #38 オフライン中に瓶詰めが終わった注文は自動納品
      G.orders = [{ id: 'o_t38', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 30, rq: 30, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; G.bq = [];
      const l9 = makeLot(caskType('bourbon'), caskSize('hogshead')); l9.age = 9; l9.L = 200; G.lots = [l9];
      ordFulfill('o_t38');
      const o0 = G.stats.orders;
      G.ls = Date.now() - 3 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      T(38, 'オフライン中に瓶詰めが終わった注文を自動納品', G.stats.orders === o0 + 1 && !G.orders.some(x => x.id === 'o_t38'), 'orders ' + o0 + '→' + G.stats.orders);
      // #39 段階的解放
      G.dl = 1; G.reputation = 0; G.stats.awardsWon = 0; G.awards = []; G.fac.distillation.p = false; G.tank = 0; G.te = 0; G.recipeOwned = ['golden_promise', 'soft_spring', 'distillery', 'unpeated'];
      const f1 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips1 = document.querySelectorAll('#sellChips .chip').length;
      switchTab('tcel'); const blend1 = document.getElementById('btnBlend').style.display;
      G.dl = 3; G.fac.distillation.p = true; G.te = 1e9; rall();
      const f2 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips2 = document.querySelectorAll('#sellChips .chip').length;
      const locks = [...document.querySelectorAll('#lineView .pst')].filter(e => e.textContent.includes('🔒')).length;
      T(39, '使えない機能は非表示（Tier1: 売るの切替2つ・ブレンド非表示）→ 条件達成で表示', f1.every(x => !x) && chips1 === 2 && blend1 === 'none' && f2.join() === 'true,true,true,true,true,false,true' && chips2 === 5 && locks === 0, JSON.stringify({ f1, f2, chips1, chips2, blend1 }));
      // #40 v7→v8 の移行
      const v7 = JSON.parse(JSON.stringify(G)); v7.ver = 7; delete v7.tut; delete v7.shipLog; delete v7.encSeen; v7.auto.fill.on = false; v7.auto.spot.on = false; v7.dl = 2; v7.cw = { glenlivid: 30 };
      const m = parseSave(v7);
      T(40, 'v4.0（schema7）からの移行: 自動設定は維持・更新案内3枚・解放済み機能の案内は出さない', m.ver === 10 && !m.auto.fill.on && !m.auto.spot.on && m.tut.q.join() === 'upd' && m.tut.seed && m.shipLog.glenlivid && TUTS.upd.steps.length === 3, JSON.stringify({ ver: m.ver, tut: m.tut, auto: m.auto }));
      G = m; tutCheck();
      T('40b', 'seed処理: 条件を満たしている解放案内は既読になる', G.tut.done.u_t2 && G.tut.done.u_still && !G.tut.seed, JSON.stringify(G.tut.done));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E8', 'v4.1ロジックテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- v7 セーブのバックアップ ----------
  {
    const v7 = { ver: 7, cash: 5000, te: 9000, dl: 1, uw: ['glenlivid'], lots: [], bottles: [], orders: [], auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: false, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('y')){sessionStorage.setItem('y','1');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v7))});}`;
    const { page, errors } = await newPage(browser, pre, true);
    await page.waitForTimeout(1500);
    const r = await page.evaluate(() => ({ bk: localStorage.getItem('we_v4_bak7:guest'), run: _tut && _tut.id, ver: G.ver, fill: G.auto.fill.on }));
    rec(41, 'v4.0セーブの読込: 移行前をバックアップ・更新案内が出る', !!r.bk && JSON.parse(r.bk).ver === 7 && r.run === 'upd' && r.ver === 10 && !r.fill, JSON.stringify({ bk: !!r.bk, run: r.run, ver: r.ver }));
    await page.screenshot({ path: 'shot_upd.png' });
    if (errors.length) rec('E9', 'v7読込テスト中のエラー', false, errors.join(' | '));
  }
  // ================= v4.2 追加テスト =================
  // ---------- 表示の基準（P1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      const out = { small: [], tiny: [], chars: [] };
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 200));
        const el = document.getElementById(t);
        el.querySelectorAll('button,[data-act],select,input,summary').forEach(b => {
          if (b.getClientRects().length === 0) return;
          const r = b.getBoundingClientRect();
          if (b.classList.contains('ib') || b.classList.contains('visitor')) return; // ⓘは疑似要素で44px、来客は動きのある要素（56px）
          if (r.height < 43.5 || (r.width < 43.5 && b.tagName !== 'INPUT')) out.small.push(t + ':' + (b.dataset.act || b.tagName) + ':' + Math.round(r.width) + 'x' + Math.round(r.height));
        });
        const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n, chars = 0;
        while (n = w.nextNode()) { const p = n.parentElement; if (!p || p.getClientRects().length === 0 || !n.textContent.trim()) continue; const fs = parseFloat(getComputedStyle(p).fontSize); if (fs < 12) out.tiny.push(t + ':' + fs + ':' + n.textContent.trim().slice(0, 10)); chars += n.textContent.replace(/\s/g, '').length; }
        out.chars.push(t + ':' + chars);
      }
      const sm = parseFloat(getComputedStyle(document.querySelector('#tcel .thead .sm')).fontSize);
      const L = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
      const muted = getComputedStyle(document.documentElement).getPropertyValue('--muted').trim();
      const cr = (L(muted) + 0.05) / (L('#241c13') + 0.05);
      const chrome = ['hdr', 'ticker', 'nav'].map(id => document.getElementById(id).getBoundingClientRect().height);
      return { ...out, sm, cr: +cr.toFixed(2), chrome };
    });
    rec(42, '押す対象がすべて44px以上・文字は12px以上（本文14px）・補足色のコントラスト4.5以上', r.small.length === 0 && r.tiny.length === 0 && r.sm >= 14 && r.cr >= 4.5, JSON.stringify({ small: r.small.slice(0, 8), tiny: r.tiny.slice(0, 8), sm: r.sm, cr: r.cr, chrome: r.chrome, chars: r.chars }));
    if (errors.length) rec('E11', '表示基準テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- タイトル・TIPS帯・樽・設定（P1） ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 740 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1500);
    const t0 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id, note: document.querySelector('.t-note').textContent.includes('20歳未満'), se: G.opt.se, bgm: G.opt.bgm }));
    await page.click('#titleBtns .btn-ok'); await page.waitForTimeout(900);
    const t1 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id }));
    rec(43, '起動時にタイトルと注意書き（音なしが既定）→ 閉じると初回案内が始まる', t0.title && !t0.tut && t0.note && t0.se === 0 && t0.bgm === 0 && !t1.title && t1.tut === 'first', JSON.stringify({ t0, t1 }));
    const tk = await page.evaluate(() => {
      const seq = []; _tk.hist = []; _tk.sinceHealth = 0;
      for (let i = 0; i < 120; i++) seq.push(tkPick());
      let maxGap = 0, gap = 0; seq.forEach(m => { if (m.cat === 'health') gap = 0; else { gap++; maxGap = Math.max(maxGap, gap); } });
      const locked = seq.filter(m => m.cat === 'tips' && m.f && !feat(m.f)).length;
      const srcOk = TICKER_MSGS.filter(m => m.cat === 'trivia' && m.src !== 'idea').every(m => SRC[m.src]);
      const bar = document.getElementById('ticker').getBoundingClientRect();
      return { maxGap, locked, srcOk, barTop: Math.round(bar.top), hdrBottom: Math.round(document.getElementById('hdr').getBoundingClientRect().bottom), n: TICKER_MSGS.length, triv: TICKER_MSGS.filter(m => m.cat === 'trivia').length, health: TICKER_MSGS.filter(m => m.cat === 'health').length, wrong: TICKER_MSGS.some(m => /京都・山崎|コンボ|プロフタブ/.test(m.text)) };
    });
    await page.evaluate(() => { if (_tut) { tutEnd(false); } });
    await page.waitForTimeout(200);
    await page.click('#ticker'); await page.waitForTimeout(300);
    const modal = await page.evaluate(() => ({ open: !document.getElementById('mo').classList.contains('h'), paused: _tk.paused, txt: document.getElementById('mc2').textContent }));
    rec(44, 'TIPS帯：ヘッダー直下に常設・健康は6件に1件以上・未解放のTIPSは出ない・豆知識は全件出典つき・誤記修正・タップで全文と出典', tk.barTop === tk.hdrBottom && tk.maxGap <= 5 && tk.locked === 0 && tk.srcOk && !tk.wrong && modal.open && modal.paused && (modal.txt.includes('出典') || modal.txt.includes('提案') || modal.txt.length > 5), JSON.stringify({ tk, modal: { open: modal.open, paused: modal.paused } }));
    await page.evaluate(() => closeM());
    const bb = await page.evaluate(() => { switchTab('td'); const r = document.getElementById('bb').getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height), cx: Math.round(r.left + r.width / 2), vw: window.innerWidth }; });
    rec(45, '樽の画像を画面中央に大きく（高さ200px以上・押せる範囲は樽の絵の幅・中心が画面中央±10px）', bb.h >= 200 && Math.abs(bb.w / bb.h - 346 / 469) < 0.02 && Math.abs(bb.cx - bb.vw / 2) <= 10, JSON.stringify(bb));
    const op = await page.evaluate(() => {
      const a = fmt(1234567); G.opt.money = 'ja'; const b = fmt(1234567), c = fmt(3.2e9), d = fmt(999); G.opt.money = 'en';
      G.opt.fs = 'l'; applyOpt(); const big = document.documentElement.classList.contains('fs-l'); G.opt.fs = 'm'; applyOpt();
      return { a, b, c, d, big };
    });
    rec(46, '設定：金額の表記（$1.23M / $123万 / $32億）と文字：大', op.a === '$1.23M' && op.b === '$123万' && op.c === '$32億' && op.d === '$999' && op.big, JSON.stringify(op));
    await ctx.close();
    if (errors.length) rec('E12', 'P1テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 遊びの厚み（P3）と保全（P2） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      // #47 章の目標
      const c0 = G.cash; G.stats.orders = 1; G.fac.distillation.p = true; G.stats.filled = 1; G.stats.shipped = 100;
      checkChapters();
      const st = G.chap; const claimed = !!st.claimed[1]; const gain = G.cash - c0;
      T(47, '章の目標：達成ごとに報酬・4つで章完了（演出を予約）', claimed && Math.abs(gain - 8000) < 1e-6 && _celebQ.length + (_celebOn ? 1 : 0) >= 1, 'gain=' + gain + ' claimed=' + claimed);
      _celebQ = []; celebClose();
      // #48 仕上げの樽
      G.dl = 2; G.cash = 1e7; G.te = 1e9; G.uw = ['jack_d'];
      const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 6; G.lots = [l];
      const f0 = lotFlavor(l); const elig0 = lotsFor('jack_d').length;
      const ok = lotFinish(l.id, 'sherry'); const f1 = lotFlavor(l);
      l.age = 7; const f2 = lotFlavor(l); l.age = 9; const f3 = lotFlavor(l);
      const again = lotFinish(l.id, 'wine');
      const sh = caskType('sherry').flavorMod.fruity;
      T(48, '仕上げ：風味を引き継ぎ、移した樽の風味が2年で満ちる・1回のみ・バーボン銘柄から外れる', ok && Math.abs(f1.fruity - f0.fruity) < 1e-6 && Math.abs(f2.fruity - (f0.fruity + sh / 2)) < 1e-6 && Math.abs(f3.fruity - Math.min(100, f0.fruity + sh)) < 1e-6 && !again && elig0 === 1 && lotsFor('jack_d').length === 0 && G.stats.finishes === 1, JSON.stringify({ f0: f0.fruity, f1: f1.fruity, f2: f2.fruity, f3: f3.fruity, again }));
      // #49 名樽と愛好会
      const n1 = makeLot(caskType('bourbon'), caskSize('hogshead')); n1.age = 14;
      const n2 = makeLot(caskType('bourbon'), caskSize('hogshead')); n2.age = 14;
      G.lots = [n1, n2]; lotName(n1.id, 'はじまりの一樽'); trackNamed();
      const o = { id: 'o_s', cid: 'society', kind: 'cask', minAge: 12, qty: 1, rq: 1, mult: 2, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o]; const m = ordMatch(o);
      const ratio = m.cash / (lotValue(n2) * 2);
      const lim0 = G.stats.limited || 0;
      ordDeliver('o_s', null); trackNamed();
      T(49, '名樽：名前を付けると愛好会が1.2倍で買い取り、蔵出しで記録に残る', m.lot === n1 && Math.abs(ratio - 1.2) < 1e-6 && G.stats.named === 1 && G.stats.limited === lim0 + 1 && G.caskLog.length === 1 && G.caskLog[0].name === 'はじまりの一樽', JSON.stringify({ ratio, log: G.caskLog }));
      // #50 取引先の人物
      G.relEvQ = []; G.rel.local = { lv: 2, done: 14 }; relAdd('local', 1);
      const q = G.relEvQ.slice(); const b0 = G.orders.length;
      relEventApply('local', 3);
      T(50, '取引先：関係★3で人物の会話が予約され、特別な予約注文が届く', q.length === 1 && q[0].lv === 3 && G.orders.length === b0 + 1 && G.orders[G.orders.length - 1].reserve, JSON.stringify(q));
      // #51 月替わりの市場
      _mktOff = false; G.awardMult = {};
      const u = (m) => { _mktForce = m; prodInvalidate(); return priceUnit('glenlivid', 8, 1, productSpec('glenlivid').target); };
      const base = u(2), dec = u(12), jul = u(7), nov = u(11);
      const nov12 = (() => { _mktForce = 11; return priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target); })();
      _mktForce = 2; const nov12b = priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target);
      _mktForce = 4; const tour = cv(); _mktForce = 2; const tour0 = cv();
      _mktForce = 0; _mktOff = true;
      T(51, '月替わりの市場：12月は単価×1.12、7月は10年未満×1.15、11月は12年以上だけ×1.12、4月はツアー×2', Math.abs(dec / base - 1.12) < 1e-9 && Math.abs(jul / base - 1.15) < 1e-9 && Math.abs(nov / base - 1) < 1e-9 && Math.abs(nov12 / nov12b - 1.12) < 1e-9 && Math.abs(tour / tour0 - 2) < 1e-9, [dec / base, jul / base, nov12 / nov12b, tour / tour0].map(x => x.toFixed(3)).join(','));
      // #52 記録
      G.records = {}; G.runStart = Date.now() - 5 * 864e5; recordTier(2); recordUnit(1234);
      const rc = G.records[G.climate];
      T(52, '気候ごとの記録：昇格までの日数と最高単価', rc && rc.tierDays[2] === 5 && rc.bestUnit === 1234, JSON.stringify(rc));
      // #53 来客
      const cash0 = G.cash; const el = document.createElement('button'); el.dataset.vip = ''; el.id = 'vis_t'; document.body.appendChild(el);
      visitorTap(el);
      T(53, '見学ツアーの来客をタップするとチップ（タップ15回分）', Math.abs(G.cash - cash0 - cv() * 15) < 1e-6, G.cash - cash0);
      // #54 景色
      const tb = [3, 6, 12, 17, 22].map(h => sceneTime(h)).join(',');
      switchTab('td'); rdistLight(); const sc = document.getElementById('scene'); const cs = getComputedStyle(sc);
      const bgOk = /data:image\/webp/.test(cs.backgroundImage) && cs.backgroundSize === 'cover';
      const cls = sc.className === 'scene t-' + sceneTime(); const f = getComputedStyle(sc).filter;
      T(54, '景色：蒸留所の絵を表示し、時間帯（朝・昼・夕・夜）で明るさと色味を変える', tb === 'night,am,day,eve,night' && bgOk && cls && f !== 'none', tb + ' / ' + sc.className + ' / ' + f);
      // #55 引き継ぎコード
      const code = encodeCode(JSON.stringify({ a: 1, t: 'ウイスキー' }));
      const back = decodeCode(code);
      let tamper = ''; try { decodeCode(code.slice(0, 10) + (code[10] === 'A' ? 'B' : 'A') + code.slice(11)); } catch (e) { tamper = e.message; }
      let cut = ''; try { decodeCode(code.slice(0, 20)); } catch (e) { cut = e.message; }
      T(55, '引き継ぎコード：往復で一致・改変や欠けは検出して理由を示す', back.t === 'ウイスキー' && /変更|切れ/.test(tamper) && cut.length > 0, tamper + ' / ' + cut);
      // #56 自動バックアップ
      for (let i = 0; i < 3; i++) localStorage.removeItem(bkKey(i));
      const a1 = autoBackup(false), a2 = autoBackup(false), a3 = autoBackup(true), a4 = autoBackup(true), a5 = autoBackup(true);
      const list = bkList();
      T(56, '自動バックアップ：6時間おき・最大3つを入れ替え', a1 && !a2 && a3 && a4 && a5 && list.length === 3, JSON.stringify([a1, a2, a3, a4, a5, list.length]));
      // #57 独自銘柄
      const real = ['Glenlivet', 'Glenfiddich', 'Johnnie Walker', 'Chivas', 'Macallan', 'Laphroaig', 'Ardbeg', 'Talisker', 'Balvenie', 'Dalmore', 'Jameson', 'Bushmills', "Jack Daniel", "Maker's Mark", 'Buffalo Trace', 'Pappy', 'Yamazaki', 'Hakushu', 'Hibiki', 'Nikka', 'Suntory', 'Crown Royal'];
      const names = WL.map(w => w.name + ' ' + w.rg).join('|');
      const hit = real.filter(n => names.toLowerCase().includes(n.toLowerCase()));
      T(57, '25銘柄が独自の名前（実在ブランド名・蒸留所名を含まない）', hit.length === 0 && WL.every(w => WL_RENAME[w.id]), hit.join(','));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E13', 'P2/P3テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- schema 8 → 9 の移行 ----------
  {
    const v8 = { ver: 8, cash: 777, te: 5000, dl: 2, uw: ['glenlivid'], lots: [], bottles: [], orders: [], stats: { orders: 3, shipped: 150, filled: 2 }, fac: { malting: { l: 3, p: true }, distillation: { l: 1, p: true } }, tut: { done: { first: true }, q: [], seed: false }, auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: true, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('z')){sessionStorage.setItem('z','1');localStorage.setItem('we_sound','off');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v8))});}`;
    const { page, errors } = await newPage(browser, pre);
    await page.waitForTimeout(2600);
    const r = await page.evaluate(() => ({ ver: G.ver, se: G.opt.se, bgm: G.opt.bgm, bk: !!localStorage.getItem('we_v4_bak8:guest'), claimed: G.chap.claimed, done: Object.keys(G.chap.done).length, cash: G.cash, seed: G.chap.seed, fill: G.auto.fill.on }));
    rec(58, 'v4.1（schema8）からの移行：バックアップ・音はOFFを引き継ぐ・達成済みの章目標は報酬なしで既読', r.ver === 10 && r.se === 0 && r.bgm === 0 && r.bk && r.claimed[1] === true && r.cash < 2000 && !r.seed && !r.fill, JSON.stringify(r));
    if (errors.length) rec('E14', '移行テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 文字：大 で横スクロールしない ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      G.opt.fs = 'l'; applyOpt(); const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth }); }
      return res;
    });
    const bad = r.filter(x => x.over > 1 || x.doc > 1);
    rec(59, '文字：大・幅360pxでも横スクロールなし', bad.length === 0, JSON.stringify(bad));
    if (errors.length) rec('E15', '文字：大テスト中のエラー', false, errors.join(' | '));
  }
  // ================= v4.3 追加テスト =================
  const STATE = function (mode) {
    if (_offlineGate) closeOfflineModal(); closeM();
    Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose();
    _mktOff = true;
    if (mode === 'fresh') { prodInvalidate(); rall(); return; }
    const late = mode === 'late';
    G.dl = late ? 5 : 3; G.cash = late ? 5e11 : 8e7; G.te = late ? 5e12 : 5e8; G.reputation = late ? 260 : 60;
    G.stats.shipped = late ? 150000 : 2500; G.stats.orders = late ? 120 : 22;
    FD.forEach((f, i) => { G.fac[f.id].p = true; G.fac[f.id].l = (late ? [48, 46, 49, 45, 40, 38] : [24, 22, 26, 21, 18, 14])[i]; });
    G.branch.malting = 1; G.branch.fermentation = 0; G.branch.distillation = late ? 1 : null;
    G.uw = WL.slice(0, late ? 40 : 14).map(w => w.id);
    const mk = (c, s, age) => { const l = makeLot(caskType(c), caskSize(s)); l.age = age; l.L = l.L0 * Math.pow(0.984, age); return l; };
    G.lots = [mk('sherry', 'hogshead', 12.4), mk('bourbon', 'hogshead', 9.1), mk('bourbon', 'quarter', 4.6), mk('wine', 'barrel', 2.2), mk('bourbon', 'butt', 7.8), mk('sherry', 'hogshead', 0.4)];
    const nl = late ? whSlots() - 6 : 10;
    for (let i = 0; i < nl; i++) G.lots.push(mk('bourbon', 'hogshead', 1 + (i % 25) * 1.1));
    G.tank = late ? tankCap() * 0.7 : 1800;
    const t = productSpec('glenlivid').target;
    invAdd('glenlivid', 140, 9, 1.05, t); invAdd('jack_d', 60, 5, 1.0, productSpec('jack_d').target); invAdd('johnnie_em', 25, 12, 1.1, productSpec('johnnie_em').target);
    if (late) { invAdd('hibikue', 80, 17, 1.12, productSpec('hibikue') ? productSpec('hibikue').target : t); }
    G.orders = [];
    for (let i = 0; i < boardSize(); i++) { const o = ordGenerate(); if (o) G.orders.push(o); }
    if (G.orders[0]) { G.orders[0].reserve = true; G.orders[0].accepted = false; }
    G.rel.local = { lv: 2, done: 9 }; G.rel.bar = { lv: 1, done: 4 };
    G.shipLog = { glenlivid: { t: Date.now(), maxAge: 9 }, jack_d: { t: Date.now(), maxAge: 5 } };
    G.bq = [{ id: 'q_x', pid: 'glenlivid', n: 300, done: 120, moved: 120, age: 9, q: 1.05, fl: t, blend: null, oid: null }];
    G.blendHistory = [{ t: Date.now(), target: 'classic_blend', score: 0.82, n: 120 }];
    G.lots[0].name = 'はじまりの一樽'; G.lots[1].fin = { from: 'bourbon', at: 8 };
    G.chap.seed = true; checkChapters();
    prodInvalidate(); rall();
  };
  async function page43(H, rm, mode) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: H }, reducedMotion: rm || 'no-preference' });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
    if (mode) { await page.evaluate(`(${STATE.toString()})(${JSON.stringify(mode)})`); await page.waitForTimeout(500); await page.evaluate(() => { _celebQ = []; celebClose(); closeM(); }); }
    return { page, errors, ctx };
  }
  // ---------- #60 よく使う4タブはスクロールなし（2画面×3状態×4タブ） ----------
  {
    const bad = []; const errs = []; let n = 0; const lists = [];
    for (const H of [667, 740]) for (const mode of ['fresh', 'mid', 'late']) {
      const { page, errors, ctx } = await page43(H, null, mode);
      const r = await page.evaluate(async () => { const o = {}; for (const t of ['td', 'tb', 'tcel', 'tsale']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); o[t] = el.scrollHeight - el.clientHeight; }
        switchTab('tcel'); await new Promise(r => setTimeout(r, 100)); const w = document.getElementById('whSummary'); w.scrollTop = 1e6; const wEnd = w.scrollTop + w.clientHeight >= w.scrollHeight - 2;
        switchTab('tsale'); await new Promise(r => setTimeout(r, 100)); const ob = document.getElementById('orderBoard'); ob.scrollTop = 1e6; const oEnd = ob.scrollTop + ob.clientHeight >= ob.scrollHeight - 2; const last = ob.lastElementChild; const lr = last && last.getBoundingClientRect(), obr = ob.getBoundingClientRect();
        return { o, wEnd, oEnd, lastVisible: !last || (lr.bottom <= obr.bottom + 1), cards: ob.children.length, casks: document.querySelectorAll('#whSummary .ck').length }; });
      Object.keys(r.o).forEach(t => { n++; if (r.o[t] > 0) bad.push(mode + H + ':' + t + '+' + r.o[t]); });
      if (mode === 'late') lists.push(r);
      errs.push(...errors); await ctx.close();
    }
    rec(60, 'よく使う4タブはスクロールなし（390×667・390×740 × 開始直後・中盤・終盤 = 24通り）', n === 24 && bad.length === 0, JSON.stringify({ n, bad }));
    rec('60b', '件数が多い一覧（樽・注文）は枠の中で最後までスクロールできる', lists.length === 2 && lists.every(l => l.wEnd && l.oEnd && l.lastVisible && l.casks >= 20), JSON.stringify(lists));
    if (errs.length) rec('E20', '1画面テスト中のエラー', false, errs.slice(0, 3).join(' | '));
  }
  // ---------- #61-62 TIPS帯は常に流れる ----------
  {
    const out = [];
    for (const rm of ['no-preference', 'reduce']) {
      const { page, errors, ctx } = await page43(740, rm);
      await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } });
      await page.evaluate(() => { const L = TICKER_MSGS.slice().sort((a, b) => b.text.length - a.text.length)[0]; tkPick = () => L; nextTicker(); });
      await page.waitForTimeout(300);
      if (rm === 'reduce') {
        const box = await page.locator('#ticker').boundingBox();
        await page.mouse.move(box.x + 200, box.y + 10); await page.mouse.down();
        const h1 = await page.evaluate(() => tkTxt.getBoundingClientRect().left); await page.waitForTimeout(700); const h2 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.up(); await page.waitForTimeout(250); const longOpen = await page.evaluate(() => !mo.classList.contains('h'));
        await page.waitForTimeout(500); const h3 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.click(box.x + 200, box.y + 10); await page.waitForTimeout(250); const tapOpen = await page.evaluate(() => !mo.classList.contains('h'));
        rec(62, 'TIPS帯：押している間は止まり、離すと再開・短いタップで全文、長押しでは開かない', Math.abs(h1 - h2) < 3 && h3 < h2 - 8 && !longOpen && tapOpen, JSON.stringify({ h1, h2, h3, longOpen, tapOpen }));
      }
      const a = await page.evaluate(() => { const el = tkTxt; const tr = tkTrack.getBoundingClientRect(); const an = el.getAnimations()[0]; const x0 = el.getBoundingClientRect().left;
        const dur = an ? an.effect.getComputedTiming().duration : 0; if (an) { an.pause(); an.currentTime = dur - 1; }
        const r = el.getBoundingClientRect(); const res = { run: el.classList.contains('run'), anim: getComputedStyle(el).animationName, ell: getComputedStyle(el).textOverflow, w: Math.round(el.offsetWidth), track: Math.round(tr.width), x0: Math.round(x0), endRight: Math.round(r.right), trackLeft: Math.round(tr.left), dur: Math.round(dur), speed: Math.round((tr.width + el.offsetWidth) / (dur / 1000)) };
        return res; });
      await page.evaluate(() => nextTicker()); await page.waitForTimeout(400);
      out.push({ rm, ...a });
      const opts = await page.evaluate(() => { switchTab('tp'); return [...document.querySelectorAll('#optBox [data-k="tk"]')].map(b => b.dataset.v).join(','); });
      out[out.length - 1].opts = opts;
      if (errors.length) rec('E21', 'TIPS帯テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    const ok = out.every(o => o.run && o.anim === 'tkScroll' && o.ell !== 'ellipsis' && o.w > o.track && o.endRight <= o.trackLeft + 2 && o.opts === 'slow,mid,fast');
    const sp = out.map(o => o.speed);
    rec(61, 'TIPS帯：「視差効果を減らす」の端末でも右から左へ流れ、最後の文字まで表示枠を通過する（減らす設定では約0.65倍の速さ・「流さない」は廃止）', ok && sp[1] < sp[0] && sp[1] >= sp[0] * 0.55, JSON.stringify(out));
    const { page, ctx } = await page43(740);
    const mig = await page.evaluate(() => { const s = JSON.parse(JSON.stringify(G)); s.opt.tk = 'still'; return sanitize(s).opt.tk; });
    rec('61b', '保存済みの「流さない」は読込時に「遅い」へ置き換える', mig === 'slow', mig);
    await ctx.close();
  }
  // ---------- #63 ホームのアイコン列 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      switchTab('td'); pushNews('テスト1'); pushNews('テスト2'); rdistLight();
      const icons = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id.replace('hi_', '') + '=' + (b.querySelector('.hib') ? b.querySelector('.hib').textContent : ''));
      const c = chapCur(), st = chapState(); const cn = c.goals.filter(g => st.done[g.id]).length;
      const dn = G.daily.missions.filter(m => m.done).length; const ts = tierReqStatus(G.dl + 1); const tok = ts.filter(o => o.ok).length;
      const expect = ['chap=' + cn + '/4', 'daily=' + dn + '/' + G.daily.missions.length, 'mkt=' + mktDaysLeft() + '日', 'tier=' + tok + '/' + ts.length, 'news=' + _newsUnread];
      const modals = {};
      for (const [k, word] of [['chap', '章の目標'], ['daily', 'デイリーミッション'], ['mkt', '今月の市場'], ['tier', '昇格の条件'], ['news', 'お知らせ']]) {
        closeM(); document.getElementById('hi_' + k).click(); await new Promise(r => setTimeout(r, 80));
        modals[k] = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes(word);
      }
      closeM(); rdistLight();
      const newsAfter = document.querySelector('#hi_news .hib') ? document.querySelector('#hi_news .hib').textContent : '';
      const gone = ['chapCard', 'mktCard', 'tierCard', 'dailyBox', 'homeNews', 'nextUnlock'].filter(id => document.getElementById(id));
      return { icons, expect, modals, newsAfter, gone, nextH: document.getElementById('nextCard') ? 999 : 0 };
    });
    rec(63, 'ホーム：章・デイリー・市場・Tier・お知らせはアイコン＋バッジ（数字は内部状態と一致）で、押すとそれぞれの詳細が開く', r.icons.join() === r.expect.join() && Object.values(r.modals).every(Boolean) && r.newsAfter === '' && r.gone.length === 0 && r.nextH <= 80, JSON.stringify(r));
    if (errors.length) rec('E22', 'アイコン列テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #64 生産ライン ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      switchTab('tb'); const f = prodFlows();
      const flows = [...document.querySelectorAll('#lineView .pflow .pfl')].slice(1).map(e => e.textContent);
      const expFlows = [0, 1, 2].map(i => STAGES[i].out + ' ' + fmtL(f.p[i + 1]) + '/時').concat(['新酒 ' + fmtL(f.newmake) + '/時']);
      const sur = [...document.querySelectorAll('#lineView .pflow')].slice(1).map(e => { const s = e.querySelector('.psur'); return s ? s.textContent : ''; });
      const pm = priceMultBase() * getEventMult('passive');
      const expSur = [0, 1, 2].map(i => f.s[i] > 0.05 ? '余剰 ' + fmtL(f.s[i]) + ' → +' + fmt(f.s[i] * STAGES[i].price * pm) + '/時' : '').concat(['']);
      const bnIdx = [...document.querySelectorAll('#lineView .pst:not(#barleyBox)')].findIndex(e => e.classList.contains('bn'));
      const caps = [...document.querySelectorAll('#lineView .pst:not(#barleyBox) .pcap')].map(e => e.textContent);
      const tank = document.getElementById('tkAmt').textContent === fmtL(G.tank) + ' / ' + fmtL(tankCap());
      const gone = ['fl', 'recipeWrap', 'facEncEl'].filter(id => document.getElementById(id));
      const mat = document.querySelector('#tb #fac_maturation, #tb #fac_bottling');
      return { flows, expFlows, sur, expSur, bnIdx, bn: f.bottleneck, capOk: caps.every((c, i) => c.startsWith('能力 ' + fmtL(f.cap[i]) + '/時')), tank, gone, mat: !!mat };
    });
    const ok = r.flows.join('|') === r.expFlows.join('|') && r.sur.join('|') === r.expSur.join('|') && r.bnIdx === r.bn && r.capOk && r.tank && r.gone.length === 0 && !r.mat;
    rec(64, '生産ライン：工程間の流量・余剰と外販収入・能力・いちばん遅い工程・タンク量が計算値と一致', ok, JSON.stringify(r));
    // 熟成庫とボトリングは各タブで強化できる
    const r2 = await page.evaluate(async () => {
      G.cash = 1e15; G.branch.maturation = 0; G.branch.bottling = 0; rall(); switchTab('tcel'); await new Promise(r => setTimeout(r, 100));
      const m0 = G.fac.maturation.l; document.querySelector('#tcel #fac_maturation [data-act="facUp"]').click();
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const b0 = G.fac.bottling.l; document.querySelector('#tsale #fac_bottling [data-act="facUp"]').click();
      const rc = (() => { switchTab('tb'); document.querySelector('[data-act="rcpBox"]').click(); const ok = !mo.classList.contains('h') && document.querySelectorAll('#mc2 .rc').length === 4; closeM(); return ok; })();
      const bl = (() => { switchTab('tcel'); document.getElementById('btnBlend').click(); const ok = !mo.classList.contains('h') && !!document.querySelector('#mc2 #blendRadar'); closeM(); return ok; })();
      const fc = (() => { document.querySelector('#fillBox [data-act="fillPickT"]').click(); const ok = document.querySelectorAll('#mc2 .ccard').length === CASK_TYPES.length; closeM(); return ok; })();
      const hist = (() => { switchTab('tb'); document.querySelector('[data-act="facHist"]').click(); const ok = document.querySelectorAll('#mc2 #facEncEl > div').length === FD.length; closeM(); return ok; })();
      return { mat: G.fac.maturation.l - m0, bot: G.fac.bottling.l - b0, rc, bl, fc, hist };
    });
    rec(65, '熟成庫は「寝かせる」、ボトリングは「売る」で強化できる・レシピ・ブレンド・樽の選択・設備の歩みはボタンから開く', r2.mat === 1 && r2.bot === 1 && r2.rc && r2.bl && r2.fc && r2.hist, JSON.stringify(r2));
    if (errors.length) rec('E23', '生産ラインテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #66 見学のお客さん ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('td'); G.hs.vis = 0; _vis.list.forEach(v => { const e = document.getElementById(v.id); if (e) e.remove(); }); _vis.list = []; _vis.next = 0;
      const r0 = Math.random; Math.random = () => 0.5; visitorTick(); Math.random = r0;
      await new Promise(r => setTimeout(r, 600));
      const v = _vis.list[0]; const el = document.getElementById(v.id); const r = el.getBoundingClientRect(); const bb = document.getElementById('bb').getBoundingClientRect();
      const toastTxt = _news.map(n => n.t).join('|');
      const txt = el.textContent; const expect = '試飲 +' + fmt(cv() * 15);
      const c0 = G.cash; el.click(); await new Promise(r => setTimeout(r, 50));
      return { txt, expect, overlap: !(r.right <= bb.left || r.left >= bb.right || r.bottom <= bb.top || r.top >= bb.bottom), h: Math.round(r.height), gain: G.cash - c0, cv15: cv() * 15, firstToast: toastTxt.includes('見学のお客さん'), seen: G.hs.vis };
    });
    rec(66, '見学のお客さん：吹き出しに「何者か」と報酬額を表示・樽の押せる範囲と重ならない・初回だけ説明が出る', r.txt.includes('見学させて') && r.txt.includes(r.expect) && !r.overlap && r.h >= 44 && Math.abs(r.gain - r.cv15) < 1e-6 && r.firstToast && r.seen === 1, JSON.stringify(r));
    if (errors.length) rec('E24', '見学テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #67 注文カード ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const hs = [...document.querySelectorAll('#orderBoard .oc2')].map(e => Math.round(e.getBoundingClientRect().height));
      const o = G.orders.find(x => !(x.reserve && x.accepted)); const n0 = G.orders.length;
      document.querySelector(`#orderBoard .oc2[data-id="${o.id}"] .ocl`).click(); await new Promise(r => setTimeout(r, 50));
      const modal = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes('見送る') && document.getElementById('mc2').textContent.includes(custById(o.cid).name);
      document.querySelector('#mc2 [data-act="ordDismissM"]').click(); await new Promise(r => setTimeout(r, 50));
      return { hs, modal, removed: G.orders.length === n0 - 1 && !G.orders.some(x => x.id === o.id), closed: mo.classList.contains('h') };
    });
    rec(67, '注文カード：1枚100px以下に圧縮・押すと詳細（人物・会話・見送る）が開き、見送ると消える', r.hs.length > 0 && r.hs.every(h => h <= 100) && r.modal && r.removed && r.closed, JSON.stringify(r));
    if (errors.length) rec('E25', '注文カードテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #68 生産の流れ（ホーム上部）の単位 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => { switchTab('td'); G.bq = []; rdistLight(); return [...document.querySelectorAll('#flow .fnode .fv')].map(e => e.textContent).concat([fmtL(prodFlows().newmake), fmtL(G.tank), G.lots.length + '/' + whSlots(), fmtN(G.bottles.reduce((a, r) => a + r.n, 0)) + '本', G.orders.length + '件']); });
    const got = r.slice(0, 5), exp = r.slice(5);
    rec(68, 'ホーム上部の流れ：生産L/時・タンクL・樽数/上限・瓶の本数・注文件数を単位つきで表示', got.join('|') === exp.join('|'), JSON.stringify({ got, exp }));
    await ctx.close();
  }
  // ---------- #69 v4.2 からの更新案内・金額の単位 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      const s = JSON.parse(JSON.stringify(G)); s.tut.done = { first: true }; s.tut.q = []; delete s.hs;
      const g = sanitize(s); const old = TUTS.u43.cond.call(null);
      const G0 = G; G = g; const condOld = TUTS.u43.cond(); G = G0;
      const fresh = defState(); G = fresh; fresh.tut.done.first = true; const condFresh = TUTS.u43.cond(); G = G0;
      const en = fmtEn(3.1e19), en2 = fmtEn(4.2e15), en3 = fmtEn(5e12);
      G.opt.money = 'ja'; const ja = fmt(3.1e19), ja2 = fmt(2.5e22); G.opt.money = 'en';
      return { condOld, condFresh, en, en2, en3, ja, ja2 };
    });
    rec(69, 'v4.2のセーブには変更点の案内を1回出し、新規には出さない', r.condOld === true && r.condFresh === false, JSON.stringify(r));
    rec(70, '大きな金額の単位（$31.00Qi・$4.20Qa・$5.00T／$3,100京・$250垓）', r.en === '$31.00Qi' && r.en2 === '$4.20Qa' && r.en3 === '$5.00T' && r.ja === '$3,100京' && r.ja2 === '$250垓', JSON.stringify(r));
    if (errors.length) rec('E26', '更新案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.4 追加テスト =================
  // ---------- #71 設定の選択表示 ----------
  {
    const { page, errors, ctx } = await page43(667);
    await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } switchTab('tp'); });
    const keys = await page.evaluate(() => [...document.querySelectorAll('#optBox [data-act="optSet"]')].map(b => b.dataset.k + '|' + b.dataset.v));
    const bad = [];
    for (const kv of keys) {
      const [k, v] = kv.split('|');
      await page.click(`#optBox [data-k="${k}"][data-v="${v}"]`); await page.waitForTimeout(120);
      const r = await page.evaluate(([k, v]) => { const b = document.querySelector(`#optBox [data-k="${k}"][data-v="${v}"]`); const sib = [...document.querySelectorAll(`#optBox [data-k="${k}"]`)].filter(x => x !== b); return { on: b.classList.contains('on') && b.getAttribute('aria-pressed') === 'true' && b.textContent.startsWith('✓'), others: sib.every(x => !x.classList.contains('on') && x.getAttribute('aria-pressed') === 'false'), bg: getComputedStyle(b).backgroundColor, bg2: sib[0] ? getComputedStyle(sib[0]).backgroundColor : '' }; }, [k, v]);
      if (!r.on || !r.others || r.bg === r.bg2) bad.push(kv + JSON.stringify(r));
    }
    await page.evaluate(() => { opt().theme = 'dark'; opt().motion = 'std'; applyOpt(); });
    rec(71, '設定：どの項目も押した直後に選択表示（塗りつぶし・✓・aria-pressed）が切り替わる', keys.length >= 14 && bad.length === 0, JSON.stringify({ n: keys.length, bad: bad.slice(0, 3) }));
    if (errors.length) rec('E30', '設定テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #72-73 クリティカル廃止・歯車・図鑑 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const base = cv(); const c0 = G.cash; for (let i = 0; i < 1000; i++) tap(null);
      const gear = document.getElementById('btnGear').textContent.trim();
      switchTab('te'); _ui.encTab = 'w'; renc();
      const cards = document.getElementById('wg').textContent;
      return { gain: G.cash - c0, expect: base * 1000, base, tapBase: BALANCE.TAP_BASE, crit: typeof BALANCE.CRIT_CHANCE, gear, glass: cards.includes('🥃'), q: cards.includes('❓'), n: document.querySelectorAll('#wg .wc').length };
    });
    rec(72, 'タップ：クリティカル廃止（1,000回で常に基本額×回数）・基本額は1.5倍', Math.abs(r.gain - r.expect) < 1e-6 && r.tapBase === 4.5 && r.crit === 'undefined', JSON.stringify(r));
    rec(73, 'ヘッダーの歯車は絵文字・図鑑のカードにグラスや色の絵文字がない', r.gear === '⚙️' && !r.glass && !r.q && r.n === 25, JSON.stringify(r));
    if (errors.length) rec('E31', '小修正テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #74 タブの印 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const bd = () => ['td', 'tb', 'tcel', 'tsale'].map(t => t + '=' + document.getElementById('bd_' + t).textContent + (document.querySelector(`#nav .nb[data-tab="${t}"]`).classList.contains('att') ? '*' : '')).join(' ');
      G.tut.q = []; updNavBadges(); const m1 = tabMarks(); const s1 = bd();
      const exp = t => { const x = m1[t]; return x.u ? '!' : x.n ? String(x.n) : ''; };
      const match = ['td', 'tb', 'tcel', 'tsale'].every(t => document.getElementById('bd_' + t).textContent === exp(t));
      // 何もできない状態：印なし
      G.orders = []; G.bq = []; G.cash = 0; G.branch.mashing = 0; G.branch.distillation = 0; G.branch.maturation = 0; G.branch.bottling = 0; G.auto.fill.on = true; G.hs.casks = CASK_TYPES.map(t => t.id).concat(CASK_SIZES.map(z => z.id)); G.lots = G.lots.slice(0, 3); prodInvalidate(); updNavBadges(); const s2 = bd();
      // 大麦切れ：造るに「!」
      barleyState().kg = 0; prodInvalidate(); updNavBadges(); const s3 = bd();
      const noSlotCount = !/tcel=\d/.test(s2);
      return { s1, match, s2, s3, noSlotCount };
    });
    rec(74, 'タブの印：件数は操作候補と一致・待つだけなら印なし（空き枠数は出さない）・大麦切れで造るに「!」', r.match && r.s2 === 'td= tb= tcel= tsale=' && /tb=!\*/.test(r.s3) && r.noSlotCount, JSON.stringify(r));
    if (errors.length) rec('E32', 'タブの印テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #75-76 大麦 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = {};
      o.start = { kg: barleyState().kg, cap: barleyCap(), auto: barleyState().auto };
      G.fac.malting.l = 1; G.cash = 100000; prodInvalidate();
      const f = prodFlows(); const pr = barleyPrice(); const c0 = G.cash, s0 = G.stats.barleyCost;
      prodTick(3600000);
      o.hour = { use: f.p[0], cost: G.stats.barleyCost - s0, expCost: f.p[0] * pr, net: G.cash - c0, expNet: f.surplusPh * getEventMult('passive') - f.p[0] * pr, kg: barleyState().kg };
      barleyState().auto = false; barleyState().kg = f.p[0] / 2; prodInvalidate(); const t0 = G.cash; prodTick(3600000);
      o.half = { gain: G.cash - t0, exp: f.surplusPh * getEventMult('passive') / 2, kg: barleyState().kg, ok: barleyOK(), p0: prodFlows().p[0] };
      barleyState().auto = true; G.cash = 1e6; barleyState().kg = barleyCap(); G.ls = Date.now() - 12 * 3600000; const s1 = G.stats.barleyCost; offline();
      o.off = { cost: G.stats.barleyCost - s1, exp: f.p[0] * BALANCE.OFFLINE_CAP_H * pr, modal: document.getElementById('mc2').textContent.includes('原料費') };
      if (_offlineGate) closeOfflineModal();
      barleyState().auto = false; barleyState().kg = 0; G.cash = 1e6; G.ls = Date.now() - 5 * 3600000; offline();
      o.stop = document.getElementById('mc2').textContent.includes('大麦が切れて止まっていた時間');
      if (_offlineGate) closeOfflineModal();
      const s = JSON.parse(JSON.stringify(G)); s.ver = 9; delete s.barley; s.opt = { fs: 'm', money: 'en', se: 0, bgm: 0, vib: true, tk: 'mid' };
      const g = parseSave(s); o.mig = { ver: g.ver, barley: g.barley, theme: g.opt.theme, motion: g.opt.motion };
      return o;
    });
    const h = r.hour;
    rec(75, '大麦：製麦した量だけ消費し原料費を払う・在庫が半分なら生産も半分・在庫切れで製麦が止まる', r.start.kg === r.start.cap && r.start.auto && Math.abs(h.cost - h.expCost) < 0.01 && Math.abs(h.net - h.expNet) < 0.01 && Math.abs(r.half.gain - r.half.exp) < 0.01 && !r.half.ok && r.half.p0 === 0, JSON.stringify(r));
    rec(76, '大麦：放置は最大8時間分を消費して報告に原料費を出す・在庫切れの停止時間を報告・schema10へ移行（サイロ満タン・色ダーク）', Math.abs(r.off.cost - r.off.exp) / r.off.exp < 0.01 && r.off.modal && r.stop && r.mig.ver === 10 && r.mig.barley.kg === null && r.mig.barley.auto === true && r.mig.theme === 'dark' && r.mig.motion === 'std', JSON.stringify(r));
    if (errors.length) rec('E33', '大麦テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #77-78 案内 ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { _mktOff = true; window._tutSw = 0; const o = switchTab; switchTab = function (id) { if (new Error().stack.includes('tutShow')) window._tutSw++; return o(id); }; });
    await page.evaluate(() => titleStart(false)); await page.waitForTimeout(1200);
    const tabs = [];
    for (let k = 0; k < 16; k++) {
      const st = await page.evaluate(() => _tut ? { i: _tut.i, tab: document.querySelector('.tab.on').id } : null);
      if (!st) break; tabs.push(st.tab);
      const box = await page.evaluate(() => { const s = tutStep(); const el = s && s.sel ? tutEl(s) : null; if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, do: !!s.do }; });
      if (box && box.do) await page.mouse.click(box.x, box.y); else await page.click('#cNext');
      await page.waitForTimeout(450);
    }
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, sw: window._tutSw, malt: facLv('malting'), orders: G.stats.orders }));
    rec(77, 'はじめての案内：案内がタブを切り替えない（ナビはプレイヤーが押す）・ホーム→売る→造るの順・最後まで進む', r.done && r.sw === 0 && r.malt >= 1 && r.orders >= 1 && tabs[0] === 'td' && tabs.includes('tsale') && tabs[tabs.length - 1] === 'tb', JSON.stringify({ r, tabs: tabs.join('>') }));
    await page.waitForTimeout(2500);
    const w = await page.evaluate(() => ({ q: G.tut.q.slice(), cel: document.getElementById('bd_tcel').textContent, run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    await page.click('#nav .nb[data-tab="tcel"]'); await page.waitForTimeout(900);
    const w2 = await page.evaluate(() => ({ run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    rec(78, '後から出る案内：別のタブにいる間はナビに「新」を付けて待ち、そのタブを開くと始まる', w.q.includes('u_age') && w.cel === '新' && w.run !== 'u_age' && w2.run === 'u_age' && w2.tab === 'tcel', JSON.stringify({ w, w2 }));
    if (errors.length) rec('E34', '案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #79 動き ----------
  {
    const { page, errors, ctx } = await page43(667, 'reduce', 'mid');
    const r = await page.evaluate(async () => {
      switchTab('tb'); await new Promise(r => setTimeout(r, 200));
      const band = document.querySelector('#lineView .pflow.run .pband'); const an = band ? getComputedStyle(band).animationName : 'none';
      const dur = band ? getComputedStyle(band).animationDuration : '';
      G.tut.q = []; updNavBadges(); const att = document.querySelector('#nav .nb.att'); const aan = att ? getComputedStyle(att, '::after').animationName : 'none';
      let conf = null; const oc = celebrate; celebrate({ icon: '🎉', title: 't', sub: '' }); await new Promise(r => setTimeout(r, 100)); conf = document.querySelectorAll('#celebrate .conf i').length; _celebQ = []; celebClose();
      return { an, dur, aan, conf, low: lowMotion() };
    });
    rec(79, '動き：「視差効果を減らす」でも生産ラインの矢印とタブの印はゆっくり動き、紙吹雪は出ない', r.an === 'pflow' && parseFloat(r.dur) >= 1 && r.aan === 'attPulse' && r.conf === 0 && r.low, JSON.stringify(r));
    if (errors.length) rec('E35', '動きテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #80 色（コントラスト）と1画面 ----------
  {
    const out = {}; let overs = [];
    for (const th of ['dark', 'light']) {
      const { page, errors, ctx } = await page43(667, null, 'mid');
      const r = await page.evaluate(async th => {
        opt().theme = th; applyOpt(); _celebQ = []; celebClose(); closeM();
        const parse = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
        const lum = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
        const bgOf = el => { let e = el; while (e) { const cs = getComputedStyle(e); if (cs.backgroundImage && cs.backgroundImage !== 'none') return null; const c = parse(cs.backgroundColor); if (c && c.a >= 0.9) return c; e = e.parentElement; } return parse(getComputedStyle(document.body).backgroundColor); };
        const low = []; let n = 0; const over = {};
        for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
          switchTab(t); await new Promise(r => setTimeout(r, 150)); _celebQ = []; celebClose();
          const el = document.getElementById(t); if (['td', 'tb', 'tcel', 'tsale'].includes(t)) over[t] = el.scrollHeight - el.clientHeight;
          const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let x;
          while (x = w.nextNode()) {
            const p = x.parentElement; if (!p || !x.textContent.trim() || p.getClientRects().length === 0 || p.closest('#stage') || p.closest('button:disabled') || p.closest('.lk') || p.closest('.ca')) continue;
            const cs = getComputedStyle(p); if (parseFloat(cs.opacity) < 1) continue;
            const fg = parse(cs.color); const bg = bgOf(p); if (!fg || !bg) continue; n++;
            const L1 = lum(fg), L2 = lum(bg); const cr = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
            if (cr < 4.5) low.push(t + ':' + cr.toFixed(2) + ':' + x.textContent.trim().slice(0, 10));
          }
        }
        return { n, low: low.slice(0, 10), nLow: low.length, over, theme: document.documentElement.dataset.theme };
      }, th);
      out[th] = r; Object.entries(r.over).forEach(([t, v]) => { if (v > 0) overs.push(th + ':' + t + '+' + v); });
      if (errors.length) rec('E36', '色テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    rec(80, '色：ダーク・ライトとも全タブの文字のコントラスト4.5以上（ライトでも4タブは1画面）', out.dark.nLow === 0 && out.light.nLow === 0 && out.light.theme === 'light' && out.dark.n > 200 && out.light.n > 200 && overs.length === 0, JSON.stringify({ dark: { n: out.dark.n, low: out.dark.low }, light: { n: out.light.n, low: out.light.low }, overs }));
  }
  // ---------- #81 樽の選択欄 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.fac.distillation.p = true; prodInvalidate(); switchTab('tcel'); rCellar();
      const picks = [...document.querySelectorAll('#fillBox .fpick')].map(b => b.textContent.replace(/\s+/g, ''));
      const newBefore = document.querySelectorAll('#fillBox .fnew').length;
      G.te = 2e7; rCellar(); updNavBadges();
      const newAfter = document.querySelectorAll('#fillBox .fpick.new').length; const mark = document.getElementById('bd_tcel').textContent;
      document.querySelector('#fillBox [data-act="fillPickT"]').click(); await new Promise(r => setTimeout(r, 50));
      const cards = document.querySelectorAll('#mc2 .ccard').length; const locked = document.querySelectorAll('#mc2 .ccard.lk').length;
      document.querySelector('#mc2 .ccard[data-id="sherry"]').click(); await new Promise(r => setTimeout(r, 50));
      rCellar(); updNavBadges();
      return { picks, newBefore, newAfter, mark, cards, locked, cask: G.auto.fill.cask, newGone: document.querySelectorAll('#fillBox .fpick.new').length, mark2: document.getElementById('bd_tcel').textContent };
    });
    rec(81, '樽詰め：「樽の種類▾」「サイズ▾」の選択欄・解禁でNEWとタブの印・カードで選べる', r.picks.length === 2 && r.picks.every(p => p.includes('▾')) && r.newBefore === 0 && r.newAfter >= 1 && r.mark !== '' && r.cards === 5 && r.locked >= 1 && r.cask === 'sherry' && r.newGone === 0, JSON.stringify(r));
    if (errors.length) rec('E37', '樽選択テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  await browser.close();
  let pass = 0;
  results.forEach(x => { if (x.ok) pass++; console.log((x.ok ? 'PASS' : 'FAIL') + ' #' + x.id + ' ' + x.name + (x.ok ? '' : '  → ' + x.detail)); });
  console.log(`\n${pass}/${results.length} passed`);
  require('fs').writeFileSync('test_results.json', JSON.stringify(results, null, 1));
})();
