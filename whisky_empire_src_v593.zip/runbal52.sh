#!/bin/bash
# usage: runb2.sh NAME N TAPS HG [env...]
NAME=$1; N=$2; T=$3; HG=$4; shift 4
O=/tmp/claude-0/$NAME; rm -rf $O; mkdir -p $O
cd /home/claude/we
i=1
while [ $i -le $N ]; do
  for j in $(seq 1 ${PAR:-6}); do
    [ $i -le $N ] || break
    ( env "$@" NODE_PATH=/home/claude/.npm-global/lib/node_modules timeout ${TMO:-900} node balance52.js 100 $T x $HG none > $O/raw_$i.txt 2>&1 ) &
    i=$((i+1))
  done
  wait
done
