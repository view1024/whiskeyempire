// 未使用のトップレベル関数を検出する（v4.6.3）
// usage: node deadcode.js [whisky_empire.dev.html]
//  - 本体 <script>（id なし・src なし）を acorn で解析し、トップレベルの function 宣言を集める
//  - 識別子としての参照（自分自身の中の再帰は除く）と、HTML 本文・文字列内の「名前(」を数える
//  - 未使用の関数からしか呼ばれない関数も、繰り返し判定して未使用に含める
//  - テスト・ボット（functest46.js / balance46.js など）から呼ばれる関数は別枠で表示する（削除しない）
const fs = require('fs');
const acorn = require('acorn');
const walk = require('acorn-walk');
const FILE = process.argv[2] || 'whisky_empire.dev.html';
const html = fs.readFileSync(FILE, 'utf8');
const blocks = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
const src = blocks.reduce((a, b) => (b.length > a.length ? b : a), '');
const rest = html.replace(src, '');
const ast = acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script' });

const decls = new Map(); // name -> [{start,end}]
for (const n of ast.body) if (n.type === 'FunctionDeclaration') {
  if (!decls.has(n.id.name)) decls.set(n.id.name, []);
  decls.get(n.id.name).push({ start: n.start, end: n.end });
}
// 参照を「どの関数の中から」かで集計する
const refs = new Map(); // name -> Set(caller or '<top>')
const owner = pos => { for (const [nm, arr] of decls) for (const d of arr) if (pos >= d.start && pos < d.end) return nm; return '<top>'; };
walk.fullAncestor(ast, (node, _st, anc) => {
  if (node.type !== 'Identifier' || !decls.has(node.name)) return;
  const parent = anc[anc.length - 2];
  if (parent && parent.type === 'FunctionDeclaration' && parent.id === node) return; // 宣言そのもの
  if (parent && parent.type === 'MemberExpression' && parent.property === node && !parent.computed) return; // obj.name
  if (parent && parent.type === 'Property' && parent.key === node && !parent.computed && !parent.shorthand) return; // {name:..}
  const who = owner(node.start);
  if (!refs.has(node.name)) refs.set(node.name, new Set());
  refs.get(node.name).add(who);
});
// 文字列リテラル・テンプレート内の「名前(」や HTML 本文での出現も参照として扱う（onclick 等の保険）
const strRefs = new Set();
walk.full(ast, node => {
  let s = null;
  if (node.type === 'Literal' && typeof node.value === 'string') s = node.value;
  if (node.type === 'TemplateElement') s = node.value.cooked || node.value.raw;
  if (!s) return;
  for (const nm of decls.keys()) if (new RegExp('\\b' + nm + '\\s*\\(').test(s)) strRefs.add(nm);
});
for (const nm of decls.keys()) if (new RegExp('\\b' + nm + '\\b').test(rest)) strRefs.add(nm);

const dead = new Set();
let changed = true;
while (changed) {
  changed = false;
  for (const nm of decls.keys()) {
    if (dead.has(nm) || strRefs.has(nm)) continue;
    const callers = [...(refs.get(nm) || [])].filter(c => c !== nm && !dead.has(c));
    if (callers.length === 0) { dead.add(nm); changed = true; }
  }
}
const testSrc = ['functest46.js', 'balance46.js', 'pxcontrast.js', 'v43.js', 'shots46.js', 'shots461.js'].filter(f => fs.existsSync(f)).map(f => fs.readFileSync(f, 'utf8')).join('\n');
const out = [];
for (const nm of dead) {
  const bytes = decls.get(nm).reduce((a, d) => a + (d.end - d.start), 0);
  const inTest = new RegExp('\\b' + nm + '\\b').test(testSrc);
  out.push({ name: nm, bytes, dup: decls.get(nm).length, usedByTests: inTest });
}
out.sort((a, b) => b.bytes - a.bytes);
const del = out.filter(x => !x.usedByTests), keep = out.filter(x => x.usedByTests);
const dups = [...decls].filter(([, a]) => a.length > 1).map(([n, a]) => n + '×' + a.length);
console.log(JSON.stringify({ file: FILE, functions: decls.size, deadRemovable: del, deadButUsedByTests: keep, removableBytes: del.reduce((a, x) => a + x.bytes, 0), duplicateDecls: dups }, null, 1));
