// ============================================================
// v5.0 職人の配置：設備（製麦室・糖化槽・発酵槽・蒸留器・ボトリング）か樽に1人ずつ置く
//  - 倍率 m = 1.10 + 0.40×(0.5×(能力−1)/9 + 0.5×(Lv−1)/9)（1.10〜1.50）
//    能力：製麦室＝目利き、ほかの設備＝手際、樽＝技。未配置・研修中・休業中は 1.00
//  - あなた（蒸留所の主）は Tier1 から配置でき、1.10 で固定（給与がないので休業の影響もない）
//  - 設備は工程の能力（stageCapAt）か瓶詰めの速さ（botRate）、樽は熟成（agingRate）に掛かる
//    天使の分け前は熟成の経過年数ごとに減るので、熟成1年あたりの減り方は配置しても同じ
//  - 1か所に1人。先客がいる所へ動かすと入れ替わる。担当の樽が目標に届いても担当はそのまま
// ============================================================
const V50={M_MIN:1.10,M_SPAN:0.40,OWNER_M:1.10,FACS:['malting','mashing','fermentation','distillation','bottling']};
const FAC_ST={malting:'mekiki',mashing:'tegiwa',fermentation:'tegiwa',distillation:'tegiwa',bottling:'tegiwa'};

// ---------- 配置の対応表（配置先 → 人） ----------
let _placeMap=null,_placeSkip=null;
function placeKey(at){return at?at.k+':'+at.id:'';}
function placeInvalidate(){_placeMap=null;}
function placeOf(w){return w===OWNER?(G.ownerAt||null):(w&&w.at)||null;}
function placeSetRaw(w,at){if(w===OWNER)G.ownerAt=at||null;else w.at=at||null;}
function placeMap(){
  if(_placeMap)return _placeMap;
  const m={};if(G.ownerAt)m[placeKey(G.ownerAt)]=OWNER;
  staffList().forEach(s=>{if(s.at){const k=placeKey(s.at);if(!m[k])m[k]=s;}});
  return _placeMap=m;
}
function placeWho(k,id){return placeMap()[k+':'+id]||null;}
function placeById(sid){return sid==='owner'?OWNER:staffList().find(s=>s.id===sid)||null;}
function placeStat(at){return at.k==='lot'?'waza':FAC_ST[at.id]||'tegiwa';}
// 能力とLvだけで決まる倍率（研修中・休業中でも表示に使う）
function placeMultBase(w,at){
  if(!w||!at)return 1;if(w===OWNER)return V50.OWNER_M;
  const st=Math.max(1,Math.min(10,(w.st&&w.st[placeStat(at)])||1)),lv=Math.max(1,Math.min(10,w.lv||1));
  return V50.M_MIN+V50.M_SPAN*(0.5*(st-1)/9+0.5*(lv-1)/9);
}
function placeIdleWhy(w,now){if(w===OWNER)return '';if(staffTraining(w,now))return '研修中';if(G.staffOff)return '休業中';return '';}
function placeMult(w,at,now){return placeIdleWhy(w,now)?1:placeMultBase(w,at);}
function facMult(fac){if(_placeSkip===fac)return 1;const w=placeWho('fac',fac);return w?placeMult(w,{k:'fac',id:fac}):1;}
function lotMult(lot){if(!G.ownerAt&&!(G.staff&&G.staff.length))return 1;const w=placeWho('lot',lot.id);return w?placeMult(w,{k:'lot',id:lot.id}):1;}
function placeMultTxt(m){return '×'+m.toFixed(2);}

// ---------- 置ける場所と名前 ----------
function placeOk(at){
  if(!at||typeof at!=='object')return false;
  if(at.k==='fac')return V50.FACS.includes(at.id)&&(at.id==='bottling'||facLv(at.id)>0);
  if(at.k==='lot')return G.lots.some(l=>l.id===at.id);
  return false;
}
function facName(id){const f=FD.find(x=>x.id===id);return f?f.name:id;}
function lotShort(l){return l.name?'「'+l.name+'」':caskLabel(l);}
function placeName(at){
  if(!at)return '待機';
  if(at.k==='fac')return facName(at.id);
  const l=G.lots.find(x=>x.id===at.id);return l?lotShort(l)+'の樽':'樽';
}
function placeKind(w){const at=placeOf(w);return at?(at.k==='lot'?'lot':at.id):'none';}
function wName(w){return w===OWNER?'あなた':w.nm;}

// ---------- 検証：形・行き先・重複（毎秒・読み込み後・放置の後） ----------
function placeSanitize(){
  const lotIds=new Set(G.lots.map(l=>l.id));const seen=new Set();let changed=false;
  const chk=at=>{
    if(!at||typeof at!=='object')return null;
    if(at.k==='fac'){if(!V50.FACS.includes(at.id)||(at.id!=='bottling'&&facLv(at.id)<=0))return null;}
    else if(at.k==='lot'){if(!lotIds.has(at.id))return null;}
    else return null;
    const k=placeKey(at);if(seen.has(k))return null;seen.add(k);return at;
  };
  const o=chk(G.ownerAt);if(o!==(G.ownerAt||null)){G.ownerAt=o;changed=true;}
  staffList().forEach(s=>{const a=chk(s.at);if(a!==(s.at||null)){
    if(s.at&&s.at.k==='lot'&&!lotIds.has(s.at.id)&&typeof staffJnl==='function')staffJnl(s,'idle');
    s.at=a;changed=true;}});
  if(changed){placeInvalidate();staffInvalidate();}
  return changed;
}

// ---------- 配置する（入れ替え・待機） ----------
function placeSet(w,at,quiet){
  if(!w)return false;
  if(w!==OWNER&&!staffList().includes(w))return false;
  if(at&&!placeOk(at)){if(!quiet)toast('そこには配置できません');return false;}
  const cur=placeOf(w);
  if(placeKey(cur)===placeKey(at))return true;
  const occ=at?placeWho(at.k,at.id):null;
  if(occ&&occ!==w)placeSetRaw(occ,cur?{k:cur.k,id:cur.id}:null);
  placeSetRaw(w,at?{k:at.k,id:at.id}:null);
  placeInvalidate();staffInvalidate();
  if(!quiet){
    let t=at?'👷 '+wName(w)+'を'+placeName(at)+'に配置しました（'+placeMultTxt(placeMultBase(w,at))+'）':'👷 '+wName(w)+'を待機にしました';
    if(occ&&occ!==w)t+=' ・ '+wName(occ)+'は'+(cur?placeName(cur):'待機')+'へ';
    toast(t,2800);
  }
  save();return true;
}

// ---------- 効果の見込み ----------
// 生産の価値（新酒＋余剰の外販、毎時）。_placeSkip の設備だけ倍率を外して比べる
function prodValuePh(){const f=prodFlows();return {nm:f.newmake,v:f.newmake*nmPrice()+f.surplusPh};}
function facGain(fac){
  const i=STAGES.findIndex(s=>s.fac===fac);if(i<0)return null;
  const a=prodValuePh();_placeSkip=fac;prodInvalidate();let b;try{b=prodValuePh();}finally{_placeSkip=null;prodInvalidate();}
  return {nm:a.nm-b.nm,v:a.v-b.v};
}
function placeGainTxt(w){
  const at=placeOf(w);if(!at)return '待機（効果なし）';
  const why=placeIdleWhy(w);if(why)return placeName(at)+' ・ '+why+'（効果なし）';
  const m=placeMult(w,at);let t=placeName(at)+' '+placeMultTxt(m);
  if(at.k==='lot'){const l=G.lots.find(x=>x.id===at.id);if(l&&lotGoalEta(l)>0)t+=' ・ '+l.goal+'年まで あと'+fmtRemain(lotGoalEta(l));else if(l)t+=' ・ 熟成 実1日で'+agingRate(l).toFixed(2)+'年';}
  else if(at.id==='bottling')t+=' ・ 瓶詰め '+fmtN(Math.round(botRate()))+'本/時';
  else{const g=facGain(at.id);if(g)t+=g.nm>1e-6?' ・ 効果 +'+fmt(g.v)+'/時':g.v>1e-6?' ・ 新酒は増えません（余剰の外販 +'+fmt(g.v)+'/時）':' ・ 今は増えません（'+(prodFlows().bottleneck>=0?facName(STAGES[prodFlows().bottleneck].fac)+'がいちばん遅い':'')+'）';}
  return t;
}
// 新酒が増えない設備に置いているか（画面の注意書き用）
function facNoGain(fac){const w=placeWho('fac',fac);if(!w||fac==='bottling'||placeIdleWhy(w))return false;const g=facGain(fac);return !!g&&g.nm<=1e-6;}

// ---------- おまかせ配置（職人だけ。あなたは動かさない） ----------
function placeBest(pool,at){return pool.slice().sort((a,b)=>(placeMultBase(b,at)-placeMultBase(a,at))||((staffTraining(a)?1:0)-(staffTraining(b)?1:0)))[0]||null;}
function placeAutoTargets(pool,taken){
  // 1) いちばん遅い工程が空いていれば、その工程に向いた人を置く（置くたびに計算し直す）
  const out=[];
  for(let g=0;g<4&&pool.length;g++){
    prodInvalidate();const f=prodFlows();if(f.bottleneck<0)break;
    const fac=STAGES[f.bottleneck].fac;const k='fac:'+fac;if(taken.has(k)||!placeOk({k:'fac',id:fac}))break;
    const at={k:'fac',id:fac};const w=placeBest(pool,at);if(!w)break;
    placeSetRaw(w,at);placeInvalidate();taken.add(k);pool.splice(pool.indexOf(w),1);out.push(w);
  }
  // 2) 瓶詰めの予約があればボトリング
  if(pool.length&&G.bq&&G.bq.length&&!taken.has('fac:bottling')){const at={k:'fac',id:'bottling'};const w=placeBest(pool,at);placeSetRaw(w,at);placeInvalidate();taken.add('fac:bottling');pool.splice(pool.indexOf(w),1);out.push(w);}
  // 3) 目標までの残りが短い樽から
  const lots=G.lots.filter(l=>lotGoalEta(l)>0&&!taken.has('lot:'+l.id)).sort((a,b)=>lotGoalEta(a)-lotGoalEta(b));
  for(const l of lots){if(!pool.length)break;const at={k:'lot',id:l.id};const w=placeBest(pool,at);placeSetRaw(w,at);placeInvalidate();taken.add('lot:'+l.id);pool.splice(pool.indexOf(w),1);out.push(w);}
  return out;
}
function placeAuto(quiet){
  const L=staffList();if(!L.length){if(!quiet)toast('職人がいません');return 0;}
  L.forEach(s=>{s.at=null;});placeInvalidate();
  const taken=new Set(G.ownerAt?[placeKey(G.ownerAt)]:[]);
  const pool=L.slice();const out=placeAutoTargets(pool,taken);
  staffInvalidate();save();
  if(!quiet)toast('👷 おまかせで'+out.length+'人を配置しました'+(pool.length?'（待機 '+pool.length+'人）':''),2600);
  return out.length;
}
// 新しく雇った人：空いている配置先のうち、おまかせと同じ順番で最初の所へ
function placeHire(s){
  const taken=new Set(Object.keys(placeMap()));
  const pool=[s];placeAutoTargets(pool,taken);staffInvalidate();
  return s.at;
}

// ---------- 職人の小窓：配置タブ ----------
function placeRowsHtml(){
  const L=staffList();
  const facRow=fac=>{
    const at={k:'fac',id:fac};const ok=placeOk(at);const w=placeWho('fac',fac);
    const i=STAGES.findIndex(s=>s.fac===fac);const bn=i>=0&&prodFlows().bottleneck===i;
    const who=w?`${escapeHtml(wName(w))} <b>${placeMultTxt(placeMult(w,at))}</b>${placeIdleWhy(w)?' ・ '+placeIdleWhy(w):''}`:'空き';
    const note=!ok?'設備がまだありません':w&&facNoGain(fac)?'今は新酒が増えません（いちばん遅い工程に置くと増えます）':'';
    return `<div class="card plc${bn?' bn':''}"><div class="row sb"><span class="tt">${facIc(fac,18)} ${escapeHtml(facName(fac))}${bn?' <span class="pbn">いちばん遅い</span>':''}</span><span class="sm">${ST_LBL[FAC_ST[fac]]}</span></div>
      <div class="row sb" style="margin-top:4px"><span class="sm plw">${who}</span>${ok?`<button type="button" class="sb2 gh" data-act="placePick" data-k="fac" data-id="${fac}">${w?'変更':'配置する'}</button>`:''}</div>${note?`<div class="sm" style="color:var(--amber)">${note}</div>`:''}</div>`;
  };
  let h=`<div class="row sb" style="margin:2px 0 6px"><span class="sm">1か所に1人。倍率は能力とLvで ×1.10〜×1.50</span><button type="button" class="sb2" data-act="placeAuto" ${L.length?'':'disabled'}>おまかせ配置</button></div>`;
  h+=`<div class="sm" style="margin:2px 0 4px;color:var(--text2)">設備（工程の能力・瓶詰めの速さ）</div>`+V50.FACS.map(facRow).join('');
  const onLots=[OWNER].concat(L).filter(w=>{const a=placeOf(w);return a&&a.k==='lot';});
  h+=`<div class="sm" style="margin:8px 0 4px;color:var(--text2)">樽（熟成の速さ・技）</div>`;
  h+=onLots.length?onLots.map(w=>{const at=placeOf(w);const l=G.lots.find(x=>x.id===at.id);if(!l)return '';
    return `<div class="card plc"><div class="row sb"><span class="tt">${escapeHtml(lotShort(l))}</span><span class="sm">${fmtAge(l.age)}${l.goal>0?' / '+l.goal+'年まで あと'+fmtRemain(lotGoalEta(l)):''}</span></div>
      <div class="row sb" style="margin-top:4px"><span class="sm plw">${escapeHtml(wName(w))} <b>${placeMultTxt(placeMult(w,at))}</b>${placeIdleWhy(w)?' ・ '+placeIdleWhy(w):''}</span><button type="button" class="sb2 gh" data-act="placeWho" data-sid="${w.id}">変更</button></div></div>`;}).join(''):'<div class="sm" style="padding:2px 0 6px">樽に配置している人はいません</div>';
  const idle=[OWNER].concat(L).filter(w=>!placeOf(w));
  if(idle.length)h+=`<div class="sm" style="margin:8px 0 4px;color:var(--text2)">待機（効果なし${L.some(s=>!s.at)?'・給与はかかります':''}）</div>`+idle.map(w=>`<div class="row sb card plc"><span class="sm plw">${escapeHtml(wName(w))}${w===OWNER?' ×1.10':' Lv'+w.lv+' ・ 技'+w.st.waza+' 手際'+w.st.tegiwa+' 目利き'+w.st.mekiki}</span><button type="button" class="sb2 gh" data-act="placeWho" data-sid="${w.id}">配置先を選ぶ</button></div>`).join('');
  return h;
}
// 配置先を決めて、人を選ぶ
let _placeRet='staff'; // 配置した後に戻る先：'staff'（職人の小窓）か 'close'（閉じる）
function openPlacePick(at,ret){
  _placeRet=ret||'staff';const back=_placeRet==='staff'?'staffBack':'closeM';
  if(!placeOk(at)){toast('そこには配置できません');return;}
  const cur=placeWho(at.k,at.id);
  const pool=[OWNER].concat(staffList()).filter(w=>w!==cur).sort((a,b)=>placeMultBase(b,at)-placeMultBase(a,at));
  const rows=pool.map(w=>{const a=placeOf(w);return `<button type="button" class="brr" data-act="placeSet" data-sid="${w.id}" data-k="${at.k}" data-id="${at.id}"><span class="brr1">${escapeHtml(wName(w))}${w===OWNER?'':' ・ '+ST_LBL[placeStat(at)]+(w.st[placeStat(at)]||1)+' ・ Lv'+w.lv}${a?'（今は'+escapeHtml(placeName(a))+'）':''}${placeIdleWhy(w)?' ・ '+placeIdleWhy(w):''}</span><span class="brr2">→ ${placeMultTxt(placeMultBase(w,at))}${cur?' ・ '+escapeHtml(wName(cur))+'は'+escapeHtml(a?placeName(a):'待機')+'へ':''}</span></button>`;}).join('');
  openModal(`<div class="mt">👷 ${escapeHtml(placeName(at))}に配置</div><div class="ms">今：${cur?escapeHtml(wName(cur))+' '+placeMultTxt(placeMult(cur,at)):'空き'} ・ 使う能力：${ST_LBL[placeStat(at)]}</div>
    ${rows||'<div class="sm tc" style="padding:8px">配置できる人がいません</div>'}
    ${cur?`<button type="button" class="btn-cancel" style="width:100%;margin-top:6px" data-act="placeSet" data-sid="${cur.id}" data-k="" data-id="">${escapeHtml(wName(cur))}を待機にする</button>`:''}
    <button type="button" class="cb" data-act="${back}">${back==='closeM'?'閉じる':'戻る'}</button>`);
}
// 人を決めて、配置先を選ぶ
function placeTargets(){
  const t=V50.FACS.filter(f=>placeOk({k:'fac',id:f})).map(f=>({k:'fac',id:f}));
  G.lots.slice().sort((a,b)=>{const ea=lotGoalEta(a)||Infinity,eb=lotGoalEta(b)||Infinity;return ea-eb||b.age-a.age;}).forEach(l=>t.push({k:'lot',id:l.id}));
  return t;
}
function openPlaceTargets(w,ret){
  if(!w)return;const cur=placeOf(w);_placeRet=ret||'staff';const back=_placeRet==='staff'?'staffBack':'closeM';
  const rows=placeTargets().filter(at=>placeKey(at)!==placeKey(cur)).map(at=>{const o=placeWho(at.k,at.id);let sub='';
    if(at.k==='lot'){const l=G.lots.find(x=>x.id===at.id);sub=fmtAge(l.age)+(l.goal>0?' ・ '+l.goal+'年まで あと'+fmtRemain(lotGoalEta(l)):'');}
    else{const i=STAGES.findIndex(s=>s.fac===at.id);sub=(i>=0&&prodFlows().bottleneck===i?'いちばん遅い工程 ・ ':'')+(i>=0?'能力 '+fmtL(stageCap(i))+'/時':'瓶詰め '+fmtN(Math.round(botRate()))+'本/時');}
    return `<button type="button" class="brr" data-act="placeSet" data-sid="${w.id}" data-k="${at.k}" data-id="${at.id}"><span class="brr1">${escapeHtml(placeName(at))}${o?'（'+escapeHtml(wName(o))+'と入れ替え）':''}</span><span class="brr2">${escapeHtml(sub)} → ${ST_LBL[placeStat(at)]} ${placeMultTxt(placeMultBase(w,at))}</span></button>`;}).join('');
  openModal(`<div class="mt">👷 ${escapeHtml(wName(w))}の配置先</div><div class="ms">今：${escapeHtml(placeName(cur))}${w===OWNER?' ・ あなたは ×1.10 で固定':' ・ 技'+w.st.waza+' 手際'+w.st.tegiwa+' 目利き'+w.st.mekiki+' ・ Lv'+w.lv}</div>
    ${rows||'<div class="sm tc" style="padding:8px">配置できる場所がありません</div>'}
    ${cur?`<button type="button" class="btn-cancel" style="width:100%;margin-top:6px" data-act="placeSet" data-sid="${w.id}" data-k="" data-id="">待機にする</button>`:''}
    <button type="button" class="cb" data-act="${back}">${back==='closeM'?'閉じる':'戻る'}</button>`);
}
function bestTargetTxt(st){
  const m=Math.max(st.waza||0,st.tegiwa||0,st.mekiki||0);
  return [st.waza===m?'樽（技）':'',st.tegiwa===m?'設備（手際）':'',st.mekiki===m?'製麦室（目利き）':''].filter(Boolean).join('・');
}

// ---------- data-act ----------
function extAct50(act,b,id){
  switch(act){
    case 'placePick': openPlacePick({k:b.dataset.k,id}); return true;
    case 'placeWho': openPlaceTargets(placeById(b.dataset.sid)); return true;
    case 'placeSet': {const w=placeById(b.dataset.sid);const at=b.dataset.k?{k:b.dataset.k,id}:null;if(placeSet(w,at)){if(_placeRet==='staff'&&staffOn())openStaffModal('post');else closeM();rall();}return true;}
    case 'placePickC': bubClose(); openPlacePick({k:b.dataset.k,id},'close'); return true;
    case 'placeWhoC': bubClose(); openPlaceTargets(placeById(b.dataset.sid),'close'); return true;
    case 'pmStart': pmStart(placeById(b.dataset.sid)); return true;
    case 'pmEnd': pmEnd(); return true;
    case 'pmIdle': {const w=_pm&&placeById(_pm.sid);pmEnd();if(w&&placeSet(w,null))rall();return true;}
    case 'facTap': if(_pm)pmTry({k:'fac',id});else openFacPlace(id); return true;
    case 'placeAuto': placeAuto();openStaffModal('post');rall(); return true;
  }
  if(typeof extAct51==='function'&&extAct51(act,b,id))return true;
  return false;
}

// ---------- 配置モード：「移動」→ 樽か設備を押す（タブを移っても続く） ----------
let _pm=null;
function pmStart(w){
  if(!w)return;_pm={sid:w.id};bubClose();closeM();
  document.body.classList.add('pm');pmBar();
}
function pmEnd(){_pm=null;document.body.classList.remove('pm');const b=$('pmBar');if(b)b.remove();}
function pmBar(){
  if(!_pm)return;const w=placeById(_pm.sid);if(!w){pmEnd();return;}
  let b=$('pmBar');if(!b){b=document.createElement('div');b.id='pmBar';b.className='pmbar';b.setAttribute('role','status');document.body.appendChild(b);}
  const h=`<span class="pmt">👷 <b>${escapeHtml(wName(w))}</b>の配置先を押してください<small>樽は「寝かせる」、設備は「造る」、ボトリングは「売る」</small></span><button type="button" class="sb2 gh" data-act="pmIdle">待機に</button><button type="button" class="sb2" data-act="pmEnd">やめる</button>`;
  if(b._h!==h){b.innerHTML=h;b._h=h;}
}
function pmTry(at){
  if(!_pm)return false;const w=placeById(_pm.sid);
  if(!w){pmEnd();return true;}
  if(!placeOk(at)){toast(at.k==='fac'?'その設備はまだありません（Lv1から配置できます）':'そこには配置できません');return true;}
  pmEnd();if(placeSet(w,at))rall();
  return true;
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&_pm)pmEnd();});

// ---------- 設備のドット絵（造るタブの行・売るタブの瓶詰め） ----------
// 行は毎秒描き直されるので、絵の要素は作り置きして差し込む（動きが途切れないように）
const _pxs=new Map();
function pxSlotKey(fac){
  const on=fac==='bottling'?true:facLv(fac)>0;const w=placeWho('fac',fac);const night=sceneTime()==='night';
  return [fac,on?1:0,w?w.id:'',w?workerAct(w,night):'',night?1:0,lowMotion()?1:0].join('|');
}
function pxSlotHtml(fac){return `<span class="pxslot" data-k="${pxSlotKey(fac)}"></span>`;}
function pxSlotBuild(k){
  const [fac,on,wid,act,night,low]=k.split('|');
  const w=wid?placeById(wid):null;
  const t=document.createElement('div');
  t.innerHTML=`<svg class="pxs" viewBox="0 0 52 44" width="52" height="44" shape-rendering="crispEdges" aria-hidden="true"${night==='1'?' data-night="1"':''}>${pxFacSvg(fac,w?0:10,12,2,on!=='1',low==='1')}${w?pxWorkerAt(w,38,44,act,2,{walk:false,flip:true}):''}</svg>`;
  const el=t.firstChild;el._k=k;return el;
}
function pxSlotFill(root,tab){
  if(!root)return;const now=Date.now();
  root.querySelectorAll('.pxslot').forEach(sl=>{
    const k=sl.dataset.k;let e=_pxs.get(k);
    if(!e){e={el:pxSlotBuild(k),anims:[],t:now};_pxs.set(k,e);if(!lowMotion())pxAnimateIn(e.el,tab,e.anims);}
    e.t=now;if(e.el.parentNode!==sl){sl.textContent='';sl.appendChild(e.el);}
  });
  _pxs.forEach((e,k)=>{if(!e.el.isConnected&&now-e.t>30000){e.anims.forEach(a=>{try{a.cancel();}catch(_){}});_pxs.delete(k);}});
  scenePlay();
}
// 設備を押す：担当と効果、職人を呼ぶ
function openFacPlace(fac){
  const at={k:'fac',id:fac};const ok=placeOk(at);const w=placeWho('fac',fac);
  const i=STAGES.findIndex(s=>s.fac===fac);const f=prodFlows();const bn=i>=0&&f.bottleneck===i;
  const lv=facLv(fac);
  const cap=i>=0?(lv>0?'能力 '+fmtL(stageCap(i))+'/時':'まだ動いていません'):'瓶詰め '+fmtN(Math.round(botRate()))+'本/時'+(lv>0?'':'（手作業）');
  const card=w?`<div class="card"><div class="row sb"><span class="tt">${escapeHtml(wName(w))} ${placeMultTxt(placeMult(w,at))}</span><span class="sm">${ST_LBL[placeStat(at)]}${w===OWNER?'':(w.st[placeStat(at)]||1)+' ・ Lv'+w.lv}</span></div><div class="sm sgn">${escapeHtml(placeGainTxt(w))}</div></div>`
    :`<div class="card"><div class="sm">担当なし。${ok?'職人を置くと'+(i>=0?'この工程の能力':'瓶詰めの速さ')+'が ×1.10〜×1.50 になります'+(i>=0?'（新酒が増えるのは、いちばん遅い工程に置いたときです）':''):'設備が Lv1 になると配置できます'}</div></div>`;
  openModal(`<div class="mt">${facIc(fac,20)} ${escapeHtml(facName(fac))}</div><div class="ms">${lv>0?'Lv'+lv+' ・ ':''}${cap}${bn?' ・ いちばん遅い工程':''} ・ 使う能力：${ST_LBL[FAC_ST[fac]]}</div>${card}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">${ok?`<button type="button" class="btn-ok" data-act="placePickC" data-k="fac" data-id="${fac}">${w?'担当を変える':'職人を呼ぶ'}</button>`:'<span></span>'}<button type="button" class="btn-cancel" data-act="facInfo" data-id="${fac}">設備の詳細</button></div>
    ${w?`<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"><button type="button" class="btn-cancel" data-act="pmStart" data-sid="${w.id}">移動</button><button type="button" class="btn-cancel" data-act="placeSet" data-sid="${w.id}" data-k="" data-id="">待機にする</button></div>`:''}
    <button type="button" class="cb" data-act="closeM">閉じる</button>`);
  _placeRet='close';
}


// ---------- 毎秒 ----------
function v50Tick(){try{if(_pm)pmBar();clBadge();}catch(e){console.warn('v50Tick',e);}}
// v5.0.1 更新のあとは⚙️と「更新履歴」に印だけ付ける（版の案内は出さない）。更新履歴を開くと消える
function clBadge(){const on=!!G&&hsState().cl!==BALANCE.APP_VERSION;const g=$('btnGear');if(g&&g.classList.contains('cln')!==on)g.classList.toggle('cln',on);const c=document.querySelector('[data-act="changelog"]');if(c&&c.classList.contains('cln')!==on)c.classList.toggle('cln',on);}

TUTS.u_place={name:'配置',cond:()=>tutBase()&&!G.tut.done.u50&&G.lots.length>0&&feat('tank'),steps:[
  {tab:'tcel',sel:'#whScene',text:'<b>あなた</b>を押して<b>「移動」</b>、続けて樽か設備を押すと、そこで働きます。'}]};
TIPS.push({id:'place',cat:'寝かせる',t:'配置と熟成',b:'樽に人を置くと、その樽の熟成が速くなります（あなた ×1.10、職人 ×1.10〜×1.50）。熟成1年あたりの天使の分け前は変わらないので、同じ年数に達したときの残量は配置しないときと同じです。'});

// ---------- 樽の小窓：担当の行 ----------
function lotPlaceRowHtml(l){
  const w=placeWho('lot',l.id);const at={k:'lot',id:l.id};
  return `<div class="msr"><div class="msl">担当</div><div class="msv">${w?escapeHtml(wName(w))+' '+placeMultTxt(placeMult(w,at))+(placeIdleWhy(w)?'（'+placeIdleWhy(w)+'）':''):'なし'} <button type="button" class="sb2 gh" data-act="placePickC" data-k="lot" data-id="${l.id}">${w?'変える':'職人を呼ぶ'}</button></div></div>`;
}
