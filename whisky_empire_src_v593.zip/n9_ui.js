// ============================================================
// v4.1 画面描画（改善計画 第5・6・8・9章）
// ============================================================
let _ui={sellTab:'ord',encTab:'w',bot:{pid:null,n:0,mode:'young',sel:[]},blend:{target:'classic_blend',picks:[{lotId:'',L:0},{lotId:'',L:0},{lotId:'',L:0},{lotId:'',L:0}]},sig:{}};
let _pendingMigModal=false;

function setHtml(el,html){if(el&&el._h!==html){el.innerHTML=html;el._h=html;}}
function setText(id,t){const e=$(id);if(e&&e.textContent!==t)e.textContent=t;}
function show(id,on){const e=$(id);if(e){const d=on?'':'none';if(e.style.display!==d)e.style.display=d;}}
function openModal(html,center){$('mc2').innerHTML=html;$('mo').classList.toggle('ctr',!!center);$('mo').classList.remove('h');}
function ib(id){return `<span class="ib" data-act="tip" data-id="${id}">ⓘ</span>`;}
function starQ(q){const n=q<0.95?1:q<1.0?2:q<1.05?3:q<1.12?4:5;return '★'.repeat(n)+'☆'.repeat(5-n);}
function starM(m){return m>=0.9?'★★★':m>=0.7?'★★☆':m>=0.5?'★☆☆':'☆☆☆';}
function flBars(fl,target){
  return '<div class="fl" style="margin:6px 0">'+FL_KEYS.map(k=>{
    const v=Math.round((fl&&fl[k])||0);const t=target?Math.round(target[k]||0):null;
    return `<div class="flr"><div class="fll">${FL_KEY_MAP[k]}</div><div class="flt"><div class="flf" style="width:${v}%"></div>${t!==null?`<i style="position:absolute;left:calc(${t}% - 1px);top:0;bottom:0;width:2px;background:var(--cream)"></i>`:''}</div><div class="flv">${v}${t!==null?'<span style="color:var(--muted)">/'+t+'</span>':''}</div></div>`;
  }).join('')+'</div>';
}
function caskLabel(l){const ct=caskType(l.cask),sz=caskSize(l.size);return ct.icon+' '+ct.name+'×'+sz.name;}
function ageBand(a){return a>=12?'b12':a>=8?'b8':a>=3?'b3':'b0';}
function facEffectText(id,lv){
  const i=STAGES.findIndex(s=>s.fac===id);
  if(i>=0)return '能力 '+fmtL(stageCapAt(i,lv))+'/時';
  if(id==='maturation')return '倉庫 '+Math.floor((BALANCE.WH_BASE+BALANCE.WH_PER_LV*lv)*brMod('maturation','slots'))+'樽';
  if(id==='bottling'){const base=lv>0?BALANCE.BOT_BASE_BPH*Math.pow(BALANCE.CAP_MUL,lv-1):BALANCE.BOT_HAND_BPH;return '瓶詰め '+fmtN(base*brMod('bottling','bph')*(G.dbgMul||1))+'本/時';}
  return '';
}
function ordUsable(o){return !o.reserve||o.accepted;}
function ordEstimate(o){
  const c=custById(o.cid);const pm=c.priceMult*(1+BALANCE.REL_PRICE_STEP*relLv(o.cid))*o.mult;
  if(o.kind==='product'){const sp=productSpec(o.pid);return sp?priceUnit(o.pid,o.minAge,1,sp.target)*o.qty*pm:0;}
  return 0;
}

// ============================================================
// 次の1手（改善計画 5.2）
// ============================================================
function actionList(){
  const now=Date.now();const out=[];
  const f=prodFlows();
  const sorted=G.orders.slice().sort((a,b)=>a.dueAt-b.dueAt);
  sorted.forEach(o=>{
    if(!(o.reserve&&o.accepted)||o.dueAt-now>=24*3600000||ordMatch(o).ok)return;
    const c=custById(o.cid);
    if(!ordInProgress(o)&&ordFulfillPlan(o).ok)out.push({tab:'tsale',urg:1,icon:'⏰',title:'予約の期限が近い注文',sub:c.name+' ・ あと'+fmtRemain(o.dueAt-now),btn:'詰めて納品',act:'ordFill',id:o.id});
    else if(!ordInProgress(o))out.push({tab:'tsale',urg:1,icon:'⏰',title:'予約の期限が近い注文',sub:c.name+' ・ あと'+fmtRemain(o.dueAt-now),btn:'詳細',act:'ordInfo',id:o.id});
  });
  sorted.forEach(o=>{
    if(!ordUsable(o)||!ordMatch(o).ok)return;
    const c=custById(o.cid);const m=ordMatch(o);
    out.push({tab:'tsale',icon:'📦',title:'納品できる注文があります',sub:c.name+' ・ 報酬 '+fmt(m.cash),btn:'納品する',act:o.kind==='cask'?'ordOpen':'ordGo',id:o.id});
  });
  sorted.forEach(o=>{
    if(!ordUsable(o)||ordInProgress(o)||ordMatch(o).ok)return;
    if(!ordFulfillPlan(o).ok)return;
    const c=custById(o.cid);
    out.push({tab:'tsale',icon:'🍾',title:'注文分を瓶詰めできます',sub:c.name+' ・ '+ordLabel(o),btn:'詰めて納品',act:'ordFill',id:o.id});
  });
  if(stageCap(0)>0){const b=barleyState();
    if(!barleyOK())out.push({tab:'tb',urg:1,icon:'🌾',title:'大麦が切れて製麦が止まっています',sub:'仕入れると再開します',btn:'仕入れ',act:'barleyOpen'});
    else if(!b.auto&&barleyHoursLeft()<1)out.push({tab:'tb',urg:1,icon:'🌾',title:'大麦が残り1時間分を切りました',sub:'自動仕入れがOFFです',btn:'仕入れ',act:'barleyOpen'});
    else if(b.auto&&barleyCostPh()>0&&G.cash<barleyCostPh()&&barleyHoursLeft()<2)out.push({tab:'tb',urg:1,icon:'🌾',title:'所持金が大麦1時間分を下回っています',sub:'買える分だけ仕入れて続けます',btn:'見る',act:'barleyOpen'});}
  if(canUpgDist())out.push({tab:'td',icon:'🎉',title:'Tier昇格できます',sub:DL[G.dl].name+'へ',btn:'見る',act:'tierOpen'});
  const bp=FD.find(x=>brPending(x.id));
  if(bp)out.push({tab:facTab(bp.id),icon:'🔧',title:bp.name+'の設備を選べます',sub:'2つから1つを選ぶ',btn:'選ぶ',act:'brOpen',fac:bp.id});
  if(f.newmake>0&&(G.tank||0)>=tankCap()*0.8){
    if(G.lots.length>=whSlots()){
      const m=G.fac.maturation;
      if(m&&m.p&&m.l<facMaxLv()&&!brPending('maturation'))out.push({tab:'tcel',urg:1,icon:'🛢️',title:'倉庫がいっぱいです',sub:'熟成庫を強化すると樽を置けます',btn:fmt(fuc('maturation')),act:'facUp',id:'maturation',dis:G.cash<fuc('maturation')});
      else if(m&&!m.p&&isUL('maturation'))out.push({tab:'tcel',urg:1,icon:'🛢️',title:'倉庫がいっぱいです',sub:'熟成庫を購入すると樽を置けます',btn:fmt(fpc('maturation')),act:'facBuy',id:'maturation',dis:G.cash<fpc('maturation')});
    }else if(!G.auto.fill.on)out.push({tab:'tcel',icon:'🫗',title:'タンクが満杯に近い',sub:'新酒を樽に詰めましょう',btn:'樽に詰める',act:'fillGo'});
  }
  if(feat('tank')&&(caskNew('type')||caskNew('size')))out.push({tab:'tcel',icon:'🛢️',title:'新しい樽が選べます',sub:'樽の種類・サイズから選ぶ',btn:'見る',act:caskNew('type')?'fillPickT':'fillPickS'});
  const buy=FD.find(x=>isUL(x.id)&&!G.fac[x.id].p&&G.cash>=fpc(x.id));
  if(buy)out.push({tab:facTab(buy.id),icon:buy.icon,title:buy.name+'を購入できます',sub:facPurposeText(buy.id),btn:fmt(fpc(buy.id)),act:'facBuy',id:buy.id});
  const up=suggestUpgrade();
  const upKey=up&&(STAGES.findIndex(s=>s.fac===up)===f.bottleneck||facLv(up)===0);
  if(up&&G.cash>=fuc(up))out.push({tab:'tb',soft:!upKey,icon:FD.find(x=>x.id===up).icon,title:FD.find(x=>x.id===up).name+'を強化',sub:facEffectText(up,facLv(up))+' → '+facEffectText(up,facLv(up)+1).replace(/^.+? /,''),btn:fmt(fuc(up)),act:'facUp',id:up});
  sorted.forEach(o=>{if(o.reserve&&!o.accepted){const c=custById(o.cid);out.push({tab:'tsale',icon:'📝',title:'予約注文が届いています',sub:c.name+' ・ 単価×'+o.mult,btn:'詳細',act:'ordInfo',id:o.id});}});
  return out;
}
function facTab(id){return id==='maturation'?'tcel':id==='bottling'?'tsale':'tb';}
// タブの印：急ぎ（!）か、できる操作の件数。soft（最低Lvの強化など常に出るもの）は数えない
function tabMarks(){
  const m={td:{n:0,u:0},tb:{n:0,u:0},tcel:{n:0,u:0},tsale:{n:0,u:0}};
  actionList().forEach(a=>{const t=m[a.tab];if(!t||a.soft||(a.dis&&!a.urg))return;t.n++;if(a.urg)t.u++;});
  return m;
}
// 強化の提案：律速工程 → 未稼働の工程 → いちばん低いLvの工程
function suggestUpgrade(){
  const f=prodFlows();
  const ok=id=>G.fac[id]&&G.fac[id].p&&G.fac[id].l<facMaxLv()&&!brPending(id);
  if(f.bottleneck>=0&&ok(STAGES[f.bottleneck].fac))return STAGES[f.bottleneck].fac;
  const idle=STAGES.find(s=>ok(s.fac)&&G.fac[s.fac].l===0);if(idle)return idle.fac;
  const st=STAGES.filter(s=>ok(s.fac)).sort((a,b)=>G.fac[a.fac].l-G.fac[b.fac].l)[0];
  return st?st.fac:null;
}
function facPurposeText(id){
  return {mashing:'麦芽から麦汁を作る',fermentation:'麦汁を発酵させる',distillation:'新酒（ニューメイク）が生まれる',maturation:'倉庫の枠が増える',bottling:'瓶詰めが速くなる'}[id]||'';
}

// ============================================================
// ホーム
// ============================================================
function flowHtml(){
  const f=prodFlows();const now=Date.now();
  const tankOn=feat('tank');const tp=tankOn?Math.min(100,Math.round((G.tank||0)/tankCap()*100)):0;
  const bot=G.bottles.reduce((a,r)=>a+r.n,0);
  const ready=G.orders.filter(o=>ordUsable(o)&&ordMatch(o).ok).length;
  const urgent=G.orders.some(o=>o.reserve&&o.accepted&&o.dueAt-now<24*3600000&&!ordMatch(o).ok);
  // v5.5 2行（名前・値）。進み具合は下の細い線
  const n=(tab,icon,val,lb,cls,g)=>`<div class="fnode ${cls||''}" data-act="goTab" data-tab="${tab}"><div class="fl2"><span class="fi">${ic(icon,13)}</span>${lb}</div><div class="fv">${val}</div>${g===undefined?'':`<i class="fg"><b style="width:${Math.max(0,Math.min(100,g))}%"></b></i>`}</div>`;
  const ar='<span class="fa">›</span>';
  const slots=whSlots();
  return n('tb','make',f.newmake>0?fmtL(f.newmake):(ti()>0?'準備中':'停止'),f.newmake>0?'生産/時':'生産',f.newmake>0?'':'off')+ar+
    n('tb','tank',tankOn?fmtL(G.tank||0):'—','タンク',!tankOn?'off':(tp>=95&&f.newmake>0?'red':''),tankOn?tp:undefined)+ar+
    n('tcel','cask',G.lots.length+'/'+slots,'樽',G.lots.length>=slots&&f.newmake>0?'red':'',slots?G.lots.length/slots*100:0)+ar+
    n('tsale','bottle',cntShort(bot)+'本','瓶','')+ar+ // v5.9 常に在庫の本数（v5.9.1「詰め中」の表記はやめた）
    n('tsale','order',G.orders.length+'件',ready?'納品可'+ready:'注文',urgent?'red':(ready?'rdy':''));
}
function rdistLight(){
  setText('cvl',fmt(tapValue()));tasteUi();
  setHtml($('flow'),flowHtml());
  const sc=$('scene');if(sc){const tb=sceneTime();const c='scene t-'+tb;if(sc.className!==c){sc.className=c;sc.dataset.time=tb;}}
  setHtml($('homeIcons'),homeIconsHtml());
}
function rdist(){
  const d=DL[G.dl-1];
  setText('dn',d.name+(G.climate&&G.climate!=='speyside'?' '+climate().icon:''));
  setText('dlv',String(G.dl));
  rTapVisuals();
  rdistLight();
  renderDailyPanel();
}

// ============================================================
// 造る
// ============================================================
// v4.3 生産ライン：縦の流れ図。工程ごとに能力バー・強化ボタン、工程間に流量と余剰（外販）を表示
function facBtnHtml(id,cls){
  const s=G.fac[id],l=s.l;
  if(!s.p){if(!isUL(id))return '';const pc=fpc(id);return `<button type="button" class="ub pbtn${G.cash>=pc?'':' ca'} ${cls||''}" data-act="facBuy" data-id="${id}"><span>購入</span><b>${fmt(pc)}</b></button>`;}
  // v5.9 設備の選択が未決でも強化の価格を出す（押すと先に選ぶ小窓 → 選んだら続けて強化。upgFac）
  if(l>=facMaxLv())return `<button type="button" class="ub pbtn mx ${cls||''}" disabled><span>Lv</span><b>最大</b></button>`;
  const uc=fuc(id);return `<button type="button" class="ub pbtn${G.cash>=uc?'':' ca'} ${cls||''}" data-act="facUp" data-id="${id}"><span>${l===0?'稼働':brPending(id)?'選んで強化':'強化'}</span><b>${fmt(uc)}</b></button>`;
}
function lineViewHtml(){
  const f=prodFlows();const pm=priceMultBase()*getEventMult('passive');
  const maxCap=Math.max(1,...f.cap);
  let h=barleyRowHtml();
  STAGES.forEach((st,i)=>{
    const fd=FD.find(x=>x.id===st.fac);const s=G.fac[st.fac];const lv=facLv(st.fac);
    const bn=f.bottleneck===i;const on=s.p&&lv>0;
    const bo=brOpt(st.fac);
    let sub;
    if(!s.p)sub=isUL(st.fac)?facPurposeText(st.fac):'🔒 '+(fd.ul||'');
    else if(!on)sub='未稼働 ・ Lv1で動き出す';
    else sub=fmtL(f.cap[i])+'/時';
    {const w=placeWho('fac',st.fac);if(w&&on)sub=(placeIdleWhy(w)?wName(w)+' '+placeIdleWhy(w):wName(w)+' '+placeMultTxt(placeMult(w,{k:'fac',id:st.fac}))+(facNoGain(st.fac)?'（今は増えません）':''))+' ・ '+sub;}
    h+=`<div class="pst${bn?' bn':''}${on?'':' off'}" id="fac_${st.fac}">
      <div class="pmain" data-act="facInfo" data-id="${st.fac}"><div class="pic pxt" data-act="facTap" data-id="${st.fac}" role="button" aria-label="${escapeHtml(fd.name)}の担当">${pxSlotHtml(st.fac)}${facSeat(st.fac)}</div>
        <div class="ptx"><div class="pnm">${escapeHtml(fd.name)}${s.p?' <span class="plv">Lv'+lv+'</span>':''}${bn?' <span class="pbn">いちばん遅い</span>':''}${brBadge(st.fac)}</div>
        <div class="pbar"><i style="width:${on?Math.max(4,f.cap[i]/maxCap*100):0}%"></i></div>
        <div class="pcap">${escapeHtml(sub)}</div></div></div>${facBtnHtml(st.fac)}</div>`;
    // 工程間の流れ
    const outName=st.out;
    if(i<3){
      const into=f.p[i+1]||0,sur=f.s[i]||0;
      h+=`<div class="pflow${on&&f.p[i]>0?' run '+flowSpd(f.p[i],maxCap):''}"><span class="pband"></span><span class="pfl" title="${escapeHtml(outName)}">${on?fmtL(into)+'/時':'—'}</span>${sur>0.05?`<span class="psur" title="次の工程に入りきらない分（${fmtL(sur)}/時）は自動で外販">外販 +${fmt(sur*st.price*pm)}/時</span>`:''}</div>`;
    }else{
      h+=`<div class="pflow${f.newmake>0?' run '+flowSpd(f.newmake,maxCap):''}"><span class="pband"></span><span class="pfl">新酒 ${f.newmake>0?fmtL(f.newmake)+'/時':'—'}</span>${f.newmake>0?'':'<span class="psur">蒸留器までそろうと新酒が生まれます</span>'}</div>`;
    }
  });
  // タンク
  if(feat('tank')){
    const cap=tankCap(),t=G.tank||0;
    let note;
    if(f.newmake<=0)note='生産していません';
    else if(t>=cap-0.5)note='満杯：あふれた新酒は外販 +'+fmt(f.newmake*nmPrice()*getEventMult('passive'))+'/時';
    else note='満杯まで '+fmtRemain((cap-t)/f.newmake*3600000);
    h+=`<div class="ptank" id="tankBox"><div class="pic ric">${ic('tank',26)}</div><div class="ptx" style="flex:1;min-width:0">
        <div class="pnm">タンク <span class="vv" id="tkAmt">${fmtL(t)} / ${fmtL(cap)}</span></div>
        <div class="pbar tk"><i id="tkFill" style="width:${Math.min(100,t/cap*100)}%"></i></div>
        <div class="pcap" id="tkNote">${escapeHtml(note)}</div></div>
      <div class="pbtns"><button type="button" class="sb2 gh" data-act="nmSell" data-l="all">外販</button><button type="button" class="sb2" data-act="goTab" data-tab="tcel">樽 ${G.lots.length}/${whSlots()} ›</button></div></div>`;
  }
  return h;
}
function flowSpd(v,max){const r=v/Math.max(1,max);return r>0.66?'s3':r>0.33?'s2':'s1';}
function recipeBoxHtml(){
  const kinds=[['grain','原料'],['water','仕込み水'],['yeast','酵母'],['peat','ピート']];
  return '<div class="rgrid">'+kinds.map(([k,lb])=>{const it=rcpItem(k,G.recipe[k]);return `<div class="rc" data-act="rcpOpen" data-kind="${k}"><div class="sm">${lb}</div><div class="tt">${it.icon||''} ${escapeHtml(it.name)}</div></div>`;}).join('')+'</div>';
}
function openRecipeBoxModal(){
  openModal(`<div class="mt">🧪 レシピ</div><div class="ms">原料・水・酵母・ピートで、新酒の風味と工程の速さが変わります。項目を押して変更</div>${recipeBoxHtml()}<button type="button" class="btn-cancel" style="width:100%;margin-top:12px" data-act="closeM">閉じる</button>`);
}
function netPh(){const f=prodFlows();const over=(G.tank||0)>=tankCap()-0.5&&f.newmake>0?f.newmake*nmPrice()*getEventMult('passive'):0;return ti()+over-barleyCostPh();}
function rMake(){
  const np=netPh();setHtml($('til'),'収支 <b style="color:'+(np>=0?'var(--green)':'var(--red)')+'">'+(np>=0?'+':'−')+fmt(Math.abs(np))+'</b>/時');
  show('btnRecipe',feat('recipe'));
  setHtml($('lineView'),lineViewHtml());
  pxSlotFill($('lineView'),'tb');
}
function rMakeLight(){rMake();}

// ============================================================
// 寝かせる
// ============================================================
function caskSeen(){const hs=hsState();if(!Array.isArray(hs.casks)){hs.casks=CASK_TYPES.filter(caskTypeUnlocked).map(t=>t.id).concat(CASK_SIZES.filter(caskSizeUnlocked).map(z=>z.id));}return hs.casks;}
function caskNew(kind){const seen=caskSeen();return (kind==='type'?CASK_TYPES.filter(caskTypeUnlocked):CASK_SIZES.filter(caskSizeUnlocked)).some(x=>!seen.includes(x.id));}
function fillChooseHtml(kind){
  const a=G.auto.fill;const seen=caskSeen();
  if(kind==='size'){
    const ct=caskType(a.cask);
    return CASK_SIZES.map(z=>{const ok=caskSizeUnlocked(z);const on=a.size===z.id;
      return `<button type="button" class="ccard${on?' on':''}${ok?'':' lk'}" ${ok?`data-act="fillSet" data-k="size" data-id="${z.id}"`:'disabled'}>
        <span class="cc1">${on?'✓ ':''}${escapeHtml(z.name)} <span class="sm">${z.litres}L</span>${ok&&!seen.includes(z.id)?' <b class="fnew">NEW</b>':''}</span>
        <span class="cc2">${ok?`熟成の速さ ×${z.agingSpeed} ・ 目減り ${(z.angelShare*100).toFixed(1)}%/年 ・ 樽代 ${fmt(caskCost(a.cask,z.id))}`:'🔒 Tier'+z.unlockTier+'で解禁'}</span>
        <span class="cc3">${escapeHtml(z.desc||'')}</span></button>`;}).join('');
  }
  return CASK_TYPES.map(t=>{const ok=caskTypeUnlocked(t);const on=a.cask===t.id;
    const fl=Object.entries(t.flavorMod||{}).map(([k,v])=>(FL_KEY_MAP[k]||k)+(v>0?'+':'')+v).join(' ');
    return `<button type="button" class="ccard${on?' on':''}${ok?'':' lk'}" ${ok?`data-act="fillSet" data-k="type" data-id="${t.id}"`:'disabled'}>
      <span class="cc1">${on?'✓ ':''}${t.icon} ${escapeHtml(t.name)}${ok&&!seen.includes(t.id)?' <b class="fnew">NEW</b>':''}</span>
      <span class="cc2">${ok?`熟成 ×${t.agingMod} ・ 樽代 ${fmt(caskCost(t.id,a.size))}（${escapeHtml(caskSize(a.size).name)}）`:'🔒 総売上 '+fmt(t.unlockSales)+' で解禁'}</span>
      <span class="cc3">${escapeHtml(t.desc||'')}${ok&&fl?' ・ 風味 '+escapeHtml(fl):''}</span></button>`;}).join('');
}
function openFillChooseModal(kind){
  kind=kind==='size'?'size':'type';
  openModal(`<div class="mt">🛢️ ${kind==='size'?'樽のサイズ':'樽の種類'}を選ぶ</div><div class="ms">自動樽詰め・今すぐ詰める の両方に使います</div><div class="ccards" id="fillChoose" data-k="${kind}">${fillChooseHtml(kind)}</div><button type="button" class="btn-cancel" style="width:100%;margin-top:8px" data-act="closeM">閉じる</button>`);
  const seen=caskSeen();(kind==='size'?CASK_SIZES.filter(caskSizeUnlocked):CASK_TYPES.filter(caskTypeUnlocked)).forEach(x=>{if(!seen.includes(x.id))seen.push(x.id);});save();
}
function openBlendModal(){
  openModal(`<div class="mt">🔀 ブレンド ${ib('blend')}</div><div class="ms">3年以上の原酒を混ぜて、目標の風味に近づけます</div><div id="blendBox"></div><button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
  const bb=$('blendBox');if(bb){bb.innerHTML=blendBoxHtml();bb._h=null;updateBlendPreview();}
}
function blendBoxHtml(){
  const b=_ui.blend;
  const ts=BLEND_TARGETS.filter(t=>(t.unlockTier||1)<=G.dl);
  if(!ts.some(t=>t.id===b.target)&&ts.length)b.target=ts[0].id;
  let h='<div class="card"><div class="chips">'+ts.map(t=>`<span class="chip ${b.target===t.id?'on':''}" data-act="blendTarget" data-id="${t.id}">${t.icon} ${escapeHtml(t.name)}</span>`).join('')+'</div>';
  const lots=G.lots.filter(l=>l.age>=3).sort((x,y)=>y.age-x.age);
  b.picks.forEach((p,i)=>{
    const l=G.lots.find(x=>x.id===p.lotId);if(!l){p.lotId='';p.L=0;}
    const max=l?Math.floor(l.L):0;
    h+=`<div class="row" style="gap:6px;margin-bottom:6px">
      <select class="sel" style="flex:1.4" data-in="blendLot" data-i="${i}"><option value="">-- 原酒${i+1} --</option>${lots.map(x=>`<option value="${x.id}" ${x.id===p.lotId?'selected':''}>${fmtAge(x.age)} ${caskType(x.cask).name} ${fmtL(x.L)}</option>`).join('')}</select>
      <input type="range" min="0" max="${max}" step="1" value="${Math.min(p.L,max)}" data-in="blendL" data-i="${i}" style="flex:1" ${l?'':'disabled'}>
      <span class="sm" style="min-width:44px;text-align:right" id="blendLv${i}">${Math.round(p.L)}L</span></div>`;
  });
  h+=`<div style="display:flex;justify-content:center"><svg id="blendRadar" width="180" height="180" viewBox="0 0 180 180"></svg></div><div id="blendPv"></div>
  <button type="button" class="cb" data-act="blendGo" style="margin-top:8px">ブレンドして瓶詰めへ</button></div>`;
  return h;
}
function drawRadar(svgId,fl,target){
  const svg=$(svgId);if(!svg)return;
  const cx=90,cy=90,r=65;const labels=['煙','果','辛','甘','花'];
  const pts=vals=>FL_KEYS.map((d,i)=>{const a=(i/5)*Math.PI*2-Math.PI/2;const v=Math.min(1,((vals&&vals[d])||0)/100);return [cx+Math.cos(a)*r*v,cy+Math.sin(a)*r*v];});
  const grid=FL_KEYS.map((_,i)=>{const a=(i/5)*Math.PI*2-Math.PI/2;return `<line x1="${cx}" y1="${cy}" x2="${(cx+Math.cos(a)*r).toFixed(1)}" y2="${(cy+Math.sin(a)*r).toFixed(1)}" stroke="var(--border)" stroke-width="1"/>`;}).join('');
  svg.innerHTML=grid
    +(target?`<polygon points="${pts(target).map(p=>p.join(',')).join(' ')}" fill="rgba(200,150,42,.1)" stroke="var(--gold)" stroke-width="1.5" stroke-dasharray="4,2"/>`:'')
    +`<polygon points="${pts(fl).map(p=>p.join(',')).join(' ')}" fill="rgba(50,200,100,.15)" stroke="var(--green)" stroke-width="1.5"/>`
    +FL_KEYS.map((d,i)=>{const a=(i/5)*Math.PI*2-Math.PI/2;return `<text x="${(cx+Math.cos(a)*(r+14)).toFixed(1)}" y="${(cy+Math.sin(a)*(r+14)+4).toFixed(1)}" text-anchor="middle" font-size="10" fill="var(--muted)">${labels[i]}</text>`;}).join('');
}
function updateBlendPreview(){
  const b=_ui.blend;const pv=blendPreview(b.target,b.picks);
  const t=BLEND_TARGETS.find(x=>x.id===b.target);
  drawRadar('blendRadar',pv.fl||{},t?t.target:null);
  const el=$('blendPv');if(!el)return;
  if(!pv.fl){el.innerHTML=`<div class="sm tc">${escapeHtml(pv.reason||'')}</div>`;return;}
  el.innerHTML=`<div class="sm tc">一致 <b style="color:var(--gold2)">${Math.round(pv.score*100)}%</b> ・ ${pv.n}本 ・ ${pv.age}年表記</div>`+
    (pv.ok?`<div class="sm tc">見込み <b style="color:var(--gold2)">${fmt(pv.unit*pv.n)}</b> ・ 瓶の資材 −${fmt(btlMatCost(pv.n).cost)} ・ あと${fmtRemain(pv.hours*3600000)}</div>`:`<div class="sm tc" style="color:var(--red)">${escapeHtml(pv.reason)}</div>`);
}
function cellarSig(){return [G.lots.filter(lotSellable).length,G.lots.map(l=>lotAgeStep(l)+':'+(l.goal||0)+(lotDoneRecent(l)?'d':'')).join(','),G.lots.length,G.lots.map(l=>l.id).join(','),whSlots(),G.dl,feat('tank'),feat('caskChoice'),G.auto.fill.on,G.auto.fill.cask,G.auto.fill.size,G.lots.map(l=>ageBand(l.age)).join(''),G.fac.maturation.l,G.fac.maturation.p,isUL('maturation'),brPending('maturation'),G.cash>=(G.fac.maturation.p?fuc('maturation'):fpc('maturation')),caskCost(G.auto.fill.cask,G.auto.fill.size),G.lots.map(l=>l.name?1:0).join('')].join('|');}
function rCellar(){
  show('btnBlend',feat('blend'));
  // v5.5 ①② は常に開いておく（たたむのをやめた）。倉庫日誌は図鑑へ
  setHtml($('celTank'),celTankHtml());
  setHtml($('celF1'),celFlowHtml(1));setHtml($('fillBox'),fillBoxHtml());setHtml($('celF2'),celFlowHtml(2));
  setHtml($('whSummary'),whHtml());
  if(typeof sceneMount==='function')sceneMount();
  const fc=$('fillChoose');if(fc)setHtml(fc,fillChooseHtml(fc.dataset.k));
  const bb=$('blendBox');
  if(bb&&feat('blend')){bb.innerHTML=blendBoxHtml();bb._h=null;updateBlendPreview();}
  _ui.sig.cel=cellarSig();
}
function rCellarLight(){
  if(_ui.sig.cel!==cellarSig()){rCellar();return;}
  const o=document.querySelector('[data-lold]');if(o&&G.lots.length)o.textContent=fmtAge(Math.max(...G.lots.map(l=>l.age)));
  const nx=document.querySelector('[data-lnext]');if(nx)nx.textContent=lotNextTxt();
  if(feat('tank')){const cap=tankCap(),t=G.tank||0;setText('clTank',fmtL(t)+' / '+fmtL(cap));const tf=$('clTankF');if(tf)tf.style.width=Math.min(100,t/cap*100).toFixed(1)+'%';const n=$('clTankN');if(n)n.innerHTML=celTankNote(t,caskSize(G.auto.fill.size),prodFlows());}
  setHtml($('celF1'),celFlowHtml(1));
  const cp=$('cpNote');if(cp)cp.textContent=cpNote();
}

// ============================================================
// 売る
// ============================================================
function sellTabs(){
  const t=[['ord','📦 出荷']]; // v5.9 注文と在庫は1画面（在庫の内訳は在庫の行で開く）
  if(feat('rel'))t.push(['rel','🤝 取引先']);
  if(feat('comp'))t.push(['comp','🏆 品評会']);
  return t;
}
function openOrderInfoModal(id){
  const o=G.orders.find(x=>x.id===id);if(!o)return;
  const c=custById(o.cid);const pp=CUST_PERSONA[o.cid]||{};const m=ordMatch(o);const due=o.dueAt-Date.now();
  const qtyTxt=o.kind==='newmake'?fmtL(o.qty):o.kind==='cask'?'1樽':fmtN(o.qty)+'本';
  let main='';
  if(o.reserve&&!o.accepted)main=`<button type="button" class="btn-ok" data-act="ordAccept" data-id="${o.id}">受注する</button>`;
  else if(m.ok)main=`<button type="button" class="btn-ok" data-act="${o.kind==='cask'?'ordOpen':'ordGo'}" data-id="${o.id}">${o.kind==='cask'?'樽を選ぶ':'納品する'}</button>`;
  else if(!ordInProgress(o)&&ordFulfillPlan(o).ok)main=`<button type="button" class="btn-ok" data-act="ordFill" data-id="${o.id}">詰めて納品</button>`;
  const canDismiss=!(o.reserve&&o.accepted);
  const cancelBtn=o.reserve&&o.accepted?`<button type="button" class="btn-cancel" data-act="ordCancel" data-id="${o.id}">取り消す（違約金 ${fmt(ordCancelCost(o).fee)}）</button>`:'';
  const note=m.ok?'':ordInProgress(o)?'瓶詰め中 → 終わると自動で納品':(ordFulfillPlan(o).reason||'');
  openModal(`<div class="row" style="gap:10px;margin-bottom:10px">${avatar(o.cid,44)}<div><div class="tt">${escapeHtml(c.name)}</div><div class="sm">${escapeHtml(pp.pname||'')}</div></div></div>
    <div class="quote">「${escapeHtml(pp.greet||'')}」</div>
    <div class="card" style="margin-top:10px"><div class="ol">${escapeHtml(ordLabel(o))} × ${qtyTxt}</div>
      <div class="sm" style="margin-top:4px">${o.reserve?(o.accepted?'予約・受注済み ・ ':'予約注文（単価×'+o.mult+'） ・ '):''}期限 あと${fmtRemain(due)}</div>
      <div class="or" style="margin-top:4px">${m.ok?'報酬 '+fmt(m.cash):(ordEstimate(o)>0?'報酬 約'+fmt(ordEstimate(o)):'')}</div>${ordMatHtml(o,m)}
      ${note?`<div class="sm" style="margin-top:4px">${escapeHtml(note)}</div>`:''}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">${canDismiss?`<button type="button" class="btn-cancel" data-act="ordDismissM" data-id="${o.id}">見送る</button>`:cancelBtn}${main||'<button type="button" class="btn-cancel" data-act="closeM">閉じる</button>'}</div>`);
}
function relListHtml(){
  return CUSTOMERS.filter(c=>(G.dl||1)>=c.tier&&(G.reputation||0)>=(c.rep||0)).map(c=>{
    const r=G.rel[c.id]||{lv:0,done:0};
    const next=BALANCE.REL_THRESH[r.lv];
    const pp=CUST_PERSONA[c.id]||{};
    return `<div class="row sb" style="padding:8px 0;border-bottom:1px solid var(--border)"><span class="row" style="gap:10px">${avatar(c.id,40)}<span><span class="tt" style="font-size:15px">${escapeHtml(c.name)}</span> <span class="sm">${escapeHtml(pp.pname||'')}</span><br><span class="sm">${'★'.repeat(r.lv)+'☆'.repeat(5-r.lv)}${next?' ・ 次まで'+(next-r.done)+'件':''}</span></span></span><span class="vv">${r.done}件</span></div>`;
  }).join('')+`<div class="row sb" style="margin-top:6px"><span class="sm">納品するほど関係が深まり、単価が上がります</span>${ib('rel')}</div>`;
}
function renderAwardsTab(){
  const rep=G.reputation||0;
  const cl=$('compList');if(!cl)return;
  const hist=(G.repHistory||[]).slice(0,3).map(h=>`<div class="row sb"><span class="sm">${escapeHtml(h.reason||'')}</span><span class="sm" style="color:${h.d>=0?'var(--green)':'var(--red)'}">${h.d>=0?'+':''}${Number(h.d).toFixed(1)}</span></div>`).join('');
  let h=`<div class="card"><div class="row sb"><span class="tt">評判 ${rep.toFixed(1)}</span><span class="row" style="gap:6px"><span class="sm" style="color:var(--gold)">単価 ×${repMult().toFixed(2)}</span>${ib('rep')}</span></div>${hist?'<div style="border-top:1px solid var(--border);margin-top:6px;padding-top:4px">'+hist+'</div>':''}</div>`;
  COMPETITIONS.filter(c=>rep>=c.unlockRep).forEach(comp=>{
    const coolEnd=(G.compCooldowns||{})[comp.id]||0;const onCd=Date.now()<coolEnd;
    const canEnter=!onCd&&G.cash>=compCost(comp);
    h+=`<div class="card" style="${(G.awards||[]).includes(comp.id)?'border-color:var(--gold2)':''}"><div class="row sb"><div style="min-width:0"><div class="tt">${comp.icon} ${escapeHtml(comp.name)}</div>
      <div class="sm">参加費 ${fmt(compCost(comp))} ・ 合格 ${Math.round(comp.qualThreshold*100)}点${onCd?' ・ 再出品まで '+fmtRemain(coolEnd-Date.now()):''}</div></div>
      <button type="button" class="sb2" data-act="compOpen" data-comp="${comp.id}" ${canEnter?'':'disabled'}>出品</button></div></div>`;
  });
  const nx=COMPETITIONS.find(c=>c.unlockRep>rep);
  if(nx)h+=`<div class="sm tc">🔓 評判${nx.unlockRep}で ${nx.icon} ${escapeHtml(nx.name)}</div>`;
  cl.innerHTML=h;
}
function shipSig(){return [_ui.sellTab,G.orders.map(o=>o.id+(o.accepted?'a':'')+(ordInProgress(o)?'p':'')+(ordMatch(o).ok?'k':'')).join(','),G.bq.map(q=>q.id).join(','),G.bottles.map(r=>r.id+':'+r.n).join(','),G.lots.length,Math.floor(G.cash).toString().length,G.dl,Math.floor(G.reputation||0),G.auto.spot.on,G.auto.spot.defKeep,sellTabs().length,_ui.invOpen?1:0,_ui.invAll?1:0,idleList().length,placeWho('fac','bottling')?1:0,G.fac.bottling?G.fac.bottling.l:0,G.fac.bottling&&G.fac.bottling.p?1:0].join('|');}
function rShip(){
  const tabs=sellTabs();
  if(!tabs.some(t=>t[0]===_ui.sellTab))_ui.sellTab='ord';
  setHtml($('sellChips'),tabs.length>1?tabs.map(([k,l])=>`<span class="chip ${_ui.sellTab===k?'on':''}" data-act="sellTab" data-id="${k}">${l}</span>`).join(''):'');
  ['ord','rel','comp'].forEach(k=>show('sp_'+k,_ui.sellTab===k));
  setText('tilSale','注文 '+G.orders.length+'/'+boardSize());
  if(_ui.sellTab==='ord'){
    setHtml($('bqBox'),bqHtml());pxSlotFill($('bqBox'),'tsale');setHtml($('sellF1'),sellFlowHtml(1));setHtml($('stockRow'),stockRowHtml());show('invBox',!!_ui.invOpen);if(_ui.invOpen)setHtml($('invBox'),invDetailHtml());setHtml($('sellF2'),sellFlowHtml(2));
    const on=$('orderNext');if(on)on.style.display='';
    const list=G.orders.slice().sort((a,b)=>{const ra=ordUsable(a)&&ordMatch(a).ok?0:ordUsable(a)&&!ordInProgress(a)&&ordFulfillPlan(a).ok?1:2,rb=ordUsable(b)&&ordMatch(b).ok?0:ordUsable(b)&&!ordInProgress(b)&&ordFulfillPlan(b).ok?1:2;return ra-rb||a.dueAt-b.dueAt;});
    setHtml($('orderBoard'),list.length?list.map(orderCardHtml).join(''):'<div class="sm tc" style="padding:14px">注文はまだありません</div>');
  }else if(_ui.sellTab==='rel')setHtml($('relList'),relListHtml());
  else if(_ui.sellTab==='comp')renderAwardsTab();
  rShipLight(true);
  _ui.sig.ship=shipSig();
}
function rShipLight(inner){
  if(!inner&&_ui.sig.ship!==shipSig()){rShip();return;}
  const now=Date.now();
  document.querySelectorAll('[data-due]').forEach(e=>{e.textContent=ordDueTxt(Number(e.dataset.due)-now);});
  setText('orderNext',G.orders.length<boardSize()?'次の注文まで '+fmtRemain(Math.max(0,G.orderClock-now)):'満杯');
  let acc=0;const rate=botRate();
  G.bq.forEach(q=>{acc+=q.n-q.done;const e=document.querySelector(`[data-bq="${q.id}"]`);if(e)e.style.width=Math.min(100,q.done/q.n*100)+'%';const d=document.querySelector(`[data-bqd="${q.id}"]`);if(d)d.textContent=fmtN(Math.floor(q.done))+'/'+fmtN(q.n)+'本';const t=document.querySelector(`[data-bqeta="${q.id}"]`);if(t)t.textContent='あと'+fmtRemain(acc/rate*3600000);});
}

// ============================================================
// 図鑑（集めて眺める場所：改善計画 第9章）
// ============================================================
// v5.5 入口のアイコンを1行に（v5.5.1 決算書も同じ画面に出す・名前を短く）。アイコンの下からスクロール。v5.8「記録」を廃止して7つ
function finUnread(){const a=G.acct;return !!(a&&a.hist&&a.hist.length&&hsState().fin!==a.hist[0].m);}
function encTabs(){
  return [['fin','fin','決算書',finUnread()?'新':''],['w','bottle','銘柄'],['t','tier','称号'],['g','barley','創業地'],
    ['j','maturation','日誌',jnlUnread()?'新':''],['f','make','設備'],['s','book','物語']];
}
function rencFin(){
  const a=acctEnsure();if(!_fin.v)_fin.v='pl';
  setHtml($('finMs'),`📊 決算書 ${ib('fin')} 第${a?a.per:1}期の事業 ・ 実際の暦の1か月ごと ・ 月が変わると前の月が確定します`);
  finRender();
  if(finUnread()){const h=G.acct.hist[0];hsState().fin=h.m;save();const e=$('ei_fin');if(e){const b=e.querySelector('.eib');if(b)b.remove();}}
}
function renc(){
  const shipped=Object.keys(G.shipLog||{}).length,tot=WL.length;
  setText('ecl','出荷した銘柄 '+shipped+' / '+tot);
  const ep=$('ep');if(ep)ep.style.width=(shipped/tot*100)+'%';
  const tabs=encTabs();if(!tabs.some(t=>t[0]===_ui.encTab))_ui.encTab='w';
  setHtml($('encGrid'),tabs.map(([k,icn,l,bd])=>`<button type="button" class="eic${_ui.encTab===k?' on':''}" data-act="encTab" data-id="${k}" id="ei_${k}" aria-label="${l}"><span class="eii">${ic(icn,20)}</span><span class="eil">${l}</span>${bd?`<span class="eib">${bd}</span>`:''}</button>`).join(''));
  ['fin','w','t','g','j','f','s'].forEach(k=>show('ep_'+k,_ui.encTab===k));
  G.encSeen=G.uw.slice();
  if(_ui.encTab==='fin')rencFin();
  else if(_ui.encTab==='w')rencW();
  else if(_ui.encTab==='t')rencT();
  else if(_ui.encTab==='g')rencR();
  else if(_ui.encTab==='j')rencJ();
  else if(_ui.encTab==='f')renderFacEncyclopedia();
  else if(_ui.encTab==='s')renderStoryPanel();
}
function rencW(){
  const fb=$('filterbar');
  if(fb&&!fb.children.length){
    WL_TYPES.forEach(t=>{
      const b=document.createElement('button');
      b.className='fb'+(t==='all'?' on':'');b.textContent=WL_TYPE_LABELS[t];b.dataset.filter=t;
      b.addEventListener('click',()=>{CF=t;document.querySelectorAll('#filterbar .fb').forEach(x=>x.classList.remove('on'));b.classList.add('on');rencW();});
      fb.appendChild(b);
    });
  }
  const g=$('wg');if(!g)return;
  const filt=CF==='all'?WL:WL.filter(w=>w.tp===CF);
  g.innerHTML=filt.map(w=>{
    const ul=G.uw.includes(w.id);const sh=!!(G.shipLog&&G.shipLog[w.id]);
    if(!ul){
      const u=UNLOCK_REQ.find(x=>x.id===w.id);const sec=u&&u.secret;
      return `<div class="wc lk" data-id="${w.id}"><div class="wn">？？？</div><div class="wlk2">${sec?'ひみつ':'未解禁'}</div></div>`;
    }
    return `<div class="wc ${sh?'ul':'ns'}" data-id="${w.id}"><div class="wn">${escapeHtml(w.name)}</div><div class="wr">${escapeHtml(w.tp)} ・ ${escapeHtml(w.rg)}</div>${sh?`<div class="ws">${'★'.repeat(w.st)+'☆'.repeat(3-w.st)}</div>`:`<div class="wsh">未出荷 ・ ${w.yr}年〜</div>`}</div>`;
  }).join('');
}
// v5.5 今の称号（最後に得た称号）を大きく、得た称号は新しい順。廃止した称号は「過去の称号」
function rencT(){
  const tl=$('tlist');if(!tl)return;
  const cur=titleLatest();const rank=getCurrentRepRank();
  const got=G.tl.map(id=>TT.find(x=>x.id===id)).filter(t=>t&&!t.ret).reverse();
  const old=G.tl.map(id=>TT.find(x=>x.id===id)).filter(t=>t&&t.ret);
  const all=TT.filter(t=>!t.ret).length;
  const chip=(t,o)=>`<span class="tch${o?' old':''}">🏅 ${escapeHtml(t.lb)}</span>`;
  tl.innerHTML=`<div class="card hl tcur"><div class="sm">今の称号</div><div class="tcn">🏅 ${escapeHtml(cur?cur.lb:gTitle())}</div><div class="sm">評判 ${Math.floor(G.reputation||0)}（${escapeHtml(rank.label)}）</div></div>
    <div class="card"><div class="row sb"><span class="tt">得た称号（新しい順）</span><span class="sm">${got.length} / ${all}</span></div><div class="tchs">${got.length?got.map(t=>chip(t)).join(''):'<span class="sm">称号はまだありません</span>'}</div></div>
    ${old.length?`<div class="card"><div class="tt">過去の称号</div><div class="sm">v5.5 で整理した称号です。今の称号には出ません</div><div class="tchs">${old.map(t=>chip(t,1)).join('')}</div></div>`:''}`;
}
function openWhiskyModal(id){
  try{
    const w=WL.find(x=>x.id===id),ul=G.uw.includes(id);
    if(!ul){
      const ui=getUnlockInfo(id);
      openModal(`<div style="font-size:36px;text-align:center;margin-bottom:8px">${ui.secret?'🌑🥃':'❓🥃'}</div><div class="mt tc">???</div><div class="ms tc">未解禁</div><div class="tc" style="padding:12px 0"><div class="sm">解禁条件</div><div style="font-family:var(--fb);font-size:15px;color:var(--gold2);margin-top:4px">${ui.secret?'秘密':escapeHtml(ui.label.replace(/販売/g,'出荷'))}</div></div>`);
      return;
    }
    const sp=productSpec(id);const lg=G.shipLog&&G.shipLog[id];
    const row=(k,v)=>`<div class="msr"><div class="msl">${k}</div><div class="msv">${v}</div></div>`;
    const d=lg&&lg.t?new Date(lg.t):null;
    openModal(`<div style="font-size:36px;text-align:center;margin-bottom:8px">${w.em}🥃</div>
      <div class="mt">${escapeHtml(w.name)}</div>
      <div class="ms">${escapeHtml(w.rg)} | ${escapeHtml(w.tp)} | ${'★'.repeat(w.st)}</div>
      <div style="background:var(--bg3);border-radius:8px;padding:10px 12px;margin-bottom:12px;font-size:14px;color:var(--text2);line-height:1.6">${escapeHtml(w.ds)}</div>
      <div class="sm" style="margin-bottom:2px">この銘柄らしい風味</div>
      ${flBars(sp.target)}
      ${row('必要年数',sp.minAge+'年以上')}
      ${sp.casks?row('使える樽',sp.casks.map(c=>caskType(c).name).join('・')+'のみ'):''}
      ${sp.minMatch?row('風味の一致',Math.round(sp.minMatch*100)+'%以上が必要'):''}
      ${row('出荷本数',fmtN(G.cw[id]||0)+'本')}
      ${lg&&lg.maxAge?row('最高年数',lg.maxAge+'年'):''}
      ${d?row('初出荷',d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate()):''}
      ${G.awardMult[id]?row('受賞','単価×'+G.awardMult[id]):''}`);
  }catch(e){console.error('openWhiskyModal error:',e);openModal('<div class="sm tc" style="padding:20px">読み込みエラー</div>');}
}

// ============================================================
// モーダル群
// ============================================================
function openUpgModal(id){
  const f=FD.find(x=>x.id===id);const s=G.fac[id];if(!f||!s)return;const l=s.l;
  if(brPending(id)){openBranchModal(id);return;}
  const max=l>=facMaxLv();
  const upg=(FAC_UPG[id]&&FAC_UPG[id][l%10])||{eq:'(拡張設備)',desc:'Tier'+G.dl+'の規模に合わせた設備拡張です。'};
  const cost=s.p?fuc(id):fpc(id),canAfford=G.cash>=cost;
  const bo=brOpt(id);
  openModal(`<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px"><div style="font-size:36px">${f.icon}</div><div>
      <div style="font-family:var(--fd);font-size:20px;font-weight:900;color:var(--gold2)">${escapeHtml(f.name)}</div>
      <div class="sm">${s.p?'Lv '+l+(max?'（最大）':' → '+(l+1)):'未購入'}${bo?' ・ 🔧 '+escapeHtml(bo.name):''}</div></div></div>
    ${!max&&s.p?`<div class="card"><div class="sm" style="color:var(--gold)">次に追加される設備</div><div class="tt">${escapeHtml(upg.eq)}</div><div class="sm" style="color:var(--text2);margin-top:4px">${escapeHtml(upg.desc)}</div></div>`:''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
      <div class="card" style="margin:0"><div class="sm">現在</div><div class="tt" style="font-size:13px">${s.p&&(l>0||id==='maturation'||id==='bottling')?facEffectText(id,l):'——'}</div></div>
      <div class="card" style="margin:0;border-color:var(--green)"><div class="sm" style="color:var(--green)">${s.p?'強化後':'購入後'}</div><div class="tt" style="font-size:13px;color:var(--green)">${max?'——':facEffectText(id,s.p?l+1:(id==='maturation'||id==='bottling'?0:1))}</div></div></div>
    ${bo?`<button type="button" class="btn-cancel" style="width:100%;margin-bottom:8px" data-act="brOpen" data-fac="${id}">設備を変更する</button>`:''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><button type="button" class="btn-cancel" data-act="closeM">閉じる</button>
      ${max?'':`<button type="button" class="btn-ok" data-act="${s.p?'facUp':'facBuy'}" data-id="${id}" ${canAfford&&(s.p||isUL(id))?'':'disabled'}>${canAfford?(s.p?'強化 ':'購入 ')+fmt(cost):'資金不足 '+fmt(cost)}</button>`}</div>`);
}
function openTierModal(){
  const n=G.dl+1;const next=DL[n-1];if(!next)return;
  const st=tierReqStatus(n);const ready=st.every(o=>o.ok);
  const rows=st.map(o=>`<div class="msr"><div class="msl">${o.ok?'✅':'⬜'} ${escapeHtml(o.label)}</div><div class="msv" style="color:${o.ok?'var(--green)':'var(--cream)'}">${o.money?fmt(o.cur)+' / '+fmt(o.need):fmtN(o.cur)+' / '+fmtN(o.need)}</div></div>`).join('');
  const custs=CUSTOMERS.filter(c=>c.tier===n).map(c=>c.icon+c.name).join('、');
  const gains=['設備の上限 Lv'+facMaxLv(n),'注文ボード +1件'];
  if(n===2)gains.push('取引先・予約注文');
  if(custs)gains.push('新しい取引先: '+custs);
  if(n===3)gains.push('ブレンド');
  openModal(`<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px"><span style="font-size:36px">🏭</span><div>
      <div style="font-family:var(--fd);font-size:20px;font-weight:900;color:var(--gold2)">${escapeHtml(next.name)}</div>
      <div class="sm">Tier ${n} / ${DL.length} ・ ${escapeHtml(next.region)}</div></div></div>
    <div class="sm" style="color:var(--gold);margin-bottom:4px">昇格の条件（すべて・順番は自由）</div>
    ${rows}
    <div class="card" style="margin-top:12px"><div class="sm" style="color:var(--green);margin-bottom:4px">昇格で増えるもの</div>${gains.map(g=>'<div class="sm" style="color:var(--text2)">・'+escapeHtml(g)+'</div>').join('')}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px"><button type="button" class="btn-cancel" data-act="closeM">閉じる</button>
      <button type="button" class="btn-ok" data-act="distConfirm" data-cost="${tierCost(n)}" data-tier="${n}" ${ready?'':'disabled'}>${ready?'✓ 昇格する':'条件未達'}</button></div>`);
}
function openBranchModal(facId){
  const fd=FD.find(x=>x.id===facId);const opts=FAC_BRANCH[facId];if(!opts)return;
  const cur=G.branch[facId];const chosen=cur!==null&&cur!==undefined;
  const can=facLv(facId)>=BALANCE.BRANCH_LV;
  const cost=chosen?brRetoolCost(facId):0;
  openModal(`<div class="mt">${fd.icon} ${escapeHtml(fd.name)}の設備</div>
    <div class="ms">${chosen?'変更には再設備費 '+fmt(cost):'2つから1つを選ぶ（初回は無料・あとで変更できる）'}${!chosen&&_brUp===facId?'<br>選んだあと Lv'+facLv(facId)+' → '+(facLv(facId)+1)+' に強化します（'+fmt(fuc(facId))+'）':''}</div>
    ${opts.map((o,i)=>`<div class="card ${cur===i?'hl':''}"><div class="tt">${escapeHtml(o.name)}${cur===i?' <span class="badge b-ok">導入済み</span>':''}</div>
      <div class="sm" style="color:var(--text2);margin:2px 0 4px">${escapeHtml(o.desc)}</div><div class="sm" style="color:var(--gold)">${escapeHtml(fmtMods(o))}</div>
      <button type="button" class="sb2" style="margin-top:6px;width:100%;padding:9px" data-act="brPick" data-fac="${facId}" data-idx="${i}" ${(!can||cur===i)?'disabled':''}>${!can?'Lv'+BALANCE.BRANCH_LV+'で選択可能':cur===i?'導入済み':chosen?'変更する（'+fmt(cost)+'）':'これにする'}</button></div>`).join('')}
    <button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}
function rcpEffectText(kind,it){
  const p=[];
  if(it.flavorMod)Object.entries(it.flavorMod).forEach(([k,v])=>p.push(FL_KEY_MAP[k]+(v>=0?'+':'')+v));
  if(kind==='grain'&&it.yieldMod!==1)p.push('製麦能力×'+it.yieldMod);
  if(kind==='grain'&&BARLEY_GRAIN_MULT[it.id]&&BARLEY_GRAIN_MULT[it.id]!==1)p.push('大麦の価格×'+BARLEY_GRAIN_MULT[it.id]);
  if(kind==='water'&&it.incMod!==1)p.push('糖化能力×'+it.incMod);
  if(kind==='yeast'&&it.fermentMod!==1)p.push('発酵能力×'+it.fermentMod);
  if(kind==='peat'){if(it.smokyMod)p.push('スモーキー+'+it.smokyMod);if(it.ppm)p.push('製麦能力×'+(1-it.ppm/250).toFixed(2));if(it.incMod!==1)p.push('スモーキー40以上の単価×'+it.incMod);}
  return p.join(' / ')||'標準';
}
function openRecipeModal(kind){
  const title={grain:'原料（大麦）',water:'仕込み水',yeast:'酵母',peat:'ピート'}[kind];
  const list=rcpList(kind).filter(it=>G.recipeOwned.includes(it.id)||rcpUnlocked(kind,it));
  openModal(`<div class="mt">🧪 ${title}</div><div class="ms">初回だけ購入。あとは自由に切り替え</div>
    ${list.map(it=>{
      const owned=G.recipeOwned.includes(it.id),cur=G.recipe[kind]===it.id,cost=rcpCost(kind,it);
      return `<div class="card ${cur?'hl':''}"><div class="row sb"><span class="tt">${it.icon||''} ${escapeHtml(it.name)}</span>${cur?'<span class="badge b-ok">使用中</span>':''}</div>
        <div class="sm" style="color:var(--gold)">${escapeHtml(rcpEffectText(kind,it))}</div>
        ${cur?'':`<button type="button" class="sb2" style="margin-top:6px;width:100%;padding:8px" data-act="rcpPick" data-kind="${kind}" data-id="${it.id}" ${(owned||G.cash>=cost)?'':'disabled'}>${owned?'これを使う':'購入して使う（'+fmt(cost)+'）'}</button>`}</div>`;
    }).join('')}
    <div class="sm" style="margin:6px 0">これから詰める樽の風味が変わります ${ib('recipe')}</div>
    <button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}
function orderNeedFor(pid){return G.orders.filter(o=>o.kind==='product'&&o.pid===pid).reduce((a,o)=>a+Math.max(0,o.qty-G.bottles.filter(r=>r.pid===pid&&r.age>=o.minAge).reduce((s,r)=>s+r.n,0)),0);}
function openBottleModal(pid){
  const cands=botPids().filter(id=>lotsFor(id).length>0);
  if(!pid){const r=ordRecs()[0];if(r){_ui.bot={pid:r.pid,n:r.n,mode:'young',sel:[],minAge:r.minAge};renderBottleModal(false);return;}}
  _ui.bot={pid:pid||cands[0]||G.uw[0]||null,n:0,mode:'young',sel:[],minAge:0};
  renderBottleModal(true);
}
function renderBottleModal(resetN){
  const b=_ui.bot;const recs=ordRecs();const recP=new Set(recs.map(r=>r.pid));
  const opts=botPids().map(id=>{const sp=productSpec(id);const L=lotsFor(id).reduce((a,l)=>a+l.L,0);return {id,sp,n:Math.floor(L/BALANCE.BOTTLE_L+1e-9)};}).filter(o=>o.n>0||o.id===b.pid).sort((x,y)=>(x.sp.house?99:x.sp.minAge)-(y.sp.house?99:y.sp.minAge)); // v5.3 ハウスモルトは最後
  if(!b.pid&&opts.length)b.pid=opts[0].id;
  if(!b.pid||!opts.length){openModal('<div class="mt">🍾 瓶詰め</div><div class="sm">瓶詰めできる原酒がありません</div>');return;}
  const sp=productSpec(b.pid);
  const elig=lotsFor(b.pid).sort((x,y)=>x.age-y.age);
  if(b.mode==='manual'&&!b.sel.length)b.sel=elig.map(l=>l.id);
  const maxN=botPreview(b.pid,1,b.mode,b.sel,b.minAge||0).maxN||0;
  if(resetN||b.n>maxN||b.n<=0){const need=orderNeedFor(b.pid);b.n=Math.min(maxN,need>0?need:Math.min(maxN,100));}
  opts.sort((x,y)=>(recP.has(y.id)?1:0)-(recP.has(x.id)?1:0));
  openModal(`<div class="mt">🍾 瓶詰めして在庫にする ${ib('bottle')}</div>${ordRecsHtml(recs)}
    <select class="sel" data-in="botPid">${opts.map(o=>`<option value="${o.id}" ${o.id===b.pid?'selected':''}>${recP.has(o.id)?'★注文 ':''}${escapeHtml(o.sp.name)}（最大${fmtN(o.n)}本）</option>`).join('')}</select>${sp.house?`<div class="sm" style="margin-top:4px">25銘柄にまだ詰められない3年以上の原酒を、蒸留所の名前で瓶詰めします（注文・品評会には使えません）</div>`:''}${b.minAge>0?`<div class="sm" style="margin-top:4px">注文に合わせて${b.minAge}年以上の原酒だけを使います</div>`:''}
    <details class="fold" style="margin-top:8px"><summary><span class="sm">使う原酒（${b.mode==='old'?'古い順':b.mode==='manual'?'手動':'若い順'}）</span></summary>
    <div class="chips">${[['young','若い順'],['old','古い順'],['manual','手動']].map(([m,l])=>`<span class="chip ${b.mode===m?'on':''}" data-act="botMode" data-mode="${m}">${l}</span>`).join('')}</div>
    ${b.mode==='manual'?`<div class="card" style="max-height:160px;overflow-y:auto">${elig.length?elig.map(l=>`<label class="row sm" style="padding:3px 0"><input type="checkbox" data-in="botSel" value="${l.id}" ${b.sel.includes(l.id)?'checked':''}> ${caskLabel(l)} ${fmtAge(l.age)} ${fmtL(l.L)}</label>`).join(''):'<span class="sm">該当なし</span>'}</div>`:''}</details>
    <div class="row sb" style="margin-top:8px"><span class="sm">本数</span><span class="vv" id="botNv">${fmtN(b.n)}本</span></div>
    <input type="range" min="${maxN>0?1:0}" max="${maxN}" step="1" value="${b.n}" data-in="botN" ${maxN>0?'':'disabled'}>
    <div id="botPv" style="margin-top:6px"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px"><button type="button" class="btn-cancel" data-act="closeM">閉じる</button><button type="button" class="btn-ok" data-act="botGo" id="botGoBtn">瓶詰め開始</button></div>`);
  updateBottlePreview();
}
function updateBottlePreview(){
  const b=_ui.bot;const el=$('botPv');if(!el)return;
  setText('botNv',fmtN(b.n)+'本');
  const pv=botPreview(b.pid,b.n,b.mode,b.sel,b.minAge||0);
  const btn=$('botGoBtn');if(btn)btn.disabled=!pv.ok;
  if(!pv.ok){el.innerHTML=`<div class="sm" style="color:var(--red)">${escapeHtml(pv.reason)}</div>`;return;}
  const row=(k,v)=>`<div class="msr" style="padding:5px 0"><div class="msl">${k}</div><div class="msv">${v}</div></div>`;
  const mat=btlMatCost(pv.n);
  el.innerHTML=row('年数表記',pv.age+'年')+row('品質',starQ(pv.q))+row('風味の一致',isHouse(b.pid)?'問わない':starM(pv.match))+row('見込み総額',fmt(pv.unit*pv.n))+row('瓶の資材',mat.free?'無料（前のオーナーの瓶）':'−'+fmt(mat.cost)+'（'+fmtPk(mat.unit)+'/本）')+row('完了まで',fmtRemain(pv.hours*3600000));
  if(btn&&!mat.free&&G.cash<mat.cost){btn.disabled=true;el.innerHTML+=`<div class="sm" style="color:var(--red)">瓶の資材代が足りません</div>`;}
}
function openOrderModal(id){
  const o=G.orders.find(x=>x.id===id);if(!o)return;
  const c=custById(o.cid);const m=ordMatch(o);
  if(!m.ok||o.kind!=='cask'){ordFulfill(id);return;}
  const body=m.lots.sort((a,b)=>lotValue(b)-lotValue(a)).map(l=>`<div class="card"><div class="row sb"><span class="tt" style="font-size:13px">${caskLabel(l)} ${fmtAge(l.age)}</span><span class="vv">${fmt(ordMatch(o,l.id).cash)}</span></div><div class="sm">${fmtL(l.L)} ・ ${starQ(l.q)}</div><button type="button" class="sb2" style="width:100%;margin-top:6px;padding:8px" data-act="ordGo" data-id="${o.id}" data-lot="${l.id}">この樽を納品</button></div>`).join('');
  openModal(`<div class="mt">${c.icon} ${escapeHtml(c.name)}へ納品</div><div class="ms">${escapeHtml(ordLabel(o))}</div>${body}`);
}
function openLotModal(id){
  const l=G.lots.find(x=>x.id===id);if(!l)return;
  const prods=lotProducts(l);
  const row=(k,v)=>`<div class="msr"><div class="msl">${k}</div><div class="msv">${v}</div></div>`;
  openModal(`<div class="mt">${l.name?'「'+escapeHtml(l.name)+'」':''}${caskLabel(l)}</div><div class="ms">${fmtAge(l.age)} ・ ${l.src==='starter'?'前オーナーの遺した樽':l.src==='migrated'?'移行した樽':'自家製原酒'}${l.fin?' ・ '+escapeHtml(caskType(l.fin.from).name)+'から移して仕上げ中（'+Math.min(BALANCE.FINISH_YEARS,Math.max(0,l.age-l.fin.at)).toFixed(1)+' / '+BALANCE.FINISH_YEARS+'年）':''}</div>
    ${row('残量',fmtL(l.L0)+' → '+fmtL(l.L)+'（'+Math.round(lotPct(l))+'% ・ 約'+fmtN(Math.floor(l.L/BALANCE.BOTTLE_L))+'本分）')}${row('品質',starQ(l.q))}${row('樽ごと売ると',fmt(lotValue(l)*BALANCE.CASK_SPOT_MULT))}
    ${lotGoalRowHtml(l)}${nextBrandHtml(l,true)}
    ${lotPlaceRowHtml(l)}
    <details class="fold" style="margin-top:8px"><summary><span class="sm">詳しく（詰められる銘柄 ${prods.length}・風味・原価）</span></summary>${row('詰められる銘柄',prods.length?prods.map(p=>escapeHtml(productSpec(p).name)).join('、'):lotSellable(l)?'ハウスモルトのみ':'なし（ハウスモルトは'+V51.SELL_AGE+'年から）')}${flBars(lotFlavor(l))}${row('目減り',(angelRate(l)*100).toFixed(1)+'%/年（天使の分け前）')}${row('帳簿の原価',fmt(lotC(l))+'（新酒＋樽代）')}${row('熟成速度','実1日で'+agingRate(l).toFixed(2)+'年'+(lotMult(l)>1?'（うち担当 '+placeMultTxt(lotMult(l))+'）':''))}</details>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button type="button" class="btn-cancel" data-act="nameOpen" data-id="${l.id}">🏷️ ${l.name?'名前を変える':'名前を付ける'}</button>${feat('finish')?`<button type="button" class="btn-cancel" data-act="finOpen" data-id="${l.id}" ${finishable(l)?'':'disabled'}>🪵 ${l.fin?'仕上げ中':'仕上げの樽へ'}</button>`:'<span></span>'}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"><button type="button" class="btn-cancel" data-act="lotSell" data-id="${l.id}" ${lotSellable(l)?'':'disabled'}>${lotSellable(l)?'樽ごと売る':V51.SELL_AGE+'年で売れます'}</button><button type="button" class="btn-ok" data-act="botOpen" data-pid="${prods[0]||(lotSellable(l)?V53.HOUSE:'')}" ${prods.length||lotSellable(l)?'':'disabled'}>瓶詰めして在庫に</button></div>`);
}
function openCompModal(compId){
  const comp=COMPETITIONS.find(x=>x.id===compId);if(!comp)return;
  const rows=G.bottles.filter(r=>r.n>=BALANCE.COMP_BOTTLES&&!isHouse(r.pid)).map(r=>({r,e:compExpected(r)})).sort((a,b)=>b.e-a.e);
  openModal(`<div class="mt">${comp.icon} ${escapeHtml(comp.name)}</div><div class="ms">瓶${BALANCE.COMP_BOTTLES}本で出品 ・ 参加費 ${fmt(compCost(comp))} ・ 合格 ${Math.round(comp.qualThreshold*100)}点 ${ib('comp')}</div>
    ${rows.length?rows.map(({r,e})=>{const sp=productSpec(r.pid);return `<div class="card"><div class="row sb"><span class="tt" style="font-size:13px">${escapeHtml(sp.name)} ${r.age}年</span><span class="vv" style="color:${e>=comp.qualThreshold?'var(--green)':'var(--muted)'}">予想${Math.round(e*100)}点</span></div><button type="button" class="sb2" style="width:100%;margin-top:6px;padding:8px" data-act="compGo" data-comp="${comp.id}" data-row="${r.id}">これを出品</button></div>`;}).join(''):'<div class="sm tc" style="padding:14px">'+BALANCE.COMP_BOTTLES+'本以上ある瓶の在庫がありません</div>'}
    <button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}
function showCompResult(res){
  const sp=productSpec(res.pid);
  if(res.win)celebrate({icon:res.comp.icon,title:res.comp.name+' 受賞',sub:(sp?sp.name:'')+' '+res.age+'年 ・ 単価×'+G.awardMult[res.pid]});
  openModal(`<div style="font-size:40px;text-align:center">${res.win?res.comp.icon:'📄'}</div><div class="mt tc">${res.win?'受賞！':'落選'}</div>
    <div class="ms tc">${escapeHtml(sp?sp.name:'')} ${res.age}年 ・ ${Math.round(res.S*100)}点（合格${Math.round(res.comp.qualThreshold*100)}点）</div>
    ${res.judges.map(j=>`<div class="card"><div class="row sb"><span class="tt" style="font-size:13px">${escapeHtml(j.name)}</span><span class="vv">${Math.round(j.score*100)}点</span></div><div class="sm" style="color:var(--text2)">「${escapeHtml(j.comment)}」</div></div>`).join('')}
    ${res.win?`<div class="sm" style="color:var(--green)">評判+${res.comp.repReward} ・ 単価×${G.awardMult[res.pid]}</div>`:`<div class="sm" style="color:var(--red)">評判-${Math.max(1,Math.round(res.comp.repReward*0.3))}</div>`}
    <button type="button" class="cb" data-act="closeM">閉じる</button>`);
}
function showMigrateModal(){
  G.migShown=true;save();
  openModal(`<div class="mt">🏭 蒸留所が生まれ変わりました</div><div class="ms">これまでの進捗はすべて引き継いでいます</div>
    <div class="card"><div class="sm" style="color:var(--text2)">・熟成中の樽 ${G.lots.filter(l=>l.src==='migrated').length}樽 → 倉庫へ<br>・製品在庫 → 瓶の在庫 ${fmtN(G.bottles.reduce((a,r)=>a+r.n,0))}本<br>・前オーナーの樽3つ（3年・5年・8年）を追加</div></div>
    <div class="card"><div class="sm" style="color:var(--text2)">🏭 造る → 🛢️ 寝かせる → 📦 売る。やることがあるタブには数字や「!」が付きます。</div></div>
    <button type="button" class="cb" data-act="closeM">はじめる</button>`);
}

// ============================================================
// 設定と記録
// ============================================================
function rprof(){
  setText('pca',fmt(G.cash));setText('pta',fmt(G.te));
  setText('pship',fmtN(G.stats.shipped)+'本');setText('pord',G.stats.orders+'件');
  setText('pmax',fmtAge(G.stats.maxAge||0));setText('pea',Object.keys(G.shipLog||{}).length+' / '+WL.length);
  setText('ptitle',gTitle());
  const av=$('pAvatar');
  if(av){const pic=LIFF_USER.picture&&/^https:\/\//i.test(LIFF_USER.picture);const h=pic?`<img src="${escapeHtml(LIFF_USER.picture)}" alt="">`:'🥃';if(av._h!==h){av.innerHTML=h;av._h=h;}}
  setText('pName',LIFF_USER.name||'蒸留家');
  const stat=$('pStat');if(stat)stat.classList.toggle('line',!!LIFF_USER.isLine);
  setText('pStatTxt',LIFF_USER.isLine?'LINEログイン中':'ゲストモード（ローカル保存）');
  const ob=$('optBox');if(ob){const h=optBoxHtml();const ae=document.activeElement;const sliding=ae&&ae.tagName==='INPUT'&&ob.contains(ae);if(ob._h!==h&&!sliding){ob.innerHTML=h;ob._h=h;}}
  setText('storeInfo','保存先: '+storageKey());
  setText('appVersion',BALANCE.APP_VERSION);setText('schemaVersion',String(BALANCE.SCHEMA_VERSION));setText('appDate',BALANCE.APP_DATE||'');
  const sh=$('btnShare');if(sh)sh.style.display=LIFF_USER.isLine?'block':'none';
  const dbx=$('dbgBox');if(dbx)dbx.style.display=(isDebugUser()&&(G.dbgMul||1)>1)?'flex':'none';
  const le=$('loadErr');if(le)le.innerHTML=_loadError?'<div class="banner" style="border-color:var(--red);color:var(--red)">⚠️ 読み込みに失敗しました: '+escapeHtml(_loadError)+'<button type="button" class="sb2" data-act="exportBackup" style="margin-left:auto">書き出す</button></div>':'';
  // v5.6 再創業のボタンは図鑑の「創業地」へ移した（rencR）
}

// ============================================================
// ナビのバッジ・ヘッダー
// ============================================================
function updNavBadges(){
  const set=(id,txt,cls)=>{const e=$(id);if(!e)return;const c='bd'+(txt!==''?' '+cls:'');if(e.className!==c)e.className=c;if(e.textContent!==txt)e.textContent=txt;};
  const m=tabMarks();const newT=typeof tutWaitingTabs==='function'?tutWaitingTabs():{};
  ['td','tb','tcel','tsale'].forEach(t=>{
    const x=m[t];const nb=document.querySelector('#nav .nb[data-tab="'+t+'"]');
    if(x.u)set('bd_'+t,'!','on');else if(x.n)set('bd_'+t,String(x.n),'g');else if(newT[t])set('bd_'+t,'新','nw');else set('bd_'+t,'','');
    if(nb){const att=!!(x.u||x.n||newT[t]);if(nb.classList.contains('att')!==att)nb.classList.toggle('att',att);}
  });
  const nw=G.uw.filter(id=>!(G.encSeen||[]).includes(id)).length;
  set('bd_te',nw?String(nw):(jnlUnread()?'新':''),nw?'g':'nw'); // v5.5 倉庫日誌の未読も図鑑に
}
function updHdrExtra(){
  animCash();
  const d=DL[G.dl-1];
  setText('dn',d.name+(G.climate&&G.climate!=='speyside'?' '+climate().icon:''));
  setText('dlv',String(G.dl));
  hdTitleUpd(); // v5.5 ヘッダーは最後に得た称号
}

function rall(){
  prodInvalidate();
  try{updHdr();}catch(e){console.warn('updHdr failed:',e);}
  try{idleChipsUpd();}catch(e){} // v5.9.3 配置を変えたらすぐ待機の人数を直す
  const at=document.querySelector('.tab.on');const id=at?at.id:'td';
  const map={td:rdist,tb:rMake,tcel:rCellar,tsale:rShip,te:renc,tp:rprof};
  try{(map[id]||rdist)();}catch(e){console.warn('render failed:',id,e);}
  try{updateRepBar();}catch(e){}
  try{updNavBadges();}catch(e){}
}
function rLight(){
  const at=document.querySelector('.tab.on');const id=at?at.id:'td';
  const map={td:rdistLight,tb:rMakeLight,tcel:rCellarLight,tsale:rShipLight,tp:rprof};
  try{(map[id]||function(){})();}catch(e){console.warn('light render failed:',id,e);}
  try{updNavBadges();}catch(e){}
}

// ============================================================
// v4.2 追加の描画（設定。v5.6 創業地の記録 rencR は n28_v56.js。v5.8 名樽の記録 rencC・ブレンドの記録 rencB は廃止）
// ============================================================
function optBoxHtml(){
  const o=opt();
  const seg=(k,opts)=>`<span class="seg" role="group">${opts.map(([v,l])=>`<button type="button" class="sb2 opt ${o[k]===v?'on':'gh'}" aria-pressed="${o[k]===v}" data-act="optSet" data-k="${k}" data-v="${v}">${o[k]===v?'✓ ':''}${l}</button>`).join('')}</span>`;
  return `<div class="optrow"><span class="tt" style="font-size:15px">文字の大きさ</span>${seg('fs',[['m','標準'],['l','大']])}</div>
    <div class="optrow"><span class="tt" style="font-size:15px">金額の表記</span>${seg('money',[['en','$1.2M'],['ja','$120万']])}</div>
    <div class="optrow"><span class="tt" style="font-size:15px">効果音</span><input type="range" min="0" max="100" step="5" value="${Math.round(o.se*100)}" data-in="optSe" aria-label="効果音の音量"></div>
    <div class="optrow"><span class="tt" style="font-size:15px">BGM</span>${seg('bgmMode',[['classic','クラシック'],['celtic','ケルト'],['off','なし']])}</div>
    <div class="optrow"><span class="tt" style="font-size:15px">BGMの音量</span><input type="range" min="0" max="100" step="5" value="${Math.round(o.bgm*100)}" data-in="optBgm" aria-label="BGMの音量"></div>
    <div class="optrow"><span class="tt" style="font-size:15px">振動（Android）</span>${seg('vib',[[true,'ON'],[false,'OFF']])}</div>
    <div class="optrow"><span class="tt" style="font-size:15px">色</span>${seg('theme',[['dark','ダーク'],['light','ライト'],['auto','端末']])}</div>
    <div class="optrow"><span class="tt" style="font-size:15px">動き</span>${seg('motion',[['std','標準'],['low','減らす']])}</div>`;
}

// v4.7 樽の小窓：次の節目と、知らせる年数の選び方（v5.0.1 「目標」を「節目」に。説明は TIPS「年数と日数」）
function lotGoalRowHtml(l){
  lotGoalInit(l);const opts=lotGoalOptions(l);
  const st=l.goal>0?l.goal+'年（あと'+fmtRemain(lotGoalEta(l))+'）':'なし（25年を超えました）';
  const btns=opts.map(v=>`<button type="button" class="chip${v===l.goal?' on':''}" data-act="lotGoal" data-id="${l.id}" data-v="${v}">${v}年</button>`).join('');
  const d=l.gt>0?new Date(l.gt):null;
  return `<div class="msr"><div class="msl">次の節目 ${ib('age')}</div><div class="msv">${st}</div></div>${btns?`<div class="chips lgo">${btns}</div>`:''}${l.gd&&d?`<div class="sm" style="color:var(--gold2)">🛢️ ${l.gd}年になった日：${d.getMonth()+1}/${d.getDate()}</div>`:''}`;
}
