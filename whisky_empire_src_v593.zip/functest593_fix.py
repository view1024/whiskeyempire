# v5.9.3 の変更に合わせて v5.9.2 までのテストを置き換える
# #179：全員が働いていても、担当のいない設備と倉庫の行には「＋」が出る（見出しの待機の札は出ない）
R2("      o.none = [document.querySelectorAll('#lineView .wseat').length + (lotSeat() ? 1 : 0), document.querySelectorAll('#idleTb .idlec').length];",
   "      const exp2 = V50.FACS.filter(f => f !== 'bottling' && placeOk({ k: 'fac', id: f }) && !placeWho('fac', f)).length;\n      o.none = [document.querySelectorAll('#lineView .wseat').length === exp2 && exp2 > 0, lotSeat() ? 1 : 0, document.querySelectorAll('#idleTb .idlec').length];\n      // 待機がいなくても「＋」から選べ、働いている人は「今は…」と出る（倉庫の「＋」は全員から選ぶ）\n      document.querySelector('#lineView .wseat').click(); await new Promise(r => setTimeout(r, 40)); o.move = document.getElementById('mc2').textContent.includes('今は'); closeM();\n      seatTap('lot', ''); o.lotAll = document.getElementById('mc2').textContent.includes('今は'); closeM();")
R2("r.none.join() === '0,0' && r.tip1[0]", "r.none.join() === 'true,1,0' && r.move && r.lotAll && r.tip1[0]")
R2("全員が働いていれば空き席も札も出ない・", "全員が働いていても担当のいない設備と倉庫の行には「＋」が出て、働いている人を移せる（v5.9.3）・待機の札は出ない・")
R2("rec(179, '小人の空き席（v5.9）：置ける人がいれば担当のいない設備にだけ点線の小人と＋・", "rec(179, '小人の空き席（v5.9）：担当のいない設備にだけ「＋」（v5.9.2 点線の小人はやめた）・")
