// 詳細設計書 第10章 テスト観点の自動確認
const { chromium } = require('playwright');
const path = require('path');
const SCHEMA = Number((require('fs').readFileSync('n1_constants.js', 'utf8').match(/SCHEMA_VERSION: (\d+)/) || [])[1]);
const FILE = 'file://' + path.resolve('whisky_empire.html');

async function newPage(browser, preload, keepTut) {
  const ctx = await browser.newContext({ viewport: { width: 360, height: 740 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  if (preload) await page.addInitScript(preload);
  await page.goto(FILE);
  await page.waitForTimeout(1200);
  await page.evaluate(() => { _mktOff = true; if (typeof titleStart === 'function') titleStart(false); });
  await page.waitForTimeout(800);
  if (!keepTut) await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose(); });
  return { page, errors, ctx };
}

(async () => {
  const browser = await chromium.launch();
  const results = [];
  const rec = (id, name, ok, detail) => { results.push({ id, name, ok, detail }); };

  // ---------- 新規ゲームでの計算テスト ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: detail === undefined ? '' : String(detail) });
      const near = (a, b, eps) => Math.abs(a - b) <= (eps || 1e-6) * Math.max(1, Math.abs(b));
      if (_offlineGate) closeOfflineModal();
      closeM();
      if (G.randomEvent) G.randomEvent.active = null; // 偶発イベントの倍率を外す
      // #1 製麦Lv1のみ
      G.fac.malting.l = 1; prodInvalidate();
      let f = prodFlows();
      T(1, '製麦Lv1のみ: newmake0・ti=300×0.9(既定の大麦)×$6=$1,620/時', f.newmake === 0 && near(ti(), 1620), 'newmake=' + f.newmake + ' ti=' + ti());
      // #2 4工程Lv3
      ['malting', 'mashing', 'fermentation', 'distillation'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 3; });
      prodInvalidate(); f = prodFlows();
      const capOk = near(f.cap[0], 388.8) && near(f.cap[1], 374.4) && near(f.cap[2], 331.2) && near(f.cap[3], 288);
      T(2, '4工程Lv3: cap・newmake・律速・余剰', capOk && near(f.newmake, 288) && f.bottleneck === 3 && near(f.s[0], 14.4) && near(f.s[1], 43.2) && near(f.s[2], 43.2), JSON.stringify({ cap: f.cap, nm: f.newmake, bn: f.bottleneck, s: f.s }));
      // #3 強化後にキャッシュ破棄
      G.cash = 1e9; const before = prodFlows().cap[3];
      upgFac('distillation');
      T(3, '強化でキャッシュ破棄・能力上昇', prodFlows().cap[3] > before && G.fac.distillation.l === 4, before + '→' + prodFlows().cap[3]);
      // #4 タンク溢れ
      G.tank = tankCap() - 1; const te0 = G.te;
      prodTick(3600000);
      T(4, 'タンク溢れ分を外販・tank=tankCap', near(G.tank, tankCap()) && G.te > te0, 'tank=' + G.tank + ' cap=' + tankCap());
      // #5 樽詰め拒否
      const n0 = G.lots.length;
      G.tank = 0; const r1 = fillCask('bourbon', 'hogshead', true);
      G.tank = 1000; const cash = G.cash; G.cash = 0; const r2 = fillCask('bourbon', 'hogshead', true); G.cash = cash;
      const slots = whSlots(); const saved = G.lots.slice();
      while (G.lots.length < slots) G.lots.push(makeLot(caskType('bourbon'), caskSize('hogshead')));
      const r3 = fillCask('bourbon', 'hogshead', true);
      G.lots = saved;
      T(5, '樽詰めの拒否（タンク不足・資金不足・満杯）', !r1 && !r2 && !r3 && G.lots.length === n0, [r1, r2, r3].join(','));
      // #6 #7 熟成
      const hog = makeLot(caskType('bourbon'), caskSize('hogshead')); lotAdvance(hog, 86400000);
      T(6, 'ホグスヘッド1日: age+1.0・L×0.984', near(hog.age, 1) && near(hog.L, 250 * 0.984), hog.age + ' ' + hog.L);
      const qc = makeLot(caskType('bourbon'), caskSize('quarter')); lotAdvance(qc, 86400000);
      T(7, 'クォーター1日: age+2.0・L×0.975', near(qc.age, 2) && near(qc.L, 50 * 0.975), qc.age + ' ' + qc.L);
      // #8 風味（シェリー樽）
      const sh = makeLot(caskType('sherry'), caskSize('hogshead')); const b0 = sh.fl0.fruity;
      sh.age = 6; const f6 = lotFlavor(sh).fruity - b0; sh.age = 12; const f12 = lotFlavor(sh).fruity - b0; sh.age = 20; const f20 = lotFlavor(sh).fruity - b0;
      T(8, 'シェリー樽の加算 6/12/20年 = 50%/100%/100%', near(f6, 10) && near(f12, 20) && near(f20, 20), [f6, f12, f20].join('/'));
      // #9 混ぜて瓶詰め
      G.uw = ['glenlivid']; G.lots = [];
      const a = makeLot(caskType('bourbon'), caskSize('hogshead')); a.age = 8.5; a.q = 1.0; a.L = 70;
      const b = makeLot(caskType('sherry'), caskSize('hogshead')); b.age = 10.2; b.q = 1.1; b.L = 70;
      G.lots.push(a, b);
      const pv = botPreview('glenlivid', 200, 'young');
      T(9, '8年+10年を混ぜる: 表記8年・品質は量で加重平均', pv.ok && pv.age === 8 && near(pv.q, 1.05, 1e-3), JSON.stringify({ ok: pv.ok, age: pv.age, q: pv.q, reason: pv.reason }));
      // #10 バーボン銘柄はシェリー樽不可
      G.uw.push('jack_d');
      const onlySherry = [b];
      G.lots = onlySherry;
      T(10, 'バーボン銘柄はシェリー樽の原酒を使えない', lotsFor('jack_d').length === 0, lotsFor('jack_d').length);
      // #11 ★3 一致度
      G.uw.push('macallen');
      const lo = makeLot(caskType('bourbon'), caskSize('hogshead')); lo.age = 20; lo.fl0 = { smoky: 100, fruity: 0, spicy: 0, sweet: 0, floral: 100 };
      G.lots = [lo];
      T(11, '★3銘柄は一致度0.5未満を除外', lotsFor('macallen').length === 0 && flavorMatch(lotFlavor(lo), productSpec('macallen').target) < 0.5, flavorMatch(lotFlavor(lo), productSpec('macallen').target).toFixed(3));
      // #12 単価
      const t = productSpec('glenlivid').target;
      // 一致度0.5になる風味: 平均差17.5
      const fl = {}; FL_KEYS.forEach(k => fl[k] = t[k]); fl.floral = t.floral - 87.5;
      const m = flavorMatch(fl, t); const u = priceUnit('glenlivid', 8, 1.0, fl);
      const expect = 100 * 8 / 3 * 1.0 * (0.7 + 0.6 * m) * distMult() * saleMult() * repMult();
      T(12, 'Glenvivid 8年・q1・一致0.5 ≈ $267', near(m, 0.5, 1e-3) && near(u, 266.67, 1e-3) && near(u, expect), 'm=' + m.toFixed(3) + ' unit=' + u.toFixed(2));
      // #13 注文の到着と上限
      G.orders = []; G.orderClock = Date.now() - 1;
      const n1 = ordSpawnTick(Date.now());
      G.orderClock = Date.now() - BALANCE.ORDER_INTERVAL_MS * 10;
      ordSpawnTick(Date.now());
      T(13, '90分ごと1件・ボード上限で停止', n1 === 1 && G.orders.length === boardSize() && G.orderClock > Date.now(), 'n1=' + n1 + ' len=' + G.orders.length + '/' + boardSize());
      // #14 在庫不足で納品拒否
      G.bottles = [];
      const o14 = { id: 'o_t14', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o14]; const c14 = G.cash;
      const d14 = ordDeliver('o_t14');
      T(14, '在庫不足の納品は拒否・状態不変', !d14 && G.orders.length === 1 && G.cash === c14, d14);
      // 正常納品
      invAdd('glenlivid', 12, 9, 1.0, t);
      const rep0 = G.reputation, sh0 = G.stats.shipped;
      const d14b = ordDeliver('o_t14');
      T('14b', '在庫十分なら納品: 資金・評判・出荷・関係', d14b && G.orders.length === 0 && G.reputation > rep0 && G.stats.shipped === sh0 + 10 && G.rel.local.done >= 1 && invTotal('glenlivid') === 2, 'rep ' + rep0 + '→' + G.reputation);
      // #15 予約の期限切れ
      const rr = G.reputation; const dn = G.rel.local.done;
      G.orders = [
        { id: 'o_r1', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: true, createdAt: 0, dueAt: Date.now() - 1 },
        { id: 'o_r2', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: false, createdAt: 0, dueAt: Date.now() - 1 },
      ];
      const ex = ordExpireTick(Date.now());
      T(15, '受注済み予約の期限切れだけ罰', ex.failed === 1 && ex.expired === 1 && G.reputation < rr && G.rel.local.done === Math.max(0, dn - 3), JSON.stringify(ex) + ' rep ' + rr + '→' + G.reputation);
      // #16 コレクター
      const y17 = makeLot(caskType('bourbon'), caskSize('hogshead')); y17.age = 17.5;
      const y19 = makeLot(caskType('bourbon'), caskSize('hogshead')); y19.age = 19;
      G.lots = [y17, y19];
      const oc = { id: 'o_c', cid: 'collector', kind: 'cask', minAge: 18, qty: 1, mult: 3, reserve: false, accepted: false, createdAt: 0, dueAt: Date.now() + 3600000 };
      const mc = ordMatch(oc);
      T(16, 'コレクター注文は18年未満の樽を選べない', mc.lots.length === 1 && mc.lots[0] === y19 && ordMatch(oc, y17.id).ok === false, mc.lots.length);
      // #17 分岐未選択
      G.fac.malting.l = 10; G.branch.malting = null; G.dl = 2;
      const pend = brPending('malting'); const lvb = G.fac.malting.l;
      upgFac('malting'); closeM();
      const blocked = G.fac.malting.l === lvb;
      brChoose('malting', 1);
      T(17, 'Lv10で分岐未選択なら強化不可・選択で能力×1.2', pend && blocked && G.branch.malting === 1 && near(stageCap(0), 300 * Math.pow(1.2, 9) * 1.2 * rcpMods().cap[0]), 'pend=' + pend + ' blocked=' + blocked);
      G.dl = 1;
      // #18 Tier条件
      G.stats.shipped = 0; G.reputation = 0; G.lots = []; G.cash = 0;
      const s0 = tierReqStatus(2).filter(o => o.ok).length;
      G.stats.shipped = 300; G.reputation = 15;
      for (let i = 0; i < 5; i++) { const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 3.2; G.lots.push(l); }
      const s1 = tierReqStatus(2).filter(o => o.ok).length; const can1 = canUpgDist();
      G.cash = tierCost(2) + 10;
      const can2 = canUpgDist();
      G.bottles = []; invAdd('glenlivid', 5, 8, 1, t);
      doUpgDist(tierCost(2), 2);
      T(18, 'Tier条件が順にok・全達成で昇格・在庫は残る', s0 === 0 && s1 === 3 && !can1 && can2 && G.dl === 2 && G.lots.length === 5 && invTotal('glenlivid') === 5, [s0, s1, can1, can2, G.dl].join(','));
      // #19 ブレンド
      G.dl = 3; G.lots = [];
      const l1 = makeLot(caskType('sherry'), caskSize('hogshead')); l1.age = 10;
      const l2 = makeLot(caskType('bourbon'), caskSize('hogshead')); l2.age = 8;
      G.lots.push(l1, l2);
      const bh0 = (G.blendHistory || []).length; const L0 = l1.L + l2.L; const bq0 = G.bq.length;
      const ok19 = blendStart('classic_blend', [{ lotId: l1.id, L: 100 }, { lotId: l2.id, L: 100 }]);
      const L1 = G.lots.reduce((a, l) => a + l.L, 0);
      chkT();
      T(19, 'ブレンドで原酒が減り履歴記録・称号「初仕込み」', ok19 && Math.abs(L0 - L1 - 200) < 1e-6 && G.blendHistory.length === bh0 + 1 && G.bq.length === bq0 + 1 && G.tl.includes('t19'), 'ok=' + ok19 + ' used=' + (L0 - L1));
      // #20 品評会（期待値）
      const row = { pid: 'glenlivid', age: 8, q: 1.05, fl: {} };
      FL_KEYS.forEach(k => row.fl[k] = t[k]); row.fl.floral = t.floral - 35; // 一致度0.8
      G.reputation = 0; G.prestige.skills = {};
      const e = compExpected(row);
      T(20, '地域品評会: 8年・q1.05・一致0.8 ⇒ 0.656点（合格0.6超）', Math.abs(e - 0.6556) < 0.001, e.toFixed(4));
      // 実出品
      G.bottles = []; invAdd('glenlivid', 10, 12, 1.2, t); G.cash = 1e7; G.compCooldowns = {};
      const res = enterComp('local_award', G.bottles[0].id);
      T('20b', '出品で6本消費・結果と講評3件・クールダウン1日', res && invTotal('glenlivid') === 4 && res.judges.length === 3 && Math.abs((G.compCooldowns.local_award - Date.now()) - 86400000) < 5000, res ? ('win=' + res.win + ' S=' + res.S.toFixed(3)) : 'null');
      closeM();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E1', '計算テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- オフライン ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const setup = () => {
        if (_offlineGate) closeOfflineModal(); closeM();
        ['malting', 'mashing', 'fermentation', 'distillation', 'maturation', 'bottling'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 5; });
        G.lots = []; G.tank = 0; G.cash = 1e7; G.auto.fill.on = false; prodInvalidate();
      };
      // #21 10時間
      setup();
      const lot = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot);
      const nm = prodFlows().newmake;
      G.ls = Date.now() - 10 * 3600000;
      offline();
      const exp21 = 10 / 24;
      T(21, '10時間不在: 熟成10時間分・生産8時間分', Math.abs(lot.age - exp21) < 1e-3 && Math.abs(G.tank - Math.min(tankCap(), nm * 8)) < 1e-3, 'age=' + lot.age.toFixed(4) + ' tank=' + G.tank.toFixed(1) + ' nm*8=' + (nm * 8).toFixed(1));
      // #22 100時間
      setup();
      const lot2 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot2);
      G.ls = Date.now() - 100 * 3600000;
      const t0 = performance.now(); offline(); const dt = performance.now() - t0;
      T(22, '100時間不在: 熟成72時間分・1秒以内', Math.abs(lot2.age - 3) < 1e-3 && dt < 1000, 'age=' + lot2.age.toFixed(4) + ' ms=' + dt.toFixed(1));
      // #23 自動樽詰め
      setup(); G.auto.fill.on = true; G.auto.fill.cask = 'bourbon'; G.auto.fill.size = 'quarter';
      G.ls = Date.now() - 4 * 3600000;
      offline();
      const ages = G.lots.map(l => l.age).sort((a, b) => b - a);
      const f = prodFlows();
      T(23, '自動樽詰め4時間: 先に詰めた樽ほど年数が大きい', G.lots.length > 1 && ages[0] > ages[ages.length - 1] && ages[0] <= 4 / 24 * 2 + 1e-9, 'lots=' + G.lots.length + ' ages=' + ages.slice(0, 3).map(a => a.toFixed(3)).join(','));
      // #24 同時発火で1回だけ
      setup();
      const lot3 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot3);
      G.ls = Date.now() - 2 * 3600000;
      offline(); offline(); window.dispatchEvent(new Event('focus')); document.dispatchEvent(new Event('visibilitychange'));
      T(24, '複数経路の同時発火でも補正1回', Math.abs(lot3.age - 2 / 24) < 1e-3, 'age=' + lot3.age.toFixed(5));
      if (_offlineGate) closeOfflineModal();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E2', 'オフラインテスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 移行 ----------
  const V6 = {
    cash: 123456789, te: 987654321, tt: 5000, dl: 3, cl: 7,
    fac: { malting: { l: 25, p: true }, mashing: { l: 22, p: true }, fermentation: { l: 20, p: true }, distillation: { l: 18, p: true }, maturation: { l: 15, p: true }, bottling: { l: 12, p: true } },
    uw: ['glenlivid', 'jameston', 'jack_d', 'johnnie_em'], cw: { glenlivid: 120, jack_d: 50 },
    am: { glenlivid: true }, inv: { glenlivid: 7, jack_d: 3 }, regions: { scotland: true }, tl: ['t1', 't9'],
    ls: Date.now() - 30 * 60000, ver: 6, dbgMul: 1,
    rawMaterials: { grain: 'optic', water: 'soft_spring', yeast: 'distillery', peat: 'unpeated' },
    casks: [{ id: 'cask_1', type: 'sherry', size: 'hogshead', whiskyId: 'glenlivid', litresFilled: 240, createdAt: Date.now() - 86400000, agingYears: 0.02, qualityMod: 1.3, sold: false },
            { id: 'cask_2', type: 'bourbon', size: 'barrel', whiskyId: 'jack_d', litresFilled: 190, createdAt: Date.now(), agingYears: 0.001, qualityMod: 0.7, sold: false }],
    channels: { active: ['dtc', 'on_trade', 'retail'], autoSellChannel: 'on_trade' },
    reputation: 42, awards: ['local_award'], compCooldowns: { local_award: Date.now() + 5 * 86400000 },
    prestige: { level: 1, bonus: 1.1, skillPoints: 1, skills: { ps_passive: 1, ps_am_slot: 1 }, legacyWhiskies: ['lw_genesis'], totalRuns: 1 },
    mg: { malting: { nextAt: 0, bonusUntil: 0, bonusMult: 1 } }, cut: {}, _cutBonus: 1, facByBrand: {}, wCd: { glenlivid: 0 },
    story: { unlocked: ['ep1'], seenNew: ['ep1'] }, daily: { date: '', missions: [], allCleared: false }, questDone: ['q_tap10']
  };
  {
    const pre = `localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(V6))});`;
    const { page, errors } = await newPage(browser, `if(!sessionStorage.getItem('x')){sessionStorage.setItem('x','1');${pre}}`, true);
    await page.waitForTimeout(600);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const bk = localStorage.getItem('we_v4_bak6:guest');
      const mig = G.lots.filter(l => l.src === 'migrated');
      const sherry = mig.find(l => l.cask === 'sherry');
      const ok = G.ver === BALANCE.SCHEMA_VERSION && G.dl === 3 && G.cash + sumO(acctLive().pur) >= 123456789 - 1 && G.fac.malting.l === 25 && G.fac.malting.p
        && mig.length === 2 && sherry && Math.abs(sherry.L - 240) < 1 && sherry.q === 1.3 && mig.find(l => l.cask === 'bourbon').q === 0.8
        && invTotal('glenlivid') === 7 && invTotal('jack_d') === 3 && G.bottles.find(b => b.pid === 'glenlivid').age === 8
        && G.rel.local.lv === 1 && G.rel.bar.lv === 1 && G.rel.retail.lv === 1 && G.rel.dutyfree.lv === 0
        && G.recipe.grain === 'optic' && G.recipeOwned.includes('optic')
        && G.prestige.skills.ps_capacity === 1 && G.prestige.skills.ps_order_slot === 1 && !G.prestige.skills.ps_passive
        && G.compCooldowns.local_award <= Date.now() + 86400000 + 1000
        && G.stats.shipped === 170 && G.stats.awardsWon === 1
        && G.lots.filter(l => l.src === 'starter').length === 3 && G.orders.length >= 1
        && !('mg' in G) && !('casks' in G) && !('inv' in G) && !('channels' in G) && !('am' in G) && !('_cutBonus' in G)
        && !!bk && JSON.parse(bk).ver === 6 && G.tl.includes('t9') && G.migratedFrom === 6;
      tutCheck(); T('25c', 'v3移行ユーザー：版の案内（upd）は出さず既読扱い・自動樽詰めと自動直販はON', !TUTS.upd && G.tut.done.upd && !G.tut.q.includes('upd') && !G.tut.done.first && G.auto.fill.on && G.auto.spot.on, JSON.stringify(G.tut));
      T(25, 'v3.8.0セーブの移行（樽・在庫・チャネル・レシピ・スキル・待ち時間・バックアップ）', ok, JSON.stringify({ ver: G.ver, lots: G.lots.map(l => l.src + ':' + l.cask + ':' + l.L.toFixed(0) + ':' + l.q), inv: G.bottles.map(b => b.pid + ':' + b.n + ':' + b.age), rel: G.rel, rc: G.recipe.grain, sk: G.prestige.skills, st: G.stats, bk: !!bk }));
      const modalShown = !$('mo').classList.contains('h') && /生まれ変わり|おかえり/.test($('mc2').textContent);
      T('25b', '移行結果（またはおかえり）モーダルが出る', modalShown, $('mc2').textContent.slice(0, 30));
      // #26 再読込で不変
      save();
      const snap = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      load();
      const snap2 = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      postLoadInit();
      T(26, '移行済みデータの再読込で変化なし（初期在庫も重複しない）', snap === snap2 && G.lots.filter(l => l.src === 'starter').length === 3, snap === snap2);
      // #27 壊れたインポート
      const before = JSON.stringify(G.stats);
      importSave(); $('ioText').value = '@@@broken@@@'; ioApplyAction();
      const ok27a = JSON.stringify(G.stats) === before;
      importSave(); $('ioText').value = btoa(unescape(encodeURIComponent(JSON.stringify({ ver: 99 })))); ioApplyAction();
      const ok27b = JSON.stringify(G.stats) === before && G.ver === BALANCE.SCHEMA_VERSION;
      closeM();
      T(27, '壊れた・新しすぎるセーブのインポートは拒否', ok27a && ok27b, ok27a + ',' + ok27b);
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    await page.screenshot({ path: 'shot_migrate.png' });
    if (errors.length) rec('E3', '移行テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 削除確認・画面 ----------
  {
    const fs = require('fs');
    const src = fs.readFileSync('whisky_empire.html', 'utf8');
    const leftovers = ['G.mg', 'craft(', 'autoSellTick', 'channelMult', 'openMiniGame', 'mgModal', 'comboCount', 'COMBO_', 'comboMul', 'CRIT_CHANCE_10000', 'comboMeter', 'id="questPanel"', 'Glenvivid', 'Johnnie Emerald', 'Davalo', 'Kawasaki'].filter(w => src.includes(w));
    rec(28, '削除対象（ミニゲーム・コンボ・ティッカー・クエスト表示）がコードに残っていない', leftovers.length === 0, leftovers.join(','));
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      if (_offlineGate) closeOfflineModal(); closeM();
      const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 150));
        const el = document.getElementById(t);
        res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth });
      }
      const navWrap = [...document.querySelectorAll('#nav .nb')].some(b => b.getBoundingClientRect().height > 70);
      return { res, navWrap };
    });
    const bad = r.res.filter(x => x.over > 1 || x.doc > 1);
    rec(29, '幅360pxで横スクロールなし・ナビが折り返さない', bad.length === 0 && !r.navWrap, JSON.stringify(r));
    if (errors.length) rec('E4', '画面テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 実プレイの通し（UI操作） ----------
  {
    const { page, errors } = await newPage(browser);
    await page.evaluate(() => { if (_offlineGate) closeOfflineModal(); closeM(); });
    // 1. 売るタブで「詰めて納品」→ 瓶詰め完了 → 自動納品
    await page.click('#nav .nb[data-tab="tsale"]');
    await page.waitForTimeout(200);
    const o0 = await page.evaluate(() => { const o = G.orders.find(x => ordFulfillPlan(x).ok); return o ? { id: o.id, qty: o.qty } : null; });
    await page.click(`[data-act="ordFill"][data-id="${o0.id}"]`);
    const q = await page.evaluate(id => ({ bq: G.bq.length, oid: G.bq[0] && G.bq[0].oid, auto: G.orders.find(o => o.id === id).autoDel, card: document.getElementById('orderBoard').textContent.includes('瓶詰め中') }), o0.id);
    await page.evaluate(() => { botTick(3600000 * (Math.ceil(botQueueBottles() / botRate()) + 1)); ordAutoTick(); rall(); });
    const after = await page.evaluate(id => ({ gone: !G.orders.some(o => o.id === id), orders: G.stats.orders, cash: G.cash, shipped: G.stats.shipped }), o0.id);
    rec(30, 'UI操作: 「詰めて納品」1回で瓶詰め→完了後に自動納品', q.bq === 1 && q.oid === o0.id && q.auto && q.card && after.gone && after.orders === 1 && after.shipped === o0.qty, JSON.stringify({ o0, q, after }));
    await page.screenshot({ path: 'shot_after_deliver.png' });
    // 2. 造るタブの一覧のボタンで直接強化
    await page.evaluate(() => { G.cash = 1e6; rall(); });
    await page.click('#nav .nb[data-tab="tb"]');
    await page.click('#lineView [data-act="facUp"][data-id="malting"]');
    const mlv = await page.evaluate(() => G.fac.malting.l);
    rec('30b', 'UI操作: 生産ラインのボタン1回で強化', mlv === 1, mlv);
    await page.screenshot({ path: 'shot_make2.png', fullPage: false });
    if (errors.length) rec('E5', '通しテスト中のエラー', false, errors.join(' | '));
  }

  const TUTS_DONE_BEFORE = ['first', 'u_age', 'u_barley', 'u44', 'u45', 'u46', 'u_cel45', 'u_line43', 'u43'];
  // ================= v4.1 追加テスト =================
  // ---------- 初回チュートリアル ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    const init = await page.evaluate(() => ({ q: G.tut.q.slice(), run: _tut && _tut.id, fill: G.auto.fill.on, spot: G.auto.spot.on, ver: G.ver }));
    rec(31, '新規開始: schema11・自動樽詰め/自動直販ON・初回案内が始まる', init.ver === SCHEMA && init.fill && init.spot && init.run === 'first', JSON.stringify(init));
    const t0 = Date.now(); let taps = 0; let firstSaleTaps = null, firstSaleSec = null;
    for (let k = 0; k < 14; k++) {
      const info = await page.evaluate(() => _tut ? { do: !!(tutStep() && tutStep().do) } : null);
      if (!info) break;
      await page.waitForTimeout(350);
      if (info.do) {
        const box = await page.evaluate(() => { const el = tutEl(tutStep()); if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
        if (box) { await page.mouse.click(box.x, box.y); taps++; } else await page.waitForTimeout(1600);
      } else { await page.mouse.click(195, 90); taps++; }
      await page.waitForTimeout(500);
      if (firstSaleTaps === null && await page.evaluate(() => G.stats.orders >= 1)) { firstSaleTaps = taps; firstSaleSec = (Date.now() - t0) / 1000; }
    }
    const end = await page.evaluate(() => ({ done: !!G.tut.done.first, rewarded: !!G.tut.rewarded, orders: G.stats.orders, malt: facLv('malting'), coach: document.getElementById('coach').classList.contains('h'), daily: feat('daily') }));
    rec(32, '初回案内: 7タップ以内（樽3回を含む）・60秒以内に最初の売上／完了で報酬・デイリー解放', firstSaleTaps !== null && firstSaleTaps <= 7 && firstSaleSec <= 60 && end.done && end.rewarded && end.malt >= 1 && end.coach && end.daily, JSON.stringify({ firstSaleTaps, firstSaleSec, end }));
    // 再読込で再表示しない・もう一度見るで再生
    await page.evaluate(() => save());
    await page.reload(); await page.waitForTimeout(1500);
    const again = await page.evaluate(() => ({ run: _tut && _tut.id, done: !!G.tut.done.first }));
    await page.evaluate(() => tutStart('first', true));
    await page.waitForTimeout(400);
    const replay = await page.evaluate(() => ({ run: _tut && _tut.id, next: getComputedStyle(document.getElementById('cNext')).visibility }));
    await page.evaluate(() => tutEnd(false));
    rec(33, '完了済みの案内は再読込で出ない・ヒント帳から再生できる（操作手順も次へで進める）', (!again.run || !TUTS_DONE_BEFORE.includes(again.run)) && again.done && replay.run === 'first' && replay.next === 'visible', JSON.stringify({ again, replay }));
    if (errors.length) rec('E6', 'チュートリアルテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- スキップで進行不能にならない ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    await page.click('#cBub [data-act="tutSkip"]');
    await page.waitForTimeout(300);
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, coach: document.getElementById('coach').classList.contains('h'), rewarded: !!G.tut.rewarded, next: document.getElementById('bd_tsale').textContent !== '' }));
    await page.click('#nav .nb[data-tab="tsale"]'); await page.waitForTimeout(300);
    await page.click('#orderBoard [data-act="ordFill"], #orderBoard [data-act="ordGo"]');
    await page.waitForTimeout(300);
    const r2 = await page.evaluate(() => ({ tab: document.querySelector('.tab.on').id, bq: G.bq.length, orders: G.stats.orders }));
    rec(34, 'スキップしても操作できる・印の付いた「売る」から最初の注文を処理できる', r.done && r.coach && !r.rewarded && r.next && (r2.bq >= 1 || r2.orders >= 1), JSON.stringify({ r, r2 }));
    if (errors.length) rec('E7', 'スキップテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- ロジック（v4.1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      if (_offlineGate) closeOfflineModal(); closeM();
      // #35 コンボ廃止
      const base = tapValue(); const c0 = G.cash; let bad = 0;
      for (let i = 0; i < 60; i++) { const b = G.cash; tap(null); const d = G.cash - b; if (!(Math.abs(d - base) < 1e-6 || Math.abs(d - base * 100) < 1e-6)) bad++; }
      T(35, 'タップ収益は連打しても一定（×1 か クリティカル×100 のみ）', bad === 0 && typeof comboMul === 'undefined', 'bad=' + bad);
      // #36 注文の年数条件を守って詰める
      G.uw = ['glenlivid']; G.lots = []; G.bq = []; G.bottles = [];
      const l8 = makeLot(caskType('bourbon'), caskSize('hogshead')); l8.age = 8.5; l8.L = 100;
      const l11 = makeLot(caskType('bourbon'), caskSize('hogshead')); l11.age = 11.2; l11.L = 100;
      G.lots.push(l8, l11);
      const o = { id: 'o_t36', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 10, qty: 20, rq: 20, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 };
      G.orders = [o];
      const ok36 = ordFulfill('o_t36');
      const usedOld = l11.L < 100 && Math.abs(l8.L - 100) < 1e-9;
      botTick(3600000 * 5); const del = ordAutoTick();
      T(36, '「詰めて納品」は注文の年数以上の樽だけを使い、完了で自動納品', ok36 && usedOld && del === 1 && G.orders.length === 0 && G.stats.orders >= 1, JSON.stringify({ ok36, usedOld, del, left: G.orders.length }));
      // #37 自動直販は注文ボードの分を売らない
      G.orders = [{ id: 'o_t37', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 80, rq: 80, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; invAdd('glenlivid', 100, 9, 1, productSpec('glenlivid').target);
      G.auto.spot.on = true; G.auto.spot.defKeep = 50;
      autoSpotTick();
      T(37, '自動直販は注文に必要な本数を残す（残す本数50・注文80 → 80本残る）', invTotal('glenlivid') === 80, invTotal('glenlivid'));
      // #38 オフライン中に瓶詰めが終わった注文は自動納品
      G.orders = [{ id: 'o_t38', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 30, rq: 30, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; G.bq = [];
      const l9 = makeLot(caskType('bourbon'), caskSize('hogshead')); l9.age = 9; l9.L = 200; G.lots = [l9];
      ordFulfill('o_t38');
      const o0 = G.stats.orders;
      G.ls = Date.now() - 3 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      T(38, 'オフライン中に瓶詰めが終わった注文を自動納品', G.stats.orders === o0 + 1 && !G.orders.some(x => x.id === 'o_t38'), 'orders ' + o0 + '→' + G.stats.orders);
      // #39 段階的解放
      G.dl = 1; G.reputation = 0; G.stats.awardsWon = 0; G.awards = []; G.fac.distillation.p = false; G.tank = 0; G.te = 0; G.recipeOwned = ['golden_promise', 'soft_spring', 'distillery', 'unpeated'];
      const f1 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips1 = document.querySelectorAll('#sellChips .chip').length;
      switchTab('tcel'); const blend1 = document.getElementById('btnBlend').style.display;
      G.dl = 3; G.fac.distillation.p = true; G.te = 1e9; rall();
      const f2 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips2 = document.querySelectorAll('#sellChips .chip').length;
      const locks = [...document.querySelectorAll('#lineView .pst')].filter(e => e.textContent.includes('🔒')).length;
      T(39, '使えない機能は非表示（Tier1: 売るの切替2つ・ブレンド非表示）→ 条件達成で表示', f1.every(x => !x) && chips1 === 2 && blend1 === 'none' && f2.join() === 'true,true,true,true,true,false,true' && chips2 === 5 && locks === 0, JSON.stringify({ f1, f2, chips1, chips2, blend1 }));
      // #40 v7→v8 の移行
      const v7 = JSON.parse(JSON.stringify(G)); v7.ver = 7; delete v7.tut; delete v7.shipLog; delete v7.encSeen; v7.auto.fill.on = false; v7.auto.spot.on = false; v7.dl = 2; v7.cw = { glenlivid: 30 };
      const m = parseSave(v7);
      T(40, 'v4.0（schema7）からの移行: 自動設定は維持・版の案内（upd）はない・解放済み機能の案内は出さない', m.ver === BALANCE.SCHEMA_VERSION && !m.auto.fill.on && !m.auto.spot.on && m.tut.q.join() === 'upd' && m.tut.seed && m.shipLog.glenlivid && !TUTS.upd, JSON.stringify({ ver: m.ver, tut: m.tut, auto: m.auto }));
      G = m; tutCheck();
      T('40b', 'seed処理: 条件を満たしている解放案内は既読になる', G.tut.done.u_t2 && G.tut.done.u_still && !G.tut.seed, JSON.stringify(G.tut.done));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E8', 'v4.1ロジックテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- v7 セーブのバックアップ ----------
  {
    const v7 = { ver: 7, cash: 5000, te: 9000, dl: 1, uw: ['glenlivid'], lots: [], bottles: [], orders: [], auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: false, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('y')){sessionStorage.setItem('y','1');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v7))});}`;
    const { page, errors } = await newPage(browser, pre, true);
    await page.waitForTimeout(1500);
    const r = await page.evaluate(() => ({ bk: localStorage.getItem('we_v4_bak7:guest'), run: _tut && _tut.id, ver: G.ver, fill: G.auto.fill.on }));
    rec(41, 'v4.0セーブの読込: 移行前をバックアップ・版の案内（upd）は出ない', !!r.bk && JSON.parse(r.bk).ver === 7 && r.run !== 'upd' && r.ver === SCHEMA && !r.fill, JSON.stringify({ bk: !!r.bk, run: r.run, ver: r.ver }));
    await page.screenshot({ path: 'shot_upd.png' });
    if (errors.length) rec('E9', 'v7読込テスト中のエラー', false, errors.join(' | '));
  }
  // ================= v4.2 追加テスト =================
  // ---------- 表示の基準（P1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      const out = { small: [], tiny: [], chars: [] };
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 200));
        const el = document.getElementById(t);
        el.querySelectorAll('button,[data-act],select,input,summary').forEach(b => {
          if (b.getClientRects().length === 0) return;
          const r = b.getBoundingClientRect();
          if (b.classList.contains('ib') || b.classList.contains('visitor')) return; // ⓘは疑似要素で44px、来客は動きのある要素（56px）
          if (r.height < 43.5 || (r.width < 43.5 && b.tagName !== 'INPUT')) out.small.push(t + ':' + (b.dataset.act || b.tagName) + ':' + Math.round(r.width) + 'x' + Math.round(r.height));
        });
        const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n, chars = 0;
        while (n = w.nextNode()) { const p = n.parentElement; if (!p || p.getClientRects().length === 0 || !n.textContent.trim()) continue; const fs = parseFloat(getComputedStyle(p).fontSize); if (fs < 12) out.tiny.push(t + ':' + fs + ':' + n.textContent.trim().slice(0, 10)); chars += n.textContent.replace(/\s/g, '').length; }
        out.chars.push(t + ':' + chars);
      }
      const sm = parseFloat(getComputedStyle(document.querySelector('#tcel .thead .sm')).fontSize);
      const L = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
      const muted = getComputedStyle(document.documentElement).getPropertyValue('--muted').trim();
      const cr = (L(muted) + 0.05) / (L('#241c13') + 0.05);
      const chrome = ['hdr', 'ticker', 'nav'].map(id => document.getElementById(id).getBoundingClientRect().height);
      return { ...out, sm, cr: +cr.toFixed(2), chrome };
    });
    rec(42, '押す対象がすべて44px以上・文字は12px以上（本文14px）・補足色のコントラスト4.5以上', r.small.length === 0 && r.tiny.length === 0 && r.sm >= 14 && r.cr >= 4.5, JSON.stringify({ small: r.small.slice(0, 8), tiny: r.tiny.slice(0, 8), sm: r.sm, cr: r.cr, chrome: r.chrome, chars: r.chars }));
    if (errors.length) rec('E11', '表示基準テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- タイトル・TIPS帯・樽・設定（P1） ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 740 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1500);
    const t0 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id, note: document.querySelector('.t-note').textContent.includes('20歳未満'), se: G.opt.se, bgm: G.opt.bgm }));
    await page.click('#titleBtns .btn-ok'); await page.waitForTimeout(900);
    const t1 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id }));
    rec(43, '起動時にタイトルと注意書き（音なしが既定）→ 閉じると初回案内が始まる', t0.title && !t0.tut && t0.note && t0.se === 0 && t0.bgm === 0 && !t1.title && t1.tut === 'first', JSON.stringify({ t0, t1 }));
    const tk = await page.evaluate(() => {
      const seq = []; _tk.hist = []; _tk.sinceHealth = 0;
      for (let i = 0; i < 120; i++) seq.push(tkPick());
      let maxGap = 0, gap = 0; seq.forEach(m => { if (m.cat === 'health') gap = 0; else { gap++; maxGap = Math.max(maxGap, gap); } });
      const locked = seq.filter(m => m.cat === 'tips' && m.f && !feat(m.f)).length;
      const srcOk = TICKER_MSGS.filter(m => m.cat === 'trivia' && m.src !== 'idea').every(m => SRC[m.src]);
      const bar = document.getElementById('ticker').getBoundingClientRect();
      return { maxGap, locked, srcOk, barTop: Math.round(bar.top), hdrBottom: Math.round(document.getElementById('hdr').getBoundingClientRect().bottom), n: TICKER_MSGS.length, triv: TICKER_MSGS.filter(m => m.cat === 'trivia').length, health: TICKER_MSGS.filter(m => m.cat === 'health').length, wrong: TICKER_MSGS.some(m => /京都・山崎|コンボ|プロフタブ/.test(m.text)) };
    });
    await page.evaluate(() => { if (_tut) { tutEnd(false); } });
    await page.waitForTimeout(200);
    await page.click('#ticker'); await page.waitForTimeout(300);
    const modal = await page.evaluate(() => ({ open: !document.getElementById('mo').classList.contains('h'), paused: _tk.paused, txt: document.getElementById('mc2').textContent }));
    rec(44, 'TIPS帯：ヘッダー直下に常設・健康は6件に1件以上・未解放のTIPSは出ない・豆知識は全件出典つき・誤記修正・タップで全文と出典', tk.barTop === tk.hdrBottom && tk.maxGap <= 5 && tk.locked === 0 && tk.srcOk && !tk.wrong && modal.open && modal.paused && (modal.txt.includes('出典') || modal.txt.includes('提案') || modal.txt.length > 5), JSON.stringify({ tk, modal: { open: modal.open, paused: modal.paused } }));
    await page.evaluate(() => closeM());
    const bb = await page.evaluate(() => { switchTab('td'); const r = document.getElementById('bb').getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height), cx: Math.round(r.left + r.width / 2), vw: window.innerWidth }; });
    rec(45, '樽の画像を画面中央に大きく（高さ200px以上・押せる範囲は樽の絵の幅・中心が画面中央±10px）', bb.h >= 200 && Math.abs(bb.w / bb.h - 346 / 469) < 0.02 && Math.abs(bb.cx - bb.vw / 2) <= 10, JSON.stringify(bb));
    const op = await page.evaluate(() => {
      const a = fmt(1234567); G.opt.money = 'ja'; const b = fmt(1234567), c = fmt(3.2e9), d = fmt(999); G.opt.money = 'en';
      G.opt.fs = 'l'; applyOpt(); const big = document.documentElement.classList.contains('fs-l'); G.opt.fs = 'm'; applyOpt();
      return { a, b, c, d, big };
    });
    rec(46, '設定：金額の表記（$1.23M / $123万 / $32億）と文字：大', op.a === '$1.23M' && op.b === '$123万' && op.c === '$32億' && op.d === '$999' && op.big, JSON.stringify(op));
    await ctx.close();
    if (errors.length) rec('E12', 'P1テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 遊びの厚み（P3）と保全（P2） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      // #47 章の目標
      const c0 = G.cash; G.stats.orders = 1; G.fac.distillation.p = true; G.stats.filled = 1; G.stats.shipped = 100;
      checkChapters();
      const st = G.chap; const claimed = !!st.claimed[1]; const gain = G.cash - c0;
      T(47, '章の目標：達成ごとに報酬・4つで章完了（演出を予約）', claimed && Math.abs(gain - 8000) < 1e-6 && _celebQ.length + (_celebOn ? 1 : 0) >= 1, 'gain=' + gain + ' claimed=' + claimed);
      _celebQ = []; celebClose();
      // #48 仕上げの樽
      G.dl = 2; G.cash = 1e7; G.te = 1e9; G.uw = ['jack_d'];
      const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 6; G.lots = [l];
      const f0 = lotFlavor(l); const elig0 = lotsFor('jack_d').length;
      const ok = lotFinish(l.id, 'sherry'); const f1 = lotFlavor(l);
      l.age = 7; const f2 = lotFlavor(l); l.age = 9; const f3 = lotFlavor(l);
      const again = lotFinish(l.id, 'wine');
      const sh = caskType('sherry').flavorMod.fruity;
      T(48, '仕上げ：風味を引き継ぎ、移した樽の風味が2年で満ちる・1回のみ・バーボン銘柄から外れる', ok && Math.abs(f1.fruity - f0.fruity) < 1e-6 && Math.abs(f2.fruity - (f0.fruity + sh / 2)) < 1e-6 && Math.abs(f3.fruity - Math.min(100, f0.fruity + sh)) < 1e-6 && !again && elig0 === 1 && lotsFor('jack_d').length === 0 && G.stats.finishes === 1, JSON.stringify({ f0: f0.fruity, f1: f1.fruity, f2: f2.fruity, f3: f3.fruity, again }));
      // #49 名樽と愛好会
      const n1 = makeLot(caskType('bourbon'), caskSize('hogshead')); n1.age = 14;
      const n2 = makeLot(caskType('bourbon'), caskSize('hogshead')); n2.age = 14;
      G.lots = [n1, n2]; lotName(n1.id, 'はじまりの一樽'); trackNamed();
      const o = { id: 'o_s', cid: 'society', kind: 'cask', minAge: 12, qty: 1, rq: 1, mult: 2, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o]; const m = ordMatch(o);
      const ratio = m.cash / Math.max(lotValueOld(n2) * 2, lotValue(n2) * BALANCE.CASK_SPOT_MULT);
      const lim0 = G.stats.limited || 0;
      ordDeliver('o_s', null); trackNamed();
      T(49, '名樽：名前を付けると愛好会が1.2倍で買い取り、蔵出しで記録に残る', m.lot === n1 && Math.abs(ratio - 1.2) < 1e-6 && G.stats.named === 1 && G.stats.limited === lim0 + 1 && G.caskLog.length === 1 && G.caskLog[0].name === 'はじまりの一樽', JSON.stringify({ ratio, log: G.caskLog }));
      // #50 取引先の人物
      G.relEvQ = []; G.rel.local = { lv: 2, done: 14 }; relAdd('local', 1);
      const q = G.relEvQ.slice(); const b0 = G.orders.length;
      relEventApply('local', 3);
      T(50, '取引先：関係★3で人物の会話が予約され、特別な予約注文が届く', q.length === 1 && q[0].lv === 3 && G.orders.length === b0 + 1 && G.orders[G.orders.length - 1].reserve, JSON.stringify(q));
      // #51 月替わりの市場
      _mktOff = false; G.awardMult = {};
      const u = (m) => { _mktForce = m; prodInvalidate(); return priceUnit('glenlivid', 8, 1, productSpec('glenlivid').target); };
      const base = u(2), dec = u(12), jul = u(7), nov = u(11);
      const nov12 = (() => { _mktForce = 11; return priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target); })();
      _mktForce = 2; const nov12b = priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target);
      _mktForce = 4; const tour = cv(); _mktForce = 2; const tour0 = cv();
      _mktForce = 0; _mktOff = true;
      T(51, '月替わりの市場：12月は単価×1.12、7月は10年未満×1.15、11月は12年以上だけ×1.12、4月はツアー×2', Math.abs(dec / base - 1.12) < 1e-9 && Math.abs(jul / base - 1.15) < 1e-9 && Math.abs(nov / base - 1) < 1e-9 && Math.abs(nov12 / nov12b - 1.12) < 1e-9 && Math.abs(tour / tour0 - 2) < 1e-9, [dec / base, jul / base, nov12 / nov12b, tour / tour0].map(x => x.toFixed(3)).join(','));
      // #52 記録
      G.records = {}; G.runStart = Date.now() - 5 * 864e5; recordTier(2); recordUnit(1234);
      const rc = G.records[G.climate];
      T(52, '気候ごとの記録：昇格までの日数と最高単価', rc && rc.tierDays[2] === 5 && rc.bestUnit === 1234, JSON.stringify(rc));
      // #53 来客
      const cash0 = G.cash; const el = document.createElement('button'); el.dataset.vip = ''; el.id = 'vis_t'; document.body.appendChild(el);
      visitorTap(el);
      T(53, '見学ツアーの来客をタップするとチップ（タップ15回分）', Math.abs(G.cash - cash0 - cv() * 15) < 1e-6, G.cash - cash0);
      // #54 景色
      const tb = [3, 6, 12, 17, 22].map(h => sceneTime(h)).join(',');
      switchTab('td'); rdistLight(); const sc = document.getElementById('scene'); const cs = getComputedStyle(sc);
      const bgOk = /data:image\/webp/.test(cs.backgroundImage) && cs.backgroundSize === 'cover';
      const cls = sc.className === 'scene t-' + sceneTime(); const f = getComputedStyle(sc).filter;
      T(54, '景色：蒸留所の絵を表示し、時間帯（朝・昼・夕・夜）で明るさと色味を変える', tb === 'night,am,day,eve,night' && bgOk && cls && f !== 'none', tb + ' / ' + sc.className + ' / ' + f);
      // #55 引き継ぎコード
      const code = encodeCode(JSON.stringify({ a: 1, t: 'ウイスキー' }));
      const back = decodeCode(code);
      let tamper = ''; try { decodeCode(code.slice(0, 10) + (code[10] === 'A' ? 'B' : 'A') + code.slice(11)); } catch (e) { tamper = e.message; }
      let cut = ''; try { decodeCode(code.slice(0, 20)); } catch (e) { cut = e.message; }
      T(55, '引き継ぎコード：往復で一致・改変や欠けは検出して理由を示す', back.t === 'ウイスキー' && /変更|切れ/.test(tamper) && cut.length > 0, tamper + ' / ' + cut);
      // #56 自動バックアップ
      for (let i = 0; i < 3; i++) localStorage.removeItem(bkKey(i));
      const a1 = autoBackup(false), a2 = autoBackup(false), a3 = autoBackup(true), a4 = autoBackup(true), a5 = autoBackup(true);
      const list = bkList();
      T(56, '自動バックアップ：6時間おき・最大3つを入れ替え', a1 && !a2 && a3 && a4 && a5 && list.length === 3, JSON.stringify([a1, a2, a3, a4, a5, list.length]));
      // #57 独自銘柄
      const real = ['Glenlivet', 'Glenfiddich', 'Johnnie Walker', 'Chivas', 'Macallan', 'Laphroaig', 'Ardbeg', 'Talisker', 'Balvenie', 'Dalmore', 'Jameson', 'Bushmills', "Jack Daniel", "Maker's Mark", 'Buffalo Trace', 'Pappy', 'Yamazaki', 'Hakushu', 'Hibiki', 'Nikka', 'Suntory', 'Crown Royal'];
      const names = WL.map(w => w.name + ' ' + w.rg).join('|');
      const hit = real.filter(n => names.toLowerCase().includes(n.toLowerCase()));
      T(57, '25銘柄が独自の名前（実在ブランド名・蒸留所名を含まない）', hit.length === 0 && WL.every(w => WL_RENAME[w.id]), hit.join(','));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E13', 'P2/P3テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- schema 8 → 9 の移行 ----------
  {
    const v8 = { ver: 8, cash: 777, te: 5000, dl: 2, uw: ['glenlivid'], lots: [], bottles: [], orders: [], stats: { orders: 3, shipped: 150, filled: 2 }, fac: { malting: { l: 3, p: true }, distillation: { l: 1, p: true } }, tut: { done: { first: true }, q: [], seed: false }, auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: true, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('z')){sessionStorage.setItem('z','1');localStorage.setItem('we_sound','off');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v8))});}`;
    const { page, errors } = await newPage(browser, pre);
    await page.waitForTimeout(2600);
    const r = await page.evaluate(() => ({ ver: G.ver, se: G.opt.se, bgm: G.opt.bgm, bk: !!localStorage.getItem('we_v4_bak8:guest'), claimed: G.chap.claimed, done: Object.keys(G.chap.done).length, cash: G.cash, seed: G.chap.seed, fill: G.auto.fill.on }));
    rec(58, 'v4.1（schema8）からの移行：バックアップ・音はOFFを引き継ぐ・達成済みの章目標は報酬なしで既読', r.ver === SCHEMA && r.se === 0 && r.bgm === 0 && r.bk && r.claimed[1] === true && r.cash < 2000 && !r.seed && !r.fill, JSON.stringify(r));
    if (errors.length) rec('E14', '移行テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 文字：大 で横スクロールしない ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      G.opt.fs = 'l'; applyOpt(); const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth }); }
      return res;
    });
    const bad = r.filter(x => x.over > 1 || x.doc > 1);
    rec(59, '文字：大・幅360pxでも横スクロールなし', bad.length === 0, JSON.stringify(bad));
    if (errors.length) rec('E15', '文字：大テスト中のエラー', false, errors.join(' | '));
  }
  // ================= v4.3 追加テスト =================
  const STATE = function (mode) {
    if (_offlineGate) closeOfflineModal(); closeM();
    Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose();
    _mktOff = true;
    if (mode === 'fresh') { prodInvalidate(); rall(); return; }
    const late = mode === 'late';
    G.dl = late ? 5 : 3; G.cash = late ? 5e11 : 8e7; G.te = late ? 5e12 : 5e8; G.reputation = late ? 260 : 60;
    G.stats.shipped = late ? 150000 : 2500; G.stats.orders = late ? 120 : 22;
    FD.forEach((f, i) => { G.fac[f.id].p = true; G.fac[f.id].l = (late ? [48, 46, 49, 45, 40, 38] : [24, 22, 26, 21, 18, 14])[i]; });
    G.branch.malting = 1; G.branch.fermentation = 0; G.branch.distillation = late ? 1 : null;
    G.uw = WL.slice(0, late ? 40 : 14).map(w => w.id);
    const mk = (c, s, age) => { const l = makeLot(caskType(c), caskSize(s)); l.age = age; l.L = l.L0 * Math.pow(0.984, age); return l; };
    G.lots = [mk('sherry', 'hogshead', 12.4), mk('bourbon', 'hogshead', 9.1), mk('bourbon', 'quarter', 4.6), mk('wine', 'barrel', 2.2), mk('bourbon', 'butt', 7.8), mk('sherry', 'hogshead', 0.4)];
    const nl = late ? whSlots() - 6 : 10;
    for (let i = 0; i < nl; i++) G.lots.push(mk('bourbon', 'hogshead', 1 + (i % 25) * 1.1));
    G.tank = late ? tankCap() * 0.7 : 1800;
    const t = productSpec('glenlivid').target;
    invAdd('glenlivid', 140, 9, 1.05, t); invAdd('jack_d', 60, 5, 1.0, productSpec('jack_d').target); invAdd('johnnie_em', 25, 12, 1.1, productSpec('johnnie_em').target);
    if (late) { invAdd('hibikue', 80, 17, 1.12, productSpec('hibikue') ? productSpec('hibikue').target : t); }
    G.orders = [];
    for (let i = 0; i < boardSize(); i++) { const o = ordGenerate(); if (o) G.orders.push(o); }
    if (G.orders[0]) { G.orders[0].reserve = true; G.orders[0].accepted = false; }
    G.rel.local = { lv: 2, done: 9 }; G.rel.bar = { lv: 1, done: 4 };
    G.shipLog = { glenlivid: { t: Date.now(), maxAge: 9 }, jack_d: { t: Date.now(), maxAge: 5 } };
    G.bq = [{ id: 'q_x', pid: 'glenlivid', n: 300, done: 120, moved: 120, age: 9, q: 1.05, fl: t, blend: null, oid: null }];
    G.blendHistory = [{ t: Date.now(), target: 'classic_blend', score: 0.82, n: 120 }];
    G.lots[0].name = 'はじまりの一樽'; G.lots[1].fin = { from: 'bourbon', at: 8 };
    G.chap.seed = true; checkChapters();
    prodInvalidate(); rall();
  };
  async function page43(H, rm, mode) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: H }, reducedMotion: rm || 'no-preference' });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
    if (mode) { await page.evaluate(`(${STATE.toString()})(${JSON.stringify(mode)})`); await page.waitForTimeout(500); await page.evaluate(() => { _celebQ = []; celebClose(); closeM(); }); }
    return { page, errors, ctx };
  }
  // ---------- #60 よく使う4タブはスクロールなし（2画面×3状態×4タブ） ----------
  {
    const bad = []; const errs = []; let n = 0; const lists = [];
    for (const H of [667, 740]) for (const mode of ['fresh', 'mid', 'late']) {
      const { page, errors, ctx } = await page43(H, null, mode);
      const r = await page.evaluate(async () => { const o = {}; const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none'; for (const t of ['td', 'tb']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); o[t] = el.scrollHeight - el.clientHeight; }
        switchTab('tcel'); await new Promise(r => setTimeout(r, 100)); const w = document.getElementById('wScroll'), ws = document.getElementById('whSummary'), tc = document.getElementById('tcel'); const inner = w.scrollHeight - w.clientHeight <= 1 && ws.scrollHeight - ws.clientHeight <= 1 && getComputedStyle(w).overflowY === 'visible'; tc.scrollTop = 1e6; await new Promise(r => setTimeout(r, 50)); const cs = [...document.querySelectorAll('#wScene .wcask')]; const lc = cs[cs.length - 1].getBoundingClientRect(), nav = document.getElementById('nav').getBoundingClientRect(), hd = document.querySelector('#tcel .thead').getBoundingClientRect(); const wEnd = inner && lc.bottom <= Math.min(innerHeight, nav.top) + 1 && lc.top >= hd.bottom - 1 && hd.top >= tc.getBoundingClientRect().top - 1;
        switchTab('tsale'); await new Promise(r => setTimeout(r, 100)); const ob = document.getElementById('orderBoard'); ob.scrollTop = 1e6; const oEnd = ob.scrollTop + ob.clientHeight >= ob.scrollHeight - 2; const last = ob.lastElementChild; const lr = last && last.getBoundingClientRect(), obr = ob.getBoundingClientRect();
        return { o, wEnd, oEnd, lastVisible: !last || (lr.bottom <= obr.bottom + 1), cards: ob.children.length, casks: document.querySelectorAll('#wScene .wcask').length }; });
      Object.keys(r.o).forEach(t => { n++; if (r.o[t] > 0) bad.push(mode + H + ':' + t + '+' + r.o[t]); });
      if (mode === 'late') lists.push(r);
      errs.push(...errors); await ctx.close();
    }
    rec(60, 'ホーム・造るはスクロールなし（390×667・390×740 × 開始直後・中盤・終盤 = 12通り。寝かせる・売るはタブ全体でスクロール）', n === 12 && bad.length === 0, JSON.stringify({ n, bad }));
    rec('60b', '寝かせる：棚と倉庫の枠に内部スクロールがなく、タブを一番下まで動かすと最後の樽が見える（見出しは上に貼り付く）・注文の一覧は最後まで届く（v5.4 から売るはタブ全体でスクロール）', lists.length === 2 && lists.every(l => l.wEnd && l.oEnd && l.lastVisible && l.casks >= 20), JSON.stringify(lists));
    if (errs.length) rec('E20', '1画面テスト中のエラー', false, errs.slice(0, 3).join(' | '));
  }
  // ---------- #61-62 TIPS帯は常に流れる ----------
  {
    const out = [];
    for (const rm of ['no-preference', 'reduce']) {
      const { page, errors, ctx } = await page43(740, rm);
      await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } });
      await page.evaluate(() => { const L = TICKER_MSGS.slice().sort((a, b) => b.text.length - a.text.length)[0]; tkPick = () => L; nextTicker(); });
      await page.waitForTimeout(300);
      if (rm === 'reduce') {
        const box = await page.locator('#ticker').boundingBox();
        await page.mouse.move(box.x + 200, box.y + 10); await page.mouse.down();
        const h1 = await page.evaluate(() => tkTxt.getBoundingClientRect().left); await page.waitForTimeout(700); const h2 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.up(); await page.waitForTimeout(250); const longOpen = await page.evaluate(() => !mo.classList.contains('h'));
        await page.waitForTimeout(500); const h3 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.click(box.x + 200, box.y + 10); await page.waitForTimeout(250); const tapOpen = await page.evaluate(() => !mo.classList.contains('h'));
        rec(62, 'TIPS帯：押している間は止まり、離すと再開・短いタップで全文、長押しでは開かない', Math.abs(h1 - h2) < 3 && h3 < h2 - 8 && !longOpen && tapOpen, JSON.stringify({ h1, h2, h3, longOpen, tapOpen }));
      }
      const a = await page.evaluate(() => { const el = tkTxt; const tr = tkTrack.getBoundingClientRect(); const an = el.getAnimations()[0]; const x0 = el.getBoundingClientRect().left;
        const dur = an ? an.effect.getComputedTiming().duration : 0; if (an) { an.pause(); an.currentTime = dur - 1; }
        const r = el.getBoundingClientRect(); const res = { run: el.classList.contains('run'), anim: getComputedStyle(el).animationName, ell: getComputedStyle(el).textOverflow, w: Math.round(el.offsetWidth), track: Math.round(tr.width), x0: Math.round(x0), endRight: Math.round(r.right), trackLeft: Math.round(tr.left), dur: Math.round(dur), speed: Math.round((tr.width + el.offsetWidth) / (dur / 1000)) };
        return res; });
      await page.evaluate(() => nextTicker()); await page.waitForTimeout(400);
      out.push({ rm, ...a });
      const opts = await page.evaluate(() => { switchTab('tp'); return [...document.querySelectorAll('#optBox [data-k="tk"]')].map(b => b.dataset.v).join(','); });
      out[out.length - 1].opts = opts;
      if (errors.length) rec('E21', 'TIPS帯テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    const ok = out.every(o => o.run && o.anim === 'tkScroll' && o.ell !== 'ellipsis' && o.w > o.track && o.endRight <= o.trackLeft + 2 && o.opts === '');
    const sp = out.map(o => o.speed);
    rec(61, 'TIPS帯：「視差効果を減らす」の端末でも右から左へ流れ、最後の文字まで表示枠を通過する（減らす設定では約0.65倍の速さ・速さの設定は v5.4 で廃止）', ok && sp[1] < sp[0] && sp[1] >= sp[0] * 0.55, JSON.stringify(out));
    const { page, ctx } = await page43(740);
    const mig = await page.evaluate(() => { const s = JSON.parse(JSON.stringify(G)); s.opt.tk = 'still'; return sanitize(s).opt.tk; });
    rec('61b', '保存済みの「流さない」は読込時に「遅い」へ置き換える', mig === 'slow', mig);
    await ctx.close();
  }
  // ---------- #63 ホームのアイコン列 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      switchTab('td'); G.hg = { n: 2, got: 2, used: 0 }; rdistLight();
      const icons = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id.replace('hi_', '') + '=' + (b.querySelector('.hib') ? b.querySelector('.hib').textContent : ''));
      const c = chapCur(), st = chapState(); const cn = c.goals.filter(g => st.done[g.id]).length;
      const dn = G.daily.missions.filter(m => m.done).length; const ts = tierReqStatus(G.dl + 1); const tok = ts.filter(o => o.ok).length;
      const expect = ['chap=' + cn + '/4', 'daily=' + dn + '/' + G.daily.missions.length, 'mkt=' + mktDaysLeft() + '日', 'tier=' + tok + '/' + ts.length, 'hg=2/' + V47.HG_MAX].concat(staffOn() ? ['staff=' + G.staff.length + '/' + staffCap()] : []);
      const modals = {};
      for (const [k, word] of [['chap', '章の目標'], ['daily', 'デイリーミッション'], ['mkt', '今月の市場'], ['tier', '昇格の条件'], ['hg', '熟成の砂時計']]) {
        closeM(); document.getElementById('hi_' + k).click(); await new Promise(r => setTimeout(r, 80));
        modals[k] = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes(word);
      }
      closeM(); rdistLight();
      const newsAfter = '';
      const gone = ['chapCard', 'mktCard', 'tierCard', 'dailyBox', 'homeNews', 'nextUnlock'].filter(id => document.getElementById(id));
      return { icons, expect, modals, newsAfter, gone, nextH: document.getElementById('nextCard') ? 999 : 0 };
    });
    rec(63, 'ホーム：章・デイリー・市場・Tier・砂時計はアイコン＋バッジ（数字は内部状態と一致）で、押すとそれぞれの詳細が開く', r.icons.join() === r.expect.join() && Object.values(r.modals).every(Boolean) && r.newsAfter === '' && r.gone.length === 0 && r.nextH <= 80, JSON.stringify(r));
    if (errors.length) rec('E22', 'アイコン列テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #64 生産ライン ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      switchTab('tb'); const f = prodFlows();
      const flows = [...document.querySelectorAll('#lineView .pflow .pfl')].slice(1).map(e => e.textContent);
      const expFlows = [0, 1, 2].map(i => fmtL(f.p[i + 1]) + '/時').concat(['新酒 ' + fmtL(f.newmake) + '/時']);
      const sur = [...document.querySelectorAll('#lineView .pflow')].slice(1).map(e => { const s = e.querySelector('.psur'); return s ? s.textContent : ''; });
      const pm = priceMultBase() * getEventMult('passive');
      const expSur = [0, 1, 2].map(i => f.s[i] > 0.05 ? '外販 +' + fmt(f.s[i] * STAGES[i].price * pm) + '/時' : '').concat(['']);
      const bnIdx = [...document.querySelectorAll('#lineView .pst:not(#barleyBox)')].findIndex(e => e.classList.contains('bn'));
      const caps = [...document.querySelectorAll('#lineView .pst:not(#barleyBox) .pcap')].map(e => e.textContent);
      const tank = document.getElementById('tkAmt').textContent === fmtL(G.tank) + ' / ' + fmtL(tankCap());
      const gone = ['fl', 'recipeWrap', 'facEncEl'].filter(id => document.getElementById(id));
      const mat = document.querySelector('#tb #fac_maturation, #tb #fac_bottling');
      return { flows, expFlows, sur, expSur, bnIdx, bn: f.bottleneck, capOk: caps.every((c, i) => c.endsWith(fmtL(f.cap[i]) + '/時') && !c.includes('能力')), tank, gone, mat: !!mat };
    });
    const ok = r.flows.join('|') === r.expFlows.join('|') && r.sur.join('|') === r.expSur.join('|') && r.bnIdx === r.bn && r.capOk && r.tank && r.gone.length === 0 && !r.mat;
    rec(64, '生産ライン：工程間の流量・余剰と外販収入・能力・いちばん遅い工程・タンク量が計算値と一致', ok, JSON.stringify(r));
    // 熟成庫とボトリングは各タブで強化できる
    const r2 = await page.evaluate(async () => {
      G.cash = 1e15; G.branch.maturation = 0; G.branch.bottling = 0; rall(); switchTab('tcel'); await new Promise(r => setTimeout(r, 100));
      const m0 = G.fac.maturation.l; document.querySelector('#tcel #fac_maturation [data-act="facUp"]').click();
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const b0 = G.fac.bottling.l; document.querySelector('#tsale #fac_bottling [data-act="facUp"]').click();
      const rc = (() => { switchTab('tb'); document.querySelector('[data-act="rcpBox"]').click(); const ok = !mo.classList.contains('h') && document.querySelectorAll('#mc2 .rc').length === 4; closeM(); return ok; })();
      const bl = (() => { switchTab('tcel'); document.getElementById('btnBlend').click(); const ok = !mo.classList.contains('h') && !!document.querySelector('#mc2 #blendRadar'); closeM(); return ok; })();
      const fc = (() => { _ui.celOpen = true; rCellar(); document.querySelector('#fillBox [data-act="fillPickT"]').click(); const ok = document.querySelectorAll('#mc2 .ccard').length === CASK_TYPES.length; closeM(); return ok; })();
      const hist = (() => { switchTab('tb'); document.querySelector('[data-act="facHist"]').click(); const ok = document.querySelectorAll('#mc2 #facEncEl > div').length === FD.length; closeM(); return ok; })();
      return { mat: G.fac.maturation.l - m0, bot: G.fac.bottling.l - b0, rc, bl, fc, hist };
    });
    rec(65, '熟成庫は「寝かせる」、ボトリングは「売る」で強化できる・レシピ・ブレンド・樽の選択・設備の歩みはボタンから開く', r2.mat === 1 && r2.bot === 1 && r2.rc && r2.bl && r2.fc && r2.hist, JSON.stringify(r2));
    if (errors.length) rec('E23', '生産ラインテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #66 見学のお客さん ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('td'); G.hs.vis = 0; _vis.list.forEach(v => { const e = document.getElementById(v.id); if (e) e.remove(); }); _vis.list = []; _vis.next = 0;
      window._tl = []; const _t0 = toast; toast = function (m, d) { _tl.push(m); return _t0(m, d); }; const r0 = Math.random; Math.random = () => 0.5; visitorTick(); Math.random = r0;
      await new Promise(r => setTimeout(r, 600));
      const v = _vis.list[0]; const el = document.getElementById(v.id); const r = el.getBoundingClientRect(); const bb = document.getElementById('bb').getBoundingClientRect();
      const toastTxt = _tl.join('|');
      const txt = el.textContent; const expect = '試飲 +' + fmt(cv() * 15); const tp = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); const onTop = el.contains(tp);
      const c0 = G.cash; el.click(); await new Promise(r => setTimeout(r, 50));
      return { txt, expect, overlap: !onTop, h: Math.round(r.height), gain: G.cash - c0, cv15: cv() * 15, firstToast: toastTxt.includes('見学のお客さん'), seen: G.hs.vis };
    });
    rec(66, '見学のお客さん：吹き出しに「何者か」と報酬額を表示・樽より手前に出て押せる・初回だけ説明が出る', r.txt.includes('見学させて') && r.txt.includes(r.expect) && !r.overlap && r.h >= 44 && Math.abs(r.gain - r.cv15) < 1e-6 && r.firstToast && r.seen === 1, JSON.stringify(r));
    if (errors.length) rec('E24', '見学テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #67 注文カード ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const hs = [...document.querySelectorAll('#orderBoard .oc2')].map(e => Math.round(e.getBoundingClientRect().height) - (e.querySelector('.olots') ? 10 : 0));
      const o = G.orders.find(x => !(x.reserve && x.accepted)); const n0 = G.orders.length;
      document.querySelector(`#orderBoard .oc2[data-id="${o.id}"] .ocl`).click(); await new Promise(r => setTimeout(r, 50));
      const modal = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes('見送る') && document.getElementById('mc2').textContent.includes(custById(o.cid).name);
      document.querySelector('#mc2 [data-act="ordDismissM"]').click(); await new Promise(r => setTimeout(r, 50));
      return { hs, modal, removed: G.orders.length === n0 - 1 && !G.orders.some(x => x.id === o.id), closed: mo.classList.contains('h') };
    });
    rec(67, '注文カード：1枚100px以下に圧縮（「倉庫の樽」ボタンがあれば110px以下）・押すと詳細（人物・会話・見送る）が開き、見送ると消える', r.hs.length > 0 && r.hs.every(h => h <= 100) && r.modal && r.removed && r.closed, JSON.stringify(r));
    if (errors.length) rec('E25', '注文カードテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #68 生産の流れ（ホーム上部）の単位 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => { switchTab('td'); G.bq = []; rdistLight(); return [...document.querySelectorAll('#flow .fnode .fv')].map(e => e.textContent).concat([fmtL(prodFlows().newmake), fmtL(G.tank), G.lots.length + '/' + whSlots(), fmtN(G.bottles.reduce((a, r) => a + r.n, 0)) + '本', G.orders.length + '件']); });
    const got = r.slice(0, 5), exp = r.slice(5);
    rec(68, 'ホーム上部の流れ：生産L/時・タンクL・樽数/上限・瓶の本数・注文件数を単位つきで表示', got.join('|') === exp.join('|'), JSON.stringify({ got, exp }));
    await ctx.close();
  }
  // ---------- #69 v4.2 からの更新案内・金額の単位 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      const s = JSON.parse(JSON.stringify(G)); s.tut.done = { first: true }; s.tut.q = []; delete s.hs;
      const VER = ['upd', 'u43', 'u_line43', 'u44', 'u45', 'u_cel45', 'u46', 'u47', 'u50', 'u_barley']; const condOld = VER.filter(k => TUTS[k]).join(); const condFresh = Object.keys(TUTS).filter(k => /^u\d/.test(k)).join();
      const en = fmtEn(3.1e19), en2 = fmtEn(4.2e15), en3 = fmtEn(5e12);
      G.opt.money = 'ja'; const ja = fmt(3.1e19), ja2 = fmt(2.5e22); G.opt.money = 'en';
      return { condOld, condFresh, en, en2, en3, ja, ja2 };
    });
    rec(69, '版の変更の案内（upd・u43〜u50 など）はない', r.condOld === '' && r.condFresh === '', JSON.stringify(r));
    rec(70, '大きな金額の単位（$31.00Qi・$4.20Qa・$5.00T／$3,100京・$250垓）', r.en === '$31.00Qi' && r.en2 === '$4.20Qa' && r.en3 === '$5.00T' && r.ja === '$3,100京' && r.ja2 === '$250垓', JSON.stringify(r));
    if (errors.length) rec('E26', '更新案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.4 追加テスト =================
  // ---------- #71 設定の選択表示 ----------
  {
    const { page, errors, ctx } = await page43(667);
    await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } switchTab('tp'); });
    const keys = await page.evaluate(() => [...document.querySelectorAll('#optBox [data-act="optSet"]')].map(b => b.dataset.k + '|' + b.dataset.v));
    const bad = [];
    for (const kv of keys) {
      const [k, v] = kv.split('|');
      await page.click(`#optBox [data-k="${k}"][data-v="${v}"]`); await page.waitForTimeout(120);
      const r = await page.evaluate(([k, v]) => { const b = document.querySelector(`#optBox [data-k="${k}"][data-v="${v}"]`); const sib = [...document.querySelectorAll(`#optBox [data-k="${k}"]`)].filter(x => x !== b); return { on: b.classList.contains('on') && b.getAttribute('aria-pressed') === 'true' && b.textContent.startsWith('✓'), others: sib.every(x => !x.classList.contains('on') && x.getAttribute('aria-pressed') === 'false'), bg: getComputedStyle(b).backgroundColor, bg2: sib[0] ? getComputedStyle(sib[0]).backgroundColor : '' }; }, [k, v]);
      if (!r.on || !r.others || r.bg === r.bg2) bad.push(kv + JSON.stringify(r));
    }
    await page.evaluate(() => { opt().theme = 'dark'; opt().motion = 'std'; applyOpt(); });
    rec(71, '設定：どの項目も押した直後に選択表示（塗りつぶし・✓・aria-pressed）が切り替わる', keys.length >= 14 && bad.length === 0, JSON.stringify({ n: keys.length, bad: bad.slice(0, 3) }));
    if (errors.length) rec('E30', '設定テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #72-73 クリティカル廃止・歯車・図鑑 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const base = tapValue(); const c0 = G.cash; for (let i = 0; i < 1000; i++) tap(null);
      const gear = document.getElementById('btnGear').textContent.trim();
      switchTab('te'); _ui.encTab = 'w'; renc();
      const cards = document.getElementById('wg').textContent;
      return { gain: G.cash - c0, expect: base * 1000, base, tapBase: BALANCE.TAP_BASE, crit: typeof BALANCE.CRIT_CHANCE, gear, glass: cards.includes('🥃'), q: cards.includes('❓'), n: document.querySelectorAll('#wg .wc').length };
    });
    rec(72, 'タップ：クリティカル廃止（1,000回で常に1回の額×回数）・基本額は1.5倍', Math.abs(r.gain - r.expect) < 1e-6 && r.tapBase === 4.5 && r.crit === 'undefined', JSON.stringify(r));
    rec(73, 'ヘッダーの歯車は絵文字・図鑑のカードにグラスや色の絵文字がない', r.gear === '⚙️' && !r.glass && !r.q && r.n === 25, JSON.stringify(r));
    if (errors.length) rec('E31', '小修正テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #74 タブの印 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const bd = () => ['td', 'tb', 'tcel', 'tsale'].map(t => t + '=' + document.getElementById('bd_' + t).textContent + (document.querySelector(`#nav .nb[data-tab="${t}"]`).classList.contains('att') ? '*' : '')).join(' ');
      G.tut.q = []; updNavBadges(); const m1 = tabMarks(); const s1 = bd();
      const exp = t => { const x = m1[t]; return x.u ? '!' : x.n ? String(x.n) : ''; };
      const match = ['td', 'tb', 'tcel', 'tsale'].every(t => document.getElementById('bd_' + t).textContent === exp(t));
      // 何もできない状態：印なし
      G.orders = []; G.bq = []; G.cash = 0; G.branch.mashing = 0; G.branch.distillation = 0; G.branch.maturation = 0; G.branch.bottling = 0; G.auto.fill.on = true; G.hs.casks = CASK_TYPES.map(t => t.id).concat(CASK_SIZES.map(z => z.id)); G.lots = G.lots.slice(0, 3); barleyState().kg = barleyCap(); prodInvalidate(); updNavBadges(); const s2 = bd();
      // 大麦切れ：造るに「!」
      barleyState().kg = 0; prodInvalidate(); updNavBadges(); const s3 = bd();
      const noSlotCount = !/tcel=\d/.test(s2);
      return { s1, match, s2, s3, noSlotCount };
    });
    rec(74, 'タブの印：件数は操作候補と一致・待つだけなら印なし（空き枠数は出さない）・大麦切れで造るに「!」', r.match && r.s2 === 'td= tb= tcel= tsale=' && /tb=!\*/.test(r.s3) && r.noSlotCount, JSON.stringify(r));
    if (errors.length) rec('E32', 'タブの印テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #75-76 大麦 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = {};
      o.start = { kg: barleyState().kg, cap: barleyCap(), auto: barleyState().auto };
      G.fac.malting.l = 1; G.cash = 100000; prodInvalidate();
      const f = prodFlows(); const pr = barleyPrice(); const c0 = G.cash, s0 = G.stats.barleyCost;
      prodTick(3600000);
      o.hour = { use: f.p[0], cost: G.stats.barleyCost - s0, expCost: f.p[0] * pr, net: G.cash - c0, expNet: f.surplusPh * getEventMult('passive') - f.p[0] * pr, kg: barleyState().kg };
      barleyState().auto = false; barleyState().kg = f.p[0] / 2; prodInvalidate(); const t0 = G.cash; prodTick(3600000);
      o.half = { gain: G.cash - t0, exp: f.surplusPh * getEventMult('passive') / 2, kg: barleyState().kg, ok: barleyOK(), p0: prodFlows().p[0] };
      barleyState().auto = true; G.cash = 1e6; barleyState().kg = barleyCap(); G.ls = Date.now() - 30 * 3600000; const s1 = G.stats.barleyCost; offline();
      o.off = { cost: G.stats.barleyCost - s1, exp: f.p[0] * BALANCE.OFFLINE_CAP_H * pr, modal: document.getElementById('mc2').textContent.includes('原料費') };
      if (_offlineGate) closeOfflineModal();
      barleyState().auto = false; barleyState().kg = 0; G.cash = 1e6; G.ls = Date.now() - 5 * 3600000; offline();
      o.stop = document.getElementById('mc2').textContent.includes('大麦が切れて止まっていた時間');
      if (_offlineGate) closeOfflineModal();
      const s = JSON.parse(JSON.stringify(G)); s.ver = 9; delete s.barley; s.opt = { fs: 'm', money: 'en', se: 0, bgm: 0, vib: true, tk: 'mid' };
      const g = parseSave(s); o.mig = { ver: g.ver, barley: g.barley, theme: g.opt.theme, motion: g.opt.motion };
      return o;
    });
    const h = r.hour;
    rec(75, '大麦：製麦した量だけ消費し原料費を払う・在庫が半分なら生産も半分・在庫切れで製麦が止まる', r.start.kg === r.start.cap && r.start.auto && Math.abs(h.cost - h.expCost) < 0.01 && Math.abs(h.net - h.expNet) < 0.01 && Math.abs(r.half.gain - r.half.exp) < 0.01 && !r.half.ok && r.half.p0 === 0, JSON.stringify(r));
    rec(76, '大麦：放置は最大24時間分を消費して報告に原料費を出す・在庫切れの停止時間を報告・schema11へ移行（サイロ満タン・色ダーク）', Math.abs(r.off.cost - r.off.exp) / r.off.exp < 0.01 && r.off.modal && r.stop && r.mig.ver === SCHEMA && r.mig.barley.kg === null && r.mig.barley.auto === true && r.mig.theme === 'dark' && r.mig.motion === 'std', JSON.stringify(r));
    if (errors.length) rec('E33', '大麦テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #77-78 案内 ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { _mktOff = true; window._tutSw = 0; const o = switchTab; switchTab = function (id) { if (new Error().stack.includes('tutShow')) window._tutSw++; return o(id); }; });
    await page.evaluate(() => titleStart(false)); await page.waitForTimeout(1200);
    const tabs = [];
    for (let k = 0; k < 16; k++) {
      const st = await page.evaluate(() => _tut ? { i: _tut.i, tab: document.querySelector('.tab.on').id } : null);
      if (!st) break; tabs.push(st.tab);
      const box = await page.evaluate(() => { const s = tutStep(); const el = s && s.sel ? tutEl(s) : null; if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, do: !!s.do }; });
      if (box && box.do) await page.mouse.click(box.x, box.y); else await page.click('#cNext');
      await page.waitForTimeout(450);
    }
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, sw: window._tutSw, malt: facLv('malting'), orders: G.stats.orders }));
    rec(77, 'はじめての案内：案内がタブを切り替えない（ナビはプレイヤーが押す）・ホーム→売る→造るの順・最後まで進む', r.done && r.sw === 0 && r.malt >= 1 && r.orders >= 1 && tabs[0] === 'td' && tabs.includes('tsale') && tabs[tabs.length - 1] === 'tb', JSON.stringify({ r, tabs: tabs.join('>') }));
    await page.waitForTimeout(2500);
    const w = await page.evaluate(() => ({ q: G.tut.q.slice(), cel: document.getElementById('bd_tcel').textContent, run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    await page.click('#nav .nb[data-tab="tcel"]'); await page.waitForTimeout(900);
    const w2 = await page.evaluate(() => ({ run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    rec(78, '後から出る案内：別のタブにいる間はナビに「新」を付けて待ち、そのタブを開くと始まる', w.q.includes('u_age') && w.cel === '新' && w.run !== 'u_age' && w2.run === 'u_age' && w2.tab === 'tcel', JSON.stringify({ w, w2 }));
    if (errors.length) rec('E34', '案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #79 動き ----------
  {
    const { page, errors, ctx } = await page43(667, 'reduce', 'mid');
    const r = await page.evaluate(async () => {
      switchTab('tb'); await new Promise(r => setTimeout(r, 200));
      const band = document.querySelector('#lineView .pflow.run .pband'); const an = band ? getComputedStyle(band).animationName : 'none';
      const dur = band ? getComputedStyle(band).animationDuration : '';
      G.tut.q = []; updNavBadges(); const att = document.querySelector('#nav .nb.att'); const aan = att ? getComputedStyle(att, '::after').animationName : 'none';
      let conf = null; const oc = celebrate; celebrate({ icon: '🎉', title: 't', sub: '' }); await new Promise(r => setTimeout(r, 100)); conf = document.querySelectorAll('#celebrate .conf i').length; _celebQ = []; celebClose();
      return { an, dur, aan, conf, low: lowMotion() };
    });
    rec(79, '動き：「視差効果を減らす」でも生産ラインの矢印とタブの印はゆっくり動き、紙吹雪は出ない', r.an === 'pflow' && parseFloat(r.dur) >= 1 && r.aan === 'attPulse' && r.conf === 0 && r.low, JSON.stringify(r));
    if (errors.length) rec('E35', '動きテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #80 色（コントラスト）と1画面 ----------
  {
    const out = {}; let overs = [];
    for (const th of ['dark', 'light']) {
      const { page, errors, ctx } = await page43(667, null, 'mid');
      const r = await page.evaluate(async th => {
        opt().theme = th; applyOpt(); _celebQ = []; celebClose(); closeM();
        const parse = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
        const lum = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
        const bgOf = el => { let e = el; while (e) { const cs = getComputedStyle(e); if (cs.backgroundImage && cs.backgroundImage !== 'none') return null; const c = parse(cs.backgroundColor); if (c && c.a >= 0.9) return c; e = e.parentElement; } return parse(getComputedStyle(document.body).backgroundColor); };
        const low = []; let n = 0; const over = {};
        for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
          switchTab(t); await new Promise(r => setTimeout(r, 150)); _celebQ = []; celebClose();
          const el = document.getElementById(t); const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none'; if (['td', 'tb'].includes(t)) over[t] = el.scrollHeight - el.clientHeight;
          const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let x;
          while (x = w.nextNode()) {
            const p = x.parentElement; if (!p || !x.textContent.trim() || p.getClientRects().length === 0 || p.closest('#stage') || p.closest('button:disabled') || p.closest('.lk') || p.closest('.ca')) continue;
            const cs = getComputedStyle(p); if (parseFloat(cs.opacity) < 1) continue;
            const fg = parse(cs.color); const bg = bgOf(p); if (!fg || !bg) continue; n++;
            const L1 = lum(fg), L2 = lum(bg); const cr = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
            if (cr < 4.5) low.push(t + ':' + cr.toFixed(2) + ':' + x.textContent.trim().slice(0, 10));
          }
        }
        return { n, low: low.slice(0, 10), nLow: low.length, over, theme: document.documentElement.dataset.theme };
      }, th);
      out[th] = r; Object.entries(r.over).forEach(([t, v]) => { if (v > 0) overs.push(th + ':' + t + '+' + v); });
      if (errors.length) rec('E36', '色テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    rec(80, '色：ダーク・ライトとも全タブの文字のコントラスト4.5以上（ライトでもホーム・造るは1画面）', out.dark.nLow === 0 && out.light.nLow === 0 && out.light.theme === 'light' && out.dark.n > 200 && out.light.n > 200 && overs.length === 0, JSON.stringify({ dark: { n: out.dark.n, low: out.dark.low }, light: { n: out.light.n, low: out.light.low }, overs }));
  }
  // ---------- #81 樽の選択欄 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.fac.distillation.p = true; prodInvalidate(); switchTab('tcel'); rCellar();
      const picks = [...document.querySelectorAll('#fillBox .fpick')].map(b => b.textContent.replace(/\s+/g, ''));
      const newBefore = document.querySelectorAll('#fillBox .fnew').length;
      G.te = 2e7; rCellar(); updNavBadges();
      const newAfter = document.querySelectorAll('#fillBox .fpick.new').length; const mark = document.getElementById('bd_tcel').textContent;
      document.querySelector('#fillBox [data-act="fillPickT"]').click(); await new Promise(r => setTimeout(r, 50));
      const cards = document.querySelectorAll('#mc2 .ccard').length; const locked = document.querySelectorAll('#mc2 .ccard.lk').length;
      document.querySelector('#mc2 .ccard[data-id="sherry"]').click(); await new Promise(r => setTimeout(r, 50));
      rCellar(); updNavBadges();
      return { picks, newBefore, newAfter, mark, cards, locked, cask: G.auto.fill.cask, newGone: document.querySelectorAll('#fillBox .fpick.new').length, mark2: document.getElementById('bd_tcel').textContent };
    });
    rec(81, '樽詰め：「樽の種類▾」「サイズ▾」の選択欄・解禁でNEWとタブの印・カードで選べる', r.picks.length === 2 && r.picks.every(p => p.includes('▾')) && r.newBefore === 0 && r.newAfter >= 1 && r.mark !== '' && r.cards === 5 && r.locked >= 1 && r.cask === 'sherry' && r.newGone === 0, JSON.stringify(r));
    if (errors.length) rec('E37', '樽選択テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.5 追加テスト =================
  // ---------- #81 ホームの並び・お知らせ廃止・次にやることの行の廃止 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      switchTab('td'); rdistLight();
      const order = [...document.getElementById('td').children].map(e => e.id);
      const st = document.getElementById('stage').getBoundingClientRect();
      const hi = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id);
      const gone = ['hintMake', 'hintAge', 'hintSell', 'hi_news', 'nextCard'].filter(id => document.getElementById(id));
      return { order, stageH: Math.round(st.height), stageBottom: Math.round(st.bottom), navTop: Math.round(document.getElementById('nav').getBoundingClientRect().top), hi, gone, nu: typeof nextUnlockText, pn: typeof pushNews };
    });
    rec(81, 'ホーム：上から「生産の流れ → アイコン列 → 景色と樽」・お知らせと各タブ冒頭の「次にやること」の行はない', r.order.join() === 'flow,homeIcons,stage' && r.stageH >= 300 && Math.abs(r.stageBottom - r.navTop) <= 12 && r.hi.includes('hi_hg') && !r.hi.includes('hi_fin') && !r.hi.includes('hi_news') && r.gone.length === 0 && r.nu === 'undefined' && r.pn === 'undefined', JSON.stringify(r));
    if (errors.length) rec('E40', 'ホーム並びテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #82-83 樽タップの額・試飲会 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('td');
      let T = Date.now(); _acctClock = () => T;
      G.taste = { n: 0, cnt: 0, day: '' };
      const expV = cv() + 0.002 * ti(); const v = tapValue();
      const c0 = G.cash; tap(null); const gain = G.cash - c0;
      const o = { expV, v, gain };
      // 29回目までは試飲会なし、30回目で評判+1・注文が30分早まる
      G.taste = { n: 0, cnt: 0, day: tasteToday() };
      const rep0 = G.reputation; const clk0 = G.orderClock = Date.now() + 5 * 3600000;
      for (let i = 0; i < 29; i++) tap(null);
      o.before = { cnt: G.taste.cnt, n: G.taste.n, rep: G.reputation - rep0 };
      tap(null);
      o.after = { cnt: G.taste.cnt, n: G.taste.n, rep: +(G.reputation - rep0).toFixed(6), clk: (clk0 - G.orderClock) / 60000, tastings: G.stats.tastings };
      o.ui = { txt: document.getElementById('tgTxt').textContent, w: document.getElementById('tgFill').style.width };
      for (let i = 0; i < 30 * 6; i++) tap(null);
      o.cap = { cnt: G.taste.cnt, n: G.taste.n, txt: document.getElementById('tgTxt').textContent };
      T += 864e5; tasteUi();
      o.next = { cnt: tasteState().cnt, txt: document.getElementById('tgTxt').textContent };
      _acctClock = () => Date.now();
      const dp = DAILY_POOL.find(p => p.id === 'dm_taste');
      o.daily = dp ? dp.label.replace('NOT回', '2回') : '';
      const tc = document.querySelector('.tgauge .tgtxt'); o.fs = parseFloat(getComputedStyle(tc).fontSize);
      return o;
    });
    rec(82, 'タップ：1回の額＝見学ツアー額＋毎時の外販収入×0.2%', Math.abs(r.v - r.expV) < 1e-9 && Math.abs(r.gain - r.v) < 1e-6 && r.v > 0, JSON.stringify({ v: r.v, expV: r.expV, gain: r.gain }));
    rec(83, '試飲会：30回で評判+1・次の注文が30分早まる・1日5回まで・日が変わると再開・ゲージ表示とデイリー', r.before.cnt === 0 && r.before.n === 29 && r.before.rep === 0 && r.after.cnt === 1 && r.after.n === 0 && Math.abs(r.after.rep - 1) < 1e-6 && Math.abs(r.after.clk - 30) < 0.01 && r.ui.txt.includes('0/30') && r.ui.txt.includes('1/5') && r.cap.cnt === 5 && r.cap.txt.includes('本日終了') && r.next.cnt === 0 && r.next.txt.includes('0/5') && r.daily === '試飲会を2回開く' && r.fs >= 12, JSON.stringify(r));
    if (errors.length) rec('E41', '試飲会テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #84-86 決算書：3表のつながり・現金の照合・原価の流れ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let T = Date.now(); _acctClock = () => T;
      G.acct = null; acctEnsure();
      const tol = v => Math.max(1, Math.abs(v) * 1e-9);
      const checks = []; const chk = tag => { const s = acctLive(); checks.push({ tag, na: naOf(s.c) - naOf(s.o) - s.ni, cash: s.c.cash - s.o.cash - s.opcf - s.invcf, unex: s.unex, tolv: tol(s.c.cash) }); };
      // 原価の流れ：樽に詰める → 瓶詰め → 直販
      G.tank = 5000; G.cash = Math.max(G.cash, 1e7); acctEnsure();
      const bA = acctBAvg(); const cc = caskCost('bourbon', 'hogshead');
      const c0 = G.cash; fillCask('bourbon', 'hogshead', false); const lot = G.lots[G.lots.length - 1];
      const fillOk = Math.abs(c0 - G.cash - cc) < 1e-6 && Math.abs(lot.c - (250 * bA + cc)) < 1e-6;
      chk('fill');
      lot.age = 12; const pid = lotProducts(lot)[0] || 'glenlivid'; if (!G.uw.includes(pid)) G.uw.push(pid);
      const lc0 = lot.c, L0 = lot.L; const n = 20; const unit = btlUnit(); const c1 = G.cash;
      const okB = botStart(pid, n, 'manual', [lot.id], {}); const q = G.bq[G.bq.length - 1];
      const matOk = okB && Math.abs(c1 - G.cash - unit * n) < 1e-6;
      const drawOk = Math.abs((lc0 - lot.c) + unit * n - q.c) < 1e-6 && Math.abs((lc0 - lot.c) / lc0 - (n * BALANCE.BOTTLE_L) / L0) < 1e-9;
      botTick(3600000 * 10);
      const row = G.bottles.find(b => b.pid === pid && b.age === q.age);
      const rowC0 = row ? row.c : -1; const rowN0 = row ? row.n : 0;
      chk('bottled');
      const s0 = acctLive(); spotSell(row.id, 5, true); const s1 = acctLive();
      const saleOk = Math.abs((rowC0 - (row.c || 0)) - rowC0 * 5 / rowN0) < 1e-6 && s1.rev.spot > s0.rev.spot;
      chk('spot');
      // 所持金を動かす処理を一通り
      acOther(1e12 - G.cash); G.cash = 1e12;
      for (const f of FD) { if (!G.fac[f.id].p && isUL(f.id)) purFac(f.id); }
      upgFac('malting'); upgClick(); purchaseRegion(Object.keys(REGIONS).find(id => !G.regions[id]) || 'x');
      const rx = REGIONS_EX.find(x => !G.regionsEx.includes(x.id)); if (rx) buyExRegion(rx.id);
      const rk = RAW_MATERIALS.grain.find(x => !G.recipeOwned.includes(x.id)); if (rk) rcpBuy('grain', rk.id);
      barleyBuyFull(); sellNewmake(100); if (G.lots.length > 3) sellLot(G.lots[0].id);
      applyEventEffect({ type: 'x', effect: { cash: -12345 } }); applyEventEffect({ type: 'x', effect: { cashMult: 1.01 } }); applyEventEffect({ type: 'x', effect: { cashBonus: '2h' }, icon: '' });
      for (let i = 0; i < 10; i++) tap(null);
      for (let i = 0; i < 36; i++) { T += 100000; prodTick(100000); lotTick(100000); botTick(100000); }
      const ol = G.lots.find(l => l.age >= 2 && typeof finishable === 'function' && finishable(l)); if (ol) lotFinish(ol.id, 'sherry');
      chk('ops');
      const dep0 = acctLive().dep;
      // 月をまたぐ
      const fa0 = faNBV(acctMonthF(T)); const faHalf = faNBV(acctMonthF(T) + V45.FA_MONTHS / 2);
      const mBefore = G.acct.cur.m; T += 40 * 864e5; acctEnsure(); const rec0 = G.acct.hist[0];
      chk('newmonth');
      const chain = Math.abs(naOf(rec0.c) - naOf(G.acct.cur.o)) < 1e-6 && Math.abs(rec0.c.cash - G.acct.cur.o.cash) < 1e-6;
      const recOk = Math.abs(naOf(rec0.c) - naOf(rec0.o) - rec0.ni) < tol(rec0.c.cash) && Math.abs(rec0.c.cash - rec0.o.cash - rec0.opcf - rec0.invcf) < tol(rec0.c.cash) && Math.abs(rec0.unex) < tol(rec0.c.cash) && rec0.m === mBefore && rec0.to === G.acct.cur.m - 1;
      // 償却：耐用年数（実時間10日）で簿価0
      const faEnd = faNBV(acctMonthF(T));
      _acctClock = () => Date.now();
      return { checks, fillOk, matOk, drawOk, saleOk, chain, recOk, rec0: { m: rec0.m, to: rec0.to, R: rec0.R, ni: rec0.ni, dep: rec0.dep, cogs: rec0.cogs, unex: rec0.unex }, dep0, fa0, faHalf, faEnd, cats: Object.keys(rec0.rev).filter(k => rec0.rev[k] > 0).join(',') + '|' + Object.keys(rec0.pur).filter(k => rec0.pur[k] > 0).join(',') + '|' + Object.keys(rec0.sga).filter(k => rec0.sga[k] > 0).join(',') };
    });
    const bad = r.checks.filter(c => Math.abs(c.na) > c.tolv || Math.abs(c.cash) > c.tolv || Math.abs(c.unex) > c.tolv);
    rec(84, '決算書：どの時点でも「期首純資産＋純利益＝期末純資産」「期首現金＋営業CF＋投資CF＝期末現金」、月をまたぐと前月が確定し翌月の期首につながる・設備は実時間10日で償却', bad.length === 0 && r.chain && r.recOk && r.fa0 > 0 && r.faHalf > r.fa0 * 0.3 && r.faHalf < r.fa0 * 0.7 && r.faEnd < 1e-6, JSON.stringify({ bad, chain: r.chain, recOk: r.recOk, rec0: r.rec0, fa0: r.fa0, faHalf: r.faHalf, faEnd: r.faEnd }));
    rec(85, '現金の照合：所持金を動かす全処理に科目が付き、科目のない増減が0', r.checks.every(c => Math.abs(c.unex) <= c.tolv) && r.cats.includes('spot') && r.cats.includes('tap') && r.cats.includes('ext') && r.cats.includes('lot') && r.cats.includes('barley') && r.cats.includes('cask') && r.cats.includes('bottle') && r.cats.includes('rcp') && r.cats.includes('rg'), JSON.stringify({ cats: r.cats, unex: r.checks.map(c => c.tag + ':' + c.unex) }));
    rec(86, '原価：樽＝新酒（大麦単価）＋樽代、瓶詰めで使った量の割合だけ原価が移り資材費が加わる、売れた分だけ在庫の原価が減る', r.fillOk && r.matOk && r.drawOk && r.saleOk, JSON.stringify({ fillOk: r.fillOk, matOk: r.matOk, drawOk: r.drawOk, saleOk: r.saleOk }));
    if (errors.length) rec('E42', '決算書テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #87 瓶の資材費 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = {};
      o.unit = btlUnit(); o.expUnit = 8 * distMult() * rawM('bottle');
      const l = G.lots.find(x => x.age >= 12) || G.lots[0]; const pid = lotProducts(l)[0];
      G.stats.freeBtl = 1; G.bq = []; G.cash = o.unit * 10 - 1;
      const n0 = G.bq.length; o.fail = !botStart(pid, 10, 'manual', [l.id], {}) && G.bq.length === n0;
      G.cash = o.unit * 10 + 5; o.ok = botStart(pid, 10, 'manual', [l.id], {}) && Math.abs(G.cash - 5) < 1e-6;
      // 最初の1回は無料
      G.stats.bottled = 0; G.stats.freeBtl = 0; G.bq = []; G.cash = 0;
      o.free = btlFreeAvail() && botStart(pid, 10, 'manual', [l.id], {}) && G.cash === 0 && G.stats.freeBtl === 1 && !btlFreeAvail();
      switchTab('tsale'); _ui.sellTab = 'ord'; rShip();
      o.bqTxt = document.querySelector('#bqBox .plv') ? document.querySelector('#bqBox .plv').textContent : '';
      const od = G.orders.find(x => x.kind === 'product' && !ordMatch(x).ok && ordFulfillPlan(x).ok);
      if (od) { openOrderInfoModal(od.id); o.modal = document.getElementById('mc2').textContent; closeM(); }
      return o;
    });
    rec(87, '瓶の資材：瓶詰めの開始時に本数×$8×Tier倍率を払う・足りなければ始まらない・最初の1回は無料・売るタブと注文の詳細に表示', Math.abs(r.unit - r.expUnit) < 1e-9 && r.fail && r.ok && r.free && r.bqTxt.includes('/本') && (!r.modal || (r.modal.includes('瓶の資材') && r.modal.includes('差し引き'))), JSON.stringify(r));
    if (errors.length) rec('E43', '資材費テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #88-89 寝かせる：①→③の流れ（自動で詰めている間は①②をたたむ）・棚の樽の見た目 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const vis = () => [...document.getElementById('tcel').children].filter(e => e.getClientRects().length).map(e => e.id || e.className).join();
      hsState().casks = CASK_TYPES.map(t => t.id).concat(CASK_SIZES.map(z => z.id)); G.auto.fill.on = true; _ui.celOpen = false; switchTab('tcel'); rCellar();
      const o = { fold: vis(), fno: (document.querySelector('#celTank .cno') || {}).textContent, ftxt: document.getElementById('celTank').textContent.includes('自動で樽詰め中') };
      document.querySelector('#celTank [data-act="celOpen"]').click();
      o.open = vis(); o.ys = ['celTank', 'fillBox', 'whSummary'].map(id => document.getElementById(id).getBoundingClientRect().top); o.nos = ['celTank', 'fillBox', 'whSummary'].map(id => (document.querySelector('#' + id + ' .cno') || {}).textContent);
      o.price = document.querySelector('#fillBox .cp1').textContent; o.cc = fmt(caskCost(G.auto.fill.cask, G.auto.fill.size));
      _ui.celOpen = false; G.auto.fill.on = false; rCellar(); o.off = vis(); G.auto.fill.on = true; rCellar();
      // 棚：1段6樽・樽の色帯＝種類・大きさ＝サイズ・線＝残量・札＝目標までの残り
      const cells = [...document.querySelectorAll('#wScene .wcask')]; const bad = [];
      const order = shelfLots().map(l => l.id).join() === cells.map(c => c.dataset.id).join();
      const wOf = c => { const b = [...c.querySelectorAll('svg g path, path')].filter(p => p.closest('.wkx') === null && !p.classList.contains('pmk')).map(p => p.getBBox()); return Math.max(...b.map(x => x.x + x.width)) - Math.min(...b.map(x => x.x)); };
      cells.forEach(c => { const l = G.lots.find(x => x.id === c.dataset.id); const fills = [...c.querySelectorAll('path')].map(p => p.getAttribute('fill'));
        const has = c0 => [c0, pxMix(c0, '#000000', .28), pxMix(c0, '#ffffff', .2)].some(x => fills.includes(x)); if (!has(PX_CT[l.cask] || '#6a6a6a') || !has(WOOD[lotAgeStep(l)])) bad.push('col:' + l.id);
        const g = c.querySelector('[data-lgg]'); if (Math.abs(+g.getAttribute('width') - Math.round(36 * lotPct(l) / 100)) > 0) bad.push('gauge:' + l.id);
        const lb = document.querySelector(`#wScene [data-wse="${l.id}"]`); if (!lb || lb.textContent !== shelfLabel(l)) bad.push('lbl:' + l.id); });
      const q = G.lots.find(l => l.size === 'quarter'), bt = G.lots.find(l => l.size === 'butt');
      const cq = cells.find(c => c.dataset.id === q.id), cb = cells.find(c => c.dataset.id === bt.id);
      const xs = cells.map(c => +c.querySelector('rect').getAttribute('x')); const cols = new Set(xs).size;
      const l0 = G.lots[0]; const g0 = +document.querySelector(`[data-lgg="${l0.id}"]`).getAttribute('width'); l0.L = l0.L * 0.5; sceneLight(); const g1 = +document.querySelector(`[data-lgg="${l0.id}"]`).getAttribute('width');
      return Object.assign(o, { n: cells.length, lots: G.lots.length, order, bad, cols, sizeOk: wOf(cq) < wOf(cb), dec: g1 < g0, noGrid: !document.querySelector('.whg2,.ck2,.whkey,.lgd') });
    });
    rec(88, '寝かせる：自動で詰めている間は ①② を1行にたたみ（押すと開く）、開くと「① タンクの新酒 → ② 空き樽を仕入れて詰める（仕入れ値）→ ③ 倉庫」を流れる矢印でつなぐ・自動OFFは開いたまま', r.fold === 'thead,celJnl,celTank,whSummary' && r.fno === '①②' && r.ftxt && r.open === 'thead,celJnl,celTank,celF1,fillBox,celF2,whSummary' && r.ys[0] < r.ys[1] && r.ys[1] < r.ys[2] && r.nos.join() === '①,②,③' && r.price.includes(r.cc) && r.off === r.open, JSON.stringify(r));
    rec(89, '倉庫の棚：全部の樽を年数の順に1段6樽で並べる・帯の色で種類・木の色で熟成・大きさでサイズ・札の下の線で残量（天使の分け前で減る）・札に目標までの残り時間・樽のマスの一覧は廃止', r.n === r.lots && r.order && r.bad.length === 0 && r.cols === 6 && r.sizeOk && r.dec && r.noGrid, JSON.stringify({ n: r.n, order: r.order, bad: r.bad, cols: r.cols, sizeOk: r.sizeOk, dec: r.dec, noGrid: r.noGrid }));
    if (errors.length) rec('E44', '寝かせるテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #90 決算書の画面 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let T = Date.now(); _acctClock = () => T;
      G.acct = null; acctEnsure(); G.cash += 1; for (let i = 0; i < 20; i++) tap(null);
      for (let i = 0; i < 36; i++) { T += 100000; prodTick(100000); }
      upgFac('malting');
      T += 35 * 864e5; acctEnsure(); for (let i = 0; i < 5; i++) tap(null);
      switchTab('te'); _ui.encTab = 'r'; renc(); const badge = document.querySelector('#recList .frec') ? '記録' : '';
      document.querySelector('#recList .frec').click(); await new Promise(r => setTimeout(r, 80));
      const o = { badge, title: document.getElementById('mc2').textContent.includes('決算書') };
      const box = () => { const cols = [...document.querySelectorAll('#finBox .fmain .fcol')].map(c => [...c.children].reduce((a, e) => a + e.getBoundingClientRect().height, 0)); return cols.map(Math.round); };
      o.views = {};
      for (const v of ['pl', 'bs', 'cf']) { document.querySelector(`#finBox [data-act="fsView"][data-v="${v}"]`).click(); await new Promise(r => setTimeout(r, 30)); o.views[v] = { cols: box(), rows: document.querySelectorAll('#finBox .frw').length, per: document.querySelector('#finBox .fper').textContent }; }
      // 面積（高さ）が金額に比例：PLの売上高の箱
      document.querySelector('#finBox [data-act="fsView"][data-v="pl"]').click(); await new Promise(r => setTimeout(r, 30));
      const p = finPeriods()[0]; const rev = document.querySelector('#finBox .fmain .b-rev'); const H = 190;
      const tot = Math.max(p.R, p.cogs + p.S + p.dep + Math.max(0, p.ni)); o.revH = rev ? rev.getBoundingClientRect().height : 0; o.revExp = p.R / tot * H;
      document.querySelector('#finBox [data-act="fsPrev"]').click(); await new Promise(r => setTimeout(r, 30));
      o.prevPer = document.querySelector('#finBox .fper').textContent;
      const mc = document.getElementById('mc2'); o.hscroll = mc.scrollWidth - mc.clientWidth;
      o.small = [...document.querySelectorAll('#finBox *')].filter(e => e.childNodes.length && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize) < 12).map(e => e.textContent.slice(0, 10));
      closeM(); o.badgeAfter = document.getElementById('hi_fin') ? 'x' : '';
      _acctClock = () => Date.now();
      return o;
    });
    const eq = c => c.length === 2 && Math.abs(c[0] - c[1]) <= 3;
    rec(90, '決算書の画面：図鑑の「記録」から開き、PL・BS・CFを切り替えてボックス図（左右の合計が一致・高さが金額に比例）と数字の表・月の切替', r.badge === '記録' && r.title && eq(r.views.pl.cols) && eq(r.views.bs.cols) && eq(r.views.cf.cols) && Math.abs(r.revH - r.revExp) <= 2 && r.views.pl.per.includes('途中経過') && r.prevPer.includes('確定') && r.hscroll <= 0 && r.small.length === 0 && r.badgeAfter === '', JSON.stringify(r));
    if (errors.length) rec('E45', '決算書画面テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #91 schema 10 → 11 の移行 ----------
  {
    const p0 = await page43(667, null, 'mid');
    const v10 = await p0.page.evaluate(() => { const s = JSON.parse(JSON.stringify(G)); s.ver = 10; delete s.acct; delete s.taste; delete s.stats.freeBtl; delete s.stats.tastings; if (s.hs) { delete s.hs.fin; delete s.hs.new45; } s.lots.forEach(l => delete l.c); s.bottles.forEach(b => delete b.c); s.bq.forEach(q => delete q.c); s.tut.done = { first: true }; s.tut.q = []; return s; });
    await p0.ctx.close();
    const pre = `if(!sessionStorage.getItem('w')){sessionStorage.setItem('w','1');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v10))});}`;
    const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.addInitScript(pre);
    await page.goto(FILE); await page.waitForTimeout(1500);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(500);
    const r = await page.evaluate(() => {
      if (_offlineGate) closeOfflineModal();
      acctEnsure(); const s = acctLive(); const a = G.acct;
      return { ver: G.ver, bk: !!localStorage.getItem('we_v4_bak10:guest'), mig: a.mig, faMig: a.faMig, faEst: faEstimate(), cap: a.cap, na0: naOf(a.cur.o), free: G.stats.freeBtl, lotsC: G.lots.every(l => l.c > 0), q: G.tut.q.slice(), new45: G.hs.new45, unex: s.unex, dNA: naOf(s.c) - naOf(s.o) - s.ni };
    });
    rec(91, 'v4.4（schema10）からの移行：バックアップ・設備はこれまでの費用から推計・開始時のBSは資産＝元入金・瓶の無料分は使用済み・版の案内は出さない', r.ver === SCHEMA && r.bk && r.mig && r.faMig > 0 && Math.abs(r.faMig - r.faEst) / r.faEst < 0.001 && Math.abs(r.cap - r.na0) < 1e-6 && r.free === 1 && r.lotsC && !r.q.includes('u45') && r.new45 === 0 && Math.abs(r.dNA) < Math.max(1, r.cap * 1e-9), JSON.stringify(r));
    if (errors.length) rec('E46', '移行テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #92 放置中に月をまたぐ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      // 帳簿を「先月」から始めたことにする
      const now = Date.now(); _acctClock = () => now - 20 * 864e5; G.acct = null; acctEnsure(); const m0 = G.acct.cur.m;
      for (let i = 0; i < 10; i++) tap(null);
      const cashBefore = G.cash;
      _acctClock = () => Date.now();
      G.ls = now - 6 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      const h = G.acct.hist[0]; const s = acctLive();
      const tol = Math.max(1, Math.abs(G.cash) * 1e-9);
      return { m0, hm: h && h.m, curm: G.acct.cur.m, closedCash: h && h.c.cash, cashBefore, offRev: s.R, okH: h && Math.abs(naOf(h.c) - naOf(h.o) - h.ni) < tol, okS: Math.abs(naOf(s.c) - naOf(s.o) - s.ni) < tol && Math.abs(s.unex) < tol };
    });
    const sameMonth = r.m0 === r.curm;
    rec(92, '放置中に月をまたいでも、前の月は放置前の状態で確定し、放置中の収益は戻った月に計上される', sameMonth || (r.hm === r.m0 && Math.abs(r.closedCash - r.cashBefore) < 1e-6 && r.offRev > 0 && r.okH && r.okS), JSON.stringify(r));
    if (errors.length) rec('E47', '放置の月またぎテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #93 再創業で事業を区切る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      acctEnsure(); for (let i = 0; i < 10; i++) tap(null);
      const per0 = G.acct.per; const R0 = acctLive().R;
      G.cash = Math.max(G.cash, PRESTIGE_COST + 1); G.dl = DL.length;
      try { execPrestige(null, 'speyside'); } catch (e) { return { err: String(e) }; }
      if (_offlineGate) closeOfflineModal(); closeM();
      for (let i = 0; i < 3; i++) tap(null);
      const a = G.acct;
      return { per0, per1: a.per, prev: a.prev.length, prevR: a.prev[0] && a.prev[0].R, R0, cap: a.cap, hist: a.hist.length };
    });
    rec(93, '再創業：決算書は新しい期として始まり、前の事業の合計が残る', !r.err && r.per1 === r.per0 + 1 && r.prev >= 1 && r.prevR >= r.R0 - 1e-6 && r.hist === 0 && r.cap > 0, JSON.stringify(r));
    if (errors.length) rec('E48', '再創業テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #94 v4.5.1 Tier4の評判条件・償却期間 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => ({ rep4: DL_REQ[3].rep, rep5: DL_REQ[4].rep, days: V45.FA_DAYS, lifeM: V45.FA_MONTHS, tier: (() => { G.dl = 3; return tierReqStatus(4).find(o => o.label === '評判').need; })() }));
    rec(94, 'v4.5.1：Tier4の評判条件は200（Tier5の240より小さい）・設備の耐用年数は実時間10日', r.rep4 === 200 && r.rep5 > r.rep4 && r.tier === 200 && r.days === 10 && Math.abs(r.lifeM - 10 / 30.4375) < 1e-12, JSON.stringify(r));
    if (errors.length) rec('E49', 'v4.5.1テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.6 追加テスト =================
  // ---------- #95-96 樽の大きさ・押せる範囲・タップの反応・見学ツアーの費用 ----------
  {
    const out = {};
    for (const [W, H] of [[393, 760], [390, 667]]) {
      const ctx = await browser.newContext({ viewport: { width: W, height: H } });
      const page = await ctx.newPage();
      await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
      await page.goto(FILE); await page.waitForTimeout(1000);
      await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(300);
      out[W + 'x' + H] = await page.evaluate(async () => {
        if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
        switchTab('td'); await new Promise(r => setTimeout(r, 200));
        const bb = document.getElementById('bb').getBoundingClientRect(); const st = document.getElementById('stage').getBoundingClientRect();
        const pad = getComputedStyle(document.getElementById('bb'), '::before'); const inset = pad.inset || pad.top;
        // 押せる範囲：絵の外側10pxも樽
        const hitOut = document.elementFromPoint(bb.left - 10, bb.top + bb.height / 2); const padHit = !!(hitOut && hitOut.closest && hitOut.closest('#bb'));
        const img = document.getElementById('bottleImg'); const ring = document.getElementById('tring');
        const res = []; for (let i = 0; i < 3; i++) { const h0 = Number(img.dataset.hit || 0), g0 = Number(ring.dataset.hit || 0); tap(null); const an = img.getAnimations ? img.getAnimations().length : 1; res.push(Number(img.dataset.hit) === h0 + 1 && Number(ring.dataset.hit) === g0 + 1 && an >= 1); await new Promise(r => setTimeout(r, 40)); }
        const over = document.getElementById('td').scrollHeight - document.getElementById('td').clientHeight;
        return { h: Math.round(bb.height), stageH: Math.round(st.height), padHit, fx: res.every(Boolean), over };
      });
      await ctx.close();
    }
    const a = out['393x760'], b = out['390x667'];
    rec(95, '樽：393×760で高さ300px・390×667で景色−70px・絵の外16pxまで押せる・押すたびに沈んで光る（連打でも毎回）・ホームは1画面', a.h === 300 && Math.abs(b.h - (b.stageH - 70)) <= 1 && a.padHit && b.padHit && a.fx && b.fx && a.over <= 0 && b.over <= 0, JSON.stringify(out));
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => { const o = []; for (const [dl, cl] of [[1, 0], [1, 3], [2, 4], [2, 7], [3, 8], [3, 9]]) { G.dl = dl; G.cl = cl; o.push(cuc()); } G.dl = 1; G.cl = 4; o.push(cuc()); return o; });
    const exp = [12000, 127776, 773302, 8229000, 39510000, 86920000];
    rec(96, '見学ツアーの費用＝$12,000×2.2^Lv×Tier倍率（上限Lvでは強化不可）', r.slice(0, 6).every((v, i) => Math.abs(v - exp[i]) / exp[i] < 0.002) && r[6] === Infinity, JSON.stringify(r));
    if (errors.length) rec('E50', '樽・ツアーのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #97 造る・寝かせる・売るに三角の矢印がない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      for (const t of ['tb', 'tcel', 'tsale']) { _ui.celOpen = true; switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); } await new Promise(r => setTimeout(r, 120));
        const fl = [...document.querySelectorAll('#' + t + ' .pflow')]; o[t] = { n: fl.length, tri: fl.filter(e => getComputedStyle(e, '::after').display !== 'none').length, band: fl.filter(e => e.querySelector('.pband')).length }; }
      return o;
    });
    rec(97, '造る・寝かせる・売る：工程の間は動く帯だけ（三角の矢印なし）', Object.values(r).every(x => x.n >= 2 && x.tri === 0 && x.band === x.n), JSON.stringify(r));
    if (errors.length) rec('E51', '矢印テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #98-99 売る：①→②→③・用意の状況・推奨 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = G.orders.find(x => x.kind === 'product' && ordUsable(x) && !ordMatch(x).ok && ordFulfillPlan(x).ok);
      if (o) ordFulfill(o.id);
      switchTab('tsale'); _ui.sellTab = 'ord'; rShip(); await new Promise(r => setTimeout(r, 120));
      const ids = [...document.getElementById('sp_ord').children].filter(e => e.getClientRects().length).map(e => e.id);
      const nos = ['bqBox', 'stockRow'].map(id => (document.querySelector('#' + id + ' .cno') || {}).textContent);
      const bq = G.bq[0]; const bqTxt = bq ? (document.querySelector(`[data-bqd="${bq.id}"]`) || {}).textContent : '';
      const bqExp = bq ? fmtN(Math.floor(bq.done)) + '/' + fmtN(bq.n) + '本' : '';
      const bad = [];
      G.orders.forEach(x => { const el = document.querySelector(`[data-ordq="${x.id}"]`); const rd = ordReady(x); if (!el || el.textContent !== rd.txt) bad.push(x.id);
        if (x.kind === 'product' || x.kind === 'type') { const m = ordMatch(x); const ip = G.bq.filter(q => q.oid === x.id).reduce((a, q) => a + q.n - (q.moved || 0), 0); if (rd.have !== Math.min(x.qty, m.have) || rd.ip !== Math.min(ip, x.qty - rd.have)) bad.push('v' + x.id); } });
      const stock = document.querySelector('#stockRow .vv').textContent; const stockExp = fmtN(G.bottles.reduce((a, b) => a + b.n, 0)) + '本';
      // 推奨：詰めて納品と同じ銘柄・足りない本数
      const recs = ordRecs(); const recOk = recs.every(x => { const pl = ordFulfillPlan(x.o); return pl.ok && pl.pid === x.pid && x.n === x.o.qty - ordMatch(x.o).have && pl.minAge === x.minAge; });
      openBottleModal(''); const mt = document.getElementById('mc2');
      const rec0 = recs[0]; const modalOk = !rec0 || (mt.querySelectorAll('.brr').length === recs.length && _ui.bot.pid === rec0.pid && _ui.bot.n === rec0.n && _ui.bot.minAge === rec0.minAge && mt.querySelector('select option').textContent.startsWith('★注文'));
      closeM();
      return { ids, nos, bqTxt, bqExp, bad, stock, stockExp, recN: recs.length, recOk, modalOk };
    });
    rec(98, '売る：上から「① 瓶詰め → ② 瓶の在庫 → ③ 注文」、瓶詰めは何本できたか、注文ごとに用意の本数（在庫・瓶詰め中）が内部の数と一致', r.ids.join() === 'bqBox,sellF1,stockRow,sellF2,orderBoard,orderNext' && r.nos.join() === '①,②' && r.bqTxt === r.bqExp && r.bad.length === 0 && r.stock === r.stockExp, JSON.stringify(r));
    rec(99, '在庫に詰める：注文に足りない銘柄を「詰めて納品」と同じ選び方で推奨し、本数と年数条件を入れて開く', r.recOk && r.modalOk, JSON.stringify({ recN: r.recN, recOk: r.recOk, modalOk: r.modalOk }));
    if (errors.length) rec('E52', '売るテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #100 読み物は中央・決算書は図鑑の記録 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('te'); const s = STORY_EPISODES[0].id; if (!G.story.unlocked.includes(s)) G.story.unlocked.push(s); openStoryModal(s); await new Promise(r => setTimeout(r, 80));
      const mb = document.querySelector('#mo .mb').getBoundingClientRect(); const cy = mb.top + mb.height / 2; const story = { cy: Math.round(cy), vh: innerHeight, close: !!document.querySelector('#mc2 [data-act="closeM"]') };
      closeM(); const after = document.getElementById('mo').classList.contains('ctr');
      openOrderInfoModal(G.orders[0].id); const mb2 = document.querySelector('#mo .mb').getBoundingClientRect(); const sheet = Math.round(innerHeight - mb2.bottom); closeM();
      openTip('order'); const tip = document.getElementById('mo').classList.contains('ctr'); closeM();
      _ui.encTab = 'r'; renc(); const card = document.querySelector('#recList .frec'); const first = document.getElementById('recList').firstElementChild === card;
      card.click(); await new Promise(r => setTimeout(r, 60)); const fin = document.getElementById('mc2').textContent.includes('決算書') && !!document.getElementById('finBox'); closeM();
      switchTab('td'); rdistLight(); const icons = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id).join();
      return { story, after, sheet, tip, first, fin, icons };
    });
    rec(100, '物語・ヒント・会話の小窓は画面中央（閉じるボタン付き）、操作の小窓は下から・決算書は図鑑の記録の先頭から開き、ホームのアイコンは章・デイリー・市場・Tier・砂時計', Math.abs(r.story.cy - r.story.vh / 2) <= 24 && r.story.close && !r.after && r.sheet <= 1 && r.tip && r.first && r.fin && r.icons.replace(',hi_staff', '') === 'hi_chap,hi_daily,hi_mkt,hi_tier,hi_hg', JSON.stringify(r));
    if (errors.length) rec('E53', '小窓テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #101-102 放置24時間・報告の出し直し・タイトル省略・記録 ----------
  {
    const p0 = await page43(667, null, 'mid');
    const r0 = await p0.page.evaluate(() => {
      if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = [];
      const f = prodFlows(); barleyState().auto = true; G.cash = 1e9; const te0 = G.te; G.ls = Date.now() - 30 * 3600000; offline();
      const shown = _offlineGate; const txt = document.getElementById('mc2').textContent; const pend = offRepGet();
      return { cap: BALANCE.OFFLINE_CAP_H, shown, cap24: txt.includes('24時間分'), pend: !!pend && pend.elapsedMs > 29 * 3600000, notice: txt.includes('20歳未満') };
    });
    // 報告を閉じずに再読込 → 起動時に出し直す・タイトルは出さない
    await p0.page.evaluate(() => { save(); });
    await p0.page.reload(); await p0.page.waitForTimeout(1600);
    const r1 = await p0.page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), titleDone: _titleDone, gate: _offlineGate, txt: document.getElementById('mc2').textContent.includes('おかえり'), diag: diagText() }));
    await p0.page.evaluate(() => { closeOfflineModal(); save(); });
    const r2 = await p0.page.evaluate(() => ({ pend: offRepGet(), bug: bugReportText().includes('起動と保存の記録') }));
    await p0.page.reload(); await p0.page.waitForTimeout(1600);
    const r3 = await p0.page.evaluate(() => ({ gate: _offlineGate }));
    await p0.ctx.close();
    rec(101, '放置：生産は24時間分まで・報告は閉じるまで保存し、再読込でも出し直す（閉じたら出ない）・注意書き付き', r0.cap === 24 && r0.shown && r0.cap24 && r0.pend && r0.notice && r1.gate && r1.txt && r2.pend === null && !r3.gate, JSON.stringify({ r0, r1: { gate: r1.gate, txt: r1.txt }, r3 }));
    rec(102, '2回目以降の起動はタイトル画面を出さずホームから・起動と保存の記録を「不具合を報告」に表示', !r1.title && r1.titleDone && /load/.test(r1.diag) && /offline/.test(r1.diag) && r2.bug, JSON.stringify({ title: r1.title, diag: r1.diag }));
    const ctx4 = await browser.newContext({ viewport: { width: 390, height: 667 } }); const pg4 = await ctx4.newPage();
    await pg4.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort()); await pg4.goto(FILE); await pg4.waitForTimeout(1500);
    const r4 = await pg4.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), done: _titleDone }));
    rec('102b', '新しく始める人にはタイトル画面を出す', r4.title && !r4.done, JSON.stringify(r4));
    await ctx4.close();
  }
  // ---------- #103 熟成の砂時計：99個まで（あふれる分は受け取らず知らせる）・デイリー全達成2個・章の目標1個・まとめて使う（n時間を1回で進め、報告は1回） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.hg = { n: 97, got: 0, used: 0 }; hgDay();
      const a = [hgAdd(1, 't'), hgAdd(5, 't'), hgAdd(1, 't')]; const n99 = G.hg.n;
      G.hg.n = 0; G.hg.src.daily = 0; G.daily.allCleared = false; G.daily.missions.forEach(m => { m.done = false; G._dmProgress[m.id] = m.target; }); tickDailyMissions(); const daily = G.hg.n;
      G.hg.n = 0; const c = chapCur(), st = chapState(); c.goals.forEach(g => { delete st.done[g.id]; }); G.stats.shipped = 1e9; G.stats.orders = 1e6; G.stats.filled = 1e6; checkChapters(); const chap = G.hg.n;
      // まとめて使う：6個 → 6時間分（熟成・注文の期限）を1回で
      G.hg.n = 10; G.hg.useDay = 0; const l = G.lots[0]; const age0 = l.age; const o0 = G.orders.find(x => !x.reserve || x.accepted); const due0 = o0 ? o0.dueAt : 0; const now = Date.now();
      if (o0) o0.dueAt = now + 3 * 3600000;
      openHgModal(); const chips = [...document.querySelectorAll('#mc2 [data-act="hgN"]')].map(b => b.dataset.v).join();
      document.querySelector('#mc2 [data-act="hgN"][data-v="6"]').click(); await new Promise(r => setTimeout(r, 30));
      const pv = document.getElementById('mc2').textContent; const warn = pv.includes('期限が切れる注文') && pv.includes('+6時間');
      const dueB = o0 ? o0.dueAt : 0; let reports = 0; const so = showOfflineSummaryModal; showOfflineSummaryModal = i => { reports++; so(i); };
      document.querySelector('#mc2 [data-act="hgUse"]').click(); await new Promise(r => setTimeout(r, 30)); showOfflineSummaryModal = so;
      const title = document.getElementById('mc2').textContent; const dAge = l.age - age0;
      const o1 = o0 && G.orders.find(x => x.id === o0.id); const dDue = o1 ? dueB - o1.dueAt : 6 * 3600000;
      const pend = offRepGet(); if (_offlineGate) closeOfflineModal();
      const after = { n: G.hg.n, used: G.hg.useDay };
      G.hg.n = 0; const none = hgUse(1);
      return { a, n99, daily, chap, chips, warn, title: title.includes('6時間進めました'), reports, dAge, rate: agingRate(l) / 24 * 6, dDue, pend, none, after, icon: document.querySelector('#hi_hg .hib') ? document.querySelector('#hi_hg .hib').textContent : '' };
    });
    const ok = r.a.join() === 'true,true,false' && r.n99 === 99 && r.daily === 3 && r.chap === 0 && r.chips === '1,3,6,12,all' && r.warn && r.title && r.reports === 1 && Math.abs(r.dAge - r.rate) / r.rate < 0.02 && Math.abs(r.dDue - 6 * 3600000) < 5000 && r.pend === null && r.none === false && r.after.n === 4 && r.after.used === 6 && /\/99$/.test(r.icon);
    rec(103, '砂時計：99個まで（あふれる分は受け取らない）・デイリー全達成で3個・章の目標の分は v5.4 で廃止・「まとめて使う」1/3/6/12/残り全部・6個で6時間分を1回で進め報告も1回・期限が切れる注文を警告・報告は保存しない', ok, JSON.stringify(r));
    if (errors.length) rec('E54', '砂時計テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #104 v4.6.1 造る・寝かせる・売るの背景の絵 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te']) { switchTab(t); await new Promise(r => setTimeout(r, 60)); const el = document.getElementById('tabBg'); const cs = getComputedStyle(el); o[t] = { on: el.classList.contains('on'), time: el.classList.contains('t-' + sceneTime()), img: /data:image\/webp/.test(cs.backgroundImage), disp: cs.display }; }
      return o;
    });
    const ok = ['tb', 'tcel', 'tsale'].every(t => r[t].on && r[t].time && r[t].img && r[t].disp === 'block') && ['td', 'te'].every(t => !r[t].on && r[t].disp === 'none');
    rec(104, '造る・寝かせる・売るの背景にそれぞれの絵を表示し、時間帯の段階をホームと同じにする（ホーム・図鑑には出さない）', ok, JSON.stringify(r));
    if (errors.length) rec('E55', '背景テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #105 v4.6.3 ファイルサイズの削減（画像の再圧縮・最小化・未使用関数の削除） ----------
  {
    const fs = require('fs');
    const dist = fs.readFileSync('whisky_empire.html', 'utf8');
    const dev = fs.existsSync('whisky_empire.dev.html') ? fs.readFileSync('whisky_empire.dev.html', 'utf8') : '';
    const main = h => [...h.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]).reduce((a, b) => (b.length > a.length ? b : a), '');
    const liff = h => (h.match(/<script id="liff-config">[\s\S]*?<\/script>/) || [''])[0];
    const DEAD = ['sceneSvg', 'sndKnock', 'chapCardHtml', 'finNew', 'modalCenter', 'upgDist', 'actAttrs', 'rTank', 'openHistModal', 'nextTicker_old', 'initTicker_old', 'sndAuction', 'toggleSound', 'getPrestigeSkillEffect', 'applyPrestigeSkills', 'currentRegion', 'exRegionMult'];
    const left = DEAD.filter(n => new RegExp('function ' + n + '\\(').test(dist) || new RegExp('function ' + n + '\\(').test(dev));
    const md = main(dist), mv = main(dev);
    const s = { bytes: Buffer.byteLength(dist), left, ratio: +(md.length / Math.max(1, mv.length)).toFixed(3), strict: /^\s*['"]use strict['"]/.test(md), liffSame: !!dev && liff(dist) === liff(dev) && liff(dist).includes('LIFF_ID') };
    const { page, errors, ctx } = await page43(667, null, 'mid');
    s.img = await page.evaluate(async () => {
      const o = {};
      for (const k of ['tb', 'tcel', 'tsale']) {
        const d = document.createElement('div'); d.className = 'tabbg bg-' + k; document.body.appendChild(d);
        const u = getComputedStyle(d).backgroundImage.match(/url\("?(data:[^")]+)"?\)/); d.remove();
        const im = new Image(); im.src = u ? u[1] : ''; try { await im.decode(); } catch (_) {}
        o[k] = im.naturalWidth;
      }
      return o;
    });
    const ok = s.bytes <= 900000 && left.length === 0 && s.ratio < 0.92 && s.strict && s.liffSame && ['tb', 'tcel', 'tsale'].every(k => s.img[k] === 800);
    rec(105, '配布版は900KB以下（v5.2 で上限を860KBから引き上げ）：タブの背景は幅800px・JSとCSSは最小化（use strict と LIFF 設定はそのまま）・未使用の関数17個は開発版にも残っていない', ok, JSON.stringify(s));
    if (errors.length) rec('E56', 'サイズ削減テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.7 追加テスト =================
  // ---------- #106 砂時計：1日24個まで・入手の機会ごとの回数の上限（ログイン1・デイリー1・節目3・納品3件ごとに1で3回）・連続ログイン7日で3個・月の決算3個・昇格5・関係2・日付で戻る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.hg = { n: 0, got: 0, used: 0 }; hgDay();
      const src = [hgAdd(1, 'l', 'login'), hgAdd(1, 'l', 'login'), hgAdd(2, 'd', 'daily'), hgAdd(2, 'd', 'daily'), hgAdd(1, 'm', 'ms'), hgAdd(1, 'm', 'ms'), hgAdd(1, 'm', 'ms'), hgAdd(1, 'm', 'ms')];
      const n0 = G.hg.n; for (let i = 0; i < 12; i++) hgOrdDone(); const ord = G.hg.n - n0;
      G.hg.n = 30; const u1 = hgUse(24); if (_offlineGate) closeOfflineModal(); const u2 = hgUse(1); if (_offlineGate) closeOfflineModal();
      const afterUse = { n: G.hg.n, useDay: G.hg.useDay, left: hgLeftToday() };
      openHgModal(); const btn = document.querySelector('#mc2 [data-act="hgUse"]').disabled; const t = document.getElementById('mc2').textContent; closeM();
      // 連続ログイン：7日続けると7日目に+3
      G.hg.n = 0; G.hg.streak = { d: '', n: 0 }; const got = []; for (let d = 1; d <= 7; d++) { off = d * 24 * 3600000; G.ls = Date.now(); closeM(); const n1 = G.hg.n; loginBonus(); got.push(G.hg.n - n1); }
      const streak = G.hg.streak.n; const d2 = { left: hgLeftToday(), src: JSON.stringify(G.hg.src) };
      G.hg.month = '2000-1'; const m1 = G.hg.n; const mon = [typeof hgMonth === 'undefined', V51.HG.month === undefined]; const month = G.hg.n - m1;
      const t0 = G.hg.n; G.cash = 1e18; hgAdd(V51.HG.tier.k, 'Tier', 'tier', true); const tier = G.hg.n - t0;
      const cid = CUSTOMERS[0].id; G.rel[cid] = { lv: 0, done: 0 }; const r0 = G.hg.n; relAdd(cid, BALANCE.REL_THRESH[0]); const rel = G.hg.n - r0;
      Date.now = rn;
      return { src, ord, u1, u2, afterUse, btn, t: t.includes('今日使える数') && t.includes('手に入れ方'), got, streak, d2, mon, month, tier, rel, max: V47.HG_MAX, day: V47.HG_DAY_USE, hgMs: V46.HG_MS };
    });
    const ok = r.src.join() === 'true,false,true,false,true,true,true,true' && r.ord === 4 && r.u1 && !r.u2 && r.afterUse.n === 7 && r.afterUse.useDay === 24 && r.afterUse.left === 0 && r.btn && r.t && r.got.join() === '1,1,1,1,1,1,4' && r.streak === 7 && r.d2.left === 24 && r.mon.join() === 'true,true' && r.month === 0 && r.tier === 5 && r.rel === 0 && r.max === 99 && r.day === 24 && r.hgMs === 3600000;
    rec(106, '砂時計：1個1時間のまま・99個まで・1日24個まで・ログイン/デイリーは1日1回・節目の樽は1日5樽・納品3件ごとに1個（1日4個）・連続ログイン7日目に+3・昇格+5・月の決算と取引先の★は v5.4 で廃止・日付が替わると戻る', ok, JSON.stringify(r));
    if (errors.length) rec('E57', '砂時計（v5.1）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #107 熟成の目標：25/50/75/100%・完成で次の節目へ・進み方によらず同じ・熟成の速さは不変 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const ct = caskType('bourbon'), sz = caskSize('hogshead');
      const mk = () => makeLot(ct, sz, { c: 0 });
      const a = mk(), b = mk(); lotGoalInit(a); lotGoalInit(b);
      const g0 = [a.goal, a.gs, Math.round((a.age - a.gs) / Math.max(1e-9, a.goal - a.gs) * 100)];
      const rate = agingRate(a); const Y = BALANCE.GAME_YEAR_MS / rate; // 1年ぶんの時間
      const goals0 = G.stats.goals || 0; G.hg.src.ms = 0; const hg0 = G.hg.n;
      _goalUI = [];
      // a：1時間刻みで3.2年ぶん / b：一度に3.2年ぶん
      const steps = Math.ceil(3.2 * Y / 3600000); for (let i = 0; i < steps; i++) lotAdvance(a, 3200 * Y / steps / 1000 * 1000 / 3200 * 3.2 > 0 ? 3.2 * Y / steps : 0);
      const qs = _goalUI.filter(x => x.id === a.id).map(x => x.q); _goalUI = [];
      lotAdvance(b, 3.2 * Y); const qb = _goalUI.filter(x => x.id === b.id).map(x => x.q);
      const res = { g0, qs, qb, a: [a.goal, a.gd, +a.gs.toFixed(3), !!a.gt, +a.age.toFixed(4)], b: [b.goal, b.gd, +b.gs.toFixed(3), +b.age.toFixed(4)], goals: (G.stats.goals || 0) - goals0, hg: G.hg.n - hg0, jnl: jnlCur().done.slice(-2).map(d => d.g) };
      // 熟成の速さは目標の有無で変わらない
      const c = mk(), d = mk(); delete d.goal; c.goal = 0; lotAdvance(c, 5 * Y); lotAdvance(d, 5 * Y);
      res.same = Math.abs(c.age - d.age) < 1e-9 && Math.abs(c.age - 5) < 1e-6;
      res.eta = Math.round(lotGoalEta(a) / 3600000); res.etaExp = Math.round((8 - a.age) / rate * 24);
      return res;
    });
    const ok = r.g0.join() === '3,0,0' && r.qs.join() === '0.25,0.5,0.75,1' && r.qb.join() === '1' && r.a[0] === 8 && r.a[1] === 3 && r.a[2] === 3 && r.a[3] && r.b[0] === 8 && r.b[1] === 3 && Math.abs(r.a[4] - r.b[3]) < 1e-3 && r.goals === 2 && r.hg === 2 && r.jnl.join() === '3,3' && r.same && Math.abs(r.eta - r.etaExp) <= 1;
    rec(107, '熟成の目標：新しい樽は3年が目標・25/50/75/100%で演出・届くと次の節目（8年）へ・毎秒でも一度でも同じ結果・日誌に記録・熟成の速さは変わらない', ok, JSON.stringify(r));
    if (errors.length) rec('E58', '熟成の目標テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #108 棚の樽：色つや10段階・札は経過年数（3年未満は薄く、節目に届くと金で「8年」）・小窓の次の節目・見出しの次に節目になる樽 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('tcel');
      const l0 = G.lots[0], l1 = G.lots[1], l2 = G.lots[2]; l0.age = 0.5; l0.goal = 3; l0.gs = 0; delete l0.gd; delete l0.gt; l1.age = 10.2; l1.goal = 12; l1.gs = 8; l1.gd = 8; l1.gt = Date.now(); l2.age = 5.37; delete l2.gt; l2.at = Date.now() - 9 * 86400000 - 3600000; l2.src = 'prod';
      rCellar(); await new Promise(r => setTimeout(r, 50));
      const c0 = document.querySelector(`#wScene .wcask[data-id="${l0.id}"]`), c1 = document.querySelector(`#wScene .wcask[data-id="${l1.id}"]`);
      const f = c => [...c.querySelectorAll('path')].map(p => p.getAttribute('fill'));
      const lbl = id => document.querySelector(`[data-wse="${id}"]`);
      const o = { w0: f(c0).includes(WOOD[0]), w1: f(c1).includes(WOOD[4]), done: c1.classList.contains('wdone'), lb1: lbl(l1.id).textContent, lb1c: lbl(l1.id).parentNode.className, lb0: lbl(l0.id).textContent, lb0c: lbl(l0.id).parentNode.className, lb2: lbl(l2.id).textContent, lb2c: lbl(l2.id).parentNode.className, next: (document.querySelector('[data-lnext]') || {}).textContent };
      o.gold = getComputedStyle(lbl(l1.id)).color === 'rgb(255, 214, 107)';
      const c2 = document.querySelector(`#wScene .wcask[data-id="${l2.id}"]`); caskKnock(l2.id, c2); o.bub = document.getElementById('wBub').textContent; bubClose();
      openLotModal(l1.id); const mt = document.getElementById('mc2').textContent; o.modal = mt.includes('次の節目') && mt.includes('担当') && mt.includes('8年になった日：') && !mt.includes('目標'); closeM();
      openLotModal(l0.id);
      const chip = [...document.querySelectorAll('#mc2 [data-act="lotGoal"]')].find(b => b.dataset.v === '8'); chip.click(); await new Promise(r => setTimeout(r, 50));
      o.setGoal = [l0.goal, +l0.gs.toFixed(2)]; closeM();
      o.noKansei = !document.getElementById('tcel').textContent.includes('完成');
      return o;
    });
    const ok = r.w0 && r.w1 && r.done && r.lb1 === '8年' && /\bdn\b/.test(r.lb1c) && r.gold && r.lb0 === '0.5年' && /\byg\b/.test(r.lb0c) && r.lb2 === '5.3年' && !/\b(yg|dn)\b/.test(r.lb2c) && /^次に\d+年になる樽まで あと/.test(r.next) && /5\.3年（詰めてから9日）/.test(r.bub) && r.modal && r.setGoal[0] === 8 && r.setGoal[1] === 0.5 && r.noKansei;
    rec(108, '棚の樽：年数で木の色が10段階・札は経過年数（3年未満は薄く、節目に届いた樽は金の札で「8年」）・吹き出しに詰めてからの日数・小窓に「次の節目」と「8年になった日」・見出しに次に節目になる樽までの時間・「完成」「目標」の言葉はない', ok, JSON.stringify(r));
    if (errors.length) rec('E59', '棚の樽テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #109 倉庫日誌：日付が替わると前の日を1件記録・14日分・寝かせるの先頭に「新」・開くと既読・保存しても同じ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.jnl = { cur: null, list: [] }; jnlRoll(); const f0 = G.stats.filled;
      G.stats.filled += 3; G.stats.bottled += 120; G.stats.orders += 2; G.te += 5000; jnlAdd('angel', 1.5);
      const rolledSame = jnlRoll();
      off = 24 * 3600000; const rolled = jnlRoll(); const e = G.jnl.list[0];
      for (let i = 2; i <= 20; i++) { off = i * 24 * 3600000; jnlRoll(); }
      const len = G.jnl.list.length; Date.now = rn; G.ls = rn(); if (_offlineGate) closeOfflineModal();
      switchTab('tcel'); rCellar(); const card = document.getElementById('celJnl'); const newMark = card.textContent.includes('新');
      card.querySelector('.jnl').click(); await new Promise(r => setTimeout(r, 60)); const modal = document.getElementById('mc2').textContent; closeM(); rCellar();
      const newAfter = document.getElementById('celJnl').textContent.includes('新');
      const s2 = sanitize(JSON.parse(JSON.stringify(G))); const same = JSON.stringify(s2.jnl.list) === JSON.stringify(G.jnl.list);
      return { rolledSame, rolled, e: { fill: e.fill, btl: e.btl, ord: e.ord, earn: e.earn, angel: e.angel }, len, newMark, modal: modal.includes('倉庫日誌') && modal.includes('今日のここまで'), newAfter, same };
    });
    const ok = !r.rolledSame && r.rolled && r.e.fill === 3 && r.e.btl === 120 && r.e.ord === 2 && r.e.earn === 5000 && Math.abs(r.e.angel - 1.5) < 1e-9 && r.len === 14 && r.newMark && r.modal && !r.newAfter && r.same;
    rec(109, '倉庫日誌：日付が替わると前の日の出来事（詰めた樽・瓶・納品・売上・天使の分け前）を1件記録・14日分・寝かせるの先頭に「新」・開くと既読・保存しても同じ', ok, JSON.stringify(r));
    if (errors.length) rec('E60', '倉庫日誌テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #110 v4.6（schema11）からの移行・ログインボーナス・放置の報告・変更点の案内 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const old = JSON.parse(JSON.stringify(G)); old.ver = 11; old.lots.forEach(l => { delete l.goal; delete l.gs; delete l.gd; delete l.gt; }); old.hg = { n: 2, got: 4, used: 2 }; delete old.jnl; old.hs.new47 = undefined; delete old.tut.done.u47;
      const m = parseSave(old);
      const o = { ver: m.ver, goals: m.lots.every(l => typeof l.goal === 'number' && l.gs === l.age), g1: m.lots.map(l => [l.age, l.goal]).slice(0, 2), hg: m.hg.n === 2 && m.hg.day === '' && m.hg.src.login === 0, jnl: Array.isArray(m.jnl.list), new47: m.hs.new47 };
      G = m; o.tut = !TUTS.u47;
      G.tut.done.u47 = true; G.hs.new47 = 1;
      // ログインボーナス（案内が済んでいてタイトルの後・小窓なし）
      closeM(); G.hg.src.login = 0; G.hg.day = dayKey(); const n0 = G.hg.n; const lb = loginBonus(); const lb2 = loginBonus(); o.login = [lb, lb2, G.hg.n - n0];
      // 放置の報告に「熟成の目標に届いた樽」
      const l = G.lots[0]; l.goal = l.age + 0.2; l.gs = l.age - 0.1; G.ls = Date.now() - 10 * 3600000; offline();
      o.rep = document.getElementById('mc2').textContent.includes('節目の年数になった樽'); if (_offlineGate) closeOfflineModal();
      return o;
    });
    const ok = r.ver === SCHEMA && r.goals && r.hg && r.jnl && r.new47 === 0 && r.tut && r.login.join() === 'true,false,1' && r.rep;
    rec(110, 'v4.6（schema11）からの移行：樽に目標・砂時計の日ごとの記録・日誌を用意（版の案内なし）／ログインボーナスは1日1回／放置の報告に節目の年数になった樽', ok, JSON.stringify(r));
    if (errors.length) rec('E61', '移行テスト（v4.7）中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.8 追加テスト =================
  // 職人を用意する（Tier と所持金を整え、候補から雇う）
  const STAFF_PREP = `(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose(); G.cash = 1e15; G.staff = []; G.staffCand = null; G.staffOff = false; prodInvalidate(); })()`;
  // ---------- #111 解放・候補者の能力の分布・求人の出し直し ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      const dl0 = G.dl; G.dl = 1; const off1 = staffOn(); v48Tick(); const btn1 = getComputedStyle(document.getElementById('btnStaff')).display;
      G.dl = 2; const on2 = staffOn(); v48Tick(); const btn2 = getComputedStyle(document.getElementById('btnStaff')).display; G.dl = dl0;
      const bad = []; const cnt = { 1: 0, 2: 0, 3: 0 }; const rg = { 1: [9, 14], 2: [13, 19], 3: [18, 24] };
      for (let i = 0; i < 600; i++) { const c = staffRoll(); cnt[c.r]++; const s = stSum(c.st); if (s < rg[c.r][0] || s > rg[c.r][1] || ST_KEYS.some(k => c.st[k] < 1 || c.st[k] > 10)) bad.push(JSON.stringify(c)); }
      const c = staffCandState(); const n = c.list.length; const h0 = G.acct.cur.sga.hire;
      const r1 = staffRefresh(); const h1 = G.acct.cur.sga.hire; const r2 = staffRefresh(); const h2 = G.acct.cur.sga.hire;
      return { off1, btn1, on2, btn2, bad: bad.slice(0, 3), cnt, n, free: [r1, h1 - h0], paid: [r2, Math.round(h2 - h1), staffRefreshCost()] };
    });
    const ok = !r.off1 && r.btn1 === 'none' && r.on2 && r.btn2 !== 'none' && r.bad.length === 0 && r.cnt[1] > r.cnt[2] && r.cnt[2] > r.cnt[3] && r.cnt[3] > 0 && r.n === 3 && r.free[0] && r.free[1] === 0 && r.paid[0] && r.paid[1] === r.paid[2];
    rec(111, '職人：Tier2で解放・候補は3人で★1〜3の能力の合計が決めた範囲（★1 9〜14・★2 13〜19・★3 18〜24、各1〜10）・求人の出し直しは1日1回無料で以降は採用費', ok, JSON.stringify(r));
    if (errors.length) rec('E62', '職人の候補テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #112 採用・在籍の上限・自動で空いている配置先へ・採用費の計上・画面 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; G.bq = []; const o = { cap: staffCap() };
      const c = staffCandState(); const fee = staffHireFee(c.list[0]); const h0 = G.acct.cur.sga.hire; const cash0 = G.cash;
      prodInvalidate(); const bn = STAGES[prodFlows().bottleneck].fac;
      o.hire = staffHire(0); o.fee = [Math.round(G.acct.cur.sga.hire - h0), fee, Math.round(cash0 - G.cash)];
      o.first = placeKey(G.staff[0].at) === 'fac:' + bn;
      let g = 0; while (G.staff.length < staffCap() && g++ < 40) { const cc = staffCandState(); if (!cc.list.length) { cc.free = 1; staffRefresh(); } staffHire(0); }
      o.n = G.staff.length; o.over = staffHire(0);
      const keys = G.staff.filter(s => s.at).map(s => placeKey(s.at)); o.uniq = new Set(keys).size === keys.length; o.lots = keys.filter(k => k.startsWith('lot:')).length;
      openStaffModal('post'); o.ui = document.querySelectorAll('#mc2 .plc').length >= 5 && !!document.querySelector('#mc2 [data-act="placeAuto"]'); openStaffModal('list'); o.ui2 = document.querySelectorAll('#mc2 .sfc').length; openStaffModal('hire'); const t = document.getElementById('mc2').textContent; o.ui3 = t.includes('求人を出し直す') || t.includes('今日の候補者はいません'); closeM();
      return o;
    });
    const ok = r.cap === 17 && r.hire && r.fee[0] === r.fee[1] && r.fee[2] === r.fee[1] && r.first && r.n === 17 && r.over === false && r.uniq && r.lots > 0 && r.ui && r.ui2 === 17 && r.ui3;
    rec(112, '採用：採用費（時給24時間分）を払い、空いている配置先（いちばん遅い工程→瓶詰めの予約があればボトリング→目標が近い樽）に入る・在籍は17人まで・1か所1人・配置/在籍/採用の画面', ok, JSON.stringify(r));
    if (errors.length) rec('E63', '採用テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #113 配置の倍率：1.10〜1.50（能力とLv）・設備は工程の能力と瓶詰め・樽は熟成・研修中と休業中は1.00・宙に浮く効果はない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (at, st, lv) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st, tr: 'calm', lv: lv || 1, xp: 0, at, hired: 0, train: 0, care: '' });
      const S = (w, t, m) => ({ waza: w, tegiwa: t, mekiki: m });
      prodInvalidate(); const base = { cap0: stageCap(0), cap3: stageCap(3), slots: whSlots(), board: boardSize(), bph: botRate(), nm: prodFlows().newmake };
      const l = G.lots[0]; const ar0 = agingRate(l);
      const set = L => { G.staff = L; G.ownerAt = null; placeInvalidate(); prodInvalidate(); };
      set([mk({ k: 'fac', id: 'malting' }, S(1, 10, 5))]); const m1 = stageCap(0) / base.cap0;           // 目利き5・Lv1
      set([mk({ k: 'fac', id: 'distillation' }, S(1, 8, 1), 5)]); const m2 = stageCap(3) / base.cap3;    // 手際8・Lv5
      set([mk({ k: 'fac', id: 'bottling' }, S(1, 10, 1), 10)]); const m3 = botRate() / base.bph;         // 手際10・Lv10
      set([mk({ k: 'lot', id: l.id }, S(10, 1, 1), 10)]); const m4 = agingRate(l) / ar0;                // 技10・Lv10
      const tr = mk({ k: 'lot', id: l.id }, S(10, 1, 1), 10); tr.train = Date.now() + 3600000; set([tr]); const mTr = agingRate(l) / ar0;
      set([mk({ k: 'lot', id: l.id }, S(10, 1, 1), 10)]); G.staffOff = true; const mOff = agingRate(l) / ar0; G.staffOff = false;
      // 17人を置いても、樽の枠・注文枠・歩留まり・品質は変わらない
      const L = []; for (let i = 0; i < 17; i++) L.push(mk(null, S(10, 10, 10), 10)); set(L); placeAuto(true);
      const pv = botPreview(G.uw[0], 1, 'old', [], 0); const pv0q = pv.ok ? pv.q : null;
      const none = { slots: whSlots() - base.slots, board: boardSize() - base.board };
      set([]); const pv2 = botPreview(G.uw[0], 1, 'old', [], 0);
      return { m1, m2, m3, m4, mTr, mOff, none, q: [pv0q, pv2.ok ? pv2.q : null], fn: typeof staffFx === 'undefined' && typeof POSTS === 'undefined' };
    });
    const e = (st, lv) => 1.1 + 0.4 * (0.5 * (st - 1) / 9 + 0.5 * (lv - 1) / 9);
    const ok = Math.abs(r.m1 - e(5, 1)) < 1e-9 && Math.abs(r.m2 - e(8, 5)) < 1e-9 && Math.abs(r.m3 - 1.5) < 1e-9 && Math.abs(r.m4 - 1.5) < 1e-9 && r.mTr === 1 && r.mOff === 1 && r.none.slots === 0 && r.none.board === 0 && r.q[0] === r.q[1] && r.fn;
    rec(113, '配置の倍率：m＝1.10＋0.40×(0.5×(能力−1)/9＋0.5×(Lv−1)/9)（製麦室は目利き・ほかの設備は手際・樽は技）・設備は工程の能力と瓶詰めの速さ・樽は熟成の速さ・研修中と休業中は1.00・17人置いても樽の枠・注文枠・品質は変わらない', ok, JSON.stringify(r));
    if (errors.length) rec('E64', '配置の倍率テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #114 給与：毎時計上・払えないと休業（効果なし・所持金は負にならない）・払えれば戻る・放置は24時間分・砂時計は1時間分 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (at) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv: 1, xp: 0, at, hired: 0, train: 0, care: '' });
      G.staff = [mk({ k: 'fac', id: 'distillation' }), mk({ k: 'fac', id: 'malting' })]; placeInvalidate(); prodInvalidate();
      const wph = staffWagesPh(); const o = { wph };
      const w0 = G.acct.cur.sga.wage; staffTick(3600000); o.hour = [G.acct.cur.sga.wage - w0, wph];
      // 払えない
      const capOn = stageCap(0); G.cash = wph * 0.25; const sw = staffTick(3600000); o.off = { flag: G.staffOff, cash: G.cash, paidH: sw.paid / wph, offH: sw.offH, cap: stageCap(0) / capOn };
      staffTick(3600000); o.stay = G.staffOff && G.cash >= 0;
      G.cash = 1e12; staffTick(1000); o.back = !G.staffOff && Math.abs(stageCap(0) - capOn) < 1e-6;
      // 放置30時間 → 24時間分、砂時計 → 1時間分
      if (_offlineGate) closeOfflineModal(); const w1 = G.acct.cur.sga.wage; G.ls = Date.now() - 30 * 3600000; offline(); o.off30 = (G.acct.cur.sga.wage - w1) / wph; o.rep = document.getElementById('mc2').textContent.includes('職人の給与'); if (_offlineGate) closeOfflineModal();
      const w2 = G.acct.cur.sga.wage; const wph2 = staffWagesPh(); G.hg.n = 1; G.hg.useDay = 0; G.ls = Date.now(); hgUse(); o.hg = (G.acct.cur.sga.wage - w2) / wph2; if (_offlineGate) closeOfflineModal();
      return o;
    });
    const ok = r.wph > 0 && Math.abs(r.hour[0] - r.hour[1]) < 1e-6 * r.wph && r.off.flag && r.off.cash >= 0 && r.off.cash < r.wph * 0.001 && Math.abs(r.off.paidH - 0.25) < 0.001 && Math.abs(r.off.offH - 0.75) < 0.001 && Math.abs(r.off.cap - 1 / (1.1 + 0.4 * 0.5 * 4 / 9)) < 0.001 && r.stay && r.back && Math.abs(r.off30 - 24) < 0.01 && r.rep && Math.abs(r.hg - 1) < 0.01;
    rec(114, '給与：毎時計上・払えない分は休業（効果が止まり所持金は負にならない）・1時間分払えるようになると戻る・放置は生産と同じ24時間分・砂時計は1時間分・放置の報告に給与', ok, JSON.stringify(r));
    if (errors.length) rec('E65', '給与テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #115 熟練度・研修・解雇・再創業で1人だけ残る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (at, lv) => ({ id: uid('s'), nm: 'T' + lv, seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv, xp: 0, at, hired: 0, train: 0, care: '' });
      G.staff = [mk({ k: 'fac', id: 'malting' }, 1), mk(null, 1), mk({ k: 'lot', id: G.lots[0].id }, 4)]; placeInvalidate(); prodInvalidate();
      const a = G.staff[0], b = G.staff[1];
      staffTick(24 * 3600000); const o = { lvA: a.lv, lvB: b.lv, xpA: Math.round(a.xp) };
      // 研修：費用・効果なし・6時間後に経験+24
      const t0 = G.acct.cur.sga.train; const cap0 = stageCap(0); o.tr = staffTrain(a.id); o.fee = [Math.round(G.acct.cur.sga.train - t0), staffTrainFee(a)]; prodInvalidate(); o.capOff = stageCap(0) < cap0;
      const lv0 = a.lv, xp0 = a.xp; a.train = Date.now() - 1; staffTick(1000); o.trEnd = a.train === 0 && (a.lv > lv0 || a.xp >= xp0 + 23.9);
      // 解雇：退職金
      const s0 = G.acct.cur.sga.sev; const sev = staffSevFee(b); o.fire = staffFire(b.id); o.sev = [Math.round(G.acct.cur.sga.sev - s0), sev]; o.n = G.staff.length;
      // 再創業で残る1人
      const keep = staffKeepOne(); o.keep = keep.length === 1 && keep[0].lv === 4 && keep[0].at === null;
      return o;
    });
    const ok = r.lvA === 2 && r.lvB === 1 && r.xpA === 0 && r.tr && r.fee[0] === r.fee[1] && r.capOff && r.trEnd && r.fire && r.sev[0] === r.sev[1] && r.n === 2 && r.keep;
    rec(115, '熟練度：配置先で1時間1経験（Lv2まで24）・待機は伸びない／研修は費用（時給12時間分）を払い6時間効果なし、終わると経験+24／解雇は退職金（時給24時間分）／再創業では最も熟練した1人が残る', ok, JSON.stringify(r));
    if (errors.length) rec('E66', '熟練度テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #116 決算書の人件費・整合・v4.7（schema12）からの移行 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(async () => {
      G.dl = 3; G.acct = { prev: [] }; acctEnsure(); const o = {};
      const old = JSON.parse(JSON.stringify(G)); old.ver = 12; delete old.staff; delete old.staffCand; delete old.staffOff;
      const m = parseSave(old); o.mig = [m.ver, Array.isArray(m.staff) && m.staff.length === 0, m.staffOff === false];
      staffCandState(); staffHire(0); staffHire(0); staffTick(5 * 3600000); staffTrain(G.staff[0].id); staffFire(G.staff[1].id);
      const lv = acctLive(); o.lab = [Math.round(acctLabor(lv)), Math.round(lv.sga.hire + lv.sga.wage + lv.sga.train + lv.sga.sev)]; o.unex = Math.abs(lv.unex) < Math.max(1, lv.R * 1e-9);
      const na0 = naOf(lv.o), na1 = naOf(lv.c); o.na = Math.abs(na0 + lv.ni - na1) < Math.max(1, Math.abs(na1) * 1e-9); o.cash = Math.abs(lv.o.cash + lv.opcf + lv.invcf - lv.c.cash) < Math.max(1, Math.abs(lv.c.cash) * 1e-9);
      openFinModal(); await new Promise(r => setTimeout(r, 80)); const t = document.getElementById('mc2').textContent; o.rows = ['うち人件費', '採用費', '給与', '研修費', '退職金'].every(w => t.includes(w)); o.box = t.includes('人件費');
      const cols = [...document.querySelectorAll('#mc2 .fbd .fcol')].map(c => [...c.children].reduce((a, e) => a + parseFloat(e.style.height), 0)); o.eq = cols.length >= 2 && Math.abs(cols[0] - cols[1]) <= 3;
      closeM();
      return o;
    });
    const ok = r.mig[0] === SCHEMA && r.mig[1] && r.mig[2] && r.lab[0] > 0 && r.lab[0] === r.lab[1] && r.unex && r.na && r.cash && r.rows && r.box && r.eq;
    rec(116, '決算書：販管費に「うち人件費」（採用費・給与・研修費・退職金）・ボックス図に人件費・純資産と現金の2つの整合式・v4.7（schema12）から移行すると職人は0人', ok, JSON.stringify(r));
    if (errors.length) rec('E67', '人件費の決算書テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.9 追加テスト =================
  const STAFF3 = `(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose(); G.cash = 1e12; G.staff = []; G.staffCand = null; G.staffOff = false; staffCandState(); for (let i = 0; i < 3; i++) staffHire(0); G.staff.forEach(s => s.at = null); G.ownerAt = null; placeInvalidate(); const L0 = G.lots.filter(l => lotGoalEta(l) > 0).sort((a, b) => lotGoalEta(a) - lotGoalEta(b)); G.staff[0].at = { k: 'lot', id: L0[0].id }; G.staff[2].at = { k: 'fac', id: 'distillation' }; placeInvalidate(); prodInvalidate(); })()`;
  // ---------- #117 倉庫の棚の景色：樽の担当は樽の横・待機の人と「あなた」は通路・寝かせるを開いている間だけ動く・動きを減らす設定で止まる ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 200));
      const sc = document.getElementById('wScene'); const wk = [...sc.querySelectorAll('.wk')];
      const o = { ids: wk.map(g => g.dataset.sid + (g.dataset.act ? '+' : '')).join(), exp: ['owner+', G.staff[1].id + '+', G.staff[0].id].sort().join() };
      o.ids = wk.map(g => g.dataset.sid + (g.dataset.act ? '+' : '')).sort().join();
      const cell = sc.querySelector(`.wcask[data-id="${G.staff[0].at.id}"]`); o.inCell = !!cell.querySelector(`.wk[data-sid="${G.staff[0].id}"]`);
      o.facNot = !sc.querySelector(`.wk[data-sid="${G.staff[2].id}"]`);
      o.run = _scene.anims.filter(a => a.playState === 'running').length;
      switchTab('tsale'); scenePlay(); o.paused = _scene.anims.length > 0 && _scene.anims.every(a => a.playState === 'paused');
      switchTab('tcel'); scenePlay(); o.again = _scene.anims.some(a => a.playState === 'running');
      G.ownerAt = { k: 'lot', id: G.lots[3].id }; placeInvalidate(); sceneLight(); o.ownerCell = !!sc.ownerDocument.querySelector(`#wScene .wcask[data-id="${G.lots[3].id}"] .wk[data-sid="owner"]`);
      opt().motion = 'low'; applyOpt(); sceneMount(); o.low = _scene.anims.length; opt().motion = 'std'; applyOpt();
      return o;
    });
    const ok = r.ids === r.exp && r.inCell && r.facNot && r.run > 0 && r.paused && r.again && r.ownerCell && r.low === 0;
    rec(117, '倉庫の棚の景色：樽の担当は担当の樽の横で働く・待機の職人と配置していない「あなた」は通路（押せる）・設備の担当は出ない・寝かせるを開いている間だけ動く・動きを減らす設定では止まる', ok, JSON.stringify(r));
    if (errors.length) rec('E68', '倉庫の景色テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #118 タップの反応と差し入れ（1日1回・経験+2・その日最初の1回だけ砂時計）・樽を叩くと残り時間（状態は変わらない） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 150));
      G.hg.n = 0; hgDay();
      const g = document.querySelector('#wScene .wk[data-act="wkTap"]:not([data-sid="owner"])'); g.dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 80));
      const bub = document.getElementById('wBub'); const o = { open: !bub.classList.contains('h'), txt: bub.textContent.length > 5, care: !!bub.querySelector('[data-act="staffCare"]') };
      o.gone = typeof staffCare === 'undefined' && !('care' in V51.HG) && !document.getElementById('wBub').textContent.includes('差し入れ');
      const lsig = () => JSON.stringify(G.lots.map(l => ({ ...l, age: 0, L: 0 }))); const snap = lsig(); const c = document.querySelector('#wScene .wcask'); c.dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
      { const bt = document.getElementById('wBub').textContent; const l = G.lots.find(x => x.id === c.dataset.id); o.knock = bt.includes(fmtAge(l.age)) && bt.includes('残り'); } o.same = lsig() === snap;
      document.body.click(); await new Promise(r => setTimeout(r, 30)); o.closed = document.getElementById('wBub').classList.contains('h');
      return o;
    });
    const ok = r.open && r.txt && !r.care && r.gone && r.knock && r.same && r.closed;
    rec(118, '職人を押すと吹き出しで一言（差し入れは v5.4 で廃止）・樽を押すと叩く音と残り時間（樽の状態は変わらない）・外を押すと閉じる', ok, JSON.stringify(r));
    if (errors.length) rec('E69', 'タップの反応テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #120 倉庫日誌に職人の出来事（採用・Lv・研修・解雇・差し入れ・休業）と1日の様子 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.jnl = { cur: null, list: [] }; jnlRoll();
      const s = G.staff[0]; staffCandState(); G.staffCand.free = 1; staffRefresh(); staffHire(0); staffXp(s, 24); staffTrain(s.id); s.train = Date.now() - 1; staffTick(1000); staffFire(G.staff[3].id);
      const cur = jnlCur().staff.slice();
      off = 24 * 3600000; jnlRoll(); const e = G.jnl.list[0];
      Date.now = rn; G.ls = rn(); if (_offlineGate) closeOfflineModal();
      openJnlModal(); const t = document.getElementById('mc2').textContent; closeM();
      return { cur, e: e.staff, t: e.staff.every(x => t.includes(x)) };
    });
    const ok = r.cur.some(x => x.includes('加わった')) && r.cur.some(x => x.includes('Lv2')) && r.cur.some(x => x.includes('研修から戻った')) && r.cur.some(x => x.includes('去った')) && r.e.length >= 4 && r.e.length <= 5 && /は.+。$/.test(r.e[r.e.length - 1]) && r.t;
    rec(120, '倉庫日誌：職人の出来事（採用・Lv・研修・解雇など）と、その日の職人の様子が1行記録され、日誌の小窓に出る', ok, JSON.stringify(r));
    if (errors.length) rec('E71', '日誌の職人テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.9.1 追加テスト =================
  // ---------- #121 タイムラプス廃止・ドット絵（輪郭がにじまない・見た目は seed で決まる・動きを減らす設定では止まる） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      const o = {};
      o.noTl = typeof tlOpen === 'undefined' && typeof tlTimes === 'undefined' && typeof _tlAnim === 'undefined' && !document.querySelector('[data-act="tlOpen"]') && !document.body.innerText.includes('振り返る');
      openLotModal(G.lots[0].id); o.modal = !document.getElementById('mc2').textContent.includes('振り返る'); closeM();
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 200));
      const sv = document.querySelector('#wScene svg'); o.crisp = sv && sv.getAttribute('shape-rendering') === 'crispEdges';
      o.px = document.querySelectorAll('#wScene .wk path').length > 20 && document.querySelectorAll('#wScene .wcask path').length > 3;
      const a = JSON.stringify(pxLook({ seed: 12345 })), b = JSON.stringify(pxLook({ seed: 12345 })), c = JSON.stringify(pxLook({ seed: 777 }));
      o.det = a === b && a !== c; o.owner = pxLook(OWNER).acc === 'pipe';
      o.bg = getComputedStyle(document.getElementById('wScene')).backgroundImage === 'none' && !sv.querySelector('linearGradient');
      o.run = _scene.anims.length > 0;
      opt().motion = 'low'; applyOpt(); sceneMount(); o.low = _scene.anims.length === 0 && document.querySelectorAll('#wScene .wk').length === 3; opt().motion = 'std'; applyOpt();
      return o;
    });
    const ok = r.noTl && r.modal && r.crisp && r.px && r.det && r.owner && r.bg && r.run && r.low;
    rec(121, 'タイムラプスを廃止（関数も「振り返る」もない）・職人と樽はドット絵（輪郭がにじまない・見た目は seed で決まる・主人は固定）・景色の背景は透明・動きを減らす設定では止まる', ok, JSON.stringify(r));
    if (errors.length) rec('E72', 'ドット絵テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.0 追加テスト =================
  // ---------- #122 熟成と天使の分け前：担当の倍率で熟成が速くなり、熟成1年あたりの減り方は同じ・残り時間・放置・砂時計にも反映 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const ct = caskType('bourbon'), sz = caskSize('hogshead');
      const a = makeLot(ct, sz, { c: 0 }), b = makeLot(ct, sz, { c: 0 }); G.lots.push(a, b); lotGoalInit(a); lotGoalInit(b);
      const s = { id: uid('s'), nm: 'T', seed: 1, r: 1, st: { waza: 10, tegiwa: 1, mekiki: 1 }, tr: 'calm', lv: 10, xp: 0, at: { k: 'lot', id: a.id }, hired: 0, train: 0, care: '' };
      G.staff = [s]; placeInvalidate();
      const o = { m: lotMult(a), eta: lotGoalEta(a) / lotGoalEta(b) };
      const Y = BALANCE.GAME_YEAR_MS / agingRateBase(a);
      // a は3年、b は2年ぶん（同じ実時間では a が1.5倍）
      lotAdvance(a, 2 * Y); lotAdvance(b, 2 * Y); o.age = [+a.age.toFixed(6), +b.age.toFixed(6)];
      lotAdvance(b, 1 * Y); o.sameL = Math.abs(a.L - b.L) / a.L < 1e-9 && Math.abs(a.age - b.age) < 1e-9;
      o.modal = (() => { openLotModal(a.id); const t = document.getElementById('mc2').textContent; closeM(); return t.includes('うち担当 ×1.50') && t.includes('担当T ×1.50'); })();
      // 放置24時間・砂時計1時間：毎秒進めたのと同じ
      const c = makeLot(ct, sz, { c: 0 }), d = makeLot(ct, sz, { c: 0 }); G.lots.push(c, d); s.at = { k: 'lot', id: c.id }; G.ownerAt = { k: 'lot', id: d.id }; placeInvalidate();
      const c0 = c.age, d0 = d.age; if (_offlineGate) closeOfflineModal(); G.cash = 1e15; G.ls = Date.now() - 24 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      o.off = [+((c.age - c0) / (24 * 3600000 / BALANCE.GAME_YEAR_MS * agingRateBase(c))).toFixed(4), +((d.age - d0) / (24 * 3600000 / BALANCE.GAME_YEAR_MS * agingRateBase(d))).toFixed(4)];
      const c1 = c.age; G.hg.n = 1; G.hg.useDay = 0; G.ls = Date.now(); hgUse(); if (_offlineGate) closeOfflineModal(); o.hg = +((c.age - c1) / (3600000 / BALANCE.GAME_YEAR_MS * agingRateBase(c))).toFixed(4);
      return o;
    });
    const ok = Math.abs(r.m - 1.5) < 1e-9 && Math.abs(r.eta - 1 / 1.5) < 1e-6 && Math.abs(r.age[0] - 3) < 1e-6 && Math.abs(r.age[1] - 2) < 1e-6 && r.sameL && r.modal && Math.abs(r.off[0] - 1.5) < 1e-3 && Math.abs(r.off[1] - 1.1) < 1e-3 && Math.abs(r.hg - 1.5) < 1e-3;
    rec(122, '熟成：担当の倍率だけ速く熟成し（残り時間も短くなる）、同じ年数に達したときの残量は配置しないときと同じ（天使の分け前は熟成1年あたり同じ）・放置24時間と砂時計にも反映・樽の小窓に担当と内訳', ok, JSON.stringify(r));
    if (errors.length) rec('E73', '熟成と配置テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #123 配置の規則：1か所1人・入れ替え・待機・置けない所・樽がなくなると待機・目標に届いても担当のまま・あなたはTier1から×1.10（休業の影響なし） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      const mk = (st) => ({ id: uid('s'), nm: 'T' + st, seed: st, r: 1, st: { waza: st, tegiwa: st, mekiki: st }, tr: 'calm', lv: 1, xp: 0, at: null, hired: 0, train: 0, care: '' });
      G.dl = 3; const A = mk(5), B = mk(7); G.staff = [A, B]; placeInvalidate();
      const L = G.lots; const o = {};
      placeSet(A, { k: 'fac', id: 'distillation' }, true); placeSet(B, { k: 'lot', id: L[0].id }, true);
      placeSet(B, { k: 'fac', id: 'distillation' }, true); o.swap = [placeKey(A.at), placeKey(B.at)].join();
      placeSet(A, null, true); o.idle = A.at === null;
      G.fac.mashing.p = false; prodInvalidate(); o.ng = placeSet(A, { k: 'fac', id: 'mashing' }, true) === false && placeSet(A, { k: 'lot', id: 'nope' }, true) === false; G.fac.mashing.p = true; prodInvalidate();
      o.bottleLv0 = (() => { const p = G.fac.bottling.p; G.fac.bottling.p = false; const ok = placeOk({ k: 'fac', id: 'bottling' }); G.fac.bottling.p = p; return ok; })();
      // 樽がなくなる：樽ごと売る・天使の分け前で処分
      placeSet(A, { k: 'lot', id: L[1].id }, true); const sold = L[1].id; sellLot(sold); staffTick(1000); o.sold = A.at === null && jnlCur().staff.some(t => t.includes('待機に戻った'));
      placeSet(A, { k: 'lot', id: G.lots[1].id }, true); const tiny = G.lots[1]; tiny.L = 0.1; lotTick(1000); staffTick(1000); o.evap = A.at === null;
      // 目標に届いても担当のまま
      const g = G.lots[2]; placeSet(A, { k: 'lot', id: g.id }, true); g.goal = g.age + 0.0001; lotAdvance(g, 864e5); o.keep = placeKey(A.at) === 'lot:' + g.id && !!g.gd;
      // あなた：Tier1から・×1.10・休業の影響なし
      G.dl = 1; G.staff = []; placeInvalidate(); o.t1 = placeSet(OWNER, { k: 'fac', id: 'malting' }, true) && Math.abs(facMult('malting') - 1.1) < 1e-9;
      G.staff = [mk(3)]; G.staffOff = true; placeInvalidate(); o.ownerOff = Math.abs(facMult('malting') - 1.1) < 1e-9; G.staffOff = false;
      // 再創業：あなたの配置は外れ、残る1人は待機。樽の枠のボーナスは残る
      return o;
    });
    const ok = r.swap.split(',')[1] === 'fac:distillation' && r.swap.split(',')[0].startsWith('lot:') && r.idle && r.ng && r.bottleLv0 && r.sold && r.evap && r.keep && r.t1 && r.ownerOff;
    rec(123, '配置の規則：1か所に1人（先客とは入れ替え）・待機にできる・未所有の設備や無い樽には置けない（ボトリングは手作業でも可）・樽を売る・天使の分け前で処分すると待機に戻り日誌に記録・目標に届いても担当のまま・あなたはTier1から ×1.10（休業の影響なし）', ok, JSON.stringify(r));
    if (errors.length) rec('E74', '配置の規則テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #124 v4.8〜v4.9（schema13）からの移行：持ち場→配置先・樽の枠は減らない（恒久のボーナス）・バックアップ・変更点の案内 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post, st, lv, extra) => Object.assign({ id: uid('s'), nm: 'T', seed: 1, r: 1, st, tr: 'calm', lv, xp: 0, post, hired: 0, train: 0, care: '' }, extra || {});
      const S = (w, t, m) => ({ waza: w, tegiwa: t, mekiki: m });
      const obj = JSON.parse(JSON.stringify(G)); obj.ver = 13; delete obj.ownerAt; delete obj.whBonus; if (obj.hs) delete obj.hs.new50;
      obj.staff = [mk('buy', S(1, 1, 9), 2), mk('still', S(1, 9, 1), 3), mk('still', S(1, 8, 1), 1), mk('still', S(1, 7, 1), 1), mk('ship', S(1, 6, 1), 1), mk('fill', S(4, 9, 1), 5, { train: Date.now() + 3600000 }), mk('fill', S(3, 8, 1), 1), mk('watch', S(8, 1, 1), 1), mk(null, S(5, 5, 5), 1)];
      obj.staffOff = true;
      // v4.9 の式：樽の枠 = floor((手際×(1+0.1(Lv−1)) の大きい順に100%・80%) / 3)、上限12
      const fp = [9 * 1.4, 8 * 1].sort((a, b) => b - a).reduce((a, v, i) => a + v * [1, 0.8, 0.6][i], 0); const expBonus = Math.min(12, Math.floor(fp / 3));
      const slotsBefore = Math.floor((BALANCE.WH_BASE + BALANCE.WH_PER_LV * facLv('maturation')) * brMod('maturation', 'slots')) + expBonus;
      const raw = JSON.stringify(obj); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, wb: m.whBonus, exp: expBonus, at: m.staff.map(s => placeKey(s.at)), owner: m.ownerAt, new50: m.hs.new50 };
      const keepG = G; G = m; placeSanitize(); o.slots = [whSlots(), slotsBefore]; o.uniq = (() => { const k = m.staff.filter(s => s.at).map(s => placeKey(s.at)); return new Set(k).size === k.length; })(); G = keepG;
      // 読み込み：移行前のデータをバックアップ
      const key = storageKey(); localStorage.setItem(key, raw); localStorage.removeItem('we_v4_bak13:' + (LIFF_USER.id || 'guest')); load(); o.bk = localStorage.getItem('we_v4_bak13:' + (LIFF_USER.id || 'guest')) === raw; o.loaded = G.ver;
      o.tut = !TUTS.u50;
      return o;
    });
    const ok = r.ver === SCHEMA && r.wb === r.exp && r.wb > 0 && r.at[0] === 'fac:malting' && r.at[1] === 'fac:distillation' && r.at[2] === 'fac:fermentation' && r.at[3] === 'fac:mashing' && r.at[4] === 'fac:bottling' && r.at[5].startsWith('lot:') && r.at[6].startsWith('lot:') && r.at[7].startsWith('lot:') && r.at[8] === '' && r.owner === null && r.new50 === 0 && r.slots[0] === r.slots[1] && r.uniq && r.bk && r.loaded === SCHEMA && r.tut;
    rec(124, 'v4.8〜v4.9（schema13）からの移行：原料調達→製麦室・蒸留→蒸留器・発酵槽・糖化槽・出荷→ボトリング・樽詰めと熟成監視→目標が近い樽・樽の枠は研修中や休業中の人も含めて移行前と同じ（恒久のボーナス）・移行前をバックアップ・版の案内なし', ok, JSON.stringify(r));
    if (errors.length) rec('E75', '移行テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #125 おまかせ配置：いちばん遅い工程→瓶詰めの予約があればボトリング→目標が近い樽・あなたは動かさない・新酒が増えない工程の注意 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (st) => ({ id: uid('s'), nm: 'T', seed: st, r: 1, st: { waza: st, tegiwa: st, mekiki: st }, tr: 'calm', lv: 1, xp: 0, at: null, hired: 0, train: 0, care: '' });
      G.staff = [mk(9), mk(8), mk(7), mk(6)]; G.ownerAt = { k: 'lot', id: G.lots[0].id }; placeInvalidate(); prodInvalidate();
      const bn = STAGES[prodFlows().bottleneck].fac; const n = placeAuto(true);
      const o = { n, first: placeKey(G.staff[0].at), bn, owner: placeKey(G.ownerAt), bott: G.staff.some(s => placeKey(s.at) === 'fac:bottling'), lots: G.staff.filter(s => s.at && s.at.k === 'lot').map(s => s.at.id) };
      const eta = G.lots.filter(l => lotGoalEta(l) > 0 && l.id !== G.lots[0].id).sort((a, b) => lotGoalEta(a) - lotGoalEta(b)).map(l => l.id);
      o.lotOrder = o.lots.every((id, i) => id === eta[i]);
      // 新酒が増えない工程（いちばん遅い工程でない）に置くと注意
      const other = STAGES.map(s => s.fac).find(f => f !== bn && facLv(f) > 0 && !placeWho('fac', f)); placeSet(G.staff[3], { k: 'fac', id: other }, true);
      o.nogain = facNoGain(other) && staffGainTxt(G.staff[3]).includes('新酒は増えません');
      switchTab('tb'); rMake(); o.row = document.getElementById('fac_' + other).textContent.includes('今は増えません');
      o.gain = staffGainTxt(G.staff[0]).includes('効果 +');
      return o;
    });
    const ok = r.n === 4 && r.first === 'fac:' + r.bn && r.owner.startsWith('lot:') && r.bott && r.lotOrder && r.nogain && r.row && r.gain;
    rec(125, 'おまかせ配置：いちばん遅い工程に向いた人→瓶詰めの予約があればボトリング→目標が近い樽の順・あなたの配置は動かさない・いちばん遅い工程でない所は「新酒は増えません」と表示', ok, JSON.stringify(r));
    if (errors.length) rec('E76', 'おまかせ配置テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #126 配置モード：樽を押して「移動」→ 造るタブの設備を押すと配置・やめる・Esc・待機・設備を押すと担当の小窓 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      const w = G.staff[0]; const lid = w.at.id; switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 100));
      document.querySelector(`#wScene .wcask[data-id="${lid}"]`).dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
      const bub = document.getElementById('wBub'); const o = { bub: !bub.classList.contains('h') && bub.textContent.includes(w.nm) && !!bub.querySelector('[data-act="pmStart"]') };
      bub.querySelector('[data-act="pmStart"]').click(); await new Promise(r => setTimeout(r, 60));
      o.mode = !!_pm && !!document.getElementById('pmBar') && document.body.classList.contains('pm');
      switchTab('tb'); rMake(); await new Promise(r => setTimeout(r, 60)); o.stay = !!_pm;
      document.querySelector('#fac_mashing .pic').click(); await new Promise(r => setTimeout(r, 60));
      o.placed = placeKey(w.at) === 'fac:mashing' && !_pm && !document.getElementById('pmBar');
      // Esc・やめる・待機
      pmStart(w); document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); o.esc = !_pm;
      pmStart(w); document.querySelector('#pmBar [data-act="pmEnd"]').click(); o.end = !_pm && placeKey(w.at) === 'fac:mashing';
      pmStart(w); document.querySelector('#pmBar [data-act="pmIdle"]').click(); o.idle = !_pm && w.at === null;
      // 設備を押す：担当の小窓 → 職人を呼ぶ
      document.querySelector('#fac_distillation .pic').click(); await new Promise(r => setTimeout(r, 60)); const t = document.getElementById('mc2').textContent; o.fm = t.includes('蒸留器') && t.includes(G.staff[2].nm) && !!document.querySelector('#mc2 [data-act="placePickC"]');
      document.querySelector('#mc2 [data-act="placePickC"]').click(); await new Promise(r => setTimeout(r, 60)); const btn = document.querySelector(`#mc2 [data-act="placeSet"][data-sid="${w.id}"]`); o.pick = !!btn; btn.click(); await new Promise(r => setTimeout(r, 60));
      o.swap = placeKey(w.at) === 'fac:distillation' && G.staff[2].at === null && document.getElementById('mo').classList.contains('h');
      // 売るタブのボトリングにも置ける
      _ui.sellTab = 'ord'; switchTab('tsale'); rall(); pmStart(G.staff[1]); document.querySelector('#fac_bottling .pic').click(); o.bot = placeKey(G.staff[1].at) === 'fac:bottling';
      return o;
    });
    const ok = r.bub && r.mode && r.stay && r.placed && r.esc && r.end && r.idle && r.fm && r.pick && r.swap && r.bot;
    rec(126, '配置モード：樽を押した吹き出しの「移動」→ タブを移っても続き、造るタブの設備の絵を押すと配置・「やめる」とEscで終わる・「待機に」・設備の絵を押すと担当の小窓（職人を呼ぶ・入れ替え）・売るタブのボトリングにも置ける', ok, JSON.stringify(r));
    if (errors.length) rec('E77', '配置モードテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #127 棚の段数：樽0・1・6・7・40・84個・空きは1段＋「あと何樽」・札は重ならない・広げると全画面 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.auto.fill.on = false; G.tank = 0; switchTab('tcel'); const all = G.lots.slice(); const slots = whSlots(); const o = { slots, cases: [] };
      for (const n of [0, 1, 6, 7, 40, 84]) {
        G.lots = all.slice(0, n); rCellar(); await new Promise(r => setTimeout(r, 30));
        const sv = document.querySelector('#wScene svg'); const vb = sv ? sv.viewBox.baseVal.height : 0; const aisle = shelfAisle().length ? SH.AISLE : 0;
        const empty = Math.max(0, slots - n), showE = Math.min(empty, n % 6 ? 6 - n % 6 : 6), rows = Math.max(1, Math.ceil((n + showE) / 6));
        const lb = [...document.querySelectorAll('#wScene .wsl')].map(e => e.getBoundingClientRect()); let ov = 0;
        for (let i = 0; i < lb.length; i++) for (let j = i + 1; j < lb.length; j++) { const a = lb[i], b = lb[j]; if (a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1) ov++; }
        const more = (document.querySelector('#wScene .wmore') || {}).textContent || '';
        o.cases.push({ n, cells: document.querySelectorAll('#wScene .wcask').length, rowsOk: Math.abs(vb - (aisle + rows * SH.RH)) < 0.5, ov, more: empty - showE > 0 ? more.includes(String(empty - showE)) : more === '' });
      }
      G.lots = all; rCellar(); o.noBig = !document.querySelector('[data-act="whBig"]') && !document.getElementById('tcel').textContent.includes('広げる');
      return o;
    });
    const ok = r.cases.every(c => c.cells === c.n && c.rowsOk && c.ov === 0 && c.more) && r.noBig;
    rec(127, '棚：樽が0・1・6・7・40・84個でも段数が正しい（1段6樽）・空きは今の段＋1段まで描き、残りは「空き あとn樽」・札は重ならない・「広げる」はない', ok, JSON.stringify(r));
    if (errors.length) rec('E78', '棚テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #128 造る・売る：設備の行の左はドット絵の設備と担当（行の高さは変わらない）・動きは開いているタブだけ・描き直しても絵は作り直さない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tb'); rMake(); await new Promise(r => setTimeout(r, 100));
      const o = {}; const rows = STAGES.map(s => document.getElementById('fac_' + s.fac));
      o.h = rows.map(e => Math.round(e.getBoundingClientRect().height)); o.px = rows.every(e => e.querySelector('.pic .pxs .pxf'));
      o.worker = !!document.querySelector('#fac_distillation .pic .wk[data-sid="' + G.staff[2].id + '"]');
      o.tag = document.getElementById('fac_distillation').textContent.includes(G.staff[2].nm + ' ×');
      const el = document.querySelector('#fac_malting .pxs'); G.tank = (G.tank || 0) + 123; rMake(); o.reuse = document.querySelector('#fac_malting .pxs') === el;
      const an = [..._pxs.values()].flatMap(e => e.anims); o.run = an.some(a => a.playState === 'running');
      switchTab('tcel'); scenePlay(); o.paused = an.filter(a => a._tab === 'tb').every(a => a.playState === 'paused');
      _ui.sellTab = 'ord'; switchTab('tsale'); rall(); o.bot = !!document.querySelector('#fac_bottling .pic .pxs');
      opt().motion = 'low'; applyOpt(); _pxs.clear(); switchTab('tb'); document.getElementById('lineView')._h = null; rMake(); o.low = [..._pxs.values()].every(e => e.anims.length === 0); opt().motion = 'std'; applyOpt();
      return o;
    });
    const ok = r.h.every(v => v <= 52) && r.px && r.worker && r.tag && r.reuse && r.run && r.paused && r.bot && r.low;
    rec(128, '造る：4工程の行の左にドット絵の設備と担当・担当の名前と倍率を表示・行の高さは v4.9 と同じ52px以下・毎秒描き直しても絵は作り直さない・動くのは開いているタブだけ・売るの瓶詰めにボトリングの絵・動きを減らす設定では動かない', ok, JSON.stringify(r));
    if (errors.length) rec('E79', '設備のドット絵テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #129 性能：樽84・職人17人で寝かせるタブの描画（CPUを4倍遅くして）1秒以内 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const cdp = await ctx.newCDPSession(page);
    await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } G.cash = 1e15; G.staff = []; G.staffCand = null;
      for (let i = 0; i < 17; i++) { const c = staffCandState(); if (!c.list.length) { c.free = 1; staffRefresh(); } staffHire(0); } placeAuto(true); closeM(); switchTab('tcel'); rCellar(); });
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
    const r = await page.evaluate(async () => { const n = G.lots.length; const t = []; for (let i = 0; i < 3; i++) { _ui.sig.cel = null; document.getElementById('whSummary')._h = null; const t0 = performance.now(); rCellar(); document.body.offsetHeight; t.push(performance.now() - t0); await new Promise(r => setTimeout(r, 50)); } return { n, staff: G.staff.length, t: t.map(v => Math.round(v)), anims: _scene.anims.length }; });
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: 1 });
    const med = r.t.slice().sort((a, b) => a - b)[1];
    rec(129, '性能：樽84・職人17人で寝かせるタブを描く時間がCPU4倍遅い条件で1秒以内（3回の中央値。v4.9の樽のマス一覧は同じ条件で約0.6秒）', r.n >= 80 && r.staff === 17 && med <= 1000, JSON.stringify(r));
    if (errors.length) rec('E80', '性能テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.0.1 追加テスト =================
  // ---------- #130 文字量：各画面の見えている文字数が目標以下（390×844・中盤） ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose(); closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      G.cash = 1e12; G.staff = []; G.staffCand = null; for (let i = 0; i < 3; i++) { staffCandState(); staffHire(0); } placeAuto(true); closeM();
      const vis = e => e.getClientRects().length > 0 && (!e.checkVisibility || e.checkVisibility({ checkVisibilityCSS: true }));
      const count = (root, skip) => { const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n, c = 0; while (n = w.nextNode()) { const p = n.parentElement; if (!p || !vis(p) || (skip && p.closest(skip))) continue; c += n.textContent.replace(/\s/g, '').length; } return c; };
      const o = {};
      for (const t of ['tb', 'tcel', 'tsale']) { switchTab(t); rall(); await new Promise(r => setTimeout(r, 200)); o[t] = count(document.getElementById(t), t === 'tcel' ? '.wsl,.wmore' : null); }
      const M = (k, f) => { f(); o[k] = count(document.getElementById('mc2')); closeM(); };
      M('lot', () => openLotModal(G.lots[0].id)); M('bottle', () => openBottleModal(G.uw[0])); M('staffList', () => openStaffModal('list')); M('hg', () => openHgModal());
      return o;
    });
    const LIM = { tb: 280, tcel: 200, tsale: 400, lot: 250, bottle: 250, staffList: 250, hg: 200 };
    const over = Object.keys(LIM).filter(k => !(r[k] <= LIM[k]));
    rec(130, '文字量：造る280・寝かせる200（棚の札を除く）・売る400・樽の小窓250・瓶詰めの小窓250・職人の一覧250・砂時計200 字以下', over.length === 0, JSON.stringify({ r, over }));
    if (errors.length) rec('E80', '文字量テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #131 版の案内をやめた：案内は1画面60字まで・「追加しました」などの言い方がない・更新のあとは⚙️と「更新履歴」に印だけ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      const steps = Object.entries(TUTS).flatMap(([k, t]) => t.steps.map(s => [k, s.text.replace(/<[^>]+>/g, '')]));
      o.long = steps.filter(([k, t]) => t.length > 60).map(([k, t]) => k + ':' + t.length);
      o.word = steps.filter(([k, t]) => /追加しました|新しく|ようになりました|加えました|変更点/.test(t)).map(([k]) => k);
      o.ver = ['upd', 'u43', 'u_line43', 'u44', 'u45', 'u_cel45', 'u46', 'u_sell46', 'u47', 'u50'].filter(k => TUTS[k]);
      o.n = Object.keys(TUTS).length;
      // 更新のあと（前の版で保存したセーブ）：⚙️と更新履歴に印 → 更新履歴を開くと消える
      G.hs.cl = '5.0.0'; v50Tick(); o.dot1 = document.getElementById('btnGear').classList.contains('cln') && getComputedStyle(document.getElementById('btnGear'), '::after').content !== 'none';
      switchTab('tp'); v50Tick(); o.dotCl = document.querySelector('[data-act="changelog"]').classList.contains('cln');
      document.querySelector('[data-act="changelog"]').click(); await new Promise(r => setTimeout(r, 50));
      o.cl = document.getElementById('mc2').textContent.includes('v' + BALANCE.APP_VERSION); closeM(); v50Tick();
      o.dot2 = !document.getElementById('btnGear').classList.contains('cln') && G.hs.cl === BALANCE.APP_VERSION;
      // 新しく始めた人には印を付けない・保存して読み直しても残る
      o.fresh = defState().hs.cl === BALANCE.APP_VERSION; o.san = sanitize(JSON.parse(JSON.stringify(G))).hs.cl === BALANCE.APP_VERSION && sanitize(Object.assign(JSON.parse(JSON.stringify(G)), { hs: {} })).hs.cl === '';
      return o;
    });
    const ok = r.long.length === 0 && r.word.length === 0 && r.ver.length === 0 && r.n <= 22 && r.dot1 && r.dotCl && r.cl && r.dot2 && r.fresh && r.san;
    rec(131, '案内：版の変更の案内（upd・u43〜u50・u_sell46）がない・1画面60字まで・「追加しました」などの言い方がない／更新のあとは⚙️と更新履歴に印、開くと消える・新規は印なし', ok, JSON.stringify(r));
    if (errors.length) rec('E81', '案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #132 TIPS：年数と日数・寝かせるの流れ・売るの流れ・瓶詰めの選び方。樽の小窓・瓶詰めの小窓のⓘから開ける ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = { ids: ['age', 'celflow', 'sellflow', 'bottle'].filter(id => TIPS.some(t => t.id === id)) };
      openLotModal(G.lots[0].id); const ib1 = document.querySelector('#mc2 .ib[data-id="age"]'); o.lotIb = !!ib1; if (ib1) ib1.click(); await new Promise(r => setTimeout(r, 50));
      o.lotTip = document.getElementById('mc2').textContent.includes('年数と日数'); closeM();
      openBottleModal(G.uw[0]); const ib2 = document.querySelector('#mc2 .ib[data-id="bottle"]'); o.btlIb = !!ib2; if (ib2) ib2.click(); await new Promise(r => setTimeout(r, 50));
      o.btlTip = document.getElementById('mc2').textContent.includes('詰めて納品'); closeM();
      o.book = (() => { openTipBook(); const t = document.getElementById('mc2').textContent; closeM(); return ['年数と日数', '寝かせるの流れ', '売るの流れ', '瓶詰めの選び方'].every(x => t.includes(x)); })();
      return o;
    });
    const ok = r.ids.length === 4 && r.lotIb && r.lotTip && r.btlIb && r.btlTip && r.book;
    rec(132, 'TIPS：年数と日数・寝かせるの流れ・売るの流れ・瓶詰めの選び方がヒント帳にあり、樽の小窓と瓶詰めの小窓のⓘから開ける', ok, JSON.stringify(r));
    if (errors.length) rec('E82', 'TIPSテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #133 寝かせるの吹き出し：画面の下半分の樽は上、上半分の樽は下に出る・見出しに隠れない（84樽） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      G.auto.fill.on = false; switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 100));
      const tc = document.getElementById('tcel'); const o = { n: G.lots.length, cases: [] };
      const hd = () => document.querySelector('#tcel .thead').getBoundingClientRect();
      const nav = document.getElementById('nav').getBoundingClientRect();
      const casks = [...document.querySelectorAll('#wScene .wcask')];
      const mid = casks[Math.floor(casks.length / 2)];
      for (const [pick, pos] of [[mid, 'start'], [mid, 'end'], [casks[casks.length - 1], 'end']]) {
        pick.scrollIntoView({ block: pos }); if (pos === 'start') tc.scrollTop -= 90; await new Promise(r => setTimeout(r, 30));
        const g = pick.getBoundingClientRect(); caskKnock(pick.dataset.id, pick); await new Promise(r => setTimeout(r, 60));
        const g2 = pick.getBoundingClientRect(); const b = document.getElementById('wBub').getBoundingClientRect(); const h = hd();
        const lower = g.top + g.height / 2 > innerHeight / 2;
        o.cases.push({ lower, above: b.bottom <= g2.top + 12, below: b.top >= g2.bottom - 10, inView: b.top >= h.bottom - 1 && b.bottom <= nav.top + 1 });
        bubClose();
      }
      tc.scrollTop = 0; await new Promise(r => setTimeout(r, 30)); casks[0].dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
      o.topRow = (() => { const b = document.getElementById('wBub').getBoundingClientRect(), h = hd(); return b.top >= h.bottom - 1; })();
      return o;
    });
    const ok = r.n >= 40 && r.cases.length === 3 && r.cases.every(c => (c.lower ? !c.below : !c.above) && c.inView) && r.cases.some(c => !c.lower) && r.cases.some(c => c.lower) && r.topRow;
    rec(133, '寝かせるの吹き出し：画面の下半分の樽は上、上半分の樽は下に出る（入りきらなければ樽に重ねる）・見出しやタブに隠れない（タブ全体でスクロール）', ok, JSON.stringify(r));
    if (errors.length) rec('E83', '吹き出しテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.1 第2回 追加テスト =================
  // ---------- #134 売り方：3年未満は売れない・吹き出しの金額が計算と一致・注文がなければ「瓶詰めして在庫へ」が先頭、使える注文があれば「注文に使う」が先頭 ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 100));
      const o = {};
      const young = G.lots.find(l => l.age < 3); const n0 = G.lots.length;
      o.youngSell = sellLot(young.id) === 0 && G.lots.length === n0;
      caskKnock(young.id, document.querySelector(`#wScene .wcask[data-id="${young.id}"]`)); const yb = document.getElementById('wBub');
      o.youngBub = yb.textContent.includes('3年で売れます') && !yb.querySelector('[data-act="lotRoute"]'); bubClose();
      openLotModal(young.id); const ybtn = document.querySelector('#mc2 [data-act="lotSell"]'); o.youngModal = ybtn.disabled && ybtn.textContent.includes('3年で売れます'); closeM();
      // 注文なし：在庫へが先頭・金額
      const saved = G.orders; G.orders = []; const l = G.lots.filter(x => x.age >= 8 && !x.name && !lotSellWarn(x)).sort((a, b) => b.age - a.age)[0];
      caskKnock(l.id, document.querySelector(`#wScene .wcask[data-id="${l.id}"]`));
      const btns = [...document.querySelectorAll('#wBub [data-act="lotRoute"]')]; o.order0 = btns.map(b => b.dataset.r).join(); o.top = btns[0].classList.contains('top');
      const pl = lotBotPlan(l); const txt = r => (btns.find(b => b.dataset.r === r) || {}).textContent || '';
      o.amt = txt('stock').includes(fmt(pl.stockMax)) && txt('stock').includes(fmtN(pl.n) + '本') && txt('spot').includes(fmt(pl.unit * BALANCE.SPOT_MULT * pl.n - (pl.mat.free ? 0 : pl.mat.cost))) && txt('cask').includes(fmt(lotValue(l) * BALANCE.CASK_SPOT_MULT));
      o.best = lotProducts(l).every(p => { const pv = botPreview(p, pl.n, 'manual', [l.id], 0); return !pv.ok || pv.unit <= pl.unit + 1e-9; });
      bubClose(); G.orders = saved;
      // 使える注文（この樽だけで足りる量）を作る → 先頭は「注文に使う」
      G.cash = 1e15; hideConfirm();
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pl.pid; a.minAge = 3; a.qty = 10; a.rq = 10; a.reserve = false; a.dueAt = Date.now() + 36e5 * 30; G.orders = [a];
      G.bottles = G.bottles.filter(b => b.pid !== pl.pid);
      rCellar(); await new Promise(r => setTimeout(r, 50));
      caskKnock(l.id, document.querySelector(`#wScene .wcask[data-id="${l.id}"]`));
      const b2 = [...document.querySelectorAll('#wBub [data-act="lotRoute"]')]; o.order1 = b2.map(b => b.dataset.r).join(); o.mark = !!document.querySelector(`#wScene .wcask[data-id="${l.id}"] .wom`);
      b2[0].click(); await new Promise(r => setTimeout(r, 30)); o.conf = document.getElementById('confirmDlg').classList.contains('on'); o.bq = G.bq.length;
      o.ordBot = G.bq.some(q => q.oid === a.id && q.n === 10) && a.autoDel === true;
      botTick(36e5 * 50); ordAutoTick(); o.delivered = !G.orders.some(x => x.id === a.id);
      return o;
    });
    const ok = r.youngSell && r.youngBub && r.youngModal && r.order0 === 'stock,spot,cask' && r.top && r.amt && r.best && r.order1 === 'ord,stock,spot,cask' && r.mark && r.ordBot && r.delivered;
    rec(134, '売り方：3年未満は売れない（吹き出しは「3年で売れます」、小窓のボタンは押せない）・注文がなければ「瓶詰めして在庫へ」が先頭・金額は計算と一致（銘柄は単価が一番高いもの）・使える注文があれば「注文に使う」が先頭で🧾の印・押すと瓶詰めして自動で納品', ok, JSON.stringify(r));
    if (errors.length) rec('E84', '売り方テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #135 「在庫へ」は瓶が在庫に入り、「瓶で売る」は詰め終わった分が直販される（自動直販の設定に関係なく）・放置中に詰め終わっても同じ ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      G.orders = []; G.bq = []; G.auto.spot.on = false; G.cash = 1e15; G.stats.freeBtl = 1;
      const L = G.lots.filter(x => x.age >= 5 && !x.name).sort((a, b) => b.age - a.age); const a = L[0], b = L[1];
      const pa = lotBotPlan(a), pb = lotBotPlan(b);
      const inv0 = G.bottles.reduce((s, x) => s + x.n, 0);
      lotRoute(a.id, 'stock'); const qa = G.bq[G.bq.length - 1]; const sa = qa && qa.sell === 0 && !G.lots.includes(a);
      botTick(36e5 * 100); const inv1 = G.bottles.reduce((s, x) => s + x.n, 0);
      const o = { sa, stock: inv1 - inv0 === pa.n };
      // 瓶で売る（自動直販 OFF のまま）
      const te0 = G.te; lotRoute(b.id, 'spot'); const qb = G.bq[G.bq.length - 1]; o.sb = qb && qb.sell === 1;
      const unit = priceUnit(qb.pid, qb.age, Math.round(qb.q / BALANCE.INV_Q_STEP) * BALANCE.INV_Q_STEP, qb.fl);
      botTick(36e5 * 100); const inv2 = G.bottles.reduce((s, x) => s + x.n, 0);
      o.spot = inv2 === inv1 && Math.abs((G.te - te0) - unit * BALANCE.SPOT_MULT * pb.n) / (unit * BALANCE.SPOT_MULT * pb.n) < 1e-6;
      // 放置中：瓶で売る → 閉じている間に詰め終わる
      const c = G.lots.filter(x => x.age >= 4 && !x.name)[0]; const pc = lotBotPlan(c); const te1 = G.te; lotRoute(c.id, 'spot');
      G.ls = Date.now() - 24 * 36e5; offline(); if (_offlineGate) closeOfflineModal();
      const inv3 = G.bottles.reduce((s, x) => s + x.n, 0); o.off = inv3 === inv2 && G.bq.length === 0 && G.te - te1 > 0;
      o.n = [pa.n, pb.n, pc.n];
      return o;
    });
    const ok = r.sa && r.stock && r.sb && r.spot && r.off;
    rec(135, '「瓶詰めして在庫へ」は樽1つを丸ごと詰めて在庫に入る・「瓶詰めして瓶で売る」は詰め終わった分を直販（自動直販OFFでも・在庫は増えない）・放置中に詰め終わっても同じ', ok, JSON.stringify(r));
    if (errors.length) rec('E85', '在庫へ・瓶で売るテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #136 確認は名前付き・次のTierの条件に要る・受けた予約注文に使える樽だけ ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      G.orders = []; G.cash = 1e15; const o = {};
      const L = G.lots.filter(x => x.age >= 3).sort((a, b) => a.age - b.age);
      const plain = L.find(l => !l.name && !lotSellWarn(l)); const named = L.find(l => !!l.name) || (() => { const l = L.find(x => x !== plain); l.name = 'テスト'; return l; })();
      const conf = () => document.getElementById('confirmDlg').classList.contains('on') && document.getElementById('confirmMsg').textContent.includes('この樽はなくなります');
      lotRouteAsk(plain.id, 'cask'); o.plain = !conf() && !G.lots.includes(plain); hideConfirm();
      lotRouteAsk(named.id, 'cask'); o.named = conf() && G.lots.includes(named); hideConfirm();
      // 次の Tier の条件に要る樽
      const req = DL_REQ[G.dl]; o.tierWarn = req ? (() => { const keep = G.lots.slice(); const x = G.lots.find(y => !y.name && y.age >= 3); const a0 = x.age; x.age = Math.max(a0, req.casks.age + 0.5); G.lots = [x]; const t = lotSellWarn(x); x.age = a0; G.lots = keep; return t.includes('Tier'); })() : true;
      // 受けた予約注文に使える樽
      const l = G.lots.filter(x => x.age >= 8 && !x.name && lotProducts(x).length)[0]; const pid = lotProducts(l)[0];
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pid; a.minAge = 3; a.qty = 5; a.rq = 5; a.reserve = true; a.accepted = true; a.dueAt = Date.now() + 36e5 * 30; G.orders.push(a); G.bottles = G.bottles.filter(b => b.pid !== pid);
      o.resWarn = lotSellWarn(l).includes('予約') && lotSellWarn(l, a.id) === '';
      return o;
    });
    const ok = r.plain && r.named && r.tierWarn && r.resWarn;
    rec(136, '確認は名前付き・次のTierの条件に要る・受けた予約注文に使える樽のときだけ（その注文に使うときは出さない）。ふつうの樽は1タップで売れる', ok, JSON.stringify(r));
    if (errors.length) rec('E86', '確認テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #137 注文→倉庫：「倉庫の樽で詰められる n樽」から寝かせるへ移り、その樽だけが光る・帯の「やめる」とEscで戻る／倉庫→売る：売れる樽の一覧・売るへの帯 ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      const o = {}; const l = G.lots.filter(x => x.age >= 8 && lotProducts(x).length).sort((a, b) => b.age - a.age)[0]; const pid = lotProducts(l)[0];
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pid; a.minAge = 8; a.qty = 20; a.rq = 20; a.reserve = false; a.dueAt = Date.now() + 36e5 * 30; G.orders = [a]; G.bottles = G.bottles.filter(b => b.pid !== pid);
      _ui.sellTab = 'ord'; switchTab('tsale'); rall(); await new Promise(r => setTimeout(r, 100));
      const chip = document.querySelector(`#orderBoard [data-act="ordLots"][data-id="${a.id}"]`); const exp = G.lots.filter(x => lotServes(x, a)).map(x => x.id).sort().join();
      o.chip = !!chip && chip.textContent.includes(ordLotCount(a) + '樽') && ordLotCount(a) > 0;
      chip.click(); await new Promise(r => setTimeout(r, 120));
      o.tab = document.querySelector('.tab.on').id; o.lit = [...document.querySelectorAll('#wScene .wcask.whl')].map(e => e.dataset.id).sort().join() === exp; o.bar = !!document.getElementById('hlBar');
      const lc = document.querySelector('#wScene .wcask.whl'); caskKnock(lc.dataset.id, lc); const first = document.querySelector('#wBub [data-act="lotRoute"]'); o.first = first && first.dataset.r === 'ord' && first.dataset.oid === a.id; bubClose();
      document.querySelector('#hlBar [data-act="hlEnd"]').click(); await new Promise(r => setTimeout(r, 50)); o.end = !_hl && !document.getElementById('hlBar') && !document.querySelector('#wScene .wcask.whl');
      hlStart(a.id); document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); o.esc = !_hl;
      // 倉庫→売る
      rCellar(); await new Promise(r => setTimeout(r, 50));
      const sb = document.querySelector('#whSummary [data-act="sellList"]'); const n3 = G.lots.filter(x => x.age >= 3).length; o.sellBtn = !!sb && sb.textContent.includes('売れる樽 ' + n3);
      sb.click(); await new Promise(r => setTimeout(r, 50)); const rows = [...document.querySelectorAll('#mc2 [data-act="sellPick"]')];
      const vals = rows.map(e => G.lots.find(x => x.id === e.dataset.id)).map(x => lotValue(x)); o.sorted = rows.length === Math.min(40, n3) && vals.every((v, i) => i === 0 || vals[i - 1] >= v);
      rows[0].click(); await new Promise(r => setTimeout(r, 150)); o.pick = !document.getElementById('wBub').classList.contains('h') && document.getElementById('mo').classList.contains('h');
      bubClose(); const fl = document.querySelector('#whSummary .sflow'); o.flow = !!fl && fl.textContent.includes('売る'); fl.click(); await new Promise(r => setTimeout(r, 50)); o.flowGo = document.querySelector('.tab.on').id === 'tsale';
      return o;
    });
    const ok = r.chip && r.tab === 'tcel' && r.lit && r.bar && r.first && r.end && r.esc && r.sellBtn && r.sorted && r.pick && r.flow && r.flowGo;
    rec(137, '注文の「倉庫の樽で詰められる n樽」→寝かせるへ移り、その樽だけが光る（吹き出しの先頭はその注文）・「やめる」とEscで戻る／倉庫の「売れる樽 n（3年以上）」は金額の高い順で、押すと棚の樽・棚の下の帯から売るへ', ok, JSON.stringify(r));
    if (errors.length) rec('E87', '注文と倉庫テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #138 v5.0（schema14）からの移行：砂時計の記録・大麦の等級・所持数はそのまま・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const old = JSON.parse(JSON.stringify(G)); old.ver = 14; old.hg = { n: 4, got: 9, used: 5, day: dayKey(), useDay: 2, src: { login: 1, daily: 0, ms: 1, care: 0 } }; delete old.barley.grade; old.bq.forEach(q => delete q.sell);
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, n: m.hg.n, src: JSON.stringify(m.hg.src), ordN: m.hg.ordN, streak: JSON.stringify(m.hg.streak), month: m.hg.month === monthKey(), grade: m.barley.grade, bq: m.bq.every(q => q.sell === 0) };
      const key = storageKey(); const bk = 'we_v4_bak14:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.ver === SCHEMA && r.n === 4 && r.src === '{"login":1,"daily":0,"ms":1,"ord":0,"tap":0}' && r.ordN === 0 && r.streak === '{"d":"","n":0}' && r.month && r.grade === 'std' && r.bq && r.bk && r.loaded === SCHEMA;
    rec(138, 'v5.0（schema14）からの移行：砂時計の所持数はそのまま・入手の記録（納品・連続ログイン・月）を用意・大麦の等級は標準・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E88', '移行（v15）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #139 「まとめて使う」6個と、1個ずつ6回は同じ結果（熟成・残量・タンク・瓶詰め） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      G.orders = []; G.ordersPaused = true; G.orderClock = Date.now() + 1e12; G.auto.spot.on = false; G.cash = 1e15;
      const snap = JSON.stringify(G); const pick = () => ({ ages: G.lots.map(l => +l.age.toFixed(6)).join(), L: G.lots.reduce((a, l) => a + l.L, 0), tank: G.tank, btl: G.stats.bottled, lots: G.lots.length });
      G.hg.n = 20; G.hg.useDay = 0; G.ls = Date.now(); hgUse(6); if (_offlineGate) closeOfflineModal(); const a = pick();
      G = JSON.parse(snap); G.hg.n = 20; G.hg.useDay = 0; for (let i = 0; i < 6; i++) { G.ls = Date.now(); hgUse(1); if (_offlineGate) closeOfflineModal(); } const b = pick();
      return { a, b };
    });
    const da = r.a.ages.split(',').map(Number), db = r.b.ages.split(',').map(Number);
    const ok = da.length === db.length && da.every((v, i) => Math.abs(v - db[i]) < 1e-4) && Math.abs(r.a.L - r.b.L) / r.a.L < 1e-6 && r.a.lots === r.b.lots && Math.abs(r.a.tank - r.b.tank) <= Math.max(1, r.a.tank * 0.01) && Math.abs(r.a.btl - r.b.btl) <= 1;
    rec(139, '砂時計の「まとめて使う」6個と1個ずつ6回で、熟成の年数・残量・樽の数・タンク・瓶詰めの本数が同じ', ok, JSON.stringify(r));
    if (errors.length) rec('E89', 'まとめて使うテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.1 第3回 追加テスト =================
  // ---------- #140 原材料：Tier1 は v5.0 と同じ価格・Tier2 は半分・Tier3 以降は売値の倍率×K に合わせて動く ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const K = V51.RAW.K; const dl0 = G.dl; const reg0 = JSON.stringify(G.regions); const o = {};
      const old = () => ({ b: STAGES[0].price * BARLEY.RATIO * distMult() * barleyGrainMult() * mktFx('barley') * barleyGrade().p, c: Math.round(caskType('bourbon').costPerL * caskSize('hogshead').litres * (1 - 0.2 * psk('ps_cask_cost')) * getEventMult('caskCost')), t: V45.BTL_UNIT * distMult() });
      G.dl = 1; let e = old(); o.t1 = [Math.abs(barleyPrice() / e.b - 1) < 1e-9, caskCost('bourbon', 'hogshead') === e.c, Math.abs(btlUnit() / e.t - 1) < 1e-9];
      G.dl = 2; e = old(); const s2 = priceMultBase() / distMult(); o.t2 = [Math.abs(barleyPrice() / e.b - Math.sqrt(s2 * K.barley)) < 1e-6, Math.abs(btlUnit() / e.t - Math.sqrt(s2 * K.bottle)) < 1e-6];
      G.dl = 3; e = old(); const s3 = priceMultBase() / distMult(); o.t3 = [Math.abs(barleyPrice() / e.b - s3 * K.barley) < 1e-6, Math.abs(btlUnit() / e.t - s3 * K.bottle) < 1e-6, Math.abs(caskCost('bourbon', 'hogshead') / (e.c * priceMultBase() * K.cask) - 1) < 1e-3];
      // 販売地域を加えて売値の倍率が上がると、原材料も同じ割合で上がる
      const b0 = barleyPrice(), m0 = priceMultBase(); const id = Object.keys(REGIONS).find(k => !G.regions[k]); if (id) G.regions[id] = true; o.reg = !id || Math.abs(barleyPrice() / b0 - priceMultBase() / m0) < 1e-6;
      G.regions = JSON.parse(reg0); G.dl = dl0;
      o.k = [K.barley, K.cask, K.bottle];
      return o;
    });
    const ok = r.t1.every(Boolean) && r.t2.every(Boolean) && r.t3.every(Boolean) && r.reg;
    rec(140, '原材料：Tier1 は v5.0 と同じ価格（大麦・空き樽・瓶の資材）・Tier2 は売値の倍率×K の平方根・Tier3 以降は売値の倍率×K・販売地域で売値の倍率が上がると原材料も同じ割合で上がる', ok, JSON.stringify(r));
    if (errors.length) rec('E90', '原材料テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #141 大麦の等級（価格と詰める樽の品質）・今月の相場の表示・資金不足の警告・決算書の「うち原材料費」 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; G.barley.grade = 'std'; const p0 = barleyPrice(), q0 = newmakeQuality();
      openBarleyModal(); o.seg = document.querySelectorAll('#mc2 [data-act="barleyGrade"]').length === 0; G.barley.grade = 'best'; prodInvalidate();
      o.best = [barleyGrade() === V51.GRADE.std, +(barleyPrice() / p0).toFixed(6), +(q0 / newmakeQuality()).toFixed(6)];
      const lot = makeLot(caskType('bourbon'), caskSize('hogshead')); o.lotQ = Math.abs(lot.q - newmakeQuality()) < 1e-9; closeM(); G.barley.grade = 'std';
      // 相場：今月の市場が大麦を上げるとき「今月高い」
      const f0 = mktFx; mktFx = k => k === 'barley' ? 1.2 : f0(k); switchTab('tb'); rMake(); o.mkt = document.getElementById('barleyBox').textContent.includes('今月高い ×1.2'); mktFx = f0; prodInvalidate();
      // 警告：自動仕入れ ON・所持金が大麦1時間分未満・残り2時間未満
      const cash0 = G.cash, kg0 = barleyState().kg; G.cash = barleyCostPh() * 0.5; barleyState().kg = barleyUsePh() * 1; o.warn = actionList().some(x => x.title.includes('所持金が大麦1時間分を下回っています')); G.cash = cash0; barleyState().kg = kg0;
      // 決算書：うち原材料費（売上比）
      const p = acctLive(); p.pur.barley = (p.pur.barley || 0); const raw = sumO(p.pur); const html = finRows(p, 'pl');
      o.pl = raw > 0 && html.includes('うち原材料費') && (p.R > 0.5 ? html.includes((raw / p.R * 100).toFixed(1) + '%') : true);
      return o;
    });
    const ok = r.seg && r.best[0] === true && r.best[1] === 1 && r.best[2] === 1 && r.lotQ && r.mkt && r.warn && r.pl;
    rec(141, '大麦の等級は v5.4 で廃止（ボタンがなく、保存に最上があっても標準の価格と品質）・今月の相場を大麦の行に表示・所持金が大麦1時間分を下回ると警告・決算書に「うち原材料費（売上の◯%）」', ok, JSON.stringify(r));
    if (errors.length) rec('E91', '等級・相場テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #142 樽の価値：一番高い銘柄の直販額の55%で樽ごと売れる・樽の注文は v5.0 までの式×倍率と樽ごと売る額の高い方 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const l = G.lots.filter(x => x.age >= 8 && lotProducts(x).length && !x.name).sort((a, b) => b.age - a.age)[0];
      const n = l.L / BALANCE.BOTTLE_L; const best = Math.max(...lotProducts(l).map(p => priceUnit(p, Math.floor(l.age), l.q, lotFlavor(l))));
      const exp = best * BALANCE.SPOT_MULT * n * V51.CASK_RATE; o.sale = lotValue(l) * BALANCE.CASK_SPOT_MULT; o.exp = exp; o.rate = +(o.sale / exp).toFixed(6);
      const te0 = G.te; sellLot(l.id); o.paid = +((G.te - te0) / exp).toFixed(6);
      const l2 = G.lots.filter(x => !x.name && lotProducts(x).length).sort((a, b) => b.age - a.age)[0]; l2.age = Math.max(l2.age, 13); const ord = { id: 'o_t', cid: 'society', kind: 'cask', minAge: 12, qty: 1, rq: 1, mult: 2, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 36e5 };
      G.orders = [ord]; const m = ordMatch(ord, l2.id); o.ord = Math.abs(m.cash / Math.max(lotValueOld(l2) * 2, lotValue(l2) * BALANCE.CASK_SPOT_MULT) - 1) < 1e-9 && m.cash >= lotValue(l2) * BALANCE.CASK_SPOT_MULT - 1e-6;
      return o;
    });
    const ok = Math.abs(r.rate - 1) < 1e-6 && Math.abs(r.paid - 1) < 1e-6 && r.ord;
    rec(142, '樽の価値：樽ごと売ると、その樽で詰められる一番高い銘柄を直販した額の55%・樽の注文の報酬は v5.0 までの式×倍率と樽ごと売る額の高い方', ok, JSON.stringify(r));
    if (errors.length) rec('E92', '樽の価値テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.2 第1回 追加テスト =================
  // ---------- #143 樽の小人：300回ごとに抽選・外れ3回で次は必ず・1日6個・日付で戻る・99個のときは受け取らない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); switchTab('td');
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off; const rr = Math.random; let rv = 0.99; Math.random = () => rv;
      const o = {}; G.hg = { n: 0, got: 0, used: 0 }; hgDay(); G.tapHg = { n: 0, miss: 0 };
      for (let i = 0; i < 299; i++) tap(); o.before = [G.tapHg.n, G.hg.n, tapHgLeft()];
      tap(); o.miss1 = [G.tapHg.n, G.tapHg.miss, G.hg.n, !!document.getElementById('dwarf')];
      for (let i = 0; i < 600; i++) tap(); o.miss3 = [G.tapHg.miss, G.hg.n];
      for (let i = 0; i < 300; i++) tap(); o.pity = [G.tapHg.miss, G.hg.n, G.hg.src.tap, document.querySelector('#dwarf .dwb') ? document.querySelector('#dwarf .dwb').textContent : ''];
      rv = 0; for (let i = 0; i < 300 * 6; i++) tap(); o.cap = [G.hg.n, G.hg.src.tap, document.getElementById('tgTxt').textContent.includes('また明日')];
      const n6 = G.hg.n; for (let i = 0; i < 600; i++) tap(); o.capped = G.hg.n === n6;
      off = 24 * 3600000; G.ls = Date.now(); hgDay(); o.day = [G.hg.src.tap, tapHgCapped()];
      G.hg.n = V47.HG_MAX; G.tapHg.n = 299; tap(); o.full = [G.hg.n, G.hg.src.tap];
      Math.random = rr; Date.now = rn;
      o.k = [V52.TAP_N, V52.TAP_P, V52.TAP_PITY, V51.HG.tap.cap];
      return o;
    });
    const ok = r.before.join() === '299,0,1' && r.miss1[0] === 0 && r.miss1[1] === 1 && r.miss1[2] === 0 && r.miss1[3] && r.miss3.join() === '3,0' && r.pity[0] === 0 && r.pity[1] === 1 && r.pity[2] === 1 && r.pity[3].includes('砂時計') && r.cap.join() === '6,6,true' && r.capped && r.day.join() === '0,false' && r.full.join() === '99,0';
    rec(143, '樽の小人：300回ごとに抽選（30%）・外れが3回続いたら次は必ず・1日6個で止まり「また明日」・日付が替わると戻る・砂時計99個のときは受け取らない', ok, JSON.stringify(r));
    if (errors.length) rec('E93', '小人テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #144 受注した予約注文の取り消し：評判・関係は期限切れと同じ・違約金は見込みの10%・枠が空く・瓶詰め中の瓶は在庫へ・所持金不足では取り消せない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const pid = G.uw[0];
      const mk = acc => { const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pid; a.minAge = 3; a.qty = 40; a.rq = 40; a.reserve = true; a.accepted = acc; a.dueAt = Date.now() + 36e5 * 40; G.orders.push(a); return a; };
      const a = mk(true); const b = mk(false);
      o.noAcc = ordCancel(b.id) === false;
      openOrderInfoModal(a.id); const btn = document.querySelector('#mc2 [data-act="ordCancel"]'); o.btn = !!btn; btn.click(); await new Promise(r => setTimeout(r, 30));
      o.conf = document.getElementById('confirmDlg').classList.contains('on') && document.getElementById('confirmMsg').textContent.includes('違約金'); hideConfirm(); closeM();
      const k = ordCancelCost(a); o.k = k; o.feeOk = Math.abs(k.fee - Math.round(ordEstAny(a) * 0.1)) < 1 && Math.abs(k.rep - ordRep(a) * 0.5) < 1e-9;
      G.bq.push({ id: 'q_t', pid, n: 10, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: a.id, c: 0 });
      const cash0 = G.cash, rep0 = G.reputation, rel0 = (G.rel.local || { done: 0 }).done, can0 = G.stats.cancel || 0, oth0 = acctLive().sga.oth || 0;
      G.cash = k.fee - 1; o.poor = ordCancel(a.id) === false && G.orders.includes(a); G.cash = cash0;
      o.done = ordCancel(a.id) && !G.orders.includes(a);
      o.d = { cash: +(cash0 - G.cash).toFixed(2), rep: +(rep0 - G.reputation).toFixed(3), rel: rel0 - G.rel.local.done, cancel: G.stats.cancel - can0, oth: +((acctLive().sga.oth || 0) - oth0).toFixed(2) };
      o.bq = G.bq.find(q => q.id === 'q_t').oid === null;
      return o;
    });
    const ok = r.noAcc && r.btn && r.conf && r.feeOk && r.k.rel === 3 && r.poor && r.done && Math.abs(r.d.cash - r.k.fee) < 1 && r.d.rep > 0 && r.d.rel === 3 && r.d.cancel === 1 && Math.abs(r.d.oth - r.k.fee) < 1 && r.bq;
    rec(144, '受注した予約注文の取り消し：評判（期限切れと同じ）・関係−3・違約金は報酬の見込みの10%（販管費のその他）・注文は消えて枠が空く・瓶詰め中の分は在庫へ・所持金不足では取り消せない・受注前は対象外', ok, JSON.stringify(r));
    if (errors.length) rec('E94', '取り消しテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #145 BGM：クラシック5曲のデータ・順に演奏・同時に鳴る音は16まで・環境音楽となしに切り替わる ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      o.pieces = BGM_PIECES.map((p, i) => { const n = bgmLoad(i); const bad = n.filter(x => !(x[0] >= 0 && x[1] > 0 && x[2] >= 24 && x[2] <= 100 && x[3] > 0 && x[3] <= 1)).length; const sorted = n.every((x, j) => j === 0 || n[j - 1][0] <= x[0]); return { id: p.id, n: n.length, bad, sorted, end: Math.round(Math.max(...n.map(x => x[0] + x[1]))) }; });
      o.def = OPT_DEFAULT.bgmMode;
      const ctxA = _getCtx(); o.audio = !!ctxA;
      opt().bgm = 0.4; opt().bgmMode = 'classic'; applyOpt(); await new Promise(r => setTimeout(r, 900));
      o.classic = [_bgm.mode, !!_bgmc.timer, _bgmc.ptr > 0];
      // 曲の終わりまで進めると次の曲へ
      const i0 = _bgmc.i; _bgmc.ptr = _bgmc.notes.length; _bgmc.t0 = (ctxA ? ctxA.currentTime : 0) - 1e4; bgmClassicTick(); o.next = _bgmc.i === (i0 + 1) % BGM_PIECES.length && _bgmc.ptr === 0;
      let maxV = 0; for (let k = 0; k < 10; k++) { _bgmc.t0 -= 0.5; bgmClassicTick(); _bgmc.voices.forEach(v => { maxV = Math.max(maxV, bgmOn(v[0])); }); } o.poly = maxV;
      opt().bgmMode = 'ambient'; applyOpt(); o.ambient = [_bgm.mode, !!_bgm.timer, !_bgmc.timer];
      opt().bgmMode = 'off'; applyOpt(); o.off = !_bgm.timer && !_bgmc.timer && !_bgm.master;
      opt().bgmMode = 'classic'; applyOpt(); switchTab('tp'); rall(); await new Promise(r => setTimeout(r, 50));
      o.ui = !!document.querySelector('[data-act="optSet"][data-k="bgmMode"][data-v="classic"]');
      bgmStop(); return o;
    });
    const ok = r.pieces.length === 6 && r.pieces.every(p => p.n > 100 && p.bad === 0 && p.sorted && p.end > 25) && r.def === 'classic' && (!r.audio || (r.classic.join() === 'classic,true,true' && r.next && r.poly <= 16 && r.ambient.join() === 'ambient,true,true' && r.off)) && r.ui;
    rec(145, 'BGM：クラシック6曲（バッハ・パッヘルベル・ベートーヴェン2曲・サティ・ラヴェル）のデータが正しい・初期値はクラシック・順に演奏し曲が終わると次へ・同時に鳴る音は16まで・⚙️で環境音楽となしに切り替わる', ok, JSON.stringify(r));
    if (errors.length) rec('E95', 'BGMテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #146 v5.1（schema15）からの移行：小人の記録・取り消しの件数・BGM はクラシック・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const old = JSON.parse(JSON.stringify(G)); old.ver = 15; delete old.tapHg; delete old.stats.cancel; old.opt.bgmMode = undefined; delete old.hg.src.tap;
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, tap: JSON.stringify(m.tapHg), cancel: m.stats.cancel, bgm: m.opt.bgmMode, src: m.hg.src.tap };
      const key = storageKey(); const bk = 'we_v4_bak15:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.ver === SCHEMA && r.tap === '{"n":0,"miss":0}' && r.cancel === 0 && r.bgm === 'classic' && r.src === 0 && r.bk && r.loaded === SCHEMA;
    rec(146, 'v5.1（schema15）からの移行：小人の記録・予約の取り消しの件数を用意・BGM はクラシック・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E96', '移行（v16）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.2 第2回 追加テスト =================
  // ---------- #147 手触り：Lvアップ・ボトルネック解消・樽詰め・瓶詰め・売却・納品の動きと「+金額」「+%」・自動はまとめる・同時に6つまで・放置と砂時計では出さない・動きを減らす設定 ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      const W = ms => new Promise(r => setTimeout(r, ms)); const ft = () => [...document.querySelectorAll('.fxf')].map(e => e.textContent);
      const clear = async () => { await W(800); };
      G.cash = 1e18; Object.keys(FAC_BRANCH).forEach(k => { if (G.branch[k] === null || G.branch[k] === undefined) G.branch[k] = 0; }); const o = {};
      // Lv アップ（いちばん遅い工程を上げてボトルネックを動かす）
      switchTab('tb'); rall(); await W(50);
      const f0 = prodFlows(); const bnFac = STAGES[f0.bottleneck].fac; let tries = 0; while (prodFlows().bottleneck === f0.bottleneck && tries++ < 60) { upgFac(bnFac); closeM(); }
      await W(120); o.upg = ft().some(t => /^\+\d+%$/.test(t)) && !!document.querySelector('#lineView .fxgl'); o.bn = ft().some(t => t.startsWith('新酒 +')) && !!document.querySelector('#lineView .pflow.fxfast'); await clear();
      // 樽詰め：寝かせるを開いているときは棚の樽が落ちる
      switchTab('tcel'); G.tank = 1e7; G.auto.fill.on = false; rall(); await W(50); fillCask('bourbon', 'hogshead', false); rall(); await W(150);
      const nl = G.lots[G.lots.length - 1]; o.drop = !!document.querySelector(`#wScene .wcask.fxdrop[data-id="${nl.id}"]`); await clear();
      // 自動の樽詰め（ホームを開いている）→ 1.5秒後に寝かせるのタブに「+3樽」が1回
      switchTab('td'); for (let i = 0; i < 3; i++) fillCask('bourbon', 'hogshead', true); await W(V52.FX_COALESCE + 100); o.pill = ft().filter(t => t === '+3樽').length === 1; await clear();
      // 瓶詰めの完了（ホーム）→ 売るに「+n本」
      G.bq = [{ id: 'q1', pid: G.uw[0], n: 7, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: null, c: 0 }, { id: 'q2', pid: G.uw[0], n: 5, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: null, c: 0 }];
      botTick(36e5 * 10); await W(V52.FX_COALESCE + 100); o.btl = ft().includes('+12本'); await clear();
      // 売却（手動）：硬貨と「+金額」／自動の直販はまとめて1回
      switchTab('tsale'); rall(); await W(50); const row = G.bottles[0]; spotSell(row.id, 1); await W(80); o.coins = document.querySelectorAll('.fxcoin').length > 0 && ft().some(t => t.startsWith('+$')); await clear();
      const v1 = spotSell(G.bottles[0].id, 1, true), v2 = spotSell(G.bottles[0].id, 1, true); await W(V52.FX_COALESCE + 100); o.autoSale = ft().filter(t => t === '+' + fmt(v1 + v2)).length === 1; await clear();
      // 納品：「納品済」の印と「評判 +n」
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = G.bottles[0].pid; a.minAge = 0; a.qty = 1; a.rq = 1; a.reserve = false; a.dueAt = Date.now() + 1e8; G.orders.unshift(a); _ui.sellTab = 'ord'; rall(); await W(80);
      const card = !!document.querySelector(`#orderBoard .oc2[data-id="${a.id}"]`); ordDeliver(a.id); await W(60); o.stamp = card && !!document.querySelector('.fxstamp') && ft().some(t => t.startsWith('評判 +')); await clear();
      // 同時に6つまで
      for (let i = 0; i < 20; i++) fxFloat('x' + i, 100, 300); o.max = document.querySelectorAll('.fxf').length; await clear();
      // 砂時計で進めた分（瓶詰め・直販）は出さない
      G.bq = [{ id: 'q3', pid: G.uw[0], n: 9, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: null, c: 0 }]; G.hg.n = 5; G.hg.useDay = 0; G.ls = Date.now(); hgUse(1); if (_offlineGate) closeOfflineModal(); await W(V52.FX_COALESCE + 100); o.hgQuiet = document.querySelectorAll('.fxf,.fxcoin,.fxstamp').length === 0; await clear();
      // 動きを減らす：硬貨・印・落下なし。数字は出る（透明度だけで消える）
      opt().motion = 'low'; applyOpt(); spotSell(G.bottles[0].id, 1); await W(60); o.low = document.querySelectorAll('.fxcoin').length === 0 && ft().some(t => t.startsWith('+$')) && getComputedStyle(document.querySelector('.fxf')).animationName === 'fxFade'; opt().motion = 'std'; applyOpt();
      await clear(); o.left = _fxN;
      return o;
    });
    const ok = r.upg && r.bn && r.drop && r.pill && r.btl && r.coins && r.autoSale && r.stamp && r.max <= 6 && r.hgQuiet && r.low && r.left === 0;
    rec(147, '手触り：Lvアップで「+%」と行の光・ボトルネック解消で「新酒 +%」と流れの加速・樽詰めで棚の樽が落ちる・自動の樽詰め／瓶詰め／直販は1.5秒にまとめて1回・手動の売却で硬貨と「+金額」・納品で「納品済」と「評判 +」・同時に6つまで・砂時計の分は出さない・動きを減らす設定では動きなし', ok, JSON.stringify(r));
    if (errors.length) rec('E97', '手触りテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.3 追加テスト =================
  // ---------- #148 ハウスモルト：3年以上のどの樽も瓶詰めできる・25銘柄に詰められる樽では銘柄が先・注文・図鑑・品評会の対象外・保存して読み直しても残る ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const mk = (cask, age) => { const l = { id: uid('l'), cask, size: 'barrel', L0: 200, L: 200, age, fl0: { ...BASE_FLAVOR }, q: 1, at: Date.now() }; G.lots.push(l); return l; };
      G.uw = ['glenlivid', 'jameston', 'jack_d']; G.bq = []; G.orders = []; G.cash = 1e9;
      const sp = productSpec('house'); o.spec = [sp.name, sp.minAge, sp.casks, sp.house, Math.abs(sp.base - 100 * V53.HOUSE_RATE) < 1e-9];
      o.fm = Math.abs(priceUnit('house', 5, 1, { smoky: 99, fruity: 0, spicy: 0, sweet: 0, floral: 0 }) - priceUnit('house', 5, 1, BASE_FLAVOR)) < 1e-9;
      const L = { b39: mk('bourbon', 3.9), s5: mk('sherry', 5), b2: mk('bourbon', 2), b85: mk('bourbon', 8.5), s85: mk('sherry', 8.5) };
      o.plan = Object.fromEntries(Object.entries(L).map(([k, l]) => { const p = lotBotPlan(l); return [k, p ? p.pid : null]; }));
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 60));
      o.bub = {}; let none = 0;
      for (const [k, l] of Object.entries(L)) { const c = document.querySelector(`#wScene .wcask[data-id="${l.id}"]`); caskKnock(l.id, c); const h = $('wBub').innerHTML; if (/詰められる銘柄がありません/.test(h)) none++; o.bub[k] = [/data-r="stock"/.test(h), /ハウスモルト/.test(h), /class="wnx/.test(h)]; }
      o.none = none;
      // 瓶詰め → 在庫 → 直販（図鑑・販売数に数えない）
      const cw0 = JSON.stringify(G.cw), sl0 = Object.keys(G.shipLog || {}).length, sh0 = G.stats.shipped;
      o.route = lotRoute(L.s5.id, 'stock'); const q = G.bq.find(x => x.pid === 'house'); o.bq = !!q;
      for (let i = 0; i < 500 && G.bq.length; i++) botTick(3600000);
      const row = G.bottles.find(x => x.pid === 'house'); o.row = row ? row.n : 0;
      spotSell(row.id, 10, true); o.ship = [JSON.stringify(G.cw) === cw0, Object.keys(G.shipLog || {}).length === sl0, G.stats.shipped - sh0];
      // 品評会・注文
      row.n = Math.max(row.n, 20); openCompModal(COMPETITIONS[0].id); o.comp = !document.querySelector(`#mc2 [data-act="compGo"][data-row="${row.id}"]`); closeM();
      G.reputation = 9999; o.enter = enterComp(COMPETITIONS[0].id, row.id) === null;
      let hp = 0; for (let i = 0; i < 300; i++) { const a = ordGenerate(); if (a && (a.pid === 'house' || a.tp === 'ハウス')) hp++; } o.ord = hp;
      // 瓶詰めの小窓：ハウスモルトは最後・説明
      openBottleModal(null); const opts = [...document.querySelectorAll('#mc2 [data-in="botPid"] option')].map(x => x.value); o.botOpts = opts[opts.length - 1] === 'house';
      _ui.bot.pid = 'house'; renderBottleModal(true); o.botNote = /注文・品評会には使えません/.test($('mc2').textContent); closeM();
      // 保存して読み直す
      const st = sanitize(JSON.parse(JSON.stringify(G))); o.load = [st.bottles.some(x => x.pid === 'house'), !('house' in st.cw), !('house' in st.shipLog)];
      return o;
    });
    const ok = r.spec.join() === 'ハウスモルト,3,,true,true' && r.fm && r.plan.b39 === 'house' && r.plan.s5 === 'house' && r.plan.b2 === null && r.plan.b85 === 'jack_d' && r.plan.s85 === 'jameston'
      && r.none === 0 && r.bub.b39.join() === 'true,true,true' && r.bub.s5.join() === 'true,true,true' && r.bub.b2.join() === 'false,false,true' && r.bub.b85.join() === 'true,false,false'
      && r.route && r.bq && r.row > 200 && r.ship.join() === 'true,true,10' && r.comp && r.enter && r.ord === 0 && r.botOpts && r.botNote && r.load.join() === 'true,true,true';
    rec(148, 'ハウスモルト：3年以上のどの樽も瓶詰めできる（風味は問わない・単価は Glen Corran の8割）・25銘柄に詰められる樽では銘柄を選ぶ・「詰められる銘柄がありません」が出ない・図鑑と販売数に数えない・品評会と注文の対象外・瓶詰めの小窓では最後・保存して読み直しても残る', ok, JSON.stringify(r));
    if (errors.length) rec('E98', 'ハウスモルトのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #149 次の銘柄：年数・樽の種類・解禁の理由と時間・「n年で知らせる」で節目がその年数になる・樽の小窓にも出る ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const mk = (cask, age) => { const l = { id: uid('l'), cask, size: 'barrel', L0: 200, L: 200, age, fl0: { ...BASE_FLAVOR }, q: 1, at: Date.now() }; G.lots.push(l); return l; };
      G.uw = ['glenlivid', 'jameston', 'jack_d'];
      const b39 = mk('bourbon', 3.9), s5 = mk('sherry', 5), b2 = mk('bourbon', 2), b85 = mk('bourbon', 8.5);
      const n1 = nextBrand(b39); o.b39 = [n1.kind, n1.pid, n1.yr, Math.abs(n1.eta - lotEtaAge(b39, 4)) < 1, !n1.cask];
      const n2 = nextBrand(s5); o.s5 = [n2.kind, n2.yr, n2.pid === 'glenlivid' || n2.pid === 'jameston', n2.cask ? n2.cask.pid : null];
      const n3 = nextBrand(b2); o.b2 = [n3.kind, n3.pid, n3.yr];
      o.b85 = nextBrandHtml(b85) === '';
      G.uw = ['jack_d']; const n4 = nextBrand(s5); o.lock = [n4.kind, n4.pid]; G.uw = ['glenlivid', 'jameston', 'jack_d'];
      // 吹き出し：理由と時間・3年未満も並べる
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 60));
      const knock = l => { caskKnock(l.id, document.querySelector(`#wScene .wcask[data-id="${l.id}"]`)); return $('wBub'); };
      let b = knock(s5); o.s5txt = [/次の銘柄/.test(b.textContent), /バーボン樽の原酒だけ/.test(b.textContent), /✓ 8年で知らせます/.test(b.textContent)];
      b = knock(b2); o.b2txt = [/3年で売れます/.test(b.textContent), /Hollow Creek/.test(b.textContent)];
      b = knock(b39); const btn = b.querySelector('[data-act="lotNotify"]'); o.btn = btn ? btn.dataset.v : null; btn.click(); await new Promise(r => setTimeout(r, 40));
      o.goal = b39.goal; o.on = /✓ 4年で知らせます/.test($('wBub').textContent);
      // 4年になると節目として届く
      lotAdvance(b39, lotEtaAge(b39, 4) + 60000); o.done = [b39.gd, b39.goal];
      // 樽の小窓
      openLotModal(s5.id); o.modal = [!!document.querySelector('#mc2 .wnx'), /ハウスモルトのみ/.test($('mc2').textContent)];
      openLotModal(b2.id); o.m2 = /ハウスモルトは3年から/.test($('mc2').textContent);
      document.querySelector('#mc2 [data-act="lotNotify"]').click(); await new Promise(r => setTimeout(r, 40)); o.mgoal = [b2.goal, !$('mo').classList.contains('h'), /✓ 4年で知らせます/.test($('mc2').textContent)];
      closeM(); return o;
    });
    const ok = r.b39.join() === 'age,jack_d,4,true,true' && r.s5[0] === 'age' && r.s5[1] === 8 && r.s5[2] && r.s5[3] === 'jack_d' && r.b2.join() === 'age,jack_d,4' && r.b85 && r.lock.join() === 'lock,glenlivid'
      && r.s5txt.join() === 'true,true,true' && r.b2txt.join() === 'true,true' && r.btn === '4' && r.goal === 4 && r.on && r.done[0] === 4 && r.modal.join() === 'true,true' && r.m2 && r.mgoal.join() === '4,true,true';
    rec(149, '次の銘柄：一番早く詰められる銘柄と、あと何時間か（3.9年のバーボン樽→Hollow Creek 4年）・バーボン樽以外は「バーボン樽の原酒だけ」と理由・解禁前の銘柄は条件・節目がすでにその年数なら「✓」・3年未満も並べる・「4年で知らせる」でその年数が次の節目になり、届くと知らせる・樽の小窓にも出る', ok, JSON.stringify(r));
    if (errors.length) rec('E99', '次の銘柄のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.4 追加テスト =================
  // ---------- #151 BGM：6曲をシャッフルして1回ずつ・周の境目で同じ曲が続かない・各曲60〜130秒・変奏が毎回変わる・同時に鳴る音は16まで・⚙️に曲名がない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      const rr = Math.random; let seed = 7; Math.random = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      _bgmc.bag = []; _bgmc.i = -1; const seq = []; for (let k = 0; k < 18; k++) { const i = bgmNext(); seq.push(i); _bgmc.i = i; }
      Math.random = rr;
      o.rounds = [0, 1, 2].map(k => new Set(seq.slice(k * 6, k * 6 + 6)).size); o.rep = seq.some((x, j) => j && seq[j - 1] === x); o.seq = seq.join('');
      const poly = N => { let mx = 0; N.forEach((n, j) => { let c = 0; for (let k = Math.max(0, j - 600); k < N.length && N[k][0] <= n[0]; k++) { const m = N[k]; if (m[0] + m[1] + BGM_TAIL[m[4]] > n[0]) c++; } if (c > mx) mx = c; }); return mx; };
      let s2 = 3; const rnd = () => { s2 = (s2 * 16807) % 2147483647; return s2 / 2147483647; };
      o.len = BGM_PIECES.map((p, i) => { let mn = 1e9, mx = 0, pm = 0, bad = 0; for (let k = 0; k < 6; k++) { const N = bgmBuild(i, rnd); const d = bgmDur(N); mn = Math.min(mn, d); mx = Math.max(mx, d); pm = Math.max(pm, poly(N)); bad += N.filter(n => !(n[0] >= 0 && n[1] > 0 && n[2] >= 24 && n[2] <= 108 && n[3] > 0 && n[3] <= 1)).length; } return [p.id, Math.round(mn), Math.round(mx), pm, bad]; });
      // 変奏の組み合わせ：乱数が違えば中身が違う
      o.vary = BGM_PIECES.map((p, i) => JSON.stringify(bgmBuild(i, () => 0.01)) !== JSON.stringify(bgmBuild(i, () => 0.99)));
      o.gap = V54.BGM_GAP;
      switchTab('tp'); rall(); await new Promise(r => setTimeout(r, 50));
      o.noName = !document.getElementById('bgmNow') && !document.getElementById('optBox').textContent.includes('♪') && typeof bgmNowTxt === 'undefined';
      o.tip = (TIPS.find(t => t.id === 'bgm') || {}).b || '';
      return o;
    });
    const ok = r.rounds.every(n => n === 6) && !r.rep && r.len.every(x => x[1] >= 60 && x[2] <= 130 && x[3] <= 16 && x[4] === 0) && r.vary.every(Boolean) && r.gap === 5 && r.noName && r.tip.includes('ボレロ') && r.tip.includes('ランダム');
    rec(151, 'BGM：6曲をシャッフルして1回ずつ流し、全部流したら並べ直す（周の境目でも同じ曲が続かない）・各曲60〜130秒・乱数で変奏の組み合わせが変わる・同時に鳴る音は16まで・曲間5秒・⚙️に曲名を出さない（TIPSに曲の一覧）', ok, JSON.stringify(r));
    if (errors.length) rec('E101', 'BGM（v5.4）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #152 ボレロ：主題 A・B は18小節で各小節3拍・三連符とタイを含む・小太鼓は2小節24打で最後まで・主題 B が A より大きい・音割れしない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      const tot = s => s.replace(/\|/g, ' ').trim().split(/\s+/).reduce((a, tok) => { const d = tok.split(':')[1].replace('~', ''); const f = d.split('/'); return a + (f.length > 1 ? f[0] / f[1] : Number(d)); }, 0);
      o.barsA = BOL_A.split('|').map(b => +tot(b).toFixed(6)); o.barsB = BOL_B.split('|').map(b => +tot(b).toFixed(6));
      const A = bgmSeq(BOL_A), B = bgmSeq(BOL_B);
      o.a0 = A[0]; o.tripB = B.filter(n => Math.abs(n[1] - 1 / 3) < 1e-9).length; o.tieA = A.filter(n => n[1] >= 2).length;
      o.rangeB = [Math.min(...B.map(n => n[2])), Math.max(...B.map(n => n[2]))];
      const bi = BGM_PIECES.findIndex(p => p.id === 'bolero'); const N = bgmBuild(bi, () => 0.5); const sp = 60 / BGM_PIECES[bi].bpm; const dur = bgmDur(N);
      const sn = N.filter(n => n[4] === 5).map(n => n[0] / sp);
      o.sn2 = sn.filter(t => t >= 6 && t < 12).length; o.snEnd = +(dur / sp - sn[sn.length - 1]).toFixed(2);
      let gap = 0; sn.forEach((t, j) => { if (j) gap = Math.max(gap, t - sn[j - 1]); }); o.snGap = +gap.toFixed(3);
      // 主題 A（独奏）と主題 B（重ねる）の大きさ
      const rms = async (b0, b1) => { const s0 = b0 * sp, s1 = b1 * sp; const ctx = new OfflineAudioContext(1, Math.ceil((s1 - s0 + 1) * 8000), 8000); const save = _bgm.master; const m = ctx.createGain(); m.gain.value = 0.22; m.connect(ctx.destination); _bgm.master = m; _bgmNoise = null;
        N.filter(n => n[0] >= s0 && n[0] < s1).forEach(n => bgmPlay(ctx, n[4], n[2], n[0] - s0, n[1], n[3]));
        const buf = await ctx.startRendering(); _bgm.master = save; _bgmNoise = null; const d = buf.getChannelData(0); let ss = 0, pk = 0; for (let k = 0; k < d.length; k++) { ss += d[k] * d[k]; pk = Math.max(pk, Math.abs(d[k])); } return [Math.sqrt(ss / d.length), pk]; };
      const ra = await rms(6, 60), rb = await rms(60, 114), re = await rms(114, 144);
      o.rms = [ra[0], rb[0], re[0]].map(v => +v.toFixed(4)); o.peak = +Math.max(ra[1], rb[1], re[1]).toFixed(3);
      o.min = +(dur / 60).toFixed(2);
      return o;
    });
    const ok = r.barsA.length === 18 && r.barsA.every(x => x === 3) && r.barsB.length === 18 && r.barsB.every(x => x === 3) && r.a0[2] === 72 && r.a0[1] === 1.5 && r.tripB === 6 && r.tieA >= 3 && r.rangeB[0] === 48 && r.rangeB[1] === 73
      && r.sn2 === 24 && r.snEnd < 4 && r.snGap <= 0.51 && r.rms[1] > r.rms[0] && r.rms[2] > r.rms[0] && r.peak < 0.9 && r.min >= 1 && r.min <= 2.2;
    rec(152, 'ボレロ：主題 A・B は18小節で各小節3拍（三連符とタイを含む・A は C5 を1拍半伸ばして始まる・B は Db5〜C3）・小太鼓は2小節で24打、最後まで続く・主題 B と終わりは主題 A より大きい・音割れしない・約2分', ok, JSON.stringify(r));
    if (errors.length) rec('E102', 'ボレロのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #153 売る：タブ全体でスクロール（中に内部スクロールがない）・見出しと切り替えは上に残る・切り替えるとタブの先頭へ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      for (let i = 0; i < 20; i++) { const a = ordGenerate(); if (a) G.orders.push(a); }
      _ui.sellTab = 'ord'; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 80));
      const t = document.getElementById('tsale'); const o = {};
      o.inner = [...t.querySelectorAll('*')].filter(e => { const s = getComputedStyle(e); return (s.overflowY === 'auto' || s.overflowY === 'scroll') && e.scrollHeight > e.clientHeight + 1; }).map(e => e.id || e.className);
      o.scroll = t.scrollHeight > t.clientHeight + 50;
      t.scrollTop = t.scrollHeight; await new Promise(r => setTimeout(r, 50));
      const tr = t.getBoundingClientRect(), hr = t.querySelector('.shead').getBoundingClientRect();
      o.sticky = Math.abs(hr.top - tr.top) <= 2 && !!t.querySelector('.shead #sellChips'); o.last = t.querySelector('#orderNext').getBoundingClientRect().bottom <= tr.bottom + 2;
      const chip = t.querySelector('[data-act="sellTab"][data-id="inv"]'); if (chip) { chip.click(); await new Promise(r => setTimeout(r, 50)); o.top = t.scrollTop === 0; } else o.top = true;
      return o;
    });
    const ok = r.inner.length === 0 && r.scroll && r.sticky && r.last && r.top;
    rec(153, '売る：注文20件でタブ全体がスクロールし、中に内部スクロールがない・見出しと切り替えのチップは上に貼り付く・最後の「次の注文まで」まで届く・切り替えるとタブの先頭へ', ok, JSON.stringify(r));
    if (errors.length) rec('E103', '売るのスクロールのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #154 トースト：豆知識の帯の下に出る・タブバーに重ならない・長い文は2行で全部見える（幅360px・文字「大」でも） ----------
  {
    const out = [];
    for (const [W, H, fs] of [[390, 844, 'm'], [360, 640, 'l']]) {
      const ctx = await browser.newContext({ viewport: { width: W, height: H } }); const page = await ctx.newPage(); const errors = [];
      page.on('pageerror', e => errors.push('pageerror: ' + e.message));
      await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
      await page.goto(FILE); await page.waitForTimeout(1000);
      await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
      const r = await page.evaluate(async (fs) => {
        if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose();
        G.opt.fs = fs; applyOpt(); await new Promise(r => setTimeout(r, 100));
        toast('👤 見学のお客さんが来ました。タップすると試飲代が入ります（12秒で帰ります）', 5000); await new Promise(r => setTimeout(r, 450));
        const e = document.getElementById('toast'); const a = e.getBoundingClientRect(), tk = document.getElementById('ticker').getBoundingClientRect(), nv = document.getElementById('nav').getBoundingClientRect();
        return { top: Math.round(a.top), bottom: Math.round(a.bottom), left: Math.round(a.left), right: Math.round(a.right), tk: Math.round(tk.bottom), nav: Math.round(nv.top), clip: e.scrollHeight > e.clientHeight + 1, lines: Math.round((a.height - 16) / parseFloat(getComputedStyle(e).lineHeight)), vw: innerWidth };
      }, fs);
      out.push({ W, fs, ...r, err: errors.length });
      await ctx.close();
    }
    const ok = out.every(o => o.top >= o.tk && o.top <= o.tk + 14 && o.bottom < o.nav && !o.clip && o.lines <= 2 && o.left >= 10 && o.right <= o.vw - 10 && o.err === 0);
    rec(154, 'トースト：豆知識の帯のすぐ下（帯の下端から14px以内）に出て、タブバーに重ならない・長い文は2行以内で切れずに全部見える・左右に余白（幅390px／幅360px・文字「大」）', ok, JSON.stringify(out));
  }
  // ---------- #155 偶発イベント：帯がない・選ぶイベントはホームの「出来事」から選ぶ・続く効果はアイコンに残り時間・終わると消える ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); switchTab('td');
      const o = { banner: !document.getElementById('eventBanner') };
      const icon = () => { rall(); const b = document.getElementById('hi_ev'); return b ? b.textContent : ''; };
      o.none = icon() === '';
      const ch = RAND_EVENTS.find(e => e.id === 're_partner'); const rep0 = G.reputation;
      showEventBanner(ch); o.ask = [G.randomEvent.ask, icon().includes('!')];
      openEvModal(); const bt = document.querySelector('#mc2 [data-act="evChoose"][data-v="0"]'); o.btns = document.querySelectorAll('#mc2 [data-act="evChoose"]').length; bt.click(); await new Promise(r => setTimeout(r, 30));
      o.chose = [G.randomEvent.ask, +(G.reputation - rep0).toFixed(2) > 0, $('mo').classList.contains('h')];
      const good = RAND_EVENTS.find(e => e.id === 're_festival'); showEventBanner(good); o.active = [!!G.randomEvent.active, /\d+分/.test(icon())];
      G.randomEvent.active.expiresAt = Date.now() - 1; tickActiveEvent(); o.end = [G.randomEvent.active, icon() === ''];
      // 保存：選ぶイベントは保存しても残る。知らない id は消える
      G.randomEvent.ask = 're_buyout'; o.san = [sanitize(JSON.parse(JSON.stringify(G))).randomEvent.ask, sanitize(Object.assign(JSON.parse(JSON.stringify(G)), { randomEvent: { lastAt: 0, sessionCount: 0, active: null, ask: 'x' } })).randomEvent.ask];
      G.randomEvent.ask = null;
      return o;
    });
    const ok = r.banner && r.none && r.ask[0] === 're_partner' && r.ask[1] && r.btns === 2 && r.chose[0] === null && r.chose[1] && r.chose[2] && r.active.join() === 'true,true' && r.end[0] === null && r.end[1] && r.san[0] === 're_buyout' && r.san[1] === null;
    rec(155, '偶発イベント：画面上の帯はない・選ぶイベントはホームのアイコン「出来事（!）」の小窓で選ぶと効果が出て消える・続く効果はアイコンに残り分・終わるとアイコンが消える・選ぶイベントは保存される', ok, JSON.stringify(r));
    if (errors.length) rec('E105', '偶発イベントのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #156 廃止した機能と移行（v16→v17）：等級・差し入れ・TIPS帯の速さがない・砂時計の入手は8種類・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {};
      openBarleyModal(); o.grade = !document.querySelector('#mc2 [data-act="barleyGrade"]') && !$('mc2').textContent.includes('等級'); closeM();
      switchTab('tp'); rall(); await new Promise(r => setTimeout(r, 30)); o.tk = !document.querySelector('#optBox [data-k="tk"]');
      o.hgKeys = Object.keys(V51.HG).join(','); openHgModal(); o.hgList = document.querySelectorAll('#mc2 .hgs').length; o.hgTxt = $('mc2').textContent.includes('差し入れ') || $('mc2').textContent.includes('月の決算'); closeM();
      o.daily = V51.HG.daily.k;
      // v16 の保存から移行
      const old = JSON.parse(JSON.stringify(G)); old.ver = 16; old.barley.grade = 'best'; old.hg.src.care = 1; old.opt.tk = 'fast'; (old.staff || []).forEach(s => s.care = dayKey());
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      o.mig = { ver: m.ver, grade: m.barley.grade, care: 'care' in m.hg.src, tk: m.opt.tk, staffCare: (m.staff || []).some(s => 'care' in s) };
      const key = storageKey(); const bk = 'we_v4_bak16:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.grade && r.tk && r.hgKeys === 'login,daily,ms,ord,tap,streak,tier,prestige' && r.hgList === 8 && !r.hgTxt && r.daily === 3
      && r.mig.ver === SCHEMA && r.mig.grade === 'std' && !r.mig.care && r.mig.tk === 'mid' && !r.mig.staffCare && r.bk && r.loaded === SCHEMA;
    rec(156, '廃止：大麦の等級・TIPS帯の速さの設定がない・砂時計の入手の機会は8種類（デイリー全達成は3個）／v16 からの移行：等級は標準・差し入れの記録を外す・TIPS帯は標準・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E106', '廃止と移行のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  await browser.close();
  let pass = 0;
  results.forEach(x => { if (x.ok) pass++; console.log((x.ok ? 'PASS' : 'FAIL') + ' #' + x.id + ' ' + x.name + (x.ok ? '' : '  → ' + x.detail)); });
  console.log(`\n${pass}/${results.length} passed`);
  require('fs').writeFileSync('test_results.json', JSON.stringify(results, null, 1));
})();
