const { chromium } = require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();
for (const rm of ['no-preference','reduce']){
const ctx=await b.newContext({viewport:{width:390,height:740},reducedMotion:rm});const p=await ctx.newPage();
await p.route(/fonts/,r=>r.abort());await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1200);
await p.evaluate(()=>{titleStart(false);});await p.waitForTimeout(500);await p.evaluate(()=>{Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}});const top=await p.evaluate(()=>{const r=ticker.getBoundingClientRect();const e=document.elementFromPoint(r.left+200,r.top+10);return e.id+'.'+e.className;});console.log('top',top);
// 最長の文を強制表示
await p.evaluate(()=>{const L=TICKER_MSGS.slice().sort((a,b)=>b.text.length-a.text.length)[0];window._L=L.text;tkPick=()=>L;nextTicker();});
await p.waitForTimeout(200);
const info=await p.evaluate(()=>{const el=tkTxt,t=tkTrack.getBoundingClientRect();return {w:el.offsetWidth,track:t.width,left:t.left,dur:getComputedStyle(el).animationDuration,cls:el.className,ov:getComputedStyle(el).textOverflow};});
const xs=[];for(let i=0;i<5;i++){xs.push(await p.evaluate(()=>Math.round(tkTxt.getBoundingClientRect().left)));await p.waitForTimeout(500);}
// 押している間は止まる
const box=await p.locator('#ticker').boundingBox();
await p.mouse.move(box.x+200,box.y+10);await p.mouse.down();
const h1=await p.evaluate(()=>tkTxt.getBoundingClientRect().left);await p.waitForTimeout(600);const h2=await p.evaluate(()=>tkTxt.getBoundingClientRect().left);
await p.mouse.up();await p.waitForTimeout(300);
const modal=await p.evaluate(()=>!mo.classList.contains('h'));
await p.mouse.click(box.x+200,box.y+10);await p.waitForTimeout(200);const modal2=await p.evaluate(()=>!mo.classList.contains('h'));
await p.waitForTimeout(400);const h3=await p.evaluate(()=>tkTxt.getBoundingClientRect().left);
console.log(rm,JSON.stringify(info),'xs',xs.join(','),'hold',Math.round(h1),Math.round(h2),'after',Math.round(h3),'longPressModal',modal,'tapModal',modal2);
await ctx.close();}
await b.close();})();
