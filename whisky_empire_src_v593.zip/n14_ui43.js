// ============================================================
// v4.3 ホームのアイコン列（章・デイリー・市場・Tier・砂時計）
// ============================================================
function hsState(){if(!G.hs||typeof G.hs!=='object')G.hs={chap:'',daily:'',mkt:''};return G.hs;}
function homeIconData(){
  const out=[];const hs=hsState();
  // 章
  const c=chapCur(),st=chapState();const cn=c.goals.filter(g=>st.done[g.id]).length;
  const ck=c.tier+':'+cn;
  out.push({k:'chap',ic:'chap',lb:'章の目標',bd:cn+'/'+c.goals.length,hl:hs.chap!==ck&&cn>0,act:'hiChap'});
  // デイリー
  if(feat('daily')&&G.daily&&G.daily.missions&&G.daily.missions.length){
    const dn=G.daily.missions.filter(m=>m.done).length;const dk=(G.daily.date||'')+':'+dn;
    out.push({k:'daily',ic:'daily',lb:'デイリー',bd:dn+'/'+G.daily.missions.length,hl:hs.daily!==dk&&dn>0,act:'hiDaily'});
  }
  // 市場
  // v5.5 「市況」：今月の市場と偶発イベントをまとめる（イベントの間は残りの分）
  const mk=mkt();const ea=evActive();
  out.push({k:'mkt',ic:'market',lb:'市況',bd:ea?Math.max(1,Math.ceil((ea.expiresAt-Date.now())/60000))+'分':mktDaysLeft()+'日',hl:hs.mkt!==mk.name||!!(ea&&hs.ev!==ea.id+':'+ea.expiresAt),act:'hiMkt'});
  // Tier
  if(G.dl>=DL.length)out.push({k:'tier',ic:'tier',lb:'Tier',bd:'最大',hl:false,act:'hiTier'});
  else{const ts=tierReqStatus(G.dl+1);const ok=ts.filter(o=>o.ok).length;out.push({k:'tier',ic:'tier',lb:'次のTier',bd:ok+'/'+ts.length,hl:ok===ts.length,act:'hiTier'});}
  // v4.6 熟成の砂時計（決算書は図鑑へ移した）
  const hg=hgState();
  out.push({k:'hg',ic:'hourglass',lb:'砂時計',bd:hg.n+'/'+V47.HG_MAX,hl:hg.n>0,act:'hgOpen'});
  // v4.8 職人
  if(typeof staffOn==='function'&&staffOn()){const L=staffList();out.push({k:'staff',ic:'staff',lb:'職人',bd:L.length+'/'+staffCap(),hl:!!G.staffOff||(!L.length),act:'staffOpen'});}
  return out;
}
function homeIconsHtml(){
  const D=homeIconData(); // v5.5 アイコンは最大6つ（1段）
  return D.map(d=>`<button type="button" class="hi${d.hl?' hl':''}" data-act="${d.act}" id="hi_${d.k}" aria-label="${escapeHtml(d.lb)}"><span class="hitop"><span class="hic">${ic(d.ic,22)}</span>${d.bd?`<span class="hib">${escapeHtml(d.bd)}</span>`:''}</span><span class="hil">${escapeHtml(d.lb)}</span></button>`).join('');
}
function hiSeen(k){
  const hs=hsState();
  if(k==='chap'){const c=chapCur(),st=chapState();hs.chap=c.tier+':'+c.goals.filter(g=>st.done[g.id]).length;}
  if(k==='daily'&&G.daily&&G.daily.missions)hs.daily=(G.daily.date||'')+':'+G.daily.missions.filter(m=>m.done).length;
  if(k==='mkt')hs.mkt=mkt().name;
  save();setHtml($('homeIcons'),homeIconsHtml());
}
function openDailyModal(){
  openModal(`<div class="mt">📅 デイリーミッション</div><div class="ms">毎日0時に入れ替わります。達成すると評判が上がります</div><div id="dailyPanel"></div><button type="button" class="btn-cancel" style="width:100%;margin-top:8px" data-act="closeM">閉じる</button>`);
  renderDailyPanel();hiSeen('daily');
}
function openMktModal(){
  const mk=mkt(),nx=mktNext();
  const ea=evActive();const ev=ea&&evById(ea.id);
  openModal(`<div class="mt">📈 市況</div><div class="ms">月ごとに市場の流れが変わり、一部の数値が上下します。ときどき出来事も起きます</div>
    ${ea?`<div class="card hl evc"><div class="sm" style="color:var(--gold)">いま起きている出来事</div><div class="tt" style="margin-top:2px">${ev?ev.icon+' '+escapeHtml(ev.name):'出来事'}</div><div class="sm" style="margin-top:4px">あと${fmtRemain(ea.expiresAt-Date.now())}</div></div>`:''}
    <div class="card${ea?'':' hl'}"><div class="sm" style="color:var(--gold)">今月の市場</div><div class="tt" style="margin-top:2px">${escapeHtml(mk.name)}</div><div class="sm" style="color:var(--cream);margin-top:4px">${escapeHtml(mk.desc)}</div><div class="sm" style="margin-top:6px">今月の残り：${mktDaysLeft()}日</div></div>
    <div class="card"><div class="sm" style="color:var(--gold)">来月の予告</div><div class="tt" style="margin-top:2px">${escapeHtml(nx.name)}</div><div class="sm" style="margin-top:4px">${escapeHtml(nx.desc)}</div></div>
    <button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
  if(ea)hsState().ev=ea.id+':'+ea.expiresAt;
  hiSeen('mkt');
}
