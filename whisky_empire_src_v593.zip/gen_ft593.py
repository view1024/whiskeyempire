# v5.9.2 の生成（try で包む前）まで → v5.9.3 の書き換え → 追加 → try で包む
s592=open('gen_ft592.py').read()
exec(s592[:s592.rindex("exec(src[cut:]")])
exec(open('functest593_fix.py').read())
if os.path.exists('functest593_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest593_add.js').read()+s[a:]
exec(src[cut:].replace("open('functest55.js','w').write(s)","pass"))
open('functest593.js','w').write(s)
