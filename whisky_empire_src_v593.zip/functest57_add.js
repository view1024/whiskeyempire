  // ================= v5.6.1・v5.7 追加テスト =================
  // ---------- #166 造る・寝かせる・売るの見出しは同じ高さで、どれも見出しのすぐ下からスクロールする（v5.6.1） ----------
  {
    const out = {}; const errs = [];
    for (const [W, H, fsl] of [[360, 640, false], [390, 667, false], [360, 740, true]]) {
      const { page, errors, ctx } = await pageW(W, H, 'late', fsl);
      const r = await page.evaluate(async () => {
        const o = {};
        for (const [t, b] of [['tb', 'lineView'], ['tcel', 'celBody'], ['tsale', 'saleBody']]) {
          if (t === 'tsale') _ui.sellTab = 'ord'; switchTab(t); await new Promise(r => setTimeout(r, 120));
          const tab = document.getElementById(t), th = tab.querySelector('.thead').getBoundingClientRect(), body = document.getElementById(b);
          o[t] = { top: Math.round(th.top), h: Math.round(th.height), body: Math.round(body.getBoundingClientRect().top), sy: getComputedStyle(body).overflowY, tabY: getComputedStyle(tab).overflowY, can: body.scrollHeight > body.clientHeight };
        }
        return o;
      });
      out[W + 'x' + H + (fsl ? 'L' : '')] = r; errs.push(...errors); await ctx.close();
    }
    const ok = Object.values(out).every(o => { const v = Object.values(o); return v.every(x => x.h === v[0].h && x.top === v[0].top && x.body === v[0].body && x.sy === 'auto' && x.tabY === 'hidden'); });
    rec(166, '造る・寝かせる・売るの見出し（v5.6.1）：3つのタブで見出しの位置と高さが同じ・どのタブも見出しはスクロールせず、すぐ下の同じ位置からスクロールする（360×640・390×667・文字：大）', ok, JSON.stringify(out));
    if (errs.length) rec('E115', '見出しのテスト中のエラー', false, errs.slice(0, 3).join(' | '));
  }
  // ---------- #167 製造費・熟成費（v5.7）：新酒1Lごとに製造費を払いタンク・樽の原価に入る・払えない分は造らない・樽はゲーム内1年ごとに詰めたときの原価の4%を積む ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      let T = Date.now(); _acctClock = () => T; G.acct = null; acctEnsure(); const o = {};
      o.k = V57.MFG_K.join() + '|' + V57.AGE_R;
      const u = mfgUnit(); o.u = Math.abs(u - V57.MFG_K[G.dl - 1] * nmPrice()) < 1e-9;
      // 製造費：タンクの1Lあたりの製造費（移動平均）
      G.tank = 0; G.tankMfg = 0; G.cash = 1e12; const c0 = G.cash, m0 = acctLive().pur.mfg; const L = mfgPay(1000);
      o.pay = [L, +(c0 - G.cash).toFixed(3) === +(1000 * u).toFixed(3), Math.abs(acctLive().pur.mfg - m0 - 1000 * u) < 1e-6]; G.tank += L;
      o.tankU = Math.abs(tankMfgU() - u) < 1e-9 && Math.abs(invBreak().tank - G.tank * (acctBAvg() + u)) < 1e-6;
      // 足りないときはその分だけ
      G.cash = 500 * u; const L2 = mfgPay(1000); o.short = [Math.round(L2), G.cash < 1e-6]; G.cash = 1e12;
      // 樽の原価に入る
      G.tank = 1000; G.tankMfg = u; G.auto.fill.on = false; fillCask('bourbon', 'hogshead', false); const lot = G.lots[G.lots.length - 1];
      o.lotC = Math.abs(lot.c - (250 * (acctBAvg() + u) + caskCost('bourbon', 'hogshead'))) < 1e-6;
      // 熟成費：ゲーム内1年で詰めたときの原価の4%
      const lc0 = lotC(lot); const before = G.lots.map(l => lotC(l)); const cash1 = G.cash; const a0 = acctLive().pur.age;
      ageCostTick(G.lots, BALANCE.GAME_YEAR_MS); const after = G.lots.map(l => lotC(l));
      o.age = [Math.abs(lotC(lot) - lc0 * 1.04) < 1e-6, Math.abs((cash1 - G.cash) - (acctLive().pur.age - a0)) < 1e-3 * Math.max(1, acctLive().pur.age - a0), after.every((v, i) => v >= before[i])];
      // 熟成しても原価が何倍にもならない（25年で 1+0.04×25 ＝ 2倍）
      const x = makeLot(caskType('bourbon'), caskSize('hogshead'), { c: 1000 }); for (let i = 0; i < 25; i++) ageCostTick([x], BALANCE.GAME_YEAR_MS); o.age25 = +(x.c / 1000).toFixed(3);
      // 払えない年は積まない
      G.cash = 0; const y = makeLot(caskType('bourbon'), caskSize('hogshead'), { c: 1000 }); ageCostTick([y], BALANCE.GAME_YEAR_MS); o.broke = y.c === 1000; G.cash = 1e12;
      _acctClock = () => Date.now();
      return o;
    });
    const ok = r.k === '0.1,0.3,0.7,0.8,0.9|0.04' && r.u && r.pay[0] === 1000 && r.pay[1] && r.pay[2] && r.tankU && r.short.join() === '500,true' && r.lotC && r.age.every(Boolean) && r.age25 === 2 && r.broke;
    rec(167, '製造費・熟成費（v5.7）：新酒1Lごとに製造費（新酒の外販価格×Tierごとの係数 0.1〜0.9）を払い、タンクと樽の原価に入る・払えない分は造らない・樽はゲーム内1年ごとに詰めたときの原価の4%を払って原価に積む（25年で2倍まで）・払えない年は積まない', ok, JSON.stringify(r));
    if (errors.length) rec('E116', '製造費のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #168 法人税・CF の間接法・耐用年数（v5.7）：月を締めると税引前利益の30%、赤字は繰り越す・未払法人税は次の月の初めに払う・営業CF＝純利益＋償却−在庫の増加…・熟成庫30年・機械15年 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      let T = Date.now(); _acctClock = () => T; G.acct = null; acctEnsure(); const o = {};
      o.calc = [acctTaxCalc(100, 0).tax, acctTaxCalc(-50, 0).loss, acctTaxCalc(100, 30).tax, acctTaxCalc(20, 30).tax, acctTaxCalc(20, 30).loss].map(v => +v.toFixed(6)).join();
      G.cash = Math.max(G.cash, 1e10);
      for (let i = 0; i < 24; i++) { T += 36e5; prodTick(36e5); lotTick(36e5); botTick(36e5); }
      // 耐用年数
      const m = acctMonthF(T); const fa0 = G.acct.fa.length; G.cash += 0; pay(3044, 'capex', 'maturation'); pay(1522, 'capex', 'distillation');
      const nb = G.acct.fa.slice(fa0); o.life = nb.map(f => +(f.L * 30.4375).toFixed(3)).join();
      const t15 = m + 15 / 30.4375 / 2; o.nbv = [+(1522 * (1 - (t15 - m) / (15 / 30.4375))).toFixed(1)];
      T += 40 * 864e5; acctEnsure(); const h = G.acct.hist[0];
      o.close = { pre: h.pretax > 0, tax: Math.abs(h.tax - 0.3 * Math.max(0, h.pretax)) < 1e-6 * Math.max(1, h.pretax), ni: Math.abs(h.ni - (h.pretax - h.tax)) < 1e-6 * Math.max(1, h.pretax), due: h.c.taxDue >= h.tax - 1e-6 };
      const live = acctLive(); o.paid = live.taxp > 0 || G.acct.taxDue < h.tax;
      const chk = s => [Math.abs(naOf(s.c) - naOf(s.o) - s.ni) < Math.max(1, Math.abs(naOf(s.c)) * 1e-9), Math.abs(s.c.cash - s.o.cash - s.opcf - s.invcf - s.fincf) < Math.max(1, Math.abs(s.c.cash) * 1e-9), Math.abs(s.ni + s.dep - (s.c.inv - s.o.inv) + ((s.c.taxDue || 0) - (s.o.taxDue || 0)) + (s.intAcc || 0) - s.opcf) < Math.max(1, Math.abs(s.opcf) * 1e-9)];
      o.idClose = chk(h); o.idLive = chk(live);
      // 画面：PL に税引前利益と法人税、CF に間接法の行、BS に負債
      _fin.i = 1; _fin.v = 'pl'; _ui.encTab = 'fin'; switchTab('te'); const pl = document.getElementById('finBox').textContent;
      _fin.v = 'cf'; finRender(); const cf = document.getElementById('finBox').textContent;
      _fin.v = 'bs'; finRender(); const bs = document.getElementById('finBox').textContent;
      o.ui = [pl.includes('税引前利益') && pl.includes('法人税（30%）'), cf.includes('当期純利益') && cf.includes('減価償却費') && cf.includes('在庫の'), bs.includes('借入金') && bs.includes('未払法人税') && bs.includes('負債合計')];
      // 在庫が増えた月は営業CFが純利益より小さく、理由の1行が出る
      o.reason = ((h.c.inv - h.o.inv > 0.5 && h.opcf < h.ni) === finKpiHtml(h).includes('在庫が')) && finKpiHtml(Object.assign({}, h, { o: Object.assign({}, h.o, { inv: h.c.inv - 1e9 }), opcf: h.ni - 1 })).includes('在庫が');
      _acctClock = () => Date.now(); _fin.i = 0; _ui.encTab = 'w';
      return o;
    });
    const ok = r.calc === '30,50,21,0,10' && r.life === '30,15' && r.close.pre && r.close.tax && r.close.ni && r.close.due && r.paid && r.idClose.every(Boolean) && r.idLive.every(Boolean) && r.ui.every(Boolean) && r.reason;
    rec(168, '法人税・CF・耐用年数（v5.7）：月を締めると税引前利益の30%が確定（赤字は繰り越して後の利益から差し引く）・未払法人税は次の月の初めに払う・純資産と現金の整合式に加え、営業CF＝純利益＋減価償却費−在庫の増加＋未払法人税の増加が成り立つ・在庫が増えた月は理由の1行・熟成庫30年・機械15年', ok, JSON.stringify(r));
    if (errors.length) rec('E117', '法人税のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #169 借入（v5.7）：Tier3 から・上限は樽の原価の50/60/70%・金利はゲーム内の年4%・元金は10年で返済・払えない利息は借入に加える・BS の画面で借りる・返す・再創業は借入を除いた現金 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      let T = Date.now(); _acctClock = () => T; G.acct = null; acctEnsure(); const o = {}; const Y = BALANCE.GAME_YEAR_MS;
      G.dl = 2; o.t2 = [loanOn(), loanBorrow(1e9)];
      o.ltv = [3, 4, 5].map(t => { G.dl = t; return +(loanLimit() / invBreak().lot).toFixed(3); }).join(); G.dl = 3;
      G.cash = 1e12; const lim = loanLimit(); const c0 = G.cash; const b = loanBorrow(1e18); o.bor = [Math.abs(b - lim) < 1e-6, Math.abs(G.cash - c0 - b) < 1e-3 * Math.max(1, b), loanAvail() < 1e-6, Math.abs(G.acct.loan.pd - b / 10) < 1e-6];
      const bal0 = G.acct.loan.bal, cash0 = G.cash; const lt = loanTick(Y);
      o.tick = [Math.abs(lt.i - bal0 * 0.04) < 1e-6 * bal0, Math.abs(lt.p - bal0 / 10) < 1e-6 * bal0, Math.abs(G.acct.loan.bal - bal0 * 0.9) < 1e-6 * bal0, Math.abs(cash0 - G.cash - lt.i - lt.p) < 1e-6 * bal0];
      // 払えない利息は借入に加える
      G.cash = 0; const bal1 = G.acct.loan.bal; loanTick(Y); o.broke = [Math.abs(G.acct.loan.bal - bal1 * 1.04) < 1e-6 * bal1, acctLive().intAcc > 0];
      G.cash = 1e12;
      // 画面：BS で借りる・返す
      _fin.i = 0; _fin.v = 'bs'; _ui.encTab = 'fin'; switchTab('te'); await new Promise(r => setTimeout(r, 30));
      const rep = document.querySelector('#finBox [data-act="loanRep"]'); rep.click(); await new Promise(r => setTimeout(r, 30)); o.repaid = G.acct.loan.bal === 0;
      const bor = document.querySelector('#finBox [data-act="loanBor"]'); bor.click(); await new Promise(r => setTimeout(r, 30)); o.step = Math.abs(G.acct.loan.bal - loanLimit() * 0.25) < 1e-6 * Math.max(1, loanLimit());
      const s = acctLive(); o.id = [Math.abs(naOf(s.c) - naOf(s.o) - s.ni) < Math.max(1, Math.abs(naOf(s.c)) * 1e-9), Math.abs(s.c.cash - s.o.cash - s.opcf - s.invcf - s.fincf) < Math.max(1, Math.abs(s.c.cash) * 1e-9), s.fincf !== 0, s.int > 0];
      // 再創業：借入金と未払の税を除いた現金
      G.dl = 5; G.cash = PRESTIGE_COST + 1; o.pres = [canPrestige(), prestigeCash() < PRESTIGE_COST]; G.cash = PRESTIGE_COST + G.acct.loan.bal + 1; o.pres.push(canPrestige());
      _acctClock = () => Date.now(); _ui.encTab = 'w';
      return o;
    });
    const ok = r.t2.join() === 'false,0' && r.ltv === '0.5,0.6,0.7' && r.bor.every(Boolean) && r.tick.every(Boolean) && r.broke.every(Boolean) && r.repaid && r.step && r.id.every(Boolean) && r.pres.join() === 'false,true,true';
    rec(169, '借入（v5.7）：Tier3 から・上限は樽の原価の50%（Tier4 60%・Tier5 70%）・金利はゲーム内の年4%・元金は10年で毎日返済・払えない利息は借入に加える・決算書の BS で「借りる（上限の25%ずつ）」「返す」・財務CF に出て整合式が成り立つ・再創業は借入金を除いた現金で判定', ok, JSON.stringify(r));
    if (errors.length) rec('E118', '借入のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #170 v5.6（schema18）からの移行：決算書の新しい項目を補う（借入0・未払の税0・繰越欠損金0）・樽とタンクの原価はそのまま・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      acctEnsure(); const old = JSON.parse(JSON.stringify(G)); old.ver = 18; if (old.acct) { delete old.acct.loan; delete old.acct.taxDue; delete old.acct.lossCF; old.acct.fa.forEach(f => delete f.L); }
      delete old.tankMfg; old.lots.forEach(l => delete l.c0); delete old.stats.mfgCost;
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, loan: m.acct && JSON.stringify(m.acct.loan), tax: m.acct && [m.acct.taxDue, m.acct.lossCF].join(), tm: m.tankMfg, lotC: m.lots.every((l, i) => l.c === old.lots[i].c), faL: m.acct.fa.every(f => !f.L) };
      const key = storageKey(); const bk = 'we_v4_bak18:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.ver === SCHEMA && r.loan === '{"bal":0,"pd":0}' && r.tax === '0,0' && r.tm === 0 && r.lotC && r.faL && r.bk && r.loaded === SCHEMA;
    rec(170, 'v5.6（schema18）からの移行：決算書の借入・未払の税・繰越欠損金を0で補う・樽の原価はそのまま・それまでの設備は10年の償却のまま・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E119', '移行（v19）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
