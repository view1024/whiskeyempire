# v5.3 の変更に合わせて v5.2 までのテストを置き換える
# #145：曲が6曲に（ボレロ）。同時に鳴る音はその時刻に鳴っている数で数える（v5.3 で数え方を先読みの数から変更）
R2("let maxV = 0; for (let k = 0; k < 10; k++) { _bgmc.t0 -= 0.5; bgmClassicTick(); maxV = Math.max(maxV, _bgmc.voices.length); } o.poly = maxV;",
   "let maxV = 0; for (let k = 0; k < 10; k++) { _bgmc.t0 -= 0.5; bgmClassicTick(); _bgmc.voices.forEach(v => { maxV = Math.max(maxV, bgmOn(v[0])); }); } o.poly = maxV;")
R2("const ok = r.pieces.length === 5 && r.pieces.every(", "const ok = r.pieces.length === 6 && r.pieces.every(")
R2("rec(145, 'BGM：クラシック5曲（バッハ・パッヘルベル・ベートーヴェン2曲・サティ）のデータが正しい", "rec(145, 'BGM：クラシック6曲（バッハ・パッヘルベル・ベートーヴェン2曲・サティ・ラヴェル）のデータが正しい")
