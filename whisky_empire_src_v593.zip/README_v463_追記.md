# v4.6.3 追記（README.md v4.6.2 への差分）

README.md（v4.6.2 の仕様書）の末尾、または更新履歴の節に次を追記してください。

## v4.6.3（2026-09-29）ファイルサイズの削減

遊び方・保存データ（SCHEMA_VERSION 11）は変わりません。

| 項目 | v4.6.2 | v4.6.3 |
|---|---|---|
| 配布版 whisky_empire.html | 898,999 B | 738,484 B（−17.9%） |
| gzip -9 | 453,978 B | 368,388 B（−18.9%） |

1. 造る・寝かせる・売るの背景画像（bg_make / bg_age / bg_sell）を 1000px → 800px、WebP 品質50 に再圧縮。
2. ビルド時に本体の JS を terser、CSS を csso で最小化。トップレベルの名前は保持。LIFF 設定の `<script id="liff-config">` は最小化しない。
3. 未使用の関数17個を削除。
4. 開発用に未最小化の whisky_empire.dev.html も出力（配布しない）。

### ビルド手順

```
npm install            # 初回のみ（terser / csso / acorn / pngjs）
python3 assemble.py    # whisky_empire.html（配布版）と whisky_empire.dev.html を生成
python3 gen_ft46.py && node functest46.js   # 115件
```

### 確認結果

- 機能テスト 115/115 件合格（#105 を追加）。
- 最小化の前後（開発版と配布版）を 6状態×2テーマ×10画面で比べ、計算済みスタイルは background-position の表記（`background:none` を csso が `0 0` に置き換えるもの。画像がないので表示に影響なし）以外で一致。画素の差は同じファイル同士の比較でも出るタイマー由来の数字の差だけ。
- コントラストの最小値：昼 4.64、夜 4.55（基準 4.5 以上）。
- バランスボット（6回・100日・1日3回）の中央値：Tier2 7.3日、Tier3 17.9日、Tier4 30.7日、Tier5 61.3日（v4.6 の実測と同じ範囲）。
