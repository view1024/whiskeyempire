// ============================================================
// v5.5 画面の整理（第1回）：小人を試飲会に・ホームのアイコン6つ・見学ツアーの強化をやめる・称号の整理
// ============================================================
// 実装計画：https://claude.ai/code/artifact/293b44c8-9442-4602-b501-77ec0f0ad3fe
//  - 小人：試飲会（30回タップ・1日5回）のたびに DWARF_P の確率で砂時計を1個（n24_v52.js dwarfTaste）
//  - 試飲代の段階（tapLv）：見学ツアーの強化ボタンをやめ、Tier と評判で自動で上がる
//  - 称号：54→31（廃止23）。廃止した称号は得られなくなり、得ていれば図鑑で「過去の称号」。ヘッダーは最後に得た称号
const V55={DWARF_P:0.2,REP_STEPS:[10,25,50,100],
  TITLE_RET:['t1','t2','t2b','t2c','t2d','t3','t3b','t4b','t5b','t6','t6b','t7','t7b','t8','t15','t11b','t11c','t11d','t11e','t17','t17b','t19b','t19c']};
V55.TITLE_RET.forEach(id=>{const t=TT.find(x=>x.id===id);if(t){t.ret=true;t.ch=()=>false;}});

// ---------- 試飲代の段階：Tier ごとに4段＋評判10・25・50・100で1段ずつ（上限は tapMaxLv） ----------
function tapLv(){
  const rep=G.reputation||0;const rs=V55.REP_STEPS.filter(v=>rep>=v).length;
  const sk=((G.prestige&&G.prestige.skills&&G.prestige.skills.ps_tap_cap)||0)*2;
  return Math.max(0,Math.min(tapMaxLv(),((G.dl||1)-1)*4+rs+sk));
}

// ---------- 称号：最後に得た（廃止していない）称号 ----------
function titleLatest(){const tl=G.tl||[];for(let i=tl.length-1;i>=0;i--){const t=TT.find(x=>x.id===tl[i]);if(t&&!t.ret)return t;}return null;}
function gTitle(){const t=titleLatest();return t?t.lb:'見習い蒸留家';}
function hdTitleUpd(){setText('hdTitle',gTitle());}

// ---------- 見学のお客さん：樽に重ならない幅にする ----------
function visFit(el){
  const st=$('stage'),bb=$('bb');if(!st||!bb||!el)return;
  const r=st.getBoundingClientRect(),b=bb.getBoundingClientRect();
  const room=Math.floor(Math.min(b.left-r.left,r.right-b.right))-10;
  el.style.maxWidth=Math.max(56,room)+'px';
  el.classList.toggle('nar',room<104);
}
