// ============================================================
// v4 定数定義（詳細設計書 第3章）
// ============================================================
const BALANCE = {
  TAP_BASE: 4.5,   // v4.4: クリティカル廃止の補い（期待値1.495倍→基本額1.5倍）
  TAP_MUL: 1.5,
  TAP_COST_BASE: 12000,   // v4.6: 見学ツアーを各Tierの前半〜半ばの使い道に（旧50）
  TAP_COST_MUL: 2.2,      // v4.6（旧3）
  FAC_INC_MUL: 1.2,
  FAC_COST_MUL: 2.2,
  YEAR_EXP: 1.0,
  OFFLINE_CAP_H: 24,      // v4.6（旧8）
  TICK_MS: 250,
  SAVE_INTERVAL_MS: 10000, // v4.6（旧30秒）
  UI_REFRESH_MS: 2000,
  MAX_LV: 10,
  SCHEMA_VERSION: 20,
  APP_VERSION: '5.9.3',
  APP_DATE: '2026-10-04',
  STORAGE_PREFIX: 'we_v4:',
  BACKUP_PREFIX: 'we_v4_bak6:',
  BACKUP7_PREFIX: 'we_v4_bak7:',
  TICK_GAP_DETECT_MS: 5000,
  // --- v4 追加 ---
  TUT_REWARD: 1000,
  FINISH_YEARS: 2,               // v4.2 仕上げの樽の風味が満ちるまでの年数              // 初回チュートリアル完了の報酬
  GAME_YEAR_MS: 86400000,        // 実1日 = ゲーム内1年
  AGING_OFFLINE_CAP_H: 72,
  CAP_MUL: 1.2,                  // 工程能力の1Lvあたり倍率
  BOTTLE_L: 0.7,
  SPOT_MULT: 0.8,                // 瓶の直販
  CASK_SPOT_MULT: 0.6,           // 樽ごと直販
  TANK_BASE_L: 2000, TANK_PER_TIER_L: 1000,
  WH_BASE: 4, WH_PER_LV: 2,      // 倉庫の樽数 = 4 + 2×熟成庫Lv
  BOT_BASE_BPH: 120,             // 瓶詰め 本/時（ボトリングLv1）
  BOT_HAND_BPH: 30,              // ボトリング未稼働時の手詰め
  ORDER_BOARD_BASE: 3,
  ORDER_INTERVAL_MS: 5400000,    // 90分
  RESERVE_RATE: 0.25, RESERVE_MULT: 1.3, RESERVE_MAX_ACCEPT: 2,
  STRETCH_RATE: 0.2,
  REL_THRESH: [3, 8, 15, 25, 40],
  REL_PRICE_STEP: 0.05,
  CASK_FLAVOR_FULL_YEARS: 12,
  FLAVOR_TOL: 35,
  STAR3_MIN_MATCH: 0.5,
  COMP_BOTTLES: 6,
  BRANCH_LV: 10,
  INV_Q_STEP: 0.05,
  NEWMAKE_ORDER_MULT: 1.5,
  DEBUG_MUL: 100
};

// v4.2 設定の既定値（文字：標準、金額：英語式、音なしで開始）
const OPT_DEFAULT={fs:'m',money:'en',se:0,bgm:0,vib:true,tk:'mid',theme:'dark',motion:'std',bgmMode:'classic'};

// 品評会の再出品待ち（1日・3日・7日・14日）
[86400000, 259200000, 604800000, 1209600000].forEach((ms, i) => { if (COMPETITIONS[i]) COMPETITIONS[i].cooldownMs = ms; });

const FL_KEYS = ['smoky', 'fruity', 'spicy', 'sweet', 'floral'];
const FL_KEY_MAP = {smoky:'スモーキー', fruity:'フルーティ', spicy:'スパイシー', sweet:'スウィート', floral:'フローラル'};

const STAGES = [
  {fac:'malting',      out:'麦芽',         base:300, price:6 },
  {fac:'mashing',      out:'麦汁',         base:260, price:12},
  {fac:'fermentation', out:'もろみ',       base:230, price:20},
  {fac:'distillation', out:'ニューメイク', base:200, price:30},
]; // base: Lv1の能力L/時、price: Tier1の外販単価$/L（distMultを乗じる）

const BASE_FLAVOR = {smoky:5, fruity:40, spicy:25, sweet:40, floral:30};
const STARTER_LOTS = [
  {cask:'bourbon', size:'hogshead', L:200, age:3},
  {cask:'bourbon', size:'quarter',  L:45,  age:5},
  {cask:'sherry',  size:'hogshead', L:220, age:8},
];
const PEAT_COST = [0, 1000000, 10000000, 50000000];

const CUSTOMERS = [
  {id:'local',     name:'地元の酒販店',     icon:'🏠', tier:1, rep:0,  priceMult:1.0, repPerBtl:0.05, qty:[6,24],   dueH:[24,36],  ageAdd:0, kinds:['product','newmake']},
  {id:'bar',       name:'バー・レストラン', icon:'🍸', tier:1, rep:10, priceMult:1.4, repPerBtl:0.15, qty:[3,12],   dueH:[36,48],  ageAdd:2, kinds:['product']},
  {id:'retail',    name:'量販店',           icon:'🏪', tier:2, rep:0,  priceMult:1.1, repPerBtl:0.02, qty:[60,240], dueH:[48,72],  ageAdd:0, kinds:['product']},
  {id:'dutyfree',  name:'免税店',           icon:'✈️', tier:2, rep:0,  priceMult:1.3, repPerBtl:0.10, qty:[24,96],  dueH:[48,72],  ageAdd:0, kinds:['type']},
  {id:'importer',  name:'輸入商',           icon:'🚢', tier:3, rep:0,  priceMult:1.6, repPerBtl:0.12, qty:[36,144], dueH:[72,96],  ageAdd:0, kinds:['flavor']},
  {id:'collector', name:'コレクター',       icon:'💎', tier:4, rep:0,  priceMult:[2,3,5], repFlat:10, repPerBtl:0, qty:[1,1], dueH:[120,168], minAge:18, kinds:['cask']},
];
const CHANNEL_TO_CUST = {dtc:'local', on_trade:'bar', retail:'retail', duty_free:'dutyfree', subscribe:'retail', auction:'collector'};

const FAC_BRANCH = {
  malting:      [{id:'floor',   name:'フロアモルティング', desc:'職人が床で麦を返す伝統製法。手間はかかるが香りが豊か。', cap:0.9, q:1.03, fl:{fruity:5}},
                 {id:'drum',    name:'ドラム式',           desc:'回転ドラムで大量に均一製麦。', cap:1.2}],
  mashing:      [{id:'lauter',  name:'ラウタータン',       desc:'澄んだ麦汁を丁寧に抽出。華やかな原酒に。', fl:{fruity:6, floral:4}},
                 {id:'filter',  name:'マッシュフィルター', desc:'高効率の濾過で処理量を増やす。', cap:1.2}],
  fermentation: [{id:'wood',    name:'木桶',               desc:'木に棲む乳酸菌が複雑な香りを生む。', cap:0.9, fl:{fruity:8, floral:5}},
                 {id:'steel',   name:'ステンレス',         desc:'衛生的で安定。処理量も多い。', cap:1.2, q:1.02}],
  distillation: [{id:'straight',name:'ストレートヘッド',   desc:'重厚でオイリーな原酒になる。', q:1.05, fl:{spicy:8, sweet:5}},
                 {id:'bulge',   name:'バルジ型',           desc:'還流が多く軽快で華やかな原酒になる。', fl:{floral:8, fruity:5}}],
  maturation:   [{id:'dunnage', name:'ダンネージ式',       desc:'低層・土間の石造り。温度が安定し目減りが少ない。', angel:0.8, aging:0.9, q:1.05},
                 {id:'rack',    name:'ラック式',           desc:'高層の棚で大量に保管できる。', slots:1.5}],
  bottling:     [{id:'ncf',     name:'ノンチルフィルター', desc:'濾過を抑え原酒の厚みを残す。愛好家に高く売れる。', price:1.08, bph:0.8},
                 {id:'fast',    name:'高速ライン',         desc:'全自動の高速充填で処理量を増やす。', bph:1.5}],
};
const BRANCH_KEY_LABEL = {cap:'能力', q:'品質', angel:'目減り', aging:'熟成速度', slots:'倉庫枠', price:'単価', bph:'瓶詰め速度'};

const DL_REQ = [
  null,
  {shipped:300,    rep:15,  casks:{age:3,  n:5 }},
  {shipped:3000,   rep:40,  casks:{age:8,  n:8 }, orders:18},
  {shipped:30000,  rep:200, casks:{age:12, n:10}, rels:{lv:2, n:2}},
  {shipped:120000, rep:240, casks:{age:18, n:10}, awards:3},
];

// v5.6 創業地（気候とその地の市場）。再創業のたびに次の1地域が開く（unlockRun＝それまでの再創業の回数）。アイラ島はスコットランドにまとめた
//  tp＝地元の種類（単価×V56.LOCAL・注文が出やすい）、young＝10年未満の原酒の単価×V56.LOCAL（台湾）
const CLIMATES = [
  {id:'speyside', name:'スコットランド（スペイサイド）', short:'スコットランド', icon:'🏴', unlockRun:0, aging:1.0, angel:1.0, fl:{},          tp:'スコッチ',     desc:'冷涼で穏やか。熟成は標準。', mkt:'スコッチの単価×1.2・スコッチの注文が出やすい'},
  {id:'ireland',  name:'アイルランド',   short:'アイルランド', icon:'☘️', unlockRun:1, aging:1.0, angel:0.9, fl:{fruity:8},  tp:'アイリッシュ', desc:'湿った海風で目減りが少なく、果実の香りが育つ。', mkt:'アイリッシュの単価×1.2・アイリッシュの注文が出やすい'},
  {id:'kentucky', name:'アメリカ（ケンタッキー）', short:'ケンタッキー', icon:'🌽', unlockRun:2, aging:1.3, angel:1.8, fl:{sweet:10},  tp:'バーボン',     desc:'寒暖差が大きく熟成が速いが目減りも大きい。', mkt:'バーボンの単価×1.2・バーボンの注文が出やすい'},
  {id:'japan',    name:'日本（山間部）', short:'日本',       icon:'🗻', unlockRun:3, aging:1.1, angel:1.2, fl:{floral:10}, tp:'ジャパニーズ', desc:'四季の変化が華やかな香りを育てる。', mkt:'ジャパニーズの単価×1.2・ジャパニーズの注文が出やすい'},
  {id:'taiwan',   name:'台湾',           short:'台湾',       icon:'🌴', unlockRun:4, aging:2.0, angel:3.0, fl:{fruity:10}, tp:null, young:true, desc:'亜熱帯。熟成は極めて速いが天使の分け前も大きい。', mkt:'10年未満の原酒の単価×1.2（若くても美味しい）'},
];

const PRESTIGE_COST = 3000000000;
const AGE_MILESTONES = [3, 8, 12, 18, 25];
const AGE_BANDS = [
  {id:'all', label:'全て', min:0,  max:Infinity},
  {id:'b0',  label:'0〜2年', min:0,  max:3},
  {id:'b3',  label:'3〜7年', min:3,  max:8},
  {id:'b8',  label:'8〜11年', min:8,  max:12},
  {id:'b12', label:'12〜17年', min:12, max:18},
  {id:'b18', label:'18年〜', min:18, max:Infinity},
];
// v5.1 売り方（3年以上）と砂時計（所持99個・1日24個・入手の機会12種類）
// HG：k＝1回の個数、cap＝1日の回数の上限（なしは上限なし）、per＝納品何件ごとか、every＝連続ログイン何日ごとか
// v5.2 樽タップの小人・予約の取り消し・BGM
const V54={BGM_GAP:5};
const V53={HOUSE:'house',HOUSE_RATE:0.8,NB_CASK_AGE:8};
const V52={CANCEL_FEE:0.1,BGM_POLY:16,BGM_GAP:8,FX_MAX:6,FX_MS:600,FX_COALESCE:1500};
const V51={SELL_AGE:3,HG_BULK:[1,3,6,12],CASK_RATE:0.55,
  // 原材料：Tier1 は v5.0 と同じ価格。Tier2 で半分、Tier3 以降は「売値の倍率×K」まで上げる（K はボットで決める）
  RAW:{K:{barley:2.8,cask:17,bottle:6},RAMP2:0.5},
  GRADE:{std:{p:1,q:1,nm:'標準'},good:{p:1.5,q:1.04,nm:'上質'},best:{p:2.5,q:1.08,nm:'最上'}},
  HG:{login:{k:1,cap:1},daily:{k:3,cap:1},ms:{k:1,cap:5},ord:{k:1,cap:4,per:3},tap:{k:1,cap:5},streak:{k:3,every:7},tier:{k:5},prestige:{k:10}}};
