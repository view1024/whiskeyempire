// ============================================================
// v4.6 実機確認の反映：タップの反応・売るの流れ・放置の報告・熟成の砂時計
// ============================================================
const V46={HG_MAX:3,HG_MS:3600000,DIAG_MAX:20};

// ---------- 樽のタップ：押すたびに沈んで戻る＋金の輪 ----------
// Web Animations で毎回最初から動かす（クラスの付け外しによる強制レイアウトを避ける）
let _tapAn=[null,null];
function tapFx(){
  if(document.hidden)return;
  const img=$('bottleImg'),r=$('tring');
  _tapAn.forEach(a=>{try{if(a)a.cancel();}catch(e){}});_tapAn=[null,null];
  if(img&&img.animate){try{_tapAn[0]=img.animate([{transform:'scale(1)'},{transform:'scale(.92) translateY(4px)',offset:.35},{transform:'scale(1)'}],{duration:160,easing:'ease-out'});}catch(e){}img.dataset.hit=String((Number(img.dataset.hit)||0)+1);}
  if(r&&r.animate&&!document.documentElement.classList.contains('lowmo')&&!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)){try{_tapAn[1]=r.animate([{opacity:.95,transform:'scale(.75)'},{opacity:0,transform:'scale(1.18)'}],{duration:450,easing:'ease-out'});}catch(e){}r.dataset.hit=String((Number(r.dataset.hit)||0)+1);}
}


// ============================================================
// 売る：瓶詰め → 瓶の在庫 → 注文（v5.9 1画面。在庫の内訳は在庫の行で開く）
// ============================================================
function bqHtml(){
  const b=G.fac.bottling;const showFac=b&&(b.p||isUL('bottling'));
  const rate=botRate();let acc=0;
  let rows='';
  G.bq.forEach((q,i)=>{
    const sp=productSpec(q.pid);acc+=q.n-q.done;if(i>=3)return;
    const o=q.oid?G.orders.find(x=>x.id===q.oid):null;const c=o?custById(o.cid):null;
    rows+=`<div class="bqr"><div class="row sb"><span class="bqn">${sp?escapeHtml(sp.name):'?'} ${q.age}年 <b data-bqd="${q.id}">${fmtN(Math.floor(q.done))}/${fmtN(q.n)}本</b> → ${c?escapeHtml(c.name):'在庫へ'}</span><span class="sm" data-bqeta="${q.id}">あと${fmtRemain(acc/rate*3600000)}</span></div><div class="pbar"><i data-bq="${q.id}" style="width:${Math.min(100,q.done/q.n*100)}%"></i></div></div>`;
  });
  if(G.bq.length>3)rows+=`<div class="sm">ほか ${G.bq.length-3}件が順番待ち</div>`;
  if(!G.bq.length)rows=`<div class="pcap">瓶詰め中のものはありません</div>`;
  const bw=placeWho('fac','bottling');
  return `<div class="card bqc" id="fac_bottling"><div class="pic pxt" data-act="facTap" data-id="bottling" role="button" aria-label="ボトリングの担当">${pxSlotHtml('bottling')}${facSeat('bottling')}</div><div class="ptx" style="flex:1;min-width:0;cursor:pointer" data-act="facInfo" data-id="bottling">
    <div class="pnm">瓶詰め${brBadge('bottling')} <span class="plv">${b&&b.p?'Lv'+b.l+' ・ ':'手作業 ・ '}${fmtN(rate)}本/時${bw?' '+placeMultTxt(placeMult(bw,{k:'fac',id:'bottling'})):''} ・ 資材 ${btlFreeAvail()?'初回無料':fmtPk(btlUnit())+'/本'}</span></div>${rows}</div>
    <div class="bqbtns">${showFac?facBtnHtml('bottling'):''}<button type="button" class="sb2 gh bqadd" data-act="botOpen" data-pid="">在庫に<br>詰める</button></div></div>`;
}
function sellFlowHtml(k){
  if(k===1){const on=G.bq.length>0;return `<div class="pflow cflow${on?' run s2':''}"><span class="pband"></span><span class="pfl">在庫へ</span></div>`;}
  const on=G.bottles.length>0&&G.orders.some(o=>ordMatch(o).ok);
  return `<div class="pflow cflow${on?' run s1':''}"><span class="pband"></span><span class="pfl">注文へ</span></div>`;
}
function stockRowHtml(){
  const tot=G.bottles.reduce((a,r)=>a+r.n,0);
  const by={};G.bottles.forEach(r=>{by[r.pid]=(by[r.pid]||0)+r.n;});
  const need=new Set();G.orders.forEach(o=>{if(!ordUsable(o))return;const pred=ordRowPred(o);G.bottles.forEach(r=>{if(pred(r))need.add(r.pid);});});
  // v5.0.1 注文に使える銘柄を先に、最大2つ
  const top=Object.keys(by).sort((a,b)=>(need.has(b)-need.has(a))||(by[b]-by[a])).slice(0,need.size?Math.min(2,need.size):1);
  const chips=top.map(p=>{const sp=productSpec(p);return `<span class="stk${need.has(p)?' use':''}">${escapeHtml(sp?sp.name:'?')} ${fmtN(by[p])}本</span>`;}).join('');
  const a=G.auto.spot;
  return `<div class="cst c2${_ui.invOpen?' open':''}" data-act="invToggle" role="button" aria-expanded="${!!_ui.invOpen}" aria-label="瓶の在庫（押すと内訳）"><div class="pic ric">${ic('bottle',26)}</div><div class="ptx" style="flex:1;min-width:0">
    <div class="pnm">瓶の在庫 <span class="vv">${fmtN(tot)}本</span></div>
    <div class="stks">${chips||'<span class="sm">まだありません</span>'}</div></div><button type="button" class="sb2 fau spotb ${a.on?'':'gh'}" data-act="autoSpot" aria-pressed="${a.on}" aria-label="自動直販 ${a.on?'ON':'OFF'}">直販<br>${a.on?'ON':'OFF'}</button><span class="cgo">${_ui.invOpen?'▴':'▾'}</span></div>`;
}
// 注文ごとの用意の状況
function ordReady(o){
  const m=ordMatch(o);
  if(o.kind==='newmake')return {have:Math.min(o.qty,m.have),ip:0,need:o.qty,txt:'タンク '+fmtL(Math.min(o.qty,m.have))+'/'+fmtL(o.qty)};
  if(o.kind==='cask')return {have:Math.min(1,m.have),ip:0,need:1,txt:m.have+'樽あり'};
  const ip=G.bq.filter(q=>q.oid===o.id).reduce((a,q)=>a+(q.n-(q.moved||0)),0);
  const have=Math.min(o.qty,m.have);
  return {have,ip:Math.min(ip,o.qty-have),need:o.qty,txt:fmtN(have)+'/'+fmtN(o.qty)+'本'+(ip>0?'（瓶詰め中 '+fmtN(Math.min(ip,o.qty-have))+'）':'')};
}
function orderCardHtml(o){
  const c=custById(o.cid);const now=Date.now();
  const m=ordMatch(o);const due=o.dueAt-now;
  const qtyTxt=o.kind==='newmake'?fmtL(o.qty):o.kind==='cask'?'1樽':fmtN(o.qty)+'本';
  const rw=m.ok?'<b style="color:var(--green)">'+fmt(m.cash)+'</b>':(ordEstimate(o)>0?'約'+fmt(ordEstimate(o)):'');
  let btn='',note='';
  if(o.reserve&&!o.accepted)btn=`<button type="button" class="sb2" data-act="ordAccept" data-id="${o.id}">受注</button>`;
  else if(m.ok)btn=`<button type="button" class="sb2" data-act="${o.kind==='cask'?'ordOpen':'ordGo'}" data-id="${o.id}">${o.kind==='cask'?'樽を<br>選ぶ':'納品'}</button>`;
  else if(ordInProgress(o))note='🍾 瓶詰め中 → 自動で納品';
  else{const pl=ordFulfillPlan(o);if(pl.ok)btn=`<button type="button" class="sb2" data-act="ordFill" data-id="${o.id}">詰めて<br>納品</button>`;else{note=pl.reason||'';const w=ordAgeWait(o);if(w>0)note='年数まで あと'+fmtRemain(w);}}
  if(!btn)btn='<span class="ocd" aria-label="詳細">›</span>';
  // v5.1 倉庫の樽で詰められる数（押すと寝かせるでその樽が光る）
  const nl=m.ok?0:ordLotCount(o);const rd=ordReady(o);const pa=Math.min(100,rd.have/rd.need*100),pb=Math.min(100-pa,rd.ip/rd.need*100);
  return `<div class="oc2 ${m.ok&&ordUsable(o)?'hl':''} ${due<6*3600000?'warn':''}" data-act="ordInfo" data-id="${o.id}">
    <div class="pic ric oav">${avatar(o.cid,40)}</div><div class="ocl"><div class="oct"><span class="ocn">${escapeHtml(c.name)}</span>${o.reserve?`<span class="badge b-res">${o.accepted?'予約済':'予約×'+o.mult}</span>`:''}<span class="ocdue" data-due="${o.dueAt}" style="color:${due<6*3600000?'var(--amber)':'var(--muted)'}">${ordDueTxt(due)}</span></div>
    <div class="ocm">${escapeHtml(ordLabel(o))} × ${qtyTxt}</div>
    <div class="ocr"><span class="ocr1">${note?escapeHtml(note):rw}</span><span class="ordq" data-ordq="${o.id}">${escapeHtml(rd.txt)}</span></div>
    <div class="ordbar"><i style="width:${pa.toFixed(1)}%"></i><i class="ip" style="width:${pb.toFixed(1)}%"></i></div></div>
    <div class="ocb">${btn.includes('class="ocd"')&&nl>0?'':btn}${nl>0?`<button type="button" class="sb2 gh olots" data-act="ordLots" data-id="${o.id}" aria-label="倉庫の樽で詰められる ${nl}樽">倉庫<br>${nl}樽</button>`:''}</div></div>`;
}
// 在庫にする瓶詰めの推奨：注文に足りない銘柄（受注済みの予約 → 期限の近い順）
function ordRecs(){
  const out=[];
  G.orders.filter(o=>ordUsable(o)&&(o.kind==='product'||o.kind==='type')&&!ordInProgress(o))
    .sort((a,b)=>((b.reserve&&b.accepted)?1:0)-((a.reserve&&a.accepted)?1:0)||a.dueAt-b.dueAt)
    .forEach(o=>{
      if(out.length>=3)return;
      const m=ordMatch(o);const short=o.qty-m.have;if(short<=0)return;
      const pl=ordFulfillPlan(o);if(!pl.ok)return;
      out.push({o,pid:pl.pid,n:short,minAge:pl.minAge,est:ordEstimate(o)});
    });
  return out;
}
function ordRecsHtml(recs){
  if(!recs.length)return '';
  return `<div class="card hl brec"><div class="sm" style="color:var(--gold2)">★ 注文に足りない銘柄</div>`+recs.map(r=>{const sp=productSpec(r.pid);const c=custById(r.o.cid);
    return `<button type="button" class="brr" data-act="botRec" data-pid="${r.pid}" data-n="${r.n}" data-min="${r.minAge}"><span class="brr1">${escapeHtml(sp.name)} ${r.minAge}年以上 ・ ${fmtN(r.n)}本</span><span class="brr2">${escapeHtml(c.name)}${r.est>0?' ・ 約'+fmt(r.est):''}</span></button>`;}).join('')
    +`</div>`;
}

// ============================================================
// 放置の報告：閉じるまで保存しておき、次の起動でも出し直す（2回読み込みにも耐える）
// ============================================================
function offRepKey(){return storageKey()+':offrep';}
function offRepGet(){try{const r=localStorage.getItem(offRepKey());return r?JSON.parse(r):null;}catch(e){return null;}}
function offRepSet(info){try{localStorage.setItem(offRepKey(),JSON.stringify(info));}catch(e){}}
function offRepClear(){try{localStorage.removeItem(offRepKey());}catch(e){}}
const OFF_SUM=['elapsedMs','goals','wage','offH','earned','barleyCost','barleyStopH','newmake','filled','overflowL','bottled','delivered','arrived','expired','failed','mfgCost','ageCost','interest','repaid'];
function offRepMerge(info){
  const p=offRepGet();if(!p||p.skip||info.skip)return info;
  const o=Object.assign({},info);
  OFF_SUM.forEach(k=>{o[k]=(Number(p[k])||0)+(Number(info[k])||0);});
  o.milestones=[...new Set([...(p.milestones||[]),...(info.milestones||[])])].sort((x,y)=>x-y);
  o.capP=!!(p.capP||info.capP);o.capA=!!(p.capA||info.capA);
  return o;
}

// ---------- 起動・保存の記録（実機で原因を確かめるため。⚙️「不具合を報告」で表示） ----------
function diagKey(){try{return storageKey()+':diag';}catch(e){return 'we_v4_diag';}}
function diagLog(ev,x){
  try{const k=diagKey();const a=JSON.parse(localStorage.getItem(k)||'[]');a.push({t:Date.now(),ev,x:x===undefined?'':String(x).slice(0,60)});while(a.length>V46.DIAG_MAX)a.shift();localStorage.setItem(k,JSON.stringify(a));}catch(e){}
}
function diagText(){
  try{const a=JSON.parse(localStorage.getItem(diagKey())||'[]');
    return a.map(d=>{const t=new Date(d.t);const p=n=>String(n).padStart(2,'0');return (t.getMonth()+1)+'/'+t.getDate()+' '+p(t.getHours())+':'+p(t.getMinutes())+':'+p(t.getSeconds())+' '+d.ev+(d.x?' '+d.x:'');}).join('\n');}catch(e){return '';}
}

// ---------- 2回目以降はタイトル画面を出さずホームから ----------
function isReturning(){return !!(G&&G.tut&&(G.tut.done.first||G.tut.done.upd))||((G&&G.stats&&G.stats.orders)||0)>0;}
function autoStart(){
  if(_titleDone)return;
  _titleDone=true;
  const t=$('title');if(t)t.classList.add('h');
  applyOpt();diagLog('autostart');
  // 音は最初に画面に触れたときに鳴らし始める（ブラウザの決まり）
  const unlock=()=>{try{const c=_getCtx();if(c&&c.state==='suspended')c.resume();}catch(e){}try{if(bgmVol()>0)bgmStart();}catch(e){}};
  document.addEventListener('pointerdown',unlock,{once:true,capture:true});
  if(_celebQ.length&&!_celebOn)setTimeout(celebNext,300);
  setTimeout(()=>{try{tutCheck();}catch(e){}},400);
}

// 熟成の砂時計は v4.7 で n18_v47.js へ移した

// ---------- v4.6.1 造る・寝かせる・売るの背景の絵（時間帯はホームと同じ4段階） ----------
function tabBgSet(id){
  const el=$('tabBg');if(!el)return;
  id=id||(document.querySelector('.tab.on')||{}).id;
  const on=id==='tb'||id==='tcel'||id==='tsale';
  const c='tabbg'+(on?' on bg-'+id+' t-'+sceneTime():'');
  if(el.className!==c)el.className=c;
}
