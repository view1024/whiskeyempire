// ============================================================
// v4.9.1 ドット絵スプライト（px_sprites.js v2 を取り込み）
//  - 1文字=1ドット。'.'=透明。m:1 の行は左右反転して16文字に複製
//  - 座標は小人基準（gx0-15, gy0-19, 足元=gy19）。1ドット=SVG 3単位
//  - 陰影は自動：右か下が輪郭・透明に接するドットは暗く、左か上なら明るく（PX_NOSH は除外）
//  - 公開：workerSvg(w,x,y,act) pxCaskGrid(w,h) pxFacSvg(fac,x,y,sc,off,still) sceneStart() pxAnimateIn(root,tab,list) pxLook(w)
// ============================================================
const PX_W = 26, PX_H = 25, PX_OX = 5, PX_OY = 4, PX_FIX = {
  K: '#2a1a10',
  E: '#1a100a',
  e: '#1a100a',
  R: '#d9776a',
  M: '#8a3a2a',
  g: '#e9e2d0',
  w: '#c8862e',
  Y: '#8a6a3a',
  y: '#d8b25a',
  L: '#ffd36a',
  l: '#5a4020',
  m: '#8a6440',
  P: '#efe4c8',
  p: '#cfc2a0',
  Q: '#7a3a2a',
  B: '#6a4630',
  T: '#3a312a',
  W: '#e8dcc0',
  G: 'rgba(255,205,100,.22)',
  F: 'rgba(255,205,100,.1)',
  Z: 'rgba(0,0,0,.35)'
}, PX_NOSH = 'KEeRMgGFZOU';

const PX_SKIN = [ '#f1d2b0', '#e5bf98', '#d6a77c', '#c08b62', '#9b6a45' ], PX_HAIR = [ '#2b1d12', '#4a3020', '#7a4a22', '#a8662c', '#c9a15a', '#b0502a', '#6b6b6b', '#d8d0c0', '#efe9dc' ], PX_KNIT = [ '#7d8a6a', '#8c8577', '#9a5a44', '#5f6f7f', '#b3a283', '#6a5a48', '#4e5e4e', '#3f5a7a', '#7a4a6a', '#a0703a' ], PX_CAP = [ '#5d6b4a', '#7a7f86', '#7a3f30', '#4b5a6a', '#9a8a6a', '#3f4a3a', '#8a5a3a', '#a83a2a', '#2f5a6a', '#6a3f6a' ], PX_LEATHER = [ '#6e4a2e', '#8a5a32', '#4e3624', '#b08a5a' ], PX_SCARF = [ '#b83a3a', '#3a6ab8', '#d8a03a', '#4e8a5a', '#e8e0d0' ], PX_STRIPE = [ '#e8dcc0', '#d8b25a', '#2a2420' ];

const PXD = {
  boot: {
    y: 17,
    r: [ '..KBBBK.', '.KBBBBBK', '.KKKKKKK' ]
  },
  body: [ {
    y: 10,
    m: 1,
    r: [ '....KKNN', '...KNANN', '..KNNAAA', '..KNNAAA', '.KNNNAaa', '.KNNNAAA', '..KKaaaa' ]
  }, {
    y: 10,
    m: 1,
    r: [ '....KKWW', '...KNJWW', '..KNNJJW', '..KNNJJW', '.KNNNJJW', '.KNNNJJW', '..KKJJJJ' ]
  }, {
    y: 10,
    m: 1,
    r: [ '....KKNN', '...KNJNN', '..KNNJNN', '..KNNJNN', '.KNNNJNN', '.KJJJJJy', '..KKTTTT' ]
  } ],
  armL: {
    y: 11,
    r: [ '.KK', 'KNN', 'KNN', 'KSSK', '.KK' ]
  },
  face: {
    y: 5,
    m: 1,
    r: [ '.KHSSSSS', '.KHSSESS', '.KSRSeSS', '.KSSSSSS', '..KSSSSS', '...KKKKK' ]
  },
  noseM: {
    y: 8,
    m: 1,
    r: [ '......RR', '.......R' ]
  },
  noseF: {
    y: 8,
    m: 1,
    r: [ '.......R', '.......M' ]
  },
  fringe: {
    y: 5,
    m: 1,
    r: [ '..HHHSSS' ]
  },
  fhair: [ {
    y: 7,
    m: 1,
    r: [ 'KH......', 'KH......', 'KHK.....', '.R......' ]
  }, {
    y: 5,
    m: 1,
    r: [ 'KHH.....', 'KHH.....', 'KHH.....', 'KHH.....', 'KHHK....', '.KK.....' ]
  } ],
  beard: [ [ '..H.....', '..KHHHHH', '.KHHHIII', '..KHHHHH', '...KKKKK' ], [ '..H.....', '..KHHHHH', '.KHHHIII', '..KHHHHH', '...KHHHH', '....KHHH', '.....KKK' ], [ '..H.....', '..KHHHHH', '.KHHHIII', '..KHHHHH', '...KHHHH', '...KHHHH', '....KHHH', '.....KHH', '......KK' ], [ '..H.....', '..KHHHHH', '.KHHHIII', '..KHHHHH', '...KHHHH', '...KHHHH', '....KHHK', '....KHK.', '....KK..' ], [ '........', '....KIII', '...KI...' ] ],
  cap: [ {
    y: 0,
    m: 1,
    r: [ '.....KKK', '...KKCCC', '..KCCCCC', '..KCCCCC', '.KDDDDDD' ]
  }, {
    y: -2,
    m: 1,
    r: [ '......KK', '.....KVV', '.....KVV', '...KKCCC', '..KCCCCC', '..KCCCCC', '.KDDDDDD' ]
  }, {
    y: 1,
    m: 1,
    r: [ '...KKKKK', '..KCCCCC', '.KCCCCCC', '.KDDDDDD' ],
    x: [ {
      y: 4,
      r: [ '.KDDDDDDDDDDDDDDDDK', '...............KKK' ]
    } ]
  }, {
    y: -4,
    m: 1,
    r: [ '.......K', '......KC', '......KC', '.....KCC', '....KCCC', '...KCCCC', '..KCCCCC', '..KCCCCC', '.KDDDDDD' ]
  }, {
    y: 2,
    m: 1,
    r: [ '...KKKKK', '..KCCCCC', '.KCCCCCC' ],
    x: [ {
      y: 4,
      r: [ '..............KCK', '...............KCK', '................K' ]
    } ]
  } ],
  acc: {
    glasses: {
      y: 5,
      m: 1,
      r: [ '....OOO.', '....O.OO', '....O.O.', '....OOO.' ]
    },
    pipe: {
      y: 8,
      r: [ '............KK', '............mK', '.........YYYmK', '............KK' ]
    },
    goggles: {
      y: 2,
      m: 1,
      r: [ '...KKKKO', '..OKUUKO' ]
    },
    flower: {
      y: 1,
      r: [ '...U', '..UyU', '...U' ]
    },
    scarf: {
      y: 10,
      m: 1,
      r: [ '..KXXXXX', '..KXXXXX' ],
      x: [ {
        y: 12,
        r: [ '...........XX', '...........XK' ]
      } ]
    },
    monocle: {
      y: 5,
      r: [ '.........OOO', '.........O.O', '.........O.O', '.........OOO', '...........O', '...........O' ]
    }
  },
  lid: {
    y: 6,
    m: 1,
    r: [ '.....S..', '.....K..' ]
  },
  shadow: {
    y: 19,
    m: 1,
    r: [ '.ZZZZZZZ', '...ZZZZZ' ]
  },
  pose: {
    taste: [ [ {
      y: 11,
      r: [ '...............KgK', '...............KwK', '...............KwK', '...............KKK' ]
    } ], [ {
      y: 7,
      a: 1,
      r: [ '.........KgK', '.........KwK', '.........KwK', '.........KSSK', '..........KNNK', '...........KNNK', '............KNNK', '.............KK' ]
    } ] ],
    sweep: [ [ {
      y: 8,
      r: [ '...............Y', '...............Y', '...............Y', '...............Y', '...............Y', '...............Y', '...............Y', '...............Y', '...............Y', '..............KyyyK', '..............KyyyK', '..............KKKKK' ]
    } ], [ {
      y: 8,
      r: [ '................Y', '................Y', '................Y', '...............Y', '...............Y', '...............Y', '..............Y', '..............Y', '..............Y', '.............KyyyK', '.............KyyyK', '.............KKKKK' ]
    } ] ],
    knock: [ [ {
      y: 5,
      a: 1,
      r: [ '..............KKKKK', '..............KmmmK', '..............KKYKK', '................Y', '...............KSK', '...............KNK', '..............KNNK', '.............KNNK', '.............NNK' ]
    } ], [ {
      y: 11,
      a: 1,
      r: [ '.............KKKK.KKK', '.............NNNNKKmK', '.............NNSSYKmK', '.............KKKKKKmK', '..................KKK' ]
    } ], [ {
      y: 14,
      r: [ '...............Y', '...............Y', '..............KKK', '..............KmK', '..............KKK' ]
    } ] ],
    lamp: [ [ {
      y: 14,
      r: [ '................K', '...............KlK', '...............KLK', '...............KLK', '...............KKK' ]
    } ], [ {
      y: 14,
      r: [ '................K', '................KlK', '................KLK', '................KLK', '................KKK' ]
    } ] ],
    read: [ [ {
      y: 11,
      a: 2,
      r: [ '...KKKKKKKKKKK', '...KPPPPQPPPPK', '...KPPPPQPPPPK', '..KSQQQQQQQQQSK', '...KKKKKKKKKKK' ]
    } ], [ {
      y: 10,
      a: 2,
      r: [ '..........KK', '...KKKKKKKPPKK', '...KPPPPQPPPPK', '...KpPPPQPPPPK', '..KSQQQQQQQQQSK', '...KKKKKKKKKKK' ]
    } ] ]
  }
};

function pxHash(s, k) {
  let h = (Math.imul(s | 0, 2654435761) ^ Math.imul(k + 1, 40503)) >>> 0;
  h ^= h >>> 15;
  h = Math.imul(h, 2246822507) >>> 0;
  h ^= h >>> 13;
  return h >>> 0;
}

function pxPick(a, s, k) {
  return a[pxHash(s, k) % a.length];
}

function pxMix(h, t, k) {
  const a = parseInt(h.slice(1), 16), b = parseInt(t.slice(1), 16);
  let o = '#';
  for (const s of [ 16, 8, 0 ]) {
    const x = a >> s & 255, y = b >> s & 255;
    o += Math.round(x + (y - x) * k).toString(16).padStart(2, '0');
  }
  return o;
}

function pxPut(g, l, dx, dy, fl) {
  (l.r || []).forEach((s, i) => {
    const y = l.y + i + PX_OY + (dy || 0);
    if (y < 0 || y >= g.length) return;
    if (l.m) s = s + s.split('').reverse().join('');
    for (let j = 0; j < s.length; j++) {
      const c = s[j];
      if (c === '.' || c === ' ') continue;
      const x = (fl ? 15 - j : j) + PX_OX + (dx || 0);
      x >= 0 && x < g[0].length && (g[y][x] = c);
    }
  });
  (l.x || []).forEach(z => pxPut(g, z, dx, dy, fl));
}

function pxGrid(ls) {
  const g = Array.from({
    length: PX_H
  }, () => Array(PX_W).fill(''));
  ls.forEach(l => l && pxPut(g, l[0] || l, l[1], l[2], l[3]));
  return g;
}

function pxSvg(g, pal, tx, ty, sc) {
  const C = c => pal[c] || PX_FIX[c] || '#ff00ff', E = (x, y) => x < 0 || y < 0 || x >= g[0].length || y >= g.length || g[y][x] === '' || g[y][x] === 'K', runs = {};
  for (let y = 0; y < g.length; y++) {
    let px = null, st = 0;
    for (let x = 0; x <= g[0].length; x++) {
      let c = null;
      if (x < g[0].length && g[y][x]) {
        const L = g[y][x];
        c = C(L);
        PX_NOSH.includes(L) || c[0] !== '#' || (E(x + 1, y) || E(x, y + 1) ? c = pxMix(c, '#000000', .28) : (E(x - 1, y) || E(x, y - 1)) && (c = pxMix(c, '#ffffff', .2)));
      }
      if (c !== px) {
        px && (runs[px] = (runs[px] || '') + `M${st} ${y}h${x - st}v1h${st - x}z`);
        px = c;
        st = x;
      }
    }
  }
  return `<g transform="translate(${tx ?? -19} ${ty ?? -14}) scale(${sc || 3})">${Object.keys(runs).map(c => `<path fill="${c}" d="${runs[c]}"/>`).join('')}</g>`;
}

function pxLook(t) {
  const s = t.seed || 1, w = t === OWNER || t.id === 'owner';
  if (w) return {
    fem: 0,
    cap: 3,
    stripe: 0,
    body: 0,
    beard: 2,
    hair: 0,
    acc: 'pipe',
    pal: pxPal('#d8d0c0', '#f1d2b0', '#a83a2a', '#4e6a5a', '#9a6a3a', PX_STRIPE[0], '#c9a15a', '#9fd0d0', PX_SCARF[0])
  };
  const fem = pxHash(s, 1) % 5 === 1, cap = pxHash(s, 2) % 5, body = pxHash(s, 3) % 3, beard = fem ? -1 : pxHash(s, 4) % 5, hair = pxHash(s, 5) % 2, r = pxHash(s, 6) % 100;
  let acc = r < 40 ? '' : r < 55 ? 'glasses' : r < 65 ? fem || beard === 4 ? 'scarf' : 'pipe' : r < 77 ? cap === 3 ? '' : 'goggles' : r < 88 ? cap === 0 || cap === 1 ? 'flower' : 'monocle' : 'monocle';
  fem && acc === 'pipe' && (acc = 'scarf');
  const U = acc === 'flower' ? '#e88aa0' : acc === 'goggles' ? '#9fd0d0' : '#efe4c8';
  return {
    fem: fem,
    cap: cap,
    body: body,
    beard: beard,
    hair: hair,
    acc: acc,
    stripe: cap !== 2 && cap !== 4 && pxHash(s, 7) % 4 === 0,
    pal: pxPal(pxPick(PX_HAIR, s, 8), pxPick(PX_SKIN, s, 9), pxPick(PX_CAP, s, 10), pxPick(PX_KNIT, s, 11), pxPick(PX_LEATHER, s, 12), pxPick(PX_STRIPE, s, 13), pxHash(s, 14) % 2 ? '#c9a15a' : '#9a9a9a', U, pxPick(PX_SCARF, s, 15))
  };
}

function pxPal(H, S, C, N, A, V, O, U, X) {
  return {
    H: H,
    I: pxMix(H, '#ffffff', .25),
    S: S,
    C: C,
    D: pxMix(C, '#000000', .3),
    N: N,
    A: A,
    a: pxMix(A, '#000000', .25),
    J: A,
    V: V,
    O: O,
    U: U,
    X: X
  };
}

function pxHead(k) {
  const L = [ PXD.face ];
  k.fem ? (L.push(PXD.fringe, PXD.fhair[k.hair]), L.push(PXD.noseF)) : (L.push({
    y: 8,
    m: 1,
    r: PXD.beard[k.beard]
  }), L.push(PXD.noseM));
  k.acc === 'glasses' && L.splice(1, 0, PXD.acc.glasses), k.acc === 'monocle' && L.push(PXD.acc.monocle), 
  k.acc === 'scarf' && L.push(PXD.acc.scarf), k.acc === 'pipe' && L.push(PXD.acc.pipe);
  L.push(PXD.cap[k.cap]), k.acc === 'goggles' && L.push(PXD.acc.goggles), k.acc === 'flower' && L.push(PXD.acc.flower);
  const g = pxGrid(L);
  if (k.stripe) for (const gy of [ -3, -1, 1, 3 ]) {
    const y = gy + PX_OY;
    if (y >= 0) g[y] = g[y].map(c => c === 'C' ? 'V' : c);
  }
  return g;
}

function pxGlow() {
  const r = [];
  for (let y = -6; y <= 6; y++) {
    let s = '';
    for (let x = -6; x <= 6; x++) {
      const d = x * x + y * y;
      s += d <= 6 ? 'G' : d <= 30 ? 'F' : '.';
    }
    r.push(s);
  }
  return {
    y: 10,
    r: r.map(s => '..........' + s)
  };
}

function workerSvg(t, e, a, n) {
  const k = pxLook(t), P = k.pal, fr = (h, i) => `<g data-f="${i}"${i ? ' opacity="0"' : ''}>${h}</g>`, bt = PXD.boot, arm = [ PXD.armL, [ PXD.armL, 0, 0, 1 ] ];
  const legs = [ [ 0, 0 ], [ -1, 0 ], [ 0, -1 ] ].map((d, i) => fr(pxSvg(pxGrid([ [ bt, 0, d[0] ], [ bt, 0, d[1], 1 ] ]), P), i)).join('');
  const ps = (PXD.pose[n] || PXD.pose.sweep).map((f, i) => {
    const L = [];
    f[0].a !== 2 && L.push(...arm.filter((x, j) => !(j == 1 && f[0].a === 1)));
    f.forEach(z => L.push(z));
    return fr((n === 'lamp' ? pxSvg(pxGrid([ [ pxGlow(), i, 0 ] ]), P) : '') + pxSvg(pxGrid(L), P), i);
  }).join('');
  return `<g class="wk" data-sid="${t.id}" data-act="wkTap" transform="translate(${e - 20} ${a - 60})" role="button" aria-label="${escapeHtml(t.nm)}">\n    <rect x="-8" y="-8" width="56" height="70" fill="transparent"/>\n    <g class="wkm" style="transform-origin:20px 58px">${pxSvg(pxGrid([ PXD.shadow ]), P)}\n    <g class="wkb" style="transform-origin:20px 58px"><g class="wkL">${legs}</g>${pxSvg(pxGrid([ PXD.body[k.body] ]), P)}\n    <g class="wkh">${pxSvg(pxHead(k), P)}<g class="wke" opacity="0">${pxSvg(pxGrid([ PXD.lid ]), P)}</g><g class="wkP">${ps}</g></g>\n    </g></g></g>`;
}

const PX_CASK_DIM = {
  quarter: [ 8, 8 ],
  barrel: [ 10, 10 ],
  hogshead: [ 12, 11 ],
  butt: [ 14, 13 ],
  puncheon: [ 15, 12 ]
}, PX_CT = {
  bourbon: '#8a5a2b',
  sherry: '#8e2f5a',
  wine: '#a82f3a',
  mizunara: '#3d7a47',
  port: '#5d3f8f'
};

function pxCaskGrid(w, h) {
  const g = [], k = w >= 12 ? 2 : 1, hb = Math.max(1, Math.round(.22 * h)), mid = Math.floor(h / 2);
  // v5.0 小さい樽（クォーター）は帯の行が箍と重なるので、帯を1つ上にずらして種類の色を見せる
  const tb = (mid + 1 === h - 1 - hb || mid + 1 === hb) ? mid - 1 : mid + 1;
  for (let y = 0; y < h; y++) {
    const ins = y === 0 || y === h - 1 ? k : Math.round(k * (1 - Math.sin(Math.PI * (y + .5) / h)) * 1.4), row = Array(w).fill('');
    for (let x = ins; x < w - ins; x++) row[x] = x === ins || x === w - 1 - ins || y === 0 || y === h - 1 ? 'K' : y === hb || y === h - 1 - hb ? 'M' : y === tb ? 'T' : (x - ins) % 3 == 2 ? 'v' : 'w';
    g.push(row);
  }
  const c = Math.floor(w / 2);
  g[mid][c - 1] = 'K', g[mid][c] = 'K';
  const sh = Array(w).fill('');
  for (let x = 1; x < w - 1; x++) sh[x] = 'Z';
  g.push(sh);
  return g;
}



// ---------- 動き（WAAPI。コマ送りは step-end、1ドット単位の移動は steps()） ----------
// root の中の .wk（人）と .pxf（設備のコマ）を動かす。作った Animation は list に入れ、_tab に属するタブを持たせる
//  .wk の data-pose があればその動作、なければ workerAct。data-walk="0" なら夜の見回りでも歩かない
function pxAnimateIn(root, tab, list) {
  if (!root || !root.animate) return;
  const night = root.classList.contains('night') || root.dataset.night === '1', S = 'step-end';
  const A = (el, k, o) => {
    if (!el) return;
    try { const an = el.animate(k, Object.assign({ iterations: Infinity }, o)); an._tab = tab; list.push(an); } catch (x) {}
  };
  root.querySelectorAll('.wk').forEach((g, idx) => {
    const sid = g.dataset.sid, w = sid === 'owner' ? OWNER : staffList().find(x => x.id === sid);
    if (!w) return;
    const act = g.dataset.pose || workerAct(w, night), walk = g.dataset.walk !== '0';
    const m = g.querySelector('.wkm'), h = g.querySelector('.wkh'), eye = g.querySelector('.wke'), L = g.querySelector('.wkL'), P = g.querySelector('.wkP');
    const c = 700 * idx, q = (w.seed || 1) % 7;
    // F：子要素を1枚ずつ見せる（seq はコマ番号の並び。on を指定すると box 自体をその番号のときだけ見せる）
    const F = (box, seq, slot, on) => {
      if (!box) return;
      const fs = on ? [box] : [...box.children];
      fs.forEach((el, ix) => {
        const v = f => on ? (f === on ? 1 : 0) : (f === ix ? 1 : 0);
        const k = seq.map((f, j) => ({ offset: j / seq.length, opacity: v(f), easing: S }));
        k.push({ offset: 1, opacity: v(seq[0]) });
        A(el, k, { duration: slot * seq.length, delay: c });
      });
    };
    const bob = d => A(h, [{ transform: 'translateY(0)', easing: S }, { transform: 'translateY(3px)', offset: .5, easing: S }, { transform: 'translateY(0)' }], { duration: d, delay: c });
    const blink = () => A(eye, [{ offset: 0, opacity: 0, easing: S }, { offset: .94, opacity: 1, easing: S }, { offset: .98, opacity: 0 }, { offset: 1, opacity: 0 }], { duration: 3600 + 400 * q, delay: c + 300 * q });
    if (act === 'lamp') {
      if (walk) A(m, [{ offset: 0, transform: 'translateX(0) scaleX(1)', easing: 'steps(9,end)' }, { offset: .45, transform: 'translateX(-27px) scaleX(1)', easing: S }, { offset: .5, transform: 'translateX(-27px) scaleX(-1)', easing: 'steps(9,end)' }, { offset: .95, transform: 'translateX(0) scaleX(-1)', easing: S }, { offset: 1, transform: 'translateX(0) scaleX(1)' }], { duration: 9e3, delay: c });
      if (walk) F(L, [1, 0, 2, 0], 220);
      bob(walk ? 440 : 1600 + 90 * q); F(P, [0, 1], 560); blink();
    } else if (act === 'taste') {
      bob(1400 + 90 * q); F(P, [0, 0, 0, 0, 0, 1, 1, 1], 450); F(eye, [0, 0, 0, 0, 0, 1, 1, 1], 450, 1);
    } else if (act === 'sweep') {
      bob(1300 + 90 * q);
      if (walk) A(m, [{ offset: 0, transform: 'translateX(0)', easing: 'steps(2,end)' }, { offset: .5, transform: 'translateX(6px)', easing: 'steps(2,end)' }, { offset: 1, transform: 'translateX(0)' }], { duration: 5200, delay: c });
      F(P, [0, 1], 380); if (walk) F(L, [0, 1, 0, 2], 760); blink();
    } else if (act === 'knock') {
      bob(1500 + 90 * q); F(P, [0, 1, 0, 1, 2, 2, 2, 2, 2, 2], 260); blink();
    } else if (act === 'read') {
      bob(2600); F(P, [0, 0, 0, 0, 0, 0, 1, 1], 420); blink();
    } else if (act === 'stir') {
      bob(1200 + 90 * q); F(P, [0, 1], 500); blink();
    } else if (act === 'carry') {
      bob(900 + 60 * q); F(P, [0, 1], 450); blink();
    }
  });
  root.querySelectorAll('.pxf').forEach(g => {
    const fs = [...g.children], n = fs.length; if (n < 2) return;
    const d = Number(g.dataset.ms) || 400;
    fs.forEach((el, ix) => {
      const k = []; for (let j = 0; j < n; j++) k.push({ offset: j / n, opacity: j === ix ? 1 : 0, easing: S });
      k.push({ offset: 1, opacity: ix === 0 ? 1 : 0 });
      A(el, k, { duration: d * n });
    });
  });
}
function sceneStart() {
  if (lowMotion()) return;
  pxAnimateIn($('wScene'), 'tcel', _scene.anims);
  scenePlay();
}

// ---------- v5.0 新しいポーズ（かき混ぜる・瓶の箱を運ぶ） ----------
PXD.pose.stir = [
  [{ y: 6, r: ['................Y', '................Y', '................Y', '................Y', '................Y', '................Y', '................Y', '................Y', '................Y', '...............KBK', '...............KBK', '...............KKK'] }],
  [{ y: 7, r: ['.................Y', '.................Y', '................Y', '................Y', '................Y', '...............Y', '...............Y', '...............Y', '..............KBK', '..............KBK', '..............KKK'] }]
];
PXD.pose.carry = [
  [{ y: 10, a: 2, r: ['....w.w.w.w.w...', '...KwKwKwKwKwK..', '..KBBBBBBBBBBBK.', '..SBBBBBBBBBBBS.', '..KBBBBBBBBBBBK.', '..KKKKKKKKKKKKK.'] }],
  [{ y: 9, a: 2, r: ['....w.w.w.w.w...', '...KwKwKwKwKwK..', '..KBBBBBBBBBBBK.', '..SBBBBBBBBBBBS.', '..KBBBBBBBBBBBK.', '..KKKKKKKKKKKKK.'] }]
];

// ---------- v5.0 設備のドット絵（16×16ドット。コマを順に見せる） ----------
const PXF_PAL = { c: '#c27a3c', s: '#9aa1a9', t: '#5f666e', w: '#9a6a3a', v: '#6b4526', b: '#d8b25a', y: '#f0d58a', f: 'rgba(240,236,228,.6)', o: '#efe6d0', m: '#b08648', g: '#4f7d5c', r: '#d9c08a', h: '#e8763a', H: '#ffd36a', n: '#4a423a', p: '#b98a55' };
const PXF = {
  malting: { ms: 520, f: [
    ['................', '................', '...........w....', '..........w.....', '.........w......', '........w.......', '.......w........', '......Kt........', '.....KttK.......', '....KKbbKK......', '...KbbbbybbK....', '..KbbybbbbbbK...', '.KbbbbbbbybbbK..', 'KbbybbbbbbbbybK.', 'KKKKKKKKKKKKKKKK', 'pvpvpvpvpvpvpvpv'],
    ['................', '............w...', '...........w....', '..........w.....', '.........w......', '........w.......', '.......Kt..y....', '......KttK...y..', '.......KK.......', '....KKbbKK......', '...KbbybbbbK....', '..KbbbbbbybbK...', '.KbbybbbbbbbbK..', 'KbbbbbbybbbbbbK.', 'KKKKKKKKKKKKKKKK', 'pvpvpvpvpvpvpvpv']] },
  mashing: { ms: 600, f: [
    ['....f......f....', '.....f....f.....', '....f......f....', '................', '..KKKKKKKKKKKK..', '.KttttttttttttK.', '.KmmmmommmmmmmK.', '.KssssssssssssK.', '.KssssssssssssK.', '.KccccccccccccK.', '.KssssssssssssK.', '.KssssssssssssK.', '.KccccccccccccK.', '.KssssssssssssK.', '..KKKKKKKKKKKK..', '..KtK......KtK..'],
    ['.....f......f...', '....f......f....', '.....f......f...', '................', '..KKKKKKKKKKKK..', '.KttttttttttttK.', '.KmmmmmmmommmmK.', '.KssssssssssssK.', '.KssssssssssssK.', '.KccccccccccccK.', '.KssssssssssssK.', '.KssssssssssssK.', '.KccccccccccccK.', '.KssssssssssssK.', '..KKKKKKKKKKKK..', '..KtK......KtK..']] },
  fermentation: { ms: 480, f: [
    ['................', '.....o....o.....', '...o....o....o..', '..KKKKKKKKKKKK..', '..KooooooooooK..', '..KwwwwwwwwwwK..', '..KttttttttttK..', '..KwwvwwwwvwwK..', '..KwwwwwwwwwwK..', '..KwwwwwwwwwwK..', '..KttttttttttK..', '..KwwvwwwwvwwK..', '..KwwwwwwwwwwK..', '..KttttttttttK..', '..KKKKKKKKKKKK..', '...KvK....KvK...'],
    ['....o.....o.....', '...o....o....o..', '................', '..KKKKKKKKKKKK..', '..KooooooooooK..', '..KwwwwwwwwwwK..', '..KttttttttttK..', '..KwwvwwwwvwwK..', '..KwwwwwwwwwwK..', '..KwwwwwwwwwwK..', '..KttttttttttK..', '..KwwvwwwwvwwK..', '..KwwwwwwwwwwK..', '..KttttttttttK..', '..KKKKKKKKKKKK..', '...KvK....KvK...']] },
  distillation: { ms: 300, f: [
    ['................', '................', '................', '......KKKKKKKK..', '......KcccccccK.', '......KcKKKKKcK.', '......KcK....KcK', '....KKKcKKK..KcK', '...KcccccccK.KcK', '..KcccccccccKKtK', '.KcccyccccccKKtK', '.KccccccccccKKtK', '..KccccccccK.KtK', '...KKKKKKKK..KKK', '...KhHhhHhK.....', '..KKKKKKKKKK....'],
    ['................', '................', '................', '......KKKKKKKK..', '......KcccccccK.', '......KcKKKKKcK.', '......KcK....KcK', '....KKKcKKK..KcK', '...KcccccccK.KcK', '..KcccccccccKKtK', '.KcccyccccccKKtK', '.KccccccccccKKtK', '..KccccccccK.KtK', '...KKKKKKKK..KKK', '...KHhHHhHK.....', '..KKKKKKKKKK....']] }
};
// ボトリング：コンベアの瓶が1ドットずつ進む（5コマで1周）
(function () {
  const fr = [];
  for (let f = 0; f < 5; f++) {
    const g = Array.from({ length: 16 }, () => Array(16).fill('.'));
    const put = (x, y, c) => { if (x >= 0 && x < 16 && y >= 0 && y < 16) g[y][x] = c; };
    for (let x = 3; x <= 12; x++) put(x, 0, 'K'); put(3, 1, 'K'); put(12, 1, 'K'); for (let x = 4; x <= 11; x++) put(x, 1, 't');
    put(7, 2, 'K'); put(8, 2, 'K'); put(7, 3, 't'); put(8, 3, 'K');
    const B = ['.KK.', '.gg.', 'KggK', 'KrrK', 'KggK', 'KKKK'];
    for (let k = -1; k < 4; k++) { const x0 = k * 5 + f; B.forEach((row, j) => [...row].forEach((ch, i) => { if (ch !== '.') put(x0 + i, 7 + j, ch); })); }
    for (let x = 0; x < 16; x++) { put(x, 13, 'K'); put(x, 14, (x + f) % 2 ? 'n' : 't'); put(x, 15, 'K'); }
    fr.push(g.map(r => r.join('')));
  }
  PXF.bottling = { ms: 300, f: fr };
})();
// 設備1台のSVG（g）。x,y は左上、sc は拡大率。off（未所有・未稼働）は暗いシルエット、still は最初のコマだけ
function pxFacSvg(fac, x, y, sc, off, still) {
  const d = PXF[fac]; if (!d) return '';
  const grid = rows => rows.map(r => [...r].map(c => c === '.' ? '' : c));
  const pal = off ? Object.fromEntries(Object.keys(PXF_PAL).map(k => [k, '#3a332c'])) : PXF_PAL;
  const frames = (still || off ? d.f.slice(0, 1) : d.f).map((rows, i) => `<g${i ? ' opacity="0"' : ''}>${pxSvg(grid(rows), pal, x, y, sc)}</g>`).join('');
  return `<g class="pxf" data-ms="${d.ms}">${frames}</g>`;
}
