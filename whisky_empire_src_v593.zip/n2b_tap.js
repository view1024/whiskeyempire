// ---------- v4.5 樽のタップ：試飲代（v5.5 Tierと評判で上がる）＋毎時の外販収入の0.2%。30回で試飲会（評判+1・次の注文が30分早まる、1日5回） ----------
function tap(e){
  const v=tapValue();
  const prevUW=G.uw.length;
  earn(v,'tap');G.tt++;
  dmProgress('dm_tap');
  tasteTap();
  sndTap(false,1);vib(8);tapFx();
  if(e){
    const x=e.clientX||(e.touches&&e.touches[0]&&e.touches[0].clientX)||160;
    const y=e.clientY||(e.touches&&e.touches[0]&&e.touches[0].clientY)||300;
    showFT('+'+fmt(v),x,y,false);
  }
  updHdr();tasteUi();
  chkUnlocks();chkT();
  if(G.uw.length!==prevUW)rLight();
}
