  // ================= v5.6 追加テスト =================
  // ---------- #162 創業地（v5.6）：5つの地・順番・気候と市場（地元の種類の単価×1.2・注文が出やすい、台湾は10年未満×1.2）・売るに地域がない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      o.ids = CLIMATES.map(c => c.id + ':' + c.unlockRun).join();
      o.ire = (c => [c.aging, c.angel, c.fl.fruity, c.tp].join())(CLIMATES.find(c => c.id === 'ireland'));
      const sc = productSpec('glenlivid'), bb = productSpec('jack_d');
      G.climate = 'speyside'; prodInvalidate(); o.sp = [originPriceMult(sc, 8), originPriceMult(bb, 8)];
      G.climate = 'kentucky'; o.ke = [originPriceMult(sc, 8), originPriceMult(bb, 8)];
      G.climate = 'taiwan'; o.tw = [originPriceMult(sc, 8), originPriceMult(sc, 12), originPriceMult(bb, 9.9)];
      G.climate = 'ireland'; const f1 = newmakeFlavor().fruity; G.climate = 'speyside'; const f0 = newmakeFlavor().fruity; o.fl = f1 - f0;
      // 注文：地元の種類は2倍出やすい（乱数を等間隔に並べて数える）
      const rr = Math.random; let k = 0; Math.random = () => ((k++ % 3000) + 0.5) / 3000;
      let n = 0; for (let i = 0; i < 3000; i++) if (originPick(['a', 'b'], x => x === 'a' ? 'スコッチ' : 'バーボン') === 'a') n++;
      Math.random = rr; o.ratio = +(n / (3000 - n)).toFixed(2);
      // 売る：地域の切り替え・地域の欄がない
      G.dl = 5; _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 50));
      o.sell = [sellTabs().map(t => t[0]).join(), !document.getElementById('sp_rg') && !document.getElementById('exRegionList') && typeof buyExRegion === 'undefined' && typeof purchaseRegion === 'undefined'];
      o.chap = CHAPTERS.find(c => c.tier === 4).goals.find(g => g.id === 'c4_1').label;
      return o;
    });
    const ok = r.ids === 'speyside:0,ireland:1,kentucky:2,japan:3,taiwan:4' && r.ire === '1,0.9,8,アイリッシュ' && r.sp.join() === '1.2,1' && r.ke.join() === '1,1.2' && r.tw.join() === '1.2,1,1.2' && r.fl === 8 && Math.abs(r.ratio - 2) <= 0.05 && r.sell[0] === 'ord,inv,rel,comp' && r.sell[1] && r.chap === '取引先2社と関係を★2にする';
    rec(162, '創業地（v5.6）：スコットランド→アイルランド→ケンタッキー→日本→台湾（アイラ島はなし・アイルランドは熟成×1.0・目減り×0.9・フルーティ+8）・地元の種類の単価×1.2、その注文は2倍出やすい・台湾は10年未満の原酒×1.2・売るの「地域」と販売地域・輸出市場の購入はない・章の目標 c4_1 は取引先', ok, JSON.stringify(r));
    if (errors.length) rec('E111', '創業地のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #163 再創業（v5.6）：図鑑の「創業地」から・再創業のたびに次の地が1つ開き、新しく開いた地を初期選択・開いていない地は選べない・記録と砂時計を引き継ぐ・買った地域の倍率は消える ----------
  {
    const { page, errors, ctx } = await page43(740, null, 'late');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = { steps: [] };
      o.noSettings = !document.querySelector('#tp #prestigePanel');
      G.regions = { scotland: true, ireland: true }; G.regionsEx = ['taiwan']; const sm0 = saleMult();
      for (let i = 0; i < 4; i++) {
        G.dl = 5; G.cash = 5e11; G.te = 1e12 * (i + 1); G.hg.n = 7; rall();
        _ui.encTab = 'g'; switchTab('te'); await new Promise(r => setTimeout(r, 40));
        const btn = document.querySelector('#ep_g [data-act="prestigeOpen"]'); const enabled = btn && !btn.disabled;
        btn.click(); await new Promise(r => setTimeout(r, 40));
        const sel = document.querySelector('#mc2 .pcl.on'); const selId = sel ? sel.dataset.id : '';
        const locked = [...document.querySelectorAll('#mc2 .pcl.lk')].length;
        // 開いていない地（台湾など）を選ぼうとしても選べない
        if (i === 0) { window._pickCl('taiwan'); o.lockPick = document.querySelector('#mc2 .pcl.on').dataset.id; }
        const prev = G.climate;
        document.querySelector('#mc2 button[onclick^="execPrestige"]').click(); await new Promise(r => setTimeout(r, 60));
        o.steps.push({ enabled, selId, locked, now: G.climate, runs: G.prestige.totalRuns, prevTe: G.records[prev].te, prevRuns: G.records[prev].runs, hg: G.hg.n, sm: saleMult() });
      }
      o.sm0 = sm0;
      _ui.encTab = 'g'; switchTab('te'); await new Promise(r => setTimeout(r, 40));
      o.cards = [...document.querySelectorAll('#recList .org .badge')].map(b => b.textContent).join();
      o.aging = climate().aging;
      return o;
    });
    const ids = r.steps.map(s => s.selId).join();
    const ok = r.noSettings && r.steps.every(s => s.enabled) && ids === 'ireland,kentucky,japan,taiwan' && r.steps.map(s => s.now).join() === ids && r.steps.map(s => s.locked).join() === '3,2,1,0' && r.lockPick === 'ireland' && r.steps.map(s => s.runs).join() === '1,2,3,4' && r.steps[0].prevTe >= 1e12 && r.steps[0].prevRuns === 1 && r.steps.every(s => s.hg >= 7 && s.sm === 1) && r.sm0 > 1 && r.cards === '経営した,経営した,経営した,経営した,経営中' && r.aging === 2;
    rec(163, '再創業（v5.6）：ボタンは図鑑の「創業地」（設定にはない）・再創業のたびに次の地が1つ開き、新しく開いた地を初期選択・開いていない地は選べない・前の地の通算の売上と回数を記録・砂時計は引き継ぐ・買った販売地域の倍率は再創業で消える・図鑑に経営中・経営した', ok, JSON.stringify(r));
    if (errors.length) rec('E112', '再創業のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #164 v5.5（schema17）からの移行：アイラ島はスコットランドに（今の地・記録をまとめる）・買った地域はそのまま・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const old = JSON.parse(JSON.stringify(G)); old.ver = 17; old.climate = 'islay'; old.regions = { scotland: true }; old.regionsEx = ['france'];
      old.records = { speyside: { bestUnit: 500, maxAge: 20, tierDays: { 2: 6, 3: 18 }, runs: 1 }, islay: { bestUnit: 900, maxAge: 12, tierDays: { 2: 5, 4: 30 }, runs: 1 }, kentucky: { bestUnit: 10, maxAge: 3, tierDays: {}, runs: 1 } };
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, cl: m.climate, rec: Object.keys(m.records).join(), sp: m.records.speyside, reg: [m.regions.scotland, m.regionsEx.join()] };
      G = m; o.sm = +saleMult().toFixed(3); o.open = CLIMATES.filter(c => originOpen(c)).map(c => c.id).join();
      const key = storageKey(); const bk = 'we_v4_bak17:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.ver === SCHEMA && r.cl === 'speyside' && r.rec === 'speyside,kentucky' && r.sp.bestUnit === 900 && r.sp.maxAge === 20 && r.sp.tierDays[2] === 5 && r.sp.tierDays[3] === 18 && r.sp.tierDays[4] === 30 && r.sp.runs === 2 && r.reg[0] === true && r.reg[1] === 'france' && r.sm === 3 && r.open.includes('kentucky') && r.bk && r.loaded === SCHEMA;
    rec(164, 'v5.5（schema17）からの移行：アイラ島で経営中ならスコットランドに・アイラ島の記録はスコットランドにまとめる（高い方・早い方・回数は合計）・先に経営した地は開いたまま・買った地域の倍率は次の再創業まで残る・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E113', '移行（v18）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #165 造る（v5.5.1）：収支の見出しは固定、大麦の行から下だけがスクロール ----------
  {
    const { page, errors, ctx } = await pageW(360, 560, 'late');
    const r = await page.evaluate(async () => {
      switchTab('tb'); await new Promise(r => setTimeout(r, 150));
      const tb = document.getElementById('tb'), lv = document.getElementById('lineView'), th = tb.querySelector('.thead');
      const t0 = th.getBoundingClientRect().top; const can = lv.scrollHeight > lv.clientHeight + 1;
      lv.scrollTop = 200; await new Promise(r => setTimeout(r, 50));
      const first = lv.firstElementChild; const lvTop = lv.getBoundingClientRect().top;
      return { tbY: getComputedStyle(tb).overflowY, lvY: getComputedStyle(lv).overflowY, can, moved: lv.scrollTop > 0, thSame: Math.abs(th.getBoundingClientRect().top - t0) < 1, tbScroll: tb.scrollTop, belowHead: lvTop >= th.getBoundingClientRect().bottom - 1, firstIsBarley: first && first.id === 'barleyBox' };
    });
    const ok = r.tbY === 'hidden' && r.lvY === 'auto' && r.can && r.moved && r.thSame && r.tbScroll === 0 && r.belowHead && r.firstIsBarley;
    rec(165, '造る（v5.5.1）：収支の見出しはスクロールしない固定の場所で、大麦の行から下（生産ライン）だけがスクロールする（360×560・終盤）', ok, JSON.stringify(r));
    if (errors.length) rec('E114', '造るのスクロールのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
