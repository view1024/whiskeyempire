const { chromium } = require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const p=await b.newPage();
await p.route(/fonts/,r=>r.abort());await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1000);
await p.evaluate(()=>titleStart(false));await p.waitForTimeout(300);
console.log(JSON.stringify(await p.evaluate(()=>{_mktOff=true;Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}
 const o={cash0:G.cash,orders:G.orders.map(x=>({q:x.qty,est:Math.round(ordEstimate(x))}))};
 const ord=G.orders.find(x=>ordFulfillPlan(x).ok);ordFulfill(ord.id,{instant:true});rall();o.afterOrder=Math.round(G.cash);
 o.cv=cv();o.cuc=cuc();o.maltCost=fpc('malting');o.fuc=fuc('malting');
 G.fac.malting.l=1;prodInvalidate();o.ti1=Math.round(ti());o.tapsPerHourEq=Math.round(ti()/cv());
 o.mashing=fpc('mashing');o.tapMax=tapMaxLv();o.TAP_COST=[BALANCE.TAP_COST_BASE,BALANCE.TAP_COST_MUL];
 // mid-game ratio
 G.dl=3;FD.forEach(f=>{G.fac[f.id].p=true;G.fac[f.id].l=20;});FD.forEach(f=>G.branch[f.id]=0);G.cl=10;prodInvalidate();o.mid={cv:Math.round(cv()),ti:Math.round(ti()),ratio:Math.round(ti()/cv())};
 o.casks=CASK_TYPES.map(c=>c.id+':'+caskCost(c.id,'hogshead'));o.nmPrice=nmPrice();
 o.bottleSpec=typeof BALANCE.BOTTLE_L!=='undefined'?BALANCE.BOTTLE_L:null;
 return o;})));await b.close();})();
