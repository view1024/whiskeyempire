function toggleDebug(){
  G.dbgMul=(G.dbgMul||1)>1?1:BALANCE.DEBUG_MUL;
  prodInvalidate();
  syncDebugBtn();
  save();
  rall();
  toast(G.dbgMul>1?`検証モード ON: 生産・瓶詰め ×${G.dbgMul}`:'検証モード OFF',2500);
}
function debugAdvance(hours){
  if(!isDebugUser())return;
  if(_offlineGate)closeOfflineModal();
  shiftTime(hours*3600000);
  toast('⏩ 時間を'+hours+'時間進めました',2000);
}
function exportBackup(){
  let raw=null;
  try{const u=LIFF_USER.id||'guest';raw=localStorage.getItem('we_v4_bak14:'+u)||localStorage.getItem('we_v4_bak13:'+u)||localStorage.getItem('we_v4_bak8:'+u)||localStorage.getItem(BALANCE.BACKUP7_PREFIX+u)||localStorage.getItem(BALANCE.BACKUP_PREFIX+u)||localStorage.getItem(storageKey());}catch(e){}
  if(!raw){toast('書き出せるデータがありません',2500);return;}
  let data;try{data=btoa(unescape(encodeURIComponent(raw)));}catch(e){toast('書き出し失敗',2500);return;}
  openModal(`<div class="mt">📤 移行前のデータ</div><div class="ms">下の文字列を保管し、不具合修正後にインポートしてください</div>
    <textarea id="ioText" readonly style="width:100%;min-height:120px;padding:10px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-family:var(--fm);font-size:16px;word-break:break-all">${escapeHtml(data)}</textarea>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px"><button class="btn-cancel" data-act="closeM">閉じる</button><button class="btn-ok" data-act="ioCopy">📋 コピー</button></div>`);
}
function shareToLine(){
  if(!LIFF_USER.isLine||typeof liff==='undefined')return;
  if(!liff.isApiAvailable||!liff.isApiAvailable('shareTargetPicker')){toast('共有機能は利用できません',3000);return;}
  const msg=`🥃 Whisky Empire プレイ中!\n蒸留所: ${DL[G.dl-1].name}（Tier${G.dl}）\n最長熟成の原酒: ${Math.floor(G.stats.maxAge||0)}年\n出荷: ${fmtN(G.stats.shipped)}本 ／ 注文達成: ${G.stats.orders}件\n図鑑: ${G.uw.length}/${WL.length}\n称号: ${gTitle()}`;
  liff.shareTargetPicker([{type:'text',text:msg}]).then(()=>toast('共有しました',2000)).catch(e=>toast('共有失敗: '+e.message,3000));
}
function switchTab(id){
  if(!$(id))return;
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));
  document.querySelectorAll('#nav .nb').forEach(b=>b.classList.remove('on'));
  $(id).classList.add('on');
  if(id!=='tsale'&&_ui.invOpen){_ui.invOpen=false;_ui.invAll=false;} // v5.9 タブを移ると在庫の内訳はたたむ
  const nb=document.querySelector(`#nav .nb[data-tab="${id}"]`);if(nb)nb.classList.add('on');
  $(id).scrollTop=0;$(id).querySelectorAll('.tscroll').forEach(e=>{e.scrollTop=0;}); // v5.6.1 見出しの下の部分がスクロールする
  if(id==='te'){G.encSeen=G.uw.slice();}
  {const home=id==='td';if(document.body.classList.contains('tkoff')===home){document.body.classList.toggle('tkoff',!home);if(home)nextTicker();}} // v5.5 豆知識の帯はホームだけ
  tabBgSet(id);
  rall();
}

// 新規の data-act（詳細設計書 8.3）
function handleAct(b,e){
  const act=b.dataset.act,id=b.dataset.id;
  switch(act){
    case 'goTab': if(b.dataset.tab)switchTab(b.dataset.tab); return true;
    case 'tierOpen': openTierModal(); return true;
    case 'facInfo': openUpgModal(id); return true;
    case 'facUp': upgFac(id); return true;
    case 'facBuy': purFac(id); closeM(); rall(); return true;
    case 'ordFill': {const inst=!!(_tut&&tutStep()&&tutStep().instant);if(ordFulfill(id,{instant:inst})){closeM();}rall();return true;}
    case 'sellTab': if(id==='inv'){_ui.sellTab='ord';_ui.invOpen=true;}else _ui.sellTab=id||'ord'; rShip(); // v5.9 inv は出荷の内訳を開いた状態 {const t=$('saleBody');if(t)t.scrollTop=0;} return true;
    case 'encTab': {const k=id||'w';if(k==='fin'&&_ui.encTab!=='fin')_fin.i=0;_ui.encTab=k;renc();const eb=$('encBody');if(eb)eb.scrollTop=0;return true;}
    case 'tip': openTip(id); return true;
    case 'tkNext': closeM(); _tk.paused=false; nextTicker(); return true;
    case 'titleStart': titleStart(b.dataset.snd==='1'?true:b.dataset.snd==='0'?false:undefined); return true;
    case 'celebClose': celebClose(); return true;
    case 'chapOpen': openChapModal(); return true;
    case 'hiChap': openChapModal(); hiSeen('chap'); return true;
    case 'hiDaily': openDailyModal(); return true;
    case 'hiMkt': openMktModal(); return true;
    case 'hiTier': if(G.dl>=DL.length)toast('最大Tierに到達しています'); else openTierModal(); return true;
    case 'hiFin': _fin.i=0;_ui.encTab='fin';switchTab('te'); return true; // v5.5.1 決算書は図鑑の画面に出す
    case 'fsPrev': _fin.i++; finRender(); return true;
    case 'fsNext': _fin.i=Math.max(0,_fin.i-1); finRender(); return true;
    case 'fsView': _fin.v=b.dataset.v||'pl'; finRender(); return true;
    case 'rcpBox': openRecipeBoxModal(); return true;
    case 'barleyOpen': openBarleyModal(); return true;
    case 'barleyBuy': if(barleyBuyFull()){openBarleyModal();rall();} return true;
    case 'barleyAuto': {const on=b.dataset.v==='1';barleyState().auto=on;prodInvalidate();save();openBarleyModal();rall();toast(on?'自動仕入れ ON':'自動仕入れ OFF：在庫が切れると製麦が止まります',2500);return true;}
    case 'blendOpen': openBlendModal(); return true;
    case 'fillChoose': case 'fillPickT': openFillChooseModal('type'); rCellar(); return true;
    case 'fillPickS': openFillChooseModal('size'); rCellar(); return true;
    case 'fillSet': {if(b.dataset.k==='size')G.auto.fill.size=id;else G.auto.fill.cask=id;save();closeM();rCellar();updNavBadges();toast('🛢️ '+(b.dataset.k==='size'?caskSize(id).name:caskType(id).name)+' を選びました',1800);return true;}
    case 'finOpen': openFinishModal(id); return true;
    case 'finGo': if(lotFinish(id,b.dataset.type)){closeM();rall();} return true;
    case 'nameOpen': openNameModal(id); return true;
    case 'nameGo': {const i=$('lotNameIn');if(lotName(id,i?i.value:'')){closeM();rall();}return true;}
    case 'relEvOk': relEventApply(b.dataset.cid,Number(b.dataset.lv)); closeM(); rall(); return true;
    case 'visTap': visitorTap(b); return true;
    case 'bkOpen': openBackupModal(); return true;
    case 'bkRestore': bkRestore(Number(b.dataset.slot)); return true;
    case 'changelog': openChangelog(); return true;
    case 'bugReport': openBugReport(); return true;
    case 'credits': openCredits(); return true;
    case 'optSet': {const k=b.dataset.k;let v=b.dataset.v;if(v==='true')v=true;else if(v==='false')v=false;opt()[k]=v;applyOpt();if(k==='tk'){nextTicker();}if(k==='money'){_hcShown=null;}save();rall();return true;}
    case 'tipBook': openTipBook(); return true;
    case 'tutNext': tutNext(); return true;
    case 'tutSkip': tutEnd(false); return true;
    case 'tutReplay': tutStart(id,true); return true;
    case 'nmSell': sellNewmake(b.dataset.l==='all'?(G.tank||0):Number(b.dataset.l)); rall(); return true;
    case 'fillGo': if(fillCask(G.auto.fill.cask,G.auto.fill.size,false)){save();rall();} return true;
    case 'autoFill': G.auto.fill.on=!G.auto.fill.on; toast(G.auto.fill.on?'自動樽詰め ON':'自動樽詰め OFF',1800); save(); rCellar(); return true;
    case 'lotBand': _ui.lotBand=id||'all'; rCellar(); return true;
    case 'lotInfo': openLotModal(id); return true;
    case 'lotSell': closeM(); lotRouteAsk(id,'cask'); return true;
    case 'botOpen': openBottleModal(b.dataset.pid||null); return true;
    case 'botMode': _ui.bot.mode=b.dataset.mode; _ui.bot.sel=[]; renderBottleModal(false); return true;
    case 'botGo': if(botStart(_ui.bot.pid,_ui.bot.n,_ui.bot.mode,_ui.bot.sel,{minAge:_ui.bot.minAge||0})){closeM();rall();} return true;
    case 'botRec': {_ui.bot={pid:b.dataset.pid,n:Number(b.dataset.n)||0,mode:'young',sel:[],minAge:Number(b.dataset.min)||0};renderBottleModal(false);return true;}
    case 'hgOpen': openHgModal(); return true;
    case 'hgUse': hgUse(b.dataset.v); return true;
    case 'hgN': _ui.hgN=b.dataset.v==='all'?'all':Number(b.dataset.v);openHgModal(); return true;
    case 'blendTarget': _ui.blend.target=id; rCellar(); return true;
    case 'blendGo': if(blendStart(_ui.blend.target,_ui.blend.picks)){_ui.blend.picks.forEach(p=>{p.lotId='';p.L=0;});closeM();rCellar();} return true;
    case 'ordOpen': openOrderModal(id); return true;
    case 'ordGo': {const o=G.orders.find(x=>x.id===id);if(o&&o.kind==='cask'&&!b.dataset.lot){openOrderModal(id);return true;}if(ordDeliver(id,b.dataset.lot||null)){closeM();}rall();return true;}
    case 'ordAccept': ordAccept(id); closeM(); rall(); return true;
    case 'ordDismiss': ordDismiss(id); rall(); return true;
    case 'ordDismissM': ordDismiss(id); closeM(); rall(); return true;
    case 'ordInfo': openOrderInfoModal(id); return true;
    case 'spotSell': {const r=G.bottles.find(x=>x.id===id);if(r){spotSell(id,b.dataset.n==='all'?r.n:Number(b.dataset.n));chkT();chkUnlocks();save();rShip();updHdr();}return true;}
    case 'autoSpot': G.auto.spot.on=!G.auto.spot.on; toast(G.auto.spot.on?'自動直販 ON（'+G.auto.spot.defKeep+'本を残す）':'自動直販 OFF',2000); save(); rShip(); return true;
    case 'keepDec': G.auto.spot.defKeep=Math.max(0,G.auto.spot.defKeep-(G.auto.spot.defKeep>100?50:10)); save(); rShip(); return true;
    case 'keepInc': G.auto.spot.defKeep+=G.auto.spot.defKeep>=100?50:10; save(); rShip(); return true;
    case 'brOpen': _brUp=null; openBranchModal(b.dataset.fac); return true;
    case 'brPick': {const f=b.dataset.fac;if(brChoose(f,Number(b.dataset.idx))){closeM();if(_brUp===f){_brUp=null;upgFac(f);}rall();}return true;} // v5.9 強化から開いたときは選んだあと続けて強化
    case 'rcpOpen': openRecipeModal(b.dataset.kind); return true;
    case 'rcpPick': {const k=b.dataset.kind;if(rcpBuy(k,id)&&rcpSet(k,id)){closeM();rall();}return true;}
    case 'compOpen': openCompModal(b.dataset.comp); return true;
    case 'compGo': {const res=enterComp(b.dataset.comp,b.dataset.row);if(res){showCompResult(res);rShip();updHdr();}return true;}
    case 'dbgHour': debugAdvance(Number(b.dataset.h)||6); return true;
    case 'exportBackup': exportBackup(); return true;
  }
  return extAct(act,b,id);
}
function handleInput(el){
  const k=el.dataset.in;
  switch(k){
    case 'fillType': G.auto.fill.cask=el.value; save(); rCellar(); break;
    case 'fillSize': G.auto.fill.size=el.value; save(); rCellar(); break;
    case 'botPid': _ui.bot.pid=el.value; _ui.bot.sel=[]; _ui.bot.minAge=0; renderBottleModal(true); break;
    case 'botN': _ui.bot.n=Number(el.value)||0; updateBottlePreview(); break;
    case 'botSel': {const s=new Set(_ui.bot.sel);if(el.checked)s.add(el.value);else s.delete(el.value);_ui.bot.sel=[...s];renderBottleModal(false);break;}
    case 'blendLot': {const i=Number(el.dataset.i);const p=_ui.blend.picks[i];p.lotId=el.value;const l=G.lots.find(x=>x.id===el.value);p.L=l?Math.min(Math.floor(l.L),100):0;rCellar();break;}
    case 'optSe': opt().se=(Number(el.value)||0)/100; applyOpt(); save(); if(opt().se>0)sndPurchase(); break;
    case 'optBgm': opt().bgm=(Number(el.value)||0)/100; applyOpt(); save(); break;
    case 'blendL': {const i=Number(el.dataset.i);_ui.blend.picks[i].L=Number(el.value)||0;setText('blendLv'+i,Math.round(_ui.blend.picks[i].L)+'L');updateBlendPreview();break;}
  }
}

function bindEvents(){
  document.querySelectorAll('#nav .nb').forEach(btn=>{btn.addEventListener('click',()=>{switchTab(btn.dataset.tab);setTimeout(()=>{try{updNavBadges();tutCheck();}catch(e){}},300);});});

  const bb=$('bb');
  let _tapPending=false;
  if(window.PointerEvent){
    bb.addEventListener('pointerdown',e=>{e.preventDefault();_tapPending=true;tap(e);setTimeout(()=>{_tapPending=false;},300);});
  }
  bb.addEventListener('touchstart',e=>{e.preventDefault();if(!_tapPending){_tapPending=true;tap(e.touches[0]||e);setTimeout(()=>{_tapPending=false;},300);}},{passive:false});
  if(!window.PointerEvent){bb.addEventListener('click',e=>{if(!_tapPending)tap(e);});}

  const di=$('distInfo');if(di)di.addEventListener('click',openDistInfoModal);

  $('wg').addEventListener('click',e=>{const c=e.target.closest('.wc');if(c&&c.dataset.id)openWhiskyModal(c.dataset.id);});

  $('mo').addEventListener('click',e=>{
    if(e.target===$('mo'))return closeM();
    const b=e.target.closest('[data-act]');if(!b)return;
    const act=b.dataset.act,id=b.dataset.id;
    if(act==='upgFac')upgFac(id);
    else if(act==='closeM')closeM();
    else if(act==='ioCopy')ioCopyAction();
    else if(act==='ioApply')ioApplyAction();
    else if(act==='distConfirm')doUpgDist(Number(b.dataset.cost),Number(b.dataset.tier));
  });
  // 新規 data-act は document で一括処理（#fl の pur/upg/hist、#rgl の region、#mo の既存actは上で処理）
  const OLD_ACTS=new Set(['region','upgFac','closeM','ioCopy','ioApply','distConfirm']);
  $('coach').addEventListener('click',tutClick);
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-act]');if(!b||OLD_ACTS.has(b.dataset.act))return;
    if(b.disabled)return;
    handleAct(b,e);
  });
  document.addEventListener('change',e=>{const el=e.target.closest('[data-in]');if(el&&el.dataset.in!=='botN'&&el.dataset.in!=='blendL')handleInput(el);});
  document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='lotNameIn'){const b=document.querySelector('[data-act="nameGo"]');if(b)b.click();}});
  document.addEventListener('input',e=>{const el=e.target.closest('[data-in]');if(el&&(el.dataset.in==='botN'||el.dataset.in==='blendL'))handleInput(el);});

  $('moClose').addEventListener('click',closeM);
  $('btnExport').addEventListener('click',exportSave);
  $('btnImport').addEventListener('click',importSave);
  $('btnShare').addEventListener('click',shareToLine);
  $('btnDebug').addEventListener('click',toggleDebug);
  $('btnReset').addEventListener('click',()=>{
    showConfirm({
      title:'データをリセット',
      msg:'このユーザーのすべての進行データ（残高・施設・原酒・図鑑）が完全に削除されます。<br>この操作は取り消せません。',
      icon:'⚠️',danger:true,yesLabel:'リセット',
      onYes:()=>{
        const ok=clearStorage();
        if(!ok){toast('リセットに失敗しました',3000);return;}
        _noSave=false;_loadError=null;
        G=defState();
        if(_tut){_tut=null;tutHide();}
        postLoadInit();
        save();switchTab('td');syncDebugBtn();
        toast('データをリセットしました',2500);
        setTimeout(tutCheck,600);
      }
    });
  });
  $('confirmYes').addEventListener('click',()=>{const cb=confirmCb;hideConfirm();if(typeof cb==='function')cb();});
  $('confirmNo').addEventListener('click',hideConfirm);
}

async function init(){
  try{
    bindEvents();
    applyIcons();
    await initLiff();
    $('ldm').textContent='ゲームデータ読込中…';
    load();
    diagLog('load',G.ls?Math.round((Date.now()-G.ls)/60000)+'分前に保存':'');
    postLoadInit();
    offline();
    chkUnlocks();
    chkT();
    rall();
    generateDailyMissions();
    renderDailyPanel();
    v47Tick();
    syncDebugBtn();
    const _av=$('appVer');if(_av)_av.textContent='v'+BALANCE.APP_VERSION;
    if(!LIFF_USER.isLine){
      const lb=$('loginBanner');
      if(lb)lb.innerHTML=`<div class="banner"><span class="b-ic">ℹ️</span><span>ゲストモードで動作中。LINEからこのアプリを開くと自動でユーザー保存されます。</span></div>`;
    }
    if(_loadError){
      toast('データの読み込み・移行に失敗しました。⚙️から移行前のデータを書き出せます',6000);
    }else if(G.migratedFrom&&!G.migShown){
      if(_offlineGate)_pendingMigModal=true;else setTimeout(showMigrateModal,300);
    }

    let lastTickAt=Date.now();
    setInterval(()=>{
      if(document.hidden){lastTickAt=Date.now();return;}
      const now=Date.now();
      const gap=now-lastTickAt;
      lastTickAt=now;
      if(gap>BALANCE.TICK_GAP_DETECT_MS){offline();chkUnlocks();rall();return;}
      const dt=BALANCE.TICK_MS;
      prodTick(dt);
      lotTick(dt);
      botTick(dt);
      loanTick(dt);taxPayNow(); // v5.7
      if(G.orders.some(o=>o.autoDel))ordAutoTick();
      tickActiveEvent();
      if(G.reputation>0&&!psk('ps_rep_decay')){G.reputation=Math.max(0,G.reputation-0.05*(dt/3600000));}
      markActive();
    },BALANCE.TICK_MS);

    setInterval(()=>{
      if(document.hidden)return;
      updHdr();
      ordExpireTick(Date.now());
      ordSpawnTick(Date.now());
      if(autoSpotTick()>0){chkUnlocks();}
      rLight();
      chkUnlocks();
      chkT();
      generateDailyMissions();tickDailyMissions();
      tryTriggerRandomEvent();
      checkStoryUnlocks();
      updateRepBar();
      tutCheck();
      v42Tick();
      v47Tick();
      v48Tick();
      v49Tick();
      v50Tick();v51Tick();
      acctTick();
    },BALANCE.UI_REFRESH_MS);

    setInterval(save,BALANCE.SAVE_INTERVAL_MS);
    hideLoading();
    autoBackup(false);
    try{if(G.relEvQ)G.relEvQ=G.relEvQ.slice(-5);}catch(e){}
    setTimeout(()=>{if(isReturning()&&!_loadError)autoStart();else showTitle();},520);
  }catch(e){
    console.error('init failed:',e);
    hideLoading(String(e.message||e));
  }
}
