const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({viewport:{width:375,height:760}})).newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type()==='error' && !/ERR_FAILED/.test(m.text())) errs.push(m.text()); if(m.type()==='warning') errs.push('warn: '+m.text()); });
  await p.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await p.goto('file://' + path.resolve('whisky_empire.html')); await p.waitForTimeout(1000);
  await p.evaluate(() => { if(_offlineGate)closeOfflineModal(); closeM(); G.cash=1e7; ['malting','mashing','fermentation','distillation','maturation','bottling'].forEach(id=>{G.fac[id].p=true;G.fac[id].l=8;}); G.auto.fill.on=true; G.auto.spot.on=true; G.auto.spot.defKeep=0; G.dbgMul=100; prodInvalidate(); rall(); });
  for (const t of ['tcel','tsale','tb','td','tp','tcel']) { await p.click(`#nav .nb[data-tab="${t}"]`); await p.waitForTimeout(3000); }
  await p.click('[data-act="botOpen"]'); await p.waitForTimeout(300);
  const r = await p.evaluate(() => ({ lots: G.lots.length, tank: Math.round(G.tank), shipped: G.stats.shipped, bottled: G.stats.bottled, cash: Math.round(G.cash) }));
  await p.click('#mo [data-act="closeM"]');
  await p.click('#nav .nb[data-tab="td"]'); for (let i=0;i<30;i++) await p.click('#bb');
  await p.waitForTimeout(2500);
  const saved = await p.evaluate(() => { save(); const s = JSON.parse(localStorage.getItem(storageKey())); return { ver: s.ver, lots: s.lots.length, size: JSON.stringify(s).length }; });
  console.log(JSON.stringify(r), JSON.stringify(saved)); console.log('errors:', errs.length?errs:'none'); await b.close();
})();
