  // ================= v5.9 追加テスト =================
  // ---------- #175 売るの統合（v5.9）：切り替えは出荷・取引先・品評会・瓶詰め → 在庫 → 注文が1画面・たたんだ状態で注文の1件目が画面に収まる・在庫の行で内訳が開く・自動直販は行のボタンで切り替わる・タブを移るとたたむ ----------
  try {
    const { page, errors, ctx } = await pageW(390, 740, 'mid', false);
    const r = await page.evaluate(async () => {
      const o = {};
      _ui.sellTab = 'ord'; _ui.invOpen = false; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 120));
      o.chips = [...document.querySelectorAll('#sellChips .chip')].map(e => e.dataset.id).join();
      o.chipTxt = document.getElementById('sellChips').textContent.includes('出荷') && !document.getElementById('sellChips').textContent.includes('在庫');
      const vis = id => { const e = document.getElementById(id); return !!e && e.getClientRects().length > 0; };
      o.order = ['bqBox', 'stockRow', 'orderBoard'].map(id => Math.round(document.getElementById(id).getBoundingClientRect().top));
      o.closed = !vis('invBox') && !document.getElementById('sp_inv');
      const oc = document.querySelector('#orderBoard .oc2'); o.firstBottom = oc ? Math.round(oc.getBoundingClientRect().bottom) : 9999; o.vh = window.innerHeight;
      o.spotBtn = !!document.querySelector('#stockRow [data-act="autoSpot"]');
      // 自動直販は行のボタンで切り替わり、内訳は開かない
      const on0 = G.auto.spot.on; document.querySelector('#stockRow [data-act="autoSpot"]').click(); await new Promise(r => setTimeout(r, 60));
      o.spot = [G.auto.spot.on === !on0, !_ui.invOpen, !vis('invBox')]; document.querySelector('#stockRow [data-act="autoSpot"]').click();
      // 在庫の行を押すと内訳（残す本数・銘柄ごとの「10本」「全部」）
      document.querySelector('#stockRow .cst').click(); await new Promise(r => setTimeout(r, 60));
      o.open = [_ui.invOpen, vis('invBox'), !!document.querySelector('#invBox [data-act="keepInc"]'), document.querySelectorAll('#invBox [data-act="spotSell"]').length > 0, document.querySelector('#stockRow .cst').getAttribute('aria-expanded')];
      o.openOrder = document.getElementById('invBox').getBoundingClientRect().top < document.getElementById('orderBoard').getBoundingClientRect().top;
      // 5銘柄以上は4つと「すべて見る」
      const base = G.bottles[0]; const ex = WL.filter(w => !G.bottles.some(b => b.pid === w.id)).slice(0, 5);
      ex.forEach((w, i) => G.bottles.push({ ...base, id: 'bt_x' + i, pid: w.id, n: 5 + i }));
      rShip(); await new Promise(r => setTimeout(r, 30));
      const nb = () => document.querySelectorAll('#invBox .invb').length;
      o.top4 = [nb(), !!document.querySelector('#invBox [data-act="invAll"]')]; document.querySelector('#invBox [data-act="invAll"]').click(); await new Promise(r => setTimeout(r, 30));
      o.all = nb() === new Set(G.bottles.map(b => b.pid)).size;
      G.bottles = G.bottles.filter(b => !String(b.id).startsWith('bt_x'));
      // タブを移るとたたむ・古い「在庫」への切り替えは内訳を開いた出荷
      switchTab('tb'); switchTab('tsale'); rShip(); o.fold = [!_ui.invOpen, !vis('invBox')];
      const bt = document.createElement('button'); bt.dataset.act = 'sellTab'; bt.dataset.id = 'inv'; document.body.appendChild(bt); bt.click(); bt.remove(); await new Promise(r => setTimeout(r, 30));
      o.legacy = [_ui.sellTab, _ui.invOpen, vis('invBox')].join();
      return o;
    });
    const ok = r.chips === 'ord,rel,comp' && r.chipTxt && r.order[0] < r.order[1] && r.order[1] < r.order[2] && r.closed && r.firstBottom <= r.vh && r.spotBtn && r.spot.every(Boolean)
      && r.open.slice(0, 4).every(Boolean) && r.open[4] === 'true' && r.openOrder && r.top4[0] === 4 && r.top4[1] && r.all && r.fold.every(Boolean) && r.legacy === 'ord,true,true';
    rec(175, '売るの統合（v5.9）：切り替えは「出荷・取引先・品評会」（在庫の画面はない）・上から瓶詰め → 在庫 → 注文・たたんだ状態で注文の1件目が 390×740 の画面に収まる・在庫の行を押すと内訳（残す本数・銘柄ごとの売る）が注文の上に開く・自動直販は行のボタンで切り替わり内訳は開かない・5銘柄以上は4つと「すべて見る」・タブを移るとたたむ・古い「在庫」への切り替えは内訳を開いた出荷', ok, JSON.stringify(r));
    if (errors.length) rec('E120', '売るの統合のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C175', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
  // ---------- #176 強化のボタン（v5.9）：設備の選択が未決でも「選んで強化 $…」と名前の横の「設備選択」・押すと選ぶ小窓 → 選ぶと Lv が1上がる・札だけ押すと強化しない・未購入のボトリングは「購入」 ----------
  try {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      G.cash = 1e15; G.fac.bottling.p = true; G.fac.bottling.l = 12; G.branch.bottling = null; G.fac.mashing.l = 12; G.branch.mashing = null;
      _ui.sellTab = 'ord'; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 60));
      const btn = document.querySelector('#fac_bottling [data-act="facUp"]');
      o.btn = !!btn && btn.textContent.includes('選んで強化') && btn.textContent.includes('$') && !document.querySelector('#fac_bottling [data-act="brOpen"].pbtn');
      o.badge = !!document.querySelector('#fac_bottling .pbr[data-act="brOpen"]');
      const lv0 = G.fac.bottling.l, c0 = G.cash, uc = fuc('bottling');
      btn.click(); await new Promise(r => setTimeout(r, 60));
      o.modal = document.getElementById('mc2').textContent.includes('選んだあと') && !document.getElementById('mo').classList.contains('h');
      document.querySelector('#mo [data-act="brPick"][data-idx="1"]').click(); await new Promise(r => setTimeout(r, 60));
      o.after = [G.branch.bottling === 1, G.fac.bottling.l === lv0 + 1, Math.abs(c0 - G.cash - uc) < uc * 0.01, document.getElementById('mo').classList.contains('h')];
      o.btn2 = document.querySelector('#fac_bottling [data-act="facUp"]').textContent.includes('強化') && !document.querySelector('#fac_bottling .pbr');
      // 札だけ押す：選ぶ小窓、選んでも強化しない（造るの糖化槽）
      switchTab('tb'); rMake(); await new Promise(r => setTimeout(r, 40));
      const lvM = G.fac.mashing.l; document.querySelector('#fac_mashing .pbr').click(); await new Promise(r => setTimeout(r, 40));
      o.badgeModal = !document.getElementById('mc2').textContent.includes('選んだあと'); document.querySelector('#mo [data-act="brPick"][data-idx="0"]').click(); await new Promise(r => setTimeout(r, 40));
      o.badgeOnly = G.branch.mashing === 0 && G.fac.mashing.l === lvM;
      // 未購入のボトリングは「購入」（手作業から機械に）
      G.fac.bottling.p = false; G.fac.bottling.l = 0; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 40));
      o.buy = !isUL('bottling') || !!document.querySelector('#fac_bottling [data-act="facBuy"]');
      return o;
    });
    const ok = r.btn && r.badge && r.modal && r.after.every(Boolean) && r.btn2 && r.badgeModal && r.badgeOnly && r.buy;
    rec(176, '強化のボタン（v5.9）：設備の選択が未決でも「選んで強化 $…」を出し、名前の横に「設備選択」・押すと選ぶ小窓（選んだあと強化すると書く）→ 選ぶと続けて Lv が1上がり代金を払う・札だけ押したときは選んでも強化しない・未購入のボトリングは「購入」', ok, JSON.stringify(r));
    if (errors.length) rec('E121', '強化のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C176', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
  // ---------- #177 文字の開始位置（v5.9）：造る・寝かせる・売るの各行の名前の左端がそろう（差2px以内）・①②③がない（360・390・文字：大） ----------
  try {
    const out = {}; const errs = [];
    for (const [W, H, fsl] of [[390, 780, false], [360, 640, false], [360, 740, true]]) {
      const { page, errors, ctx } = await pageW(W, H, 'mid', fsl);
      const r = await page.evaluate(async () => {
        const o = {}; const L = s => { const e = document.querySelector(s); return e ? Math.round(e.getBoundingClientRect().left) : null; };
        switchTab('tb'); rMake(); await new Promise(r => setTimeout(r, 80));
        o.tb = [L('#barleyBox .pnm'), L('#fac_malting .pnm'), L('#fac_distillation .pnm'), L('#tankBox .pnm')];
        o.tbTxt = document.getElementById('lineView').textContent;
        switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 80));
        o.tcel = [L('#celTank .pnm'), L('#fillBox .cst2'), L('#fac_maturation .pnm')];
        o.celTxt = ['celTank', 'fillBox', 'whSummary'].map(id => document.getElementById(id).textContent).join('');
        _ui.sellTab = 'ord'; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 80));
        o.tsale = [L('#fac_bottling .pnm'), L('#stockRow .pnm'), L('#orderBoard .oc2 .ocn')];
        o.saleTxt = document.getElementById('sp_ord').textContent;
        return o;
      });
      const all = [...r.tb, ...r.tcel, ...r.tsale]; const no = /[①②③]/.test(r.tbTxt + r.celTxt + r.saleTxt);
      out[W + 'x' + H + (fsl ? 'L' : '')] = { left: all, spread: Math.max(...all) - Math.min(...all), circled: no };
      errs.push(...errors); await ctx.close();
    }
    const ok = Object.values(out).every(v => v.left.every(x => x !== null) && v.spread <= 2 && !v.circled);
    rec(177, '文字の開始位置（v5.9）：造る（大麦・設備・タンク）・寝かせる（タンクの新酒・空き樽・倉庫）・売る（瓶詰め・在庫・注文）の名前の左端の差が2px以内・①②③がない（390×780・360×640・360×740 文字：大）', ok, JSON.stringify(out));
    if (errs.length) rec('E122', '開始位置のテスト中のエラー', false, errs.slice(0, 3).join(' | '));
  } catch (e) { rec('C177', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
  // ---------- #178 ホームの瓶（v5.9・v5.9.1）：瓶詰め中でも在庫の本数・「詰め中」は出さない・1万以上は「1.2万本」 ----------
  try {
    const { page, errors, ctx } = await page43(780, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {}; switchTab('td'); rall(); await new Promise(r => setTimeout(r, 60));
      const tile = () => { const e = document.querySelector('#flow .fnode[data-tab="tsale"]'); return e ? [e.querySelector('.fv').textContent, e.querySelector('.fl2').textContent] : null; };
      const tot = G.bottles.reduce((a, b) => a + b.n, 0);
      if (!G.bq.length) G.bq.push({ id: 'bq_t', pid: G.bottles[0].pid, age: 9, n: 100, done: 0 });
      rall(); o.busy = tile(); o.exp = cntShort(tot) + '本';
      G.bq = []; rall(); o.idle = tile();
      o.short = [cntShort(9999), cntShort(12345), cntShort(250000000)].join();
      return o;
    });
    const ok = r.busy && r.busy[0] === r.exp && r.busy[1] === '瓶' && r.idle[0] === r.exp && r.idle[1] === '瓶' && r.short === '9,999,1.2万,2.5億';
    rec(178, 'ホームの瓶（v5.9・v5.9.1）：瓶詰め中でも数字は在庫の本数・下の文字は常に「瓶」（「詰め中」は出さない）・1万以上は「1.2万」', ok, JSON.stringify(r));
    if (errors.length) rec('E123', 'ホームの瓶のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C178', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
  // ---------- #179 小人の空き席（v5.9）：置ける人がいれば担当のいない設備に点線の小人と＋・全員働いていれば出ない・見出しの「待機 n」・押すと選ぶ小窓・倉庫の空き席は配置モード・初めて雇ったあと1回だけ吹き出し ----------
  try {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      G.staff = []; G.ownerAt = null; placeInvalidate(); G.hs.seatTip = 0;
      switchTab('tb'); rall(); await new Promise(r => setTimeout(r, 60));
      const exp = V50.FACS.filter(f => f !== 'bottling' && placeOk({ k: 'fac', id: f }) && !placeWho('fac', f)).length;
      o.seats = [document.querySelectorAll('#lineView .wseat').length, exp];
      v51Tick(); o.chip = (document.querySelector('#idleTb .idlec') || {}).textContent;
      o.noTip = !document.querySelector('.seattip'); // 職人を雇うまでは吹き出しを出さない
      // 空き席を押すと選ぶ小窓
      document.querySelector('#lineView .wseat').click(); await new Promise(r => setTimeout(r, 40));
      o.pick = document.getElementById('mc2').textContent.includes('に配置'); closeM();
      // 待機の札を押すと空き席が光る
      document.querySelector('#idleTb .idlec').click(); o.glow = document.body.classList.contains('seatglow');
      // 倉庫の空き席：待機が1人なら配置モード
      switchTab('tcel'); rall(); await new Promise(r => setTimeout(r, 40));
      const ls = document.querySelector('#fac_maturation .wseat'); o.lotSeat = !!ls; if (ls) { ls.click(); o.pm = !!_pm; pmEnd(); }
      // 全員が働いていれば出ない
      placeSet(OWNER, { k: 'lot', id: G.lots[0].id }); switchTab('tb'); rall(); v51Tick(); await new Promise(r => setTimeout(r, 40));
      o.none = [document.querySelectorAll('#lineView .wseat').length + (lotSeat() ? 1 : 0), document.querySelectorAll('#idleTb .idlec').length];
      // 職人を雇うと（待機）、空き席に1回だけ吹き出し
      const s = { id: 's_t', nm: 'テスト', seed: 3, r: 1, st: { waza: 3, tegiwa: 3, mekiki: 3 }, tr: 'calm', lv: 1, xp: 0, at: null, hired: Date.now(), train: 0 };
      G.staff.push(s); staffInvalidate(); placeInvalidate(); rall(); await new Promise(r => setTimeout(r, 40)); v51Tick();
      o.tip1 = [!!document.querySelector('.seattip'), G.hs.seatTip];
      document.querySelectorAll('.seattip').forEach(e => e.remove()); rall(); v51Tick(); o.tip2 = !document.querySelector('.seattip');
      o.chip2 = (document.querySelector('#idleTb .idlec') || {}).textContent;
      return o;
    });
    const ok = r.seats[0] === r.seats[1] && r.seats[0] > 0 && r.chip === '1' && r.noTip && r.pick && r.glow && r.lotSeat && r.pm && r.none.join() === '0,0' && r.tip1[0] && r.tip1[1] === 1 && r.tip2 && r.chip2 === '1';
    rec(179, '小人の空き席（v5.9）：置ける人がいれば担当のいない設備にだけ点線の小人と＋・見出しに待機の人数・空き席を押すと選ぶ小窓・待機の札を押すと空き席が光る・倉庫の空き席は配置モード（待機が1人のとき）・全員が働いていれば空き席も札も出ない・職人を雇ったあと空き席に1回だけ「押すとここで働きます」', ok, JSON.stringify(r));
    if (errors.length) rec('E124', '空き席のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C179', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
