// ============================================================
// v5.3 ハウスモルト（3年から詰められる自家銘柄）・「次の銘柄」の案内
// ============================================================
// 実装計画：https://claude.ai/code/artifact/bc48f823-2589-462f-a4c5-0cdf2819d43e
//  - 25銘柄は最低でも4年（バーボン樽だけ）・8年（ほかの樽）からなので、3〜8年の樽に「詰められる銘柄」がない時期があった
//  - ハウスモルト：どの樽でも3年から・風味を問わない・単価は Glen Corran の V53.HOUSE_RATE 倍
//    注文・図鑑・品評会には使わない（在庫・直販・瓶で売るだけ）。25銘柄に詰められる樽では自動で選ばない
//  - 吹き出し・樽の小窓・瓶詰めの小窓に「次の銘柄：◯◯（n年）まで あと◯」と「n年で知らせる」

// ---------- ハウスモルト ----------
function houseSpec(){
  if(houseSpec._s)return houseSpec._s;
  const w=WL.find(x=>x.id==='glenlivid');
  return (houseSpec._s={pid:V53.HOUSE,name:'ハウスモルト',icon:'🏠🥃',minAge:V51.SELL_AGE,casks:null,target:wlFlavor(w),minMatch:0,base:w.bs*w.ck*V53.HOUSE_RATE,tp:'ハウス',house:true});
}
function isHouse(pid){return pid===V53.HOUSE;}
// 25銘柄（解禁済み）に、3年以上ならハウスモルトを足したもの
function lotProductsH(lot){const p=lotProducts(lot);if(lotEligible(lot,houseSpec()))p.push(V53.HOUSE);return p;}
// 瓶詰めの銘柄の候補（解禁済みの25銘柄＋ハウスモルト）
function botPids(){return G.uw.concat([V53.HOUSE]);}

// ---------- 次の銘柄 ----------
// 樽の種類・風味・解禁の条件を満たす銘柄のうち、年数に届くまでが一番短いもの。
// なければ、解禁の順で一番近い銘柄（樽の種類と風味が合うもの）とその条件
function nextBrand(l){
  if(!l)return null;
  const fl=lotFlavor(l);let best=null,cask=null,lock=null;
  WL.forEach(w=>{
    const sp=productSpec(w.id);if(!sp)return;
    const ul=G.uw.includes(w.id);
    if(sp.casks&&!sp.casks.includes(l.cask)){if(ul&&l.age<V53.NB_CASK_AGE&&(!cask||sp.minAge<cask.yr))cask={pid:w.id,name:sp.name,yr:sp.minAge,tp:sp.tp};return;}
    if(sp.minMatch>0&&flavorMatch(fl,sp.target)<sp.minMatch)return;
    if(!ul)return;
    if(l.age>=sp.minAge)return;
    const eta=lotEtaAge(l,sp.minAge);
    if(!best||sp.minAge<best.yr||(sp.minAge===best.yr&&sp.base>productSpec(best.pid).base))best={kind:'age',pid:w.id,name:sp.name,yr:sp.minAge,eta};
  });
  if(!best){
    for(const r of UNLOCK_REQ){
      if(G.uw.includes(r.id))continue;const sp=productSpec(r.id);if(!sp)continue;
      if(sp.casks&&!sp.casks.includes(l.cask))continue;
      if(sp.minMatch>0&&flavorMatch(fl,sp.target)<sp.minMatch)continue;
      lock={kind:'lock',pid:r.id,name:sp.name,yr:sp.minAge,label:r.label};break;
    }
  }
  const r=best||lock||{kind:'none'};
  // バーボン樽以外で、もっと若い年数のバーボン銘柄があるときは理由を添える
  if(cask&&(r.kind!=='age'||cask.yr<r.yr))r.cask=cask;
  return r;
}
// 1行の案内（HTML）。詰められる銘柄が今あるときは ''
function nextBrandHtml(l,inModal){
  if(!l||lotProducts(l).length)return '';
  const nb=nextBrand(l);if(!nb)return '';
  let t='';
  if(nb.kind==='age'){
    const on=l.goal===nb.yr;
    t=`<span>次の銘柄：<b>${escapeHtml(nb.name)}</b>（${nb.yr}年）まで あと${fmtRemain(nb.eta)}</span>`+
      `<button type="button" class="sb2 gh wnb"${on?' disabled':''} data-act="lotNotify" data-id="${l.id}" data-v="${nb.yr}">${on?'✓ '+nb.yr+'年で知らせます':nb.yr+'年で知らせる'}</button>`;
  }else if(nb.kind==='lock')t=`<span>次の銘柄：<b>${escapeHtml(nb.name)}</b>（${nb.yr}年）は${escapeHtml(nb.label.replace(/で解禁$/,''))}で解禁</span>`;
  else t='<span>この樽の風味に合う銘柄がまだありません</span>';
  if(nb.cask)t+=`<small>${escapeHtml(nb.cask.name)}（${nb.cask.yr}年）など${escapeHtml(nb.cask.tp)}の銘柄は、バーボン樽の原酒だけ</small>`;
  return `<div class="wnx${inModal?' wnxm':''}">${t}</div>`;
}
function lotNotify(id,v){
  const l=G.lots.find(x=>x.id===id);if(!l||!lotSetGoal(id,v))return false;
  toast('🔔 '+lotShort(l)+'が'+v+'年になったら知らせます',2200);
  return true;
}

// ---------- data-act ----------
function extAct53(act,b,id){
  switch(act){
    case 'lotNotify': if(lotNotify(id,b.dataset.v)){
      const inModal=!!b.closest('#mo');
      if(inModal)openLotModal(id);else{try{rCellar();}catch(e){}const c=document.querySelector(`#wScene .wcask[data-id="${id}"]`);if(c)caskKnock(id,c);}
    } return true;
  }
  return false;
}
TIPS.push({id:'house',cat:'売る',t:'ハウスモルト',b:'蒸留所の名前で瓶詰めする銘柄です。どの樽の原酒でも3年から詰められ、風味は問いません。単価は Glen Corran の約8割（風味の一致は問わず一定）で、注文・品評会には使えず、図鑑にも数えません。25銘柄にまだ詰められない樽は、棚の吹き出しに「次の銘柄」と、その年数まであと何時間かが出ます。「n年で知らせる」を押すと、その年数を次の節目にします。'});
