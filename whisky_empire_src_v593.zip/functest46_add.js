  // ================= v4.6 追加テスト =================
  // ---------- #95-96 樽の大きさ・押せる範囲・タップの反応・見学ツアーの費用 ----------
  {
    const out = {};
    for (const [W, H] of [[393, 760], [390, 667]]) {
      const ctx = await browser.newContext({ viewport: { width: W, height: H } });
      const page = await ctx.newPage();
      await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
      await page.goto(FILE); await page.waitForTimeout(1000);
      await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(300);
      out[W + 'x' + H] = await page.evaluate(async () => {
        if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
        switchTab('td'); await new Promise(r => setTimeout(r, 200));
        const bb = document.getElementById('bb').getBoundingClientRect(); const st = document.getElementById('stage').getBoundingClientRect();
        const pad = getComputedStyle(document.getElementById('bb'), '::before'); const inset = pad.inset || pad.top;
        // 押せる範囲：絵の外側10pxも樽
        const hitOut = document.elementFromPoint(bb.left - 10, bb.top + bb.height / 2); const padHit = !!(hitOut && hitOut.closest && hitOut.closest('#bb'));
        const img = document.getElementById('bottleImg'); const ring = document.getElementById('tring');
        const res = []; for (let i = 0; i < 3; i++) { const h0 = Number(img.dataset.hit || 0), g0 = Number(ring.dataset.hit || 0); tap(null); const an = img.getAnimations ? img.getAnimations().length : 1; res.push(Number(img.dataset.hit) === h0 + 1 && Number(ring.dataset.hit) === g0 + 1 && an >= 1); await new Promise(r => setTimeout(r, 40)); }
        const over = document.getElementById('td').scrollHeight - document.getElementById('td').clientHeight;
        return { h: Math.round(bb.height), stageH: Math.round(st.height), padHit, fx: res.every(Boolean), over };
      });
      await ctx.close();
    }
    const a = out['393x760'], b = out['390x667'];
    rec(95, '樽：393×760で高さ300px・390×667で景色−70px・絵の外16pxまで押せる・押すたびに沈んで光る（連打でも毎回）・ホームは1画面', a.h === 300 && Math.abs(b.h - (b.stageH - 70)) <= 1 && a.padHit && b.padHit && a.fx && b.fx && a.over <= 0 && b.over <= 0, JSON.stringify(out));
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => { const o = []; for (const [dl, cl] of [[1, 0], [1, 3], [2, 4], [2, 7], [3, 8], [3, 9]]) { G.dl = dl; G.cl = cl; o.push(cuc()); } G.dl = 1; G.cl = 4; o.push(cuc()); return o; });
    const exp = [12000, 127776, 773302, 8229000, 39510000, 86920000];
    rec(96, '見学ツアーの費用＝$12,000×2.2^Lv×Tier倍率（上限Lvでは強化不可）', r.slice(0, 6).every((v, i) => Math.abs(v - exp[i]) / exp[i] < 0.002) && r[6] === Infinity, JSON.stringify(r));
    if (errors.length) rec('E50', '樽・ツアーのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #97 造る・寝かせる・売るに三角の矢印がない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      for (const t of ['tb', 'tcel', 'tsale']) { switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); } await new Promise(r => setTimeout(r, 120));
        const fl = [...document.querySelectorAll('#' + t + ' .pflow')]; o[t] = { n: fl.length, tri: fl.filter(e => getComputedStyle(e, '::after').display !== 'none').length, band: fl.filter(e => e.querySelector('.pband')).length }; }
      return o;
    });
    rec(97, '造る・寝かせる・売る：工程の間は動く帯だけ（三角の矢印なし）', Object.values(r).every(x => x.n >= 2 && x.tri === 0 && x.band === x.n), JSON.stringify(r));
    if (errors.length) rec('E51', '矢印テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #98-99 売る：①→②→③・用意の状況・推奨 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = G.orders.find(x => x.kind === 'product' && ordUsable(x) && !ordMatch(x).ok && ordFulfillPlan(x).ok);
      if (o) ordFulfill(o.id);
      switchTab('tsale'); _ui.sellTab = 'ord'; rShip(); await new Promise(r => setTimeout(r, 120));
      const ids = [...document.getElementById('sp_ord').children].filter(e => e.getClientRects().length).map(e => e.id);
      const nos = ['bqBox', 'stockRow'].map(id => (document.querySelector('#' + id + ' .cno') || {}).textContent);
      const bq = G.bq[0]; const bqTxt = bq ? (document.querySelector(`[data-bqd="${bq.id}"]`) || {}).textContent : '';
      const bqExp = bq ? fmtN(Math.floor(bq.done)) + '/' + fmtN(bq.n) + '本' : '';
      const bad = [];
      G.orders.forEach(x => { const el = document.querySelector(`[data-ordq="${x.id}"]`); const rd = ordReady(x); if (!el || el.textContent !== rd.txt) bad.push(x.id);
        if (x.kind === 'product' || x.kind === 'type') { const m = ordMatch(x); const ip = G.bq.filter(q => q.oid === x.id).reduce((a, q) => a + q.n - (q.moved || 0), 0); if (rd.have !== Math.min(x.qty, m.have) || rd.ip !== Math.min(ip, x.qty - rd.have)) bad.push('v' + x.id); } });
      const stock = document.querySelector('#stockRow .vv').textContent; const stockExp = fmtN(G.bottles.reduce((a, b) => a + b.n, 0)) + '本';
      // 推奨：詰めて納品と同じ銘柄・足りない本数
      const recs = ordRecs(); const recOk = recs.every(x => { const pl = ordFulfillPlan(x.o); return pl.ok && pl.pid === x.pid && x.n === x.o.qty - ordMatch(x.o).have && pl.minAge === x.minAge; });
      openBottleModal(''); const mt = document.getElementById('mc2');
      const rec0 = recs[0]; const modalOk = !rec0 || (mt.querySelectorAll('.brr').length === recs.length && _ui.bot.pid === rec0.pid && _ui.bot.n === rec0.n && _ui.bot.minAge === rec0.minAge && mt.querySelector('select option').textContent.startsWith('★注文'));
      closeM();
      return { ids, nos, bqTxt, bqExp, bad, stock, stockExp, recN: recs.length, recOk, modalOk };
    });
    rec(98, '売る：上から「① 瓶詰め → ② 瓶の在庫 → ③ 注文」、瓶詰めは何本できたか、注文ごとに用意の本数（在庫・瓶詰め中）が内部の数と一致', r.ids.join() === 'bqBox,sellF1,stockRow,sellF2,orderBoard,orderNext' && r.nos.join() === '①,②' && r.bqTxt === r.bqExp && r.bad.length === 0 && r.stock === r.stockExp, JSON.stringify(r));
    rec(99, '在庫に詰める：注文に足りない銘柄を「詰めて納品」と同じ選び方で推奨し、本数と年数条件を入れて開く', r.recOk && r.modalOk, JSON.stringify({ recN: r.recN, recOk: r.recOk, modalOk: r.modalOk }));
    if (errors.length) rec('E52', '売るテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #100 読み物は中央・決算書は図鑑の記録 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('te'); const s = STORY_EPISODES[0].id; if (!G.story.unlocked.includes(s)) G.story.unlocked.push(s); openStoryModal(s); await new Promise(r => setTimeout(r, 80));
      const mb = document.querySelector('#mo .mb').getBoundingClientRect(); const cy = mb.top + mb.height / 2; const story = { cy: Math.round(cy), vh: innerHeight, close: !!document.querySelector('#mc2 [data-act="closeM"]') };
      closeM(); const after = document.getElementById('mo').classList.contains('ctr');
      openOrderInfoModal(G.orders[0].id); const mb2 = document.querySelector('#mo .mb').getBoundingClientRect(); const sheet = Math.round(innerHeight - mb2.bottom); closeM();
      openTip('order'); const tip = document.getElementById('mo').classList.contains('ctr'); closeM();
      _ui.encTab = 'r'; renc(); const card = document.querySelector('#recList .frec'); const first = document.getElementById('recList').firstElementChild === card;
      card.click(); await new Promise(r => setTimeout(r, 60)); const fin = document.getElementById('mc2').textContent.includes('決算書') && !!document.getElementById('finBox'); closeM();
      switchTab('td'); rdistLight(); const icons = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id).join();
      return { story, after, sheet, tip, first, fin, icons };
    });
    rec(100, '物語・ヒント・会話の小窓は画面中央（閉じるボタン付き）、操作の小窓は下から・決算書は図鑑の記録の先頭から開き、ホームのアイコンは章・デイリー・市場・Tier・砂時計', Math.abs(r.story.cy - r.story.vh / 2) <= 24 && r.story.close && !r.after && r.sheet <= 1 && r.tip && r.first && r.fin && r.icons === 'hi_chap,hi_daily,hi_mkt,hi_tier,hi_hg', JSON.stringify(r));
    if (errors.length) rec('E53', '小窓テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #101-102 放置24時間・報告の出し直し・タイトル省略・記録 ----------
  {
    const p0 = await page43(667, null, 'mid');
    const r0 = await p0.page.evaluate(() => {
      if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = [];
      const f = prodFlows(); barleyState().auto = true; G.cash = 1e9; const te0 = G.te; G.ls = Date.now() - 30 * 3600000; offline();
      const shown = _offlineGate; const txt = document.getElementById('mc2').textContent; const pend = offRepGet();
      return { cap: BALANCE.OFFLINE_CAP_H, shown, cap24: txt.includes('24時間分'), pend: !!pend && pend.elapsedMs > 29 * 3600000, notice: txt.includes('20歳未満') };
    });
    // 報告を閉じずに再読込 → 起動時に出し直す・タイトルは出さない
    await p0.page.evaluate(() => { save(); });
    await p0.page.reload(); await p0.page.waitForTimeout(1600);
    const r1 = await p0.page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), titleDone: _titleDone, gate: _offlineGate, txt: document.getElementById('mc2').textContent.includes('おかえり'), diag: diagText() }));
    await p0.page.evaluate(() => { closeOfflineModal(); save(); });
    const r2 = await p0.page.evaluate(() => ({ pend: offRepGet(), bug: bugReportText().includes('起動と保存の記録') }));
    await p0.page.reload(); await p0.page.waitForTimeout(1600);
    const r3 = await p0.page.evaluate(() => ({ gate: _offlineGate }));
    await p0.ctx.close();
    rec(101, '放置：生産は24時間分まで・報告は閉じるまで保存し、再読込でも出し直す（閉じたら出ない）・注意書き付き', r0.cap === 24 && r0.shown && r0.cap24 && r0.pend && r0.notice && r1.gate && r1.txt && r2.pend === null && !r3.gate, JSON.stringify({ r0, r1: { gate: r1.gate, txt: r1.txt }, r3 }));
    rec(102, '2回目以降の起動はタイトル画面を出さずホームから・起動と保存の記録を「不具合を報告」に表示', !r1.title && r1.titleDone && /load/.test(r1.diag) && /offline/.test(r1.diag) && r2.bug, JSON.stringify({ title: r1.title, diag: r1.diag }));
    const ctx4 = await browser.newContext({ viewport: { width: 390, height: 667 } }); const pg4 = await ctx4.newPage();
    await pg4.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort()); await pg4.goto(FILE); await pg4.waitForTimeout(1500);
    const r4 = await pg4.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), done: _titleDone }));
    rec('102b', '新しく始める人にはタイトル画面を出す', r4.title && !r4.done, JSON.stringify(r4));
    await ctx4.close();
  }
  // ---------- #103 熟成の砂時計 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.hg = { n: 0, got: 0, used: 0 };
      const a = [hgAdd(1, 't'), hgAdd(1, 't'), hgAdd(1, 't'), hgAdd(1, 't')]; const n3 = G.hg.n;
      // デイリー全達成・章の目標で入手
      G.hg.n = 0; G.daily.allCleared = false; G.daily.missions.forEach(m => { m.done = false; G._dmProgress[m.id] = m.target; }); tickDailyMissions(); const daily = G.hg.n;
      G.hg.n = 0; const c = chapCur(), st = chapState(); c.goals.forEach(g => { delete st.done[g.id]; }); G.stats.shipped = 1e9; G.stats.orders = 1e6; G.stats.filled = 1e6; checkChapters(); const chap = G.hg.n;
      // 使う：1時間分進む（熟成・注文の期限）
      G.hg.n = 1; const l = G.lots[0]; const age0 = l.age; const due0 = G.orders[0] ? G.orders[0].dueAt : 0; const now = Date.now();
      const due1h = G.orders.filter(o => o.dueAt - now <= 3600000 && (!o.reserve || o.accepted)).length;
      openHgModal(); const warn = document.getElementById('mc2').textContent.includes('期限が1時間以内'); closeM();
      const ok = hgUse(); const title = document.getElementById('mc2').textContent; const dAge = l.age - age0; const dDue = G.orders[0] ? due0 - G.orders[0].dueAt : 3600000;
      const pend = offRepGet(); if (_offlineGate) closeOfflineModal();
      const none = hgUse();
      return { a, n3, daily, chap, ok, used: G.hg.used, dAge, rate: agingRate(l) / 24, dDue, title: title.includes('1時間進めました'), pend, none, warn, due1h, icon: document.querySelector('#hi_hg .hib') ? document.querySelector('#hi_hg .hib').textContent : '' };
    });
    rec(103, '砂時計：デイリー全達成・章の目標で1個ずつ・3個まで・1個で1時間分（熟成と注文の期限が1時間進む）・期限が近い注文を警告・報告は保存しない', r.a.join() === 'true,true,true,false' && r.n3 === 3 && r.daily >= 1 && r.chap >= 1 && r.ok && r.used === 1 && Math.abs(r.dAge - r.rate) / r.rate < 0.02 && Math.abs(r.dDue - 3600000) < 5000 && r.title && r.pend === null && r.none === false && (r.due1h === 0 || r.warn), JSON.stringify(r));
    if (errors.length) rec('E54', '砂時計テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #104 v4.6.1 造る・寝かせる・売るの背景の絵 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te']) { switchTab(t); await new Promise(r => setTimeout(r, 60)); const el = document.getElementById('tabBg'); const cs = getComputedStyle(el); o[t] = { on: el.classList.contains('on'), time: el.classList.contains('t-' + sceneTime()), img: /data:image\/webp/.test(cs.backgroundImage), disp: cs.display }; }
      return o;
    });
    const ok = ['tb', 'tcel', 'tsale'].every(t => r[t].on && r[t].time && r[t].img && r[t].disp === 'block') && ['td', 'te'].every(t => !r[t].on && r[t].disp === 'none');
    rec(104, '造る・寝かせる・売るの背景にそれぞれの絵を表示し、時間帯の段階をホームと同じにする（ホーム・図鑑には出さない）', ok, JSON.stringify(r));
    if (errors.length) rec('E55', '背景テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #105 v4.6.3 ファイルサイズの削減（画像の再圧縮・最小化・未使用関数の削除） ----------
  {
    const fs = require('fs');
    const dist = fs.readFileSync('whisky_empire.html', 'utf8');
    const dev = fs.existsSync('whisky_empire.dev.html') ? fs.readFileSync('whisky_empire.dev.html', 'utf8') : '';
    const main = h => [...h.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]).reduce((a, b) => (b.length > a.length ? b : a), '');
    const liff = h => (h.match(/<script id="liff-config">[\s\S]*?<\/script>/) || [''])[0];
    const DEAD = ['sceneSvg', 'sndKnock', 'chapCardHtml', 'finNew', 'modalCenter', 'upgDist', 'actAttrs', 'rTank', 'openHistModal', 'nextTicker_old', 'initTicker_old', 'sndAuction', 'toggleSound', 'getPrestigeSkillEffect', 'applyPrestigeSkills', 'currentRegion', 'exRegionMult'];
    const left = DEAD.filter(n => new RegExp('function ' + n + '\\(').test(dist) || new RegExp('function ' + n + '\\(').test(dev));
    const md = main(dist), mv = main(dev);
    const s = { bytes: Buffer.byteLength(dist), left, ratio: +(md.length / Math.max(1, mv.length)).toFixed(3), strict: /^\s*['"]use strict['"]/.test(md), liffSame: !!dev && liff(dist) === liff(dev) && liff(dist).includes('LIFF_ID') };
    const { page, errors, ctx } = await page43(667, null, 'mid');
    s.img = await page.evaluate(async () => {
      const o = {};
      for (const k of ['tb', 'tcel', 'tsale']) {
        const d = document.createElement('div'); d.className = 'tabbg bg-' + k; document.body.appendChild(d);
        const u = getComputedStyle(d).backgroundImage.match(/url\("?(data:[^")]+)"?\)/); d.remove();
        const im = new Image(); im.src = u ? u[1] : ''; try { await im.decode(); } catch (_) {}
        o[k] = im.naturalWidth;
      }
      return o;
    });
    const ok = s.bytes <= 760000 && left.length === 0 && s.ratio < 0.92 && s.strict && s.liffSame && ['tb', 'tcel', 'tsale'].every(k => s.img[k] === 800);
    rec(105, '配布版は760KB以下：タブの背景は幅800px・JSとCSSは最小化（use strict と LIFF 設定はそのまま）・未使用の関数17個は開発版にも残っていない', ok, JSON.stringify(s));
    if (errors.length) rec('E56', 'サイズ削減テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
