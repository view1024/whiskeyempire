// ============================================================
// v4.7 待ち時間を楽しむ：砂時計の調整・樽の目標と節目・倉庫日誌
// ============================================================
const V47={HG_MAX:99,HG_DAY_USE:24,JNL_MAX:14,JNL_DONE_MAX:5,DONE_SHOW_MS:12*3600000};
// 日付は Date.now() から作る（ボットや試験で時計を進めたときも日が替わるように）
function dayNum(k){const p=String(k).split('-').map(Number);return p.length===3&&p.every(isFinite)?Date.UTC(p[0],p[1]-1,p[2])/864e5:0;}
function dayKey(ts){const d=new Date(ts===undefined?Date.now():ts);return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();}

// ---------- 熟成の砂時計：1個で1時間（据え置き）・99個まで・1日24個まで（v5.1）。入手の機会は V51.HG ----------
const HG_DAILY=['login','daily','ms','ord','tap'];
function hgSrc0(){return {login:0,daily:0,ms:0,ord:0,tap:0};}
function monthKey(ts){const d=new Date(ts===undefined?Date.now():ts);return d.getFullYear()+'-'+(d.getMonth()+1);}
function hgState(){
  if(!G.hg||typeof G.hg!=='object')G.hg={n:0,got:0,used:0};
  const h=G.hg;
  if(typeof h.day!=='string')h.day='';
  if(!(h.useDay>=0))h.useDay=0;
  if(!h.src||typeof h.src!=='object')h.src=hgSrc0();
  HG_DAILY.forEach(k=>{if(!(h.src[k]>=0))h.src[k]=0;});
  if(!(h.ordN>=0))h.ordN=0;
  if(!h.streak||typeof h.streak!=='object')h.streak={d:'',n:0};
  if(typeof h.month!=='string')h.month=monthKey();
  return h;
}
function hgDay(){const h=hgState();const t=dayKey();if(h.day!==t){h.day=t;h.useDay=0;h.src=hgSrc0();}return h;}
// src：入手の機会（V51.HG のキー）。1日の回数に上限がある機会は、上限に達したら受け取らない
function hgAdd(k,why,src,quiet){
  const h=hgDay();const d=src&&V51.HG[src];
  if(d&&d.cap){if((h.src[src]||0)>=d.cap)return false;h.src[src]=(h.src[src]||0)+1;}
  if(h.n>=V47.HG_MAX){if(!_offlineRunning)toast('⏳ 砂時計が'+V47.HG_MAX+'個です。使ってから受け取りましょう（'+why+'の分は受け取れませんでした）',3600);return false;}
  const add=Math.min(k,V47.HG_MAX-h.n);
  h.n+=add;h.got+=add;
  if(!_offlineRunning&&!quiet)toast('⏳ 砂時計 +'+add+'（'+why+'） '+h.n+'/'+V47.HG_MAX+(h.n>=V47.HG_MAX?' ・ 上限です':''),3200);
  return true;
}
// 注文の納品：3件ごとに1個（1日 V51.HG.ord.cap 個まで）
function hgOrdDone(){const h=hgDay();h.ordN=(h.ordN||0)+1;if(h.ordN>=V51.HG.ord.per){h.ordN-=V51.HG.ord.per;hgAdd(V51.HG.ord.k,'注文の納品','ord',true);}}
function hgLeftToday(){const h=hgDay();return Math.max(0,V47.HG_DAY_USE-h.useDay);}
function hgDueList(ms){const now=Date.now();ms=ms||V46.HG_MS;return G.orders.filter(o=>o.dueAt-now<=ms&&(!o.reserve||o.accepted));}
// 小窓の一覧：短い名前と今日の回数（上限のない機会は個数だけ）
const HG_SRC_LBL=[['login','ログイン'],['streak','連続ログイン7日ごと'],['daily','デイリー全達成'],['ms','節目の年数になった樽'],['ord','納品3件ごと'],['tap','樽の小人（試飲会）'],['tier','Tierの昇格'],['prestige','再創業']];
function hgSrcList(){return HG_SRC_LBL;}
function hgSel(){const left=Math.min(hgState().n,hgLeftToday());let n=(_ui.hgN==='all')?left:(_ui.hgN||1);return Math.max(0,Math.min(n,left));}
function openHgModal(){
  const h=hgDay();const left=hgLeftToday();const mx=Math.min(h.n,left);const sel=hgSel();
  const src=hgSrcList().map(([k,l])=>{const d=V51.HG[k];const c=h.src[k]||0;const full=d.cap&&c>=d.cap;return `<span class="hgs${full?' ok':''}">${full?'✓':''}${escapeHtml(l)} +${d.k}${d.cap?' <em>'+c+'/'+d.cap+'</em>':''}</span>`;}).join('');
  const due=sel>0?hgDueList(sel*V46.HG_MS):[];
  const chips=V51.HG_BULK.map(n=>`<button type="button" class="chip${_ui.hgN===n||(!_ui.hgN&&n===1)?' on':''}" data-act="hgN" data-v="${n}" ${n>mx?'disabled':''}>${n}個</button>`).join('')+`<button type="button" class="chip${_ui.hgN==='all'?' on':''}" data-act="hgN" data-v="all" ${mx>0?'':'disabled'}>残り全部（${mx}）</button>`;
  openModal(`<div class="mt">⏳ 熟成の砂時計 ${ib('hourglass')}</div>
    <div class="card"><div class="row sb"><span class="tt">持っている数</span><span class="vv">${h.n} / ${V47.HG_MAX}</span></div>
      <div class="row sb" style="margin-top:4px"><span class="sm">今日使える数</span><span class="vv" data-hgleft>あと${left}個</span></div></div>
    <div class="chips hgb">${chips}</div>
    ${sel>0?`<div class="sm hgpv">熟成 +${sel}時間（${(sel/24).toFixed(2)}年）・注文の期限も進む</div>`:''}
    ${due.length>0?`<div class="card warn"><div class="sm" style="color:var(--amber)">⚠ 期限が切れる注文 ${due.length}件（${due.slice(0,3).map(o=>escapeHtml(custById(o.cid).name)).join('・')}${due.length>3?' ほか':''}）</div></div>`:''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"><button type="button" class="btn-cancel" data-act="closeM">閉じる</button><button type="button" class="btn-ok" data-act="hgUse" data-v="${sel}" ${sel>0?'':'disabled'}>${left<=0?'今日は使い切りました':h.n<=0?'持っていません':sel+'時間進める'}</button></div>
    <details class="fold"><summary><span class="sm">手に入れ方（今日）</span></summary><div class="hgsl">${src}</div></details>`);
}
// n 個をまとめて使う：n 時間を1回で進め、放置と同じ形の報告を出す
function hgUse(n){
  n=Math.floor(Number(n)||1);
  const h=hgDay();if(h.n<=0){toast('砂時計を持っていません');return false;}
  if(h.useDay>=V47.HG_DAY_USE){toast('今日はもう使えません（1日'+V47.HG_DAY_USE+'個まで・0時に戻ります）',3000);return false;}
  n=Math.max(1,Math.min(n,h.n,V47.HG_DAY_USE-h.useDay));
  h.n-=n;h.used=(h.used||0)+n;h.useDay+=n;_ui.hgN=1;
  closeM();diagLog('hourglass',n+'個');
  _hgRun=true;
  try{shiftTime(n*V46.HG_MS);}finally{_hgRun=false;}
  save();rall();return true;
}
let _hgRun=false;

// ---------- 樽の熟成の目標：次の節目（3/8/12/18/25年）か、選んだ注文の年数 ----------
function lotGoalNext(a){return AGE_MILESTONES.find(m=>m>a+1e-9)||0;}
function lotGoalInit(l){if(!(typeof l.goal==='number'&&isFinite(l.goal))){l.goal=lotGoalNext(l.age);l.gs=l.age;}if(!(typeof l.gs==='number'&&isFinite(l.gs)))l.gs=Math.min(l.age,l.goal||l.age);return l;}
function lotGoalEta(l){lotGoalInit(l);if(!(l.goal>0)||l.age>=l.goal)return 0;const r=agingRate(l);return r>0?(l.goal-l.age)/r*BALANCE.GAME_YEAR_MS:Infinity;}
function lotAgeStep(l){return Math.max(0,Math.min(9,Math.floor(l.age/2.5)));}
function lotDoneRecent(l){return !!(l.gt&&Date.now()-l.gt<V47.DONE_SHOW_MS);}
let _goalUI=[],_goalOff=0,_goalOffIds=[],_goalHg=false;
// lotAdvance から毎回呼ぶ（毎秒・放置・砂時計のどの進み方でも同じ判定になる）
function lotGoalStep(l,before,L0){
  if(isFinite(L0)&&L0>l.L)jnlAdd('angel',L0-l.L);
  if(!(typeof l.goal==='number'&&isFinite(l.goal))){l.goal=lotGoalNext(before);l.gs=before;}
  if(!(l.goal>0))return;
  if(!(l.goal-l.gs>0))l.gs=Math.min(before,l.goal-0.01);
  const span=l.goal-l.gs;const p0=(before-l.gs)/span,p1=(l.age-l.gs)/span;
  let q=0;[0.25,0.5,0.75].forEach(t=>{if(p0<t&&p1>=t)q=t;});
  let done=false;
  while(l.goal>0&&l.age>=l.goal){lotGoalDone(l);done=true;}
  if(!_offlineRunning&&(q||done))_goalUI.push({id:l.id,q:done?1:q});
}
function lotGoalDone(l){
  const g=l.goal;l.gd=g;l.gt=Date.now();l.gs=g;l.goal=lotGoalNext(g);
  jnlDone(l,g);G.stats.goals=(G.stats.goals||0)+1;
  if(_offlineRunning){_goalOff++;if(_goalOffIds.length<3)_goalOffIds.push(l.id);}
  if(hgAdd(1,'熟成の節目','ms',true)&&!_offlineRunning)_goalHg=true;
}
function lotSetGoal(id,v){
  const l=G.lots.find(x=>x.id===id);v=Number(v);if(!l||!(v>l.age))return false;
  l.goal=v;l.gs=l.age;save();return true;
}
function lotGoalOptions(l){
  const s=new Set(AGE_MILESTONES.filter(m=>m>l.age+0.05));
  G.orders.forEach(o=>{if(ordUsable(o)&&o.minAge>l.age+0.05&&o.minAge<=40)s.add(o.minAge);});
  return [...s].sort((a,b)=>a-b).slice(0,6);
}
function lotNextEta(){let m=Infinity,lot=null;G.lots.forEach(l=>{const e=lotGoalEta(l);if(e>0&&e<m){m=e;lot=l;}});return lot?{ms:m,lot}:null;}
function lotNextTxt(){const n=lotNextEta();return n?'次に'+n.lot.goal+'年になる樽まで あと'+fmtShort(n.ms):'';}
// 注文の条件の年数に届くまでの時間（銘柄の注文で、年数だけ足りない樽があるとき）
function ordAgeWait(o){
  if(o.kind!=='product')return 0;
  const sp=productSpec(o.pid);if(!sp||sp.blend)return 0;
  const need=Math.max(o.minAge||0,sp.minAge||0);let best=Infinity;
  G.lots.forEach(l=>{if(l.age>=need||l.L<BALANCE.BOTTLE_L)return;if(sp.casks&&!sp.casks.includes(l.cask))return;if(sp.minMatch>0&&flavorMatch(lotFlavor(l),sp.target)<sp.minMatch)return;const r=agingRate(l);if(r>0)best=Math.min(best,(need-l.age)/r*BALANCE.GAME_YEAR_MS);});
  return isFinite(best)?best:0;
}
// 節目・目標の演出（毎秒の画面更新から）
function goalAnnounce(){
  if(!_goalUI.length)return;
  const list=_goalUI;_goalUI=[];
  const dn=list.filter(x=>x.q===1);
  if(dn.length){
    const l=G.lots.find(x=>x.id===dn[0].id);
    toast('🛢️ '+(l?(l.name?'「'+l.name+'」':caskLabel(l))+' が'+l.gd+'年になりました':'樽が節目の年数になりました')+(dn.length>1?'（ほか'+(dn.length-1)+'樽）':'')+(_goalHg?' ・ 砂時計+1':''),3600);
    _goalHg=false;try{sndQuest();}catch(e){}
    if(_ui.sig)_ui.sig.cel=null;
  }
  if(lowMotion())return;
  // v5.0 棚の樽の枠を光らせる
  list.forEach(x=>{const el=document.querySelector(`#wScene .wcask[data-id="${x.id}"] .wglow`);if(!el||!el.animate)return;
    try{el.animate([{opacity:0},{opacity:x.q===1?1:.6,offset:.3},{opacity:0}],{duration:x.q===1?1400:900,easing:'ease-out'});}catch(e){}});
}

// ---------- 倉庫日誌：1日の最初の起動で、前の日の出来事を1件記録する（14日分） ----------
const JNL_W=['晴れ','くもり','雨','霧','風'];
const JNL_LINES={
  win:['霜の朝。冷えた倉庫で、樽はじっと息をひそめている。','雪が屋根を白くした。石壁の内側は変わらず静かだ。','乾いた北風。樽の木が少し締まった音を立てる。','夜明けが遅い。ランタンの灯りで樽の列を見回った。','凍える外気。倉庫の中だけが、ゆっくりと時間を刻む。'],
  spr:['雪解けの水が川を満たした。仕込み水がやわらかい。','窓を開けると、新しい麦の匂いが入ってきた。','春の雨。樽の表面がしっとりと色を深める。','ツバメが軒先に戻ってきた。倉庫はいつもどおり静かだ。','暖かい午後。樽の中で原酒が少し動いた気がする。'],
  sum:['暑い一日。樽がふくらみ、原酒が木に深く染み込む。','夕立のあと、倉庫に木と土の匂いが満ちた。','長い夕暮れ。天使の分け前が、少し多めに空へ昇る。','蝉の声。石壁の奥は、夏でもひんやりしている。','夜風が涼しい。樽の列のあいだを、ゆっくり歩いた。'],
  aut:['収穫の季節。麦畑が金色に揺れている。','木の葉が色づいた。樽の色も、少しずつ深くなっていく。','霧の朝。倉庫の扉を開けると、甘い香りがこぼれた。','秋晴れ。樽の栓を確かめて回った。どれも機嫌がいい。','夜が長くなってきた。熟成には、いい季節だ。']
};
function jnlSeason(d){const m=Number(String(d).split('-')[1])||1;return m===12||m<=2?'win':m<=5?'spr':m<=8?'sum':'aut';}
function jnlHash(s){let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h);}
function jnlLine(e){const L=JNL_LINES[jnlSeason(e.d)];return L[e.w%L.length];}
function jnlWeather(e){return JNL_W[jnlHash(e.d+'w')%JNL_W.length];}
function jnlState(){if(!G.jnl||typeof G.jnl!=='object')G.jnl={cur:null,list:[]};if(!Array.isArray(G.jnl.list))G.jnl.list=[];return G.jnl;}
function jnlNew(d){return {d,s0:{f:G.stats.filled||0,b:G.stats.bottled||0,o:G.stats.orders||0,e:G.te||0},angel:0,done:[],dn:0,staff:[]};}
function jnlCur(){const j=jnlState();if(!j.cur)j.cur=jnlNew(dayKey());return j.cur;}
function jnlAdd(k,v){const c=jnlCur();c[k]=(c[k]||0)+v;}
function jnlDone(l,g){const c=jnlCur();if(c.done.length<V47.JNL_DONE_MAX)c.done.push({c:l.cask,z:l.size,g,n:l.name||''});else c.dn=(c.dn||0)+1;}
function jnlRoll(){
  const j=jnlState();const t=dayKey();
  if(!j.cur){j.cur=jnlNew(t);return false;}
  if(dayNum(t)<=dayNum(j.cur.d))return false; // 同じ日・時計が戻ったときは記録しない
  const c=j.cur,s=c.s0||{};const d0=v=>Math.max(0,v||0);
  const e={d:c.d,fill:d0((G.stats.filled||0)-(s.f||0)),btl:d0((G.stats.bottled||0)-(s.b||0)),ord:d0((G.stats.orders||0)-(s.o||0)),earn:d0((G.te||0)-(s.e||0)),angel:d0(c.angel),done:(c.done||[]).slice(0,V47.JNL_DONE_MAX),dn:c.dn||0,staff:(c.staff||[]).slice(0,4).concat(typeof jnlStaffLine==='function'?[jnlStaffLine(c.d)]:[]).filter(Boolean),w:jnlHash(c.d)%5};
  j.list.unshift(e);if(j.list.length>V47.JNL_MAX)j.list.length=V47.JNL_MAX;
  j.cur=jnlNew(t);
  return true;
}
function jnlDate(d){const p=String(d).split('-');return (Number(p[1])||0)+'/'+(Number(p[2])||0);}
function jnlFacts(e){
  const a=[];
  if(e.fill>0)a.push('樽を'+fmtN(e.fill)+'樽詰めた');
  if(e.btl>0)a.push('瓶を'+fmtN(e.btl)+'本詰めた');
  if(e.ord>0)a.push('注文を'+fmtN(e.ord)+'件納品した');
  if(e.earn>0)a.push('売上 '+fmt(e.earn));
  if(e.angel>=0.05)a.push('天使の分け前 '+fmtL(e.angel));
  return a;
}
function jnlDoneTxt(e){return (e.done||[]).map(x=>(x.n?'「'+x.n+'」':caskType(x.c).name+'×'+caskSize(x.z).name)+' '+x.g+'年').join('、')+(e.dn>0?' ほか'+e.dn+'樽':'');}
function jnlStaffTxt(e){return (e.staff||[]).map(x=>typeof x==='string'?x:(x&&x.t)||'').filter(Boolean);}
function jnlUnread(){const j=jnlState();const e=j.list[0];return !!(e&&G.hs&&G.hs.jnl!==e.d);}
// v5.5 倉庫日誌は図鑑の「倉庫日誌」で読む（寝かせるのカードはやめた）
function rencJ(){
  const el=$('jnlList');if(!el)return;
  const j=jnlState();
  const rows=j.list.map(e=>{const f=jnlFacts(e);const st=jnlStaffTxt(e);
    return `<div class="card jne"><div class="row sb"><span class="tt">${jnlDate(e.d)}</span><span class="sm">${jnlWeather(e)}</span></div><div class="sm jl">${escapeHtml(jnlLine(e))}</div>
      ${e.done&&e.done.length?`<div class="sm" style="color:var(--gold2);margin-top:4px">🛢️ 節目の年数になった樽：${escapeHtml(jnlDoneTxt(e))}</div>`:''}
      ${st.length?`<div class="sm" style="margin-top:4px">👷 ${st.map(escapeHtml).join('<br>👷 ')}</div>`:''}
      ${f.length?`<div class="sm" style="margin-top:4px;color:var(--text2)">${f.map(escapeHtml).join(' ・ ')}</div>`:''}</div>`;}).join('');
  const c=jnlCur();const cf=jnlFacts({fill:(G.stats.filled||0)-(c.s0.f||0),btl:(G.stats.bottled||0)-(c.s0.b||0),ord:(G.stats.orders||0)-(c.s0.o||0),earn:(G.te||0)-(c.s0.e||0),angel:c.angel});
  el.innerHTML=`<div class="ms">1日の最初の起動で、前の日の出来事が記録されます（${V47.JNL_MAX}日分）</div>
    <div class="card"><div class="row sb"><span class="tt">今日のここまで</span><span class="sm">${jnlDate(c.d)}</span></div><div class="sm" style="color:var(--text2)">${cf.length?cf.map(escapeHtml).join(' ・ '):'まだ記録はありません'}${c.done.length?'<br>🛢️ 節目の年数になった樽：'+escapeHtml(jnlDoneTxt(c)):''}</div></div>
    ${rows||'<div class="sm tc" style="padding:8px">最初の日誌は、明日の最初の起動で届きます</div>'}`;
  if(j.list[0]&&G.hs&&G.hs.jnl!==j.list[0].d){G.hs.jnl=j.list[0].d;save();try{updNavBadges();}catch(e){}}
}

// ---------- ログインボーナスと毎秒の処理 ----------
function loginBonus(){
  const h=hgDay();if(h.src.login)return false;
  if(!_titleDone||_offlineGate||G.fresh||_tut)return false;
  if(!(G.tut&&(G.tut.done.first||G.tut.done.upd)))return false;
  const mo=$('mo');if(mo&&!mo.classList.contains('h'))return false;
  // 連続ログイン：前の日にも受け取っていれば続く。7日ごとに3個
  const st=h.streak,t=dayKey();if(st.d!==t){st.n=(st.d&&dayNum(t)-dayNum(st.d)===1)?st.n+1:1;st.d=t;}
  const got=hgAdd(V51.HG.login.k,'ログインボーナス','login',true);
  const bonus=st.n>0&&st.n%V51.HG.streak.every===0&&hgAdd(V51.HG.streak.k,'連続ログイン'+st.n+'日','streak',true);
  toast(got?'⏳ ログインボーナス：砂時計 +'+(V51.HG.login.k+(bonus?V51.HG.streak.k:0))+'（連続'+st.n+'日）'+h.n+'/'+V47.HG_MAX+(jnlUnread()?' ・ 倉庫日誌が届いています':''):'⏳ 砂時計が'+V47.HG_MAX+'個です。使ってから受け取りましょう',3600);
  save();return true;
}
function v47Tick(){
  try{
    if(jnlRoll()&&_ui.sig)_ui.sig.cel=null;
    hgDay();loginBonus();goalAnnounce();
  }catch(e){console.warn('v47Tick',e);}
}
// v4.7 以降の data-act（handleAct の最後から呼ぶ）
function extAct(act,b,id){
  switch(act){
    case 'lotGoal': if(lotSetGoal(id,b.dataset.v)){openLotModal(id);rCellar();toast('🎯 次の節目を'+b.dataset.v+'年にしました',1800);} return true;
  }
  if(typeof extAct48==='function'&&extAct48(act,b,id))return true;
  if(typeof extAct49==='function'&&extAct49(act,b,id))return true;
  if(typeof extAct50==='function'&&extAct50(act,b,id))return true;
  return false;
}

