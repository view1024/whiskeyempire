function defState(){
  const fac={};
  FD.forEach(f=>{fac[f.id]={l:0,p:false};});
  if(fac['malting'])fac['malting'].p=true;
  const rel={};CUSTOMERS.forEach(c=>{rel[c.id]={lv:0,done:0};});
  const branch={};FD.forEach(f=>{branch[f.id]=null;});
  return {
    cash:0,te:0,tt:0,dl:1,cl:0,fac,uw:[],cw:{},
    regions:{},regionsEx:[],tl:[],
    ls:Date.now(),ver:BALANCE.SCHEMA_VERSION,dbgMul:1,
    reputation:0,repHistory:[],awards:[],compCooldowns:{},blendHistory:[],
    questDone:[],daily:{date:'',missions:[],allCleared:false},_dmProgress:{},
    prestige:{level:0,bonus:1.0,skillPoints:0,skills:{},legacyWhiskies:[],totalRuns:0},
    randomEvent:{lastAt:0,sessionCount:0,active:null},
    story:{unlocked:[],seenNew:[]},
    tank:0,lots:[],bottles:[],bq:[],orders:[],orderClock:0,seq:0,rel,
    recipe:{grain:'golden_promise',water:'soft_spring',yeast:'distillery',peat:'unpeated'},
    recipeOwned:['golden_promise','soft_spring','distillery','unpeated'],
    branch,
    auto:{fill:{on:true,cask:'bourbon',size:'hogshead'},spot:{on:true,defKeep:50,keep:{}}},
    tut:{done:{},q:['first'],seed:false},shipLog:{},encSeen:[],
    opt:{...OPT_DEFAULT},chap:{done:{},claimed:{}},records:{},runStart:Date.now(),relEvQ:[],hs:{chap:'',daily:'',mkt:'',vis:0,new43:1,casks:null,new44:1,fin:null,new45:1,new46:1,new47:1,new50:1,jnl:'',cl:BALANCE.APP_VERSION},barley:{kg:null,auto:true,grade:'std'},acct:null,taste:{n:0,cnt:0,day:''},hg:{n:0,got:0,used:0,day:'',useDay:0,src:{login:0,daily:0,ms:0,ord:0,tap:0},ordN:0,streak:{d:'',n:0},month:monthKey()},jnl:{cur:null,list:[]},staff:[],staffCand:null,staffOff:false,ownerAt:null,whBonus:0,
    stats:{shipped:0,orders:0,failed:0,filled:0,bottled:0,maxAge:0,awardsWon:0,reserveDone:0,compEntered:0,finishes:0,named:0,limited:0,barleyKg:0,barleyCost:0,freeBtl:0,tastings:0,goals:0,cancel:0,mfgCost:0,ageCost:0},tankMfg:0,
    awardMult:{},climate:'speyside',migratedFrom:null,migShown:false,fresh:true
  };
}

const V6_ONLY_FIELDS=['mg','cut','_cutBonus','_cutBonusTaps','cutState','facByBrand','am','aw','amPriority','wCd','auctionCooldown','channels','casks','inv','rawMaterials','wash','washMax'];

function sanitize(s){
  const d=defState();
  if(!s||typeof s!=='object')return d;
  const num=(v,def,min,max)=>{v=Number(v);if(!isFinite(v))v=def;return clamp(v,min,max);};
  const isObj=v=>v&&typeof v==='object'&&!Array.isArray(v);
  s.cash=num(s.cash,0,0,1e300);
  s.te=num(s.te,0,0,1e300);
  s.tt=Math.floor(num(s.tt,0,0,1e15));
  s.dl=Math.floor(num(s.dl,1,1,DL.length));
  s.cl=Math.floor(num(s.cl,0,0,50));
  s.uw=Array.isArray(s.uw)?[...new Set(s.uw.filter(id=>WL.some(w=>w.id===id)))]:[];
  s.tl=Array.isArray(s.tl)?s.tl.filter(x=>typeof x==='string'):[];
  const cw={};if(isObj(s.cw))Object.keys(s.cw).forEach(k=>{if(WL.some(w=>w.id===k))cw[k]=Math.floor(num(s.cw[k],0,0,1e15));});s.cw=cw;
  const rg={};if(isObj(s.regions))Object.keys(s.regions).forEach(id=>{if(REGIONS[id])rg[id]=!!s.regions[id];});s.regions=rg;
  s.regionsEx=Array.isArray(s.regionsEx)?s.regionsEx.filter(id=>REGIONS_EX.some(r=>r.id===id)):[];
  const fac={};
  FD.forEach(f=>{const cur=(isObj(s.fac)&&s.fac[f.id])||{l:0,p:false};fac[f.id]={l:Math.floor(num(cur.l,0,0,50)),p:!!cur.p};});
  fac['malting'].p=true;s.fac=fac;
  s.ls=Number(s.ls)||Date.now();
  s.dbgMul=num(s.dbgMul,1,1,100000);
  s.reputation=num(s.reputation,0,0,1e9);
  if(!Array.isArray(s.repHistory))s.repHistory=[];
  s.awards=Array.isArray(s.awards)?s.awards.filter(id=>COMPETITIONS.some(c=>c.id===id)):[];
  if(!isObj(s.compCooldowns))s.compCooldowns={};
  s.blendHistory=Array.isArray(s.blendHistory)?s.blendHistory.slice(0,20):[];
  if(!Array.isArray(s.questDone))s.questDone=[];
  if(!isObj(s.daily))s.daily=d.daily;
  if(!isObj(s._dmProgress))s._dmProgress={};
  if(!isObj(s.prestige))s.prestige=d.prestige;
  s.prestige=Object.assign({},d.prestige,s.prestige);
  if(!isObj(s.prestige.skills))s.prestige.skills={};
  if(!Array.isArray(s.prestige.legacyWhiskies))s.prestige.legacyWhiskies=[];
  if(!isObj(s.randomEvent))s.randomEvent=d.randomEvent;
  delete s.randomEvent.ask; // v5.5 選ぶイベントは廃止
  if(!isObj(s.story))s.story=d.story;
  // --- v7 ---
  s.tank=num(s.tank,0,0,1e15);s.tankMfg=num(s.tankMfg,0,0,1e15); // v5.7 タンクの新酒1Lあたりの製造費
  s.lots=Array.isArray(s.lots)?s.lots.filter(l=>isObj(l)&&CASK_TYPES.some(c=>c.id===l.cask)&&CASK_SIZES.some(z=>z.id===l.size)).slice(0,400).map(l=>{
    const fl0={};FL_KEYS.forEach(k=>{fl0[k]=num(l.fl0&&l.fl0[k],BASE_FLAVOR[k],0,100);});
    const o={id:String(l.id||('l_s'+Math.random().toString(36).slice(2))),cask:l.cask,size:l.size,L0:num(l.L0,250,1,1000),L:num(l.L,0,0,1000),age:num(l.age,0,0,200),fl0,q:num(l.q,1,0.8,1.5),at:Number(l.at)||Date.now(),src:String(l.src||'prod')};
    if(typeof l.name==='string'&&l.name.trim())o.name=l.name.trim().slice(0,12);
    if(isObj(l.fin)&&CASK_TYPES.some(c=>c.id===l.fin.from))o.fin={from:l.fin.from,at:num(l.fin.at,0,0,200)};
    if(l.c!==undefined&&isFinite(Number(l.c))&&Number(l.c)>=0)o.c=Number(l.c);
    if(l.c0!==undefined&&isFinite(Number(l.c0))&&Number(l.c0)>=0)o.c0=Number(l.c0); // v5.7 詰めたときの原価（熟成費の基準）
    if(l.goal!==undefined&&isFinite(Number(l.goal))){o.goal=num(l.goal,0,0,200);o.gs=num(l.gs,o.age,0,200);}
    if(l.gd!==undefined&&isFinite(Number(l.gd))){o.gd=num(l.gd,0,0,200);o.gt=Number(l.gt)||0;}
    return o;
  }).filter(l=>l.L>=BALANCE.BOTTLE_L):[];
  const normFl=o=>{const r={};FL_KEYS.forEach(k=>{r[k]=num(o&&o[k],0,0,100);});return r;};
  s.bottles=Array.isArray(s.bottles)?s.bottles.filter(r=>isObj(r)&&productSpec(r.pid)).map(r=>({id:String(r.id||('b_s'+Math.random().toString(36).slice(2))),pid:r.pid,n:Math.floor(num(r.n,0,0,1e15)),age:Math.floor(num(r.age,0,0,200)),q:num(r.q,1,0.8,1.5),fl:normFl(r.fl),c:(r.c!==undefined&&isFinite(Number(r.c))&&Number(r.c)>=0)?Number(r.c):undefined})).filter(r=>r.n>=1).slice(0,200):[];
  s.bq=Array.isArray(s.bq)?s.bq.filter(q=>isObj(q)&&productSpec(q.pid)).map(q=>({id:String(q.id),pid:q.pid,n:Math.floor(num(q.n,1,1,1e15)),done:num(q.done,0,0,1e15),moved:Math.floor(num(q.moved,0,0,1e15)),age:Math.floor(num(q.age,0,0,200)),q:num(q.q,1,0.8,1.5),fl:normFl(q.fl),blend:q.blend||null,oid:q.oid?String(q.oid):null,c:(q.c!==undefined&&isFinite(Number(q.c))&&Number(q.c)>=0)?Number(q.c):undefined,sell:q.sell?1:0})).slice(0,20):[];
  s.orders=Array.isArray(s.orders)?s.orders.filter(o=>isObj(o)&&custById(o.cid)).slice(0,12):[];
  s.orderClock=Number(s.orderClock)||0;
  s.seq=Math.floor(num(s.seq,0,0,1e12));
  const rel={};CUSTOMERS.forEach(c=>{const r=isObj(s.rel)&&s.rel[c.id]||{};rel[c.id]={lv:Math.floor(num(r.lv,0,0,5)),done:Math.floor(num(r.done,0,0,1e9))};});s.rel=rel;
  s.recipeOwned=Array.isArray(s.recipeOwned)?s.recipeOwned.filter(x=>typeof x==='string'):d.recipeOwned.slice();
  d.recipeOwned.forEach(id=>{if(!s.recipeOwned.includes(id))s.recipeOwned.push(id);});
  if(!isObj(s.recipe))s.recipe={...d.recipe};
  ['grain','water','yeast','peat'].forEach(k=>{const id=s.recipe[k];if(!rcpList(k).some(x=>x.id===id)||!s.recipeOwned.includes(id))s.recipe[k]=d.recipe[k];});
  const br={};FD.forEach(f=>{const v=isObj(s.branch)?s.branch[f.id]:null;br[f.id]=(v===0||v===1)?v:null;});s.branch=br;
  const au=isObj(s.auto)?s.auto:{};
  s.auto={fill:Object.assign({},d.auto.fill,isObj(au.fill)?au.fill:{}),spot:Object.assign({},d.auto.spot,isObj(au.spot)?au.spot:{})};
  s.auto.fill.on=!!s.auto.fill.on;s.auto.spot.on=!!s.auto.spot.on;
  if(!CASK_TYPES.some(c=>c.id===s.auto.fill.cask))s.auto.fill.cask='bourbon';
  if(!CASK_SIZES.some(c=>c.id===s.auto.fill.size))s.auto.fill.size='hogshead';
  s.auto.spot.defKeep=Math.floor(num(s.auto.spot.defKeep,50,0,1e12));
  if(!isObj(s.auto.spot.keep))s.auto.spot.keep={};
  const st=isObj(s.stats)?s.stats:{};s.stats={};
  Object.keys(d.stats).forEach(k=>{s.stats[k]=num(st[k],0,0,1e15);});
  const am={};if(isObj(s.awardMult))Object.keys(s.awardMult).forEach(k=>{if(productSpec(k))am[k]=num(s.awardMult[k],1,1,3);});s.awardMult=am;
  if(!CLIMATES.some(c=>c.id===s.climate))s.climate='speyside';
  // --- v9 ---
  const op=isObj(s.opt)?s.opt:{};s.opt={...OPT_DEFAULT,...op};
  if(s.opt.bgmMode==='ambient')s.opt.bgmMode='celtic'; // v5.8 環境音楽→ケルト
  if(!['classic','celtic','off'].includes(s.opt.bgmMode))s.opt.bgmMode='classic';
  delete s.tapHg; // v5.5 小人は試飲会に移した（タップの回数は数えない）
  s.opt.fs=s.opt.fs==='l'?'l':'m';s.opt.money=s.opt.money==='ja'?'ja':'en';s.opt.se=num(s.opt.se,0,0,1);s.opt.bgm=num(s.opt.bgm,0,0,1);s.opt.vib=s.opt.vib!==false;if(s.opt.tk==='still')s.opt.tk='slow';if(!['slow','mid','fast'].includes(s.opt.tk))s.opt.tk='mid';if(!['dark','light','auto'].includes(s.opt.theme))s.opt.theme='dark';if(!['std','low'].includes(s.opt.motion))s.opt.motion='std';
  const ch=isObj(s.chap)?s.chap:{};s.chap={done:isObj(ch.done)?ch.done:{},claimed:isObj(ch.claimed)?ch.claimed:{},seed:!!ch.seed};
  {const rs=isObj(s.records)?s.records:{};s.records={};CLIMATES.forEach(c=>{const r=rs[c.id];if(!isObj(r))return;const td={};if(isObj(r.tierDays))[2,3,4,5].forEach(t=>{if(r.tierDays[t]>0)td[t]=num(r.tierDays[t],0,0,1e6);});
    s.records[c.id]={bestUnit:num(r.bestUnit,0,0,1e18),maxAge:num(r.maxAge,0,0,999),tierDays:td,runs:Math.floor(num(r.runs,0,0,999)),te:num(r.te,0,0,1e21),maxTier:Math.floor(num(r.maxTier,1,1,DL.length))};});} // v5.6 創業地ごとの記録
  const bl=isObj(s.barley)?s.barley:{};s.barley={kg:(bl.kg===null||bl.kg===undefined)?null:num(bl.kg,0,0,1e15),auto:bl.auto!==false,grade:['std','good','best'].includes(bl.grade)?bl.grade:'std'};
  const hs=isObj(s.hs)?s.hs:{};s.hs={chap:String(hs.chap||''),daily:String(hs.daily||''),mkt:String(hs.mkt||''),vis:hs.vis?1:0,new43:hs.new43?1:0,casks:Array.isArray(hs.casks)?hs.casks.filter(x=>typeof x==='string'):null,new44:hs.new44?1:0,fin:(hs.fin===null||hs.fin===undefined||!isFinite(Number(hs.fin)))?null:Number(hs.fin),new45:hs.new45?1:0,new46:hs.new46?1:0,new47:hs.new47===0?0:1,new50:hs.new50===0?0:1,jnl:String(hs.jnl||''),cl:String(hs.cl||''),ev:String(hs.ev||''),seatTip:hs.seatTip?1:0};
  s.acct=acctSanitize(s.acct);
  {const h=isObj(s.hg)?s.hg:{};const sr=isObj(h.src)?h.src:{};const st=isObj(h.streak)?h.streak:{};const c=(v,m)=>Math.floor(num(v,0,0,m));s.hg={n:c(h.n,V47.HG_MAX),got:c(h.got,1e9),used:c(h.used,1e9),day:String(h.day||''),useDay:c(h.useDay,99),src:{login:c(sr.login,9),daily:c(sr.daily,9),ms:c(sr.ms,9),ord:c(sr.ord,9),tap:c(sr.tap,9)},ordN:c(h.ordN,99),streak:{d:String(st.d||''),n:c(st.n,1e6)},month:typeof h.month==='string'?h.month:monthKey()};}
  s.jnl=jnlSanitize(s.jnl);
  s.staff=staffSanitize(s.staff);s.staffCand=staffCandSanitize(s.staffCand);s.staffOff=!!s.staffOff&&s.staff.length>0;
  s.ownerAt=placeAtSanitize(s.ownerAt);s.whBonus=Math.max(0,Math.min(12,Math.floor(Number(s.whBonus)||0)));
  {const t=isObj(s.taste)?s.taste:{};s.taste={n:Math.floor(num(t.n,0,0,V45.TASTE_N-1)),cnt:Math.floor(num(t.cnt,0,0,V45.TASTE_MAX)),day:String(t.day||'')};}
  s.runStart=Number(s.runStart)||Date.now();
  delete s.caskLog; // v5.8 名樽の記録は廃止
  s.relEvQ=Array.isArray(s.relEvQ)?s.relEvQ.filter(e=>isObj(e)&&custById(e.cid)).slice(0,10):[];
  // --- v8 ---
  const tu=isObj(s.tut)?s.tut:{};
  s.tut={done:isObj(tu.done)?tu.done:{},q:Array.isArray(tu.q)?tu.q.filter(x=>typeof x==='string').slice(0,20):[],seed:!!tu.seed,rewarded:!!tu.rewarded};
  const sl={};if(isObj(s.shipLog))Object.keys(s.shipLog).forEach(k=>{const v=s.shipLog[k];if(WL.some(w=>w.id===k)&&isObj(v))sl[k]={t:Number(v.t)||Date.now(),maxAge:num(v.maxAge,0,0,200)};});
  Object.keys(s.cw).forEach(k=>{if(s.cw[k]>0&&!sl[k])sl[k]={t:0,maxAge:0};});s.shipLog=sl;
  s.encSeen=Array.isArray(s.encSeen)?s.encSeen.filter(id=>WL.some(w=>w.id===id)):s.uw.slice();
  s.orders.forEach(o=>{o.autoDel=!!o.autoDel;});
  s.bq.forEach(q=>{if(q.oid&&!s.orders.some(o=>o.id===q.oid))q.oid=null;});
  V6_ONLY_FIELDS.forEach(k=>{delete s[k];});
  Object.keys(s).filter(k=>k.startsWith('_amLast_')).forEach(k=>delete s[k]);
  s.ver=BALANCE.SCHEMA_VERSION;
  return {...d,...s};
}

// v6以前 → v7（詳細設計書 第9章）
function migrateV7(s){
  if(!s||typeof s!=='object')return defState();
  if((Number(s.ver)||0)>=7)return s;
  const now=Date.now();
  const lots=[];
  (Array.isArray(s.casks)?s.casks:[]).forEach((c,i)=>{
    if(!c||c.sold)return;
    const sz=CASK_SIZES.find(x=>x.id===c.size),ct=CASK_TYPES.find(x=>x.id===c.type);
    if(!sz||!ct)return;
    const w=WL.find(x=>x.id===c.whiskyId);
    lots.push({id:'l_m'+i+'_'+now.toString(36),cask:ct.id,size:sz.id,L0:sz.litres,L:clamp(Number(c.litresFilled)||sz.litres,0,sz.litres),age:clamp(Number(c.agingYears)||0,0,100),fl0:w?wlFlavor(w):{...BASE_FLAVOR},q:clamp(Number(c.qualityMod)||1,0.8,1.5),at:Number(c.createdAt)||now,src:'migrated'});
  });
  s.lots=lots;
  const bottles=[];
  if(s.inv&&typeof s.inv==='object'){
    Object.keys(s.inv).forEach((id,i)=>{const w=WL.find(x=>x.id===id);const n=Math.floor(Number(s.inv[id])||0);if(w&&n>0)bottles.push({id:'b_m'+i+'_'+now.toString(36),pid:id,n,age:w.yr,q:1,fl:wlFlavor(w)});});
  }
  s.bottles=bottles;
  const rel={};CUSTOMERS.forEach(c=>{rel[c.id]={lv:0,done:0};});
  const act=(s.channels&&Array.isArray(s.channels.active))?s.channels.active:[];
  act.forEach(ch=>{const cid=CHANNEL_TO_CUST[ch];if(cid&&rel[cid].lv<1)rel[cid]={lv:1,done:3};});
  s.rel=rel;
  const rm=s.rawMaterials||{};
  s.recipe={grain:rm.grain||'golden_promise',water:rm.water||'soft_spring',yeast:rm.yeast||'distillery',peat:rm.peat||'unpeated'};
  s.recipeOwned=[...new Set(['golden_promise','soft_spring','distillery','unpeated',s.recipe.grain,s.recipe.water,s.recipe.yeast,s.recipe.peat])];
  if(s.prestige&&s.prestige.skills){
    const sk=s.prestige.skills;
    [['ps_passive','ps_capacity'],['ps_craft_cost','ps_cask_cost'],['ps_am_slot','ps_order_slot']].forEach(([a,b])=>{if(sk[a]){sk[b]=(sk[b]||0)+sk[a];delete sk[a];}});
  }
  if(s.compCooldowns&&typeof s.compCooldowns==='object'){
    Object.keys(s.compCooldowns).forEach(k=>{const c=COMPETITIONS.find(x=>x.id===k);if(c)s.compCooldowns[k]=Math.min(Number(s.compCooldowns[k])||0,now+c.cooldownMs);});
  }
  const shipped=Object.values(s.cw||{}).reduce((a,v)=>a+(Number(v)||0),0);
  s.stats={shipped,orders:0,failed:0,filled:0,bottled:0,maxAge:lots.reduce((a,l)=>Math.max(a,l.age),0),awardsWon:Array.isArray(s.awards)?s.awards.length:0};
  s.tank=0;s.bq=[];s.orders=[];s.orderClock=now;s.seq=0;
  const branch={};FD.forEach(f=>{branch[f.id]=null;});s.branch=branch;
  s.auto={fill:{on:true,cask:'bourbon',size:'hogshead'},spot:{on:true,defKeep:50,keep:{}}};
  s.awardMult={};s.climate='speyside';
  s.migratedFrom=Number(s.ver)||6;s.migShown=false;s.fresh=true;
  V6_ONLY_FIELDS.forEach(k=>{delete s[k];});
  Object.keys(s).filter(k=>k.startsWith('_amLast_')).forEach(k=>delete s[k]);
  s.ver=7;
  return s;
}

// v7 → v8（改善計画 7.4：既存ユーザーには更新案内3枚、解放済み機能の案内は出さない）
function migrateV8(s){
  if((Number(s.ver)||0)>=8)return s;
  s.tut={done:{},q:['upd'],seed:true};
  s.encSeen=Array.isArray(s.uw)?s.uw.slice():[];
  s.ver=8;
  return s;
}
// v8 → v9（v4.2）：音は以前のON/OFFを引き継ぎ、BGMはOFFで開始
function migrateV9(s){
  if((Number(s.ver)||0)>=9)return s;
  let snd=true;try{snd=localStorage.getItem('we_sound')!=='off';}catch(e){}
  s.opt={...OPT_DEFAULT,se:snd?0.6:0,bgm:0};
  s.chap={done:{},claimed:{},seed:true};
  s.runStart=Number(s.runStart)||Date.now();
  s.ver=9;return s;
}
// v9 → v10（v4.4）：大麦のサイロは満タンで開始・自動仕入れON・色はダーク・動きは標準
function migrateV10(s){
  if((Number(s.ver)||0)>=10)return s;
  s.barley={kg:null,auto:true};
  s.opt=Object.assign({},s.opt||{},{theme:(s.opt&&s.opt.theme)||'dark',motion:(s.opt&&s.opt.motion)||'std'});
  s.ver=10;return s;
}
// v10 → v11（v4.5）：決算書を始める。設備はこれまでの費用から推計（acctEnsureで計算）、瓶の無料分は使用済み扱い
function migrateV11(s){
  if((Number(s.ver)||0)>=11)return s;
  s.acct={mig:true,prev:[]};
  s.stats=Object.assign({},s.stats||{},{freeBtl:1});
  s.taste={n:0,cnt:0,day:''};
  s.hs=Object.assign({},s.hs||{},{new45:0});
  s.ver=11;return s;
}
// v11 → v12（v4.7）：樽に熟成の目標、砂時計の日ごとの記録、倉庫日誌、変更点の案内
function migrateV12(s){
  if((Number(s.ver)||0)>=12)return s;
  (Array.isArray(s.lots)?s.lots:[]).forEach(l=>{if(l&&typeof l==='object'){const a=Number(l.age)||0;l.goal=AGE_MILESTONES.find(m=>m>a+1e-9)||0;l.gs=a;}});
  s.hg=Object.assign({n:0,got:0,used:0},s.hg||{},{day:'',useDay:0,src:{login:0,daily:0,ms:0,care:0}});
  s.jnl={cur:null,list:[]};
  s.hs=Object.assign({},s.hs||{},{new47:0});
  s.ver=12;return s;
}
// v12 → v13（v4.8）：職人（最初はいない）
function migrateV13(s){
  if((Number(s.ver)||0)>=13)return s;
  s.staff=[];s.staffCand=null;s.staffOff=false;
  s.ver=13;return s;
}
// v13 → v14（v5.0）：持ち場を配置先に。旧「樽詰め」の枠は G.whBonus として恒久化
function migrateV14(s){
  if((Number(s.ver)||0)>=14)return s;
  const L=Array.isArray(s.staff)?s.staff.filter(x=>x&&typeof x==='object'):[];
  const lvF=x=>1+0.1*((Number(x.lv)||1)-1),stv=(x,k)=>Number(x.st&&x.st[k])||0;
  // 1) 樽の枠：研修中・休業中も含めて数える（移行の瞬間に枠が減らないように）
  const fp=L.filter(x=>x.post==='fill').map(x=>stv(x,'tegiwa')*lvF(x)).sort((a,b)=>b-a).reduce((a,v,i)=>a+v*([1,0.8,0.6][i]||0),0);
  s.whBonus=Math.min(12,Math.floor(fp/3));
  // 2) 持ち場 → 配置先（同じ持ち場の中は能力の高い人から。行き先がなければ待機）
  const fac=s.fac||{};const own=id=>id==='bottling'||!!(fac[id]&&fac[id].p&&(Number(fac[id].l)||0)>0);
  const used=new Set();const take=(k,id)=>{const key=k+':'+id;if(used.has(key))return null;used.add(key);return {k,id};};
  const left=l=>(Number(l.goal)>0?Number(l.goal):99)-(Number(l.age)||0);
  const lots=(Array.isArray(s.lots)?s.lots:[]).filter(l=>l&&typeof l==='object'&&l.id).slice().sort((a,b)=>left(a)-left(b));
  const by=(p,k)=>L.filter(x=>x.post===p).sort((a,b)=>(stv(b,k)-stv(a,k))||((Number(b.lv)||1)-(Number(a.lv)||1)));
  L.forEach(x=>{x.at=null;});
  by('buy','mekiki').forEach(x=>{if(own('malting'))x.at=take('fac','malting');});
  by('still','tegiwa').forEach(x=>{for(const id of ['distillation','fermentation','mashing']){if(!own(id))continue;const t=take('fac',id);if(t){x.at=t;break;}}});
  by('ship','tegiwa').forEach(x=>{x.at=take('fac','bottling');});
  L.filter(x=>x.post==='fill'||x.post==='watch').sort((a,b)=>stv(b,'waza')-stv(a,'waza')).forEach(x=>{for(const l of lots){const t=take('lot',String(l.id));if(t){x.at=t;break;}}});
  s.ownerAt=null;s.hs=Object.assign({},s.hs||{},{new50:0});
  s.ver=14;return s;
}
// v14 → v15（v5.1）：砂時計の入手の記録（回数・納品の数・連続ログイン・月）と大麦の等級。所持数はそのまま
function migrateV15(s){
  if((Number(s.ver)||0)>=15)return s;
  const h=Object.assign({n:0,got:0,used:0},s.hg||{});const sr=h.src||{};
  h.src={login:sr.login?1:0,daily:sr.daily?1:0,ms:sr.ms?1:0,care:sr.care?1:0,ord:0};h.ordN=0;h.streak={d:'',n:0};h.month=monthKey();
  s.hg=h;s.barley=Object.assign({},s.barley||{},{grade:'std'});
  s.ver=15;return s;
}
// v15 → v16（v5.2）：樽の小人の記録・予約の取り消しの件数・BGM はクラシック
function migrateV16(s){
  if((Number(s.ver)||0)>=16)return s;
  s.tapHg={n:0,miss:0};s.stats=Object.assign({},s.stats||{},{cancel:0});
  s.opt=Object.assign({},s.opt||{},{bgmMode:'classic'});
  if(s.hg&&s.hg.src)s.hg.src.tap=0;
  s.ver=16;return s;
}
function migrateV17(s){
  if((Number(s.ver)||0)>=17)return s;
  // v5.4 大麦の等級・差し入れ・TIPS帯の速さを廃止。砂時計の入手の記録から差し入れを外す
  if(s.barley&&typeof s.barley==='object')s.barley.grade='std';
  if(s.hg&&s.hg.src&&typeof s.hg.src==='object')delete s.hg.src.care;
  if(s.opt&&typeof s.opt==='object')s.opt.tk='mid';
  if(Array.isArray(s.staff))s.staff.forEach(x=>{if(x&&typeof x==='object')delete x.care;});
  if(s.randomEvent&&typeof s.randomEvent==='object')s.randomEvent.ask=null;
  s.ver=17;return s;
}
// v5.6 アイラ島はスコットランドにまとめる（今の地・記録）。販売地域・輸出市場の倍率は次の再創業まで残す（データはそのまま）
function migrateV18(s){
  if((Number(s.ver)||0)>=18)return s;
  if(s.climate==='islay')s.climate='speyside';
  const rs=s.records;
  if(rs&&typeof rs==='object'&&rs.islay&&typeof rs.islay==='object'){
    const a=rs.islay,b=(rs.speyside&&typeof rs.speyside==='object')?rs.speyside:{bestUnit:0,maxAge:0,tierDays:{},runs:0};
    const td=Object.assign({},b.tierDays||{});Object.keys(a.tierDays||{}).forEach(t=>{const v=Number(a.tierDays[t]);if(v>0&&(!(td[t]>0)||v<td[t]))td[t]=v;});
    rs.speyside={bestUnit:Math.max(Number(a.bestUnit)||0,Number(b.bestUnit)||0),maxAge:Math.max(Number(a.maxAge)||0,Number(b.maxAge)||0),tierDays:td,runs:(Number(a.runs)||0)+(Number(b.runs)||0),te:(Number(a.te)||0)+(Number(b.te)||0),maxTier:Math.max(Number(a.maxTier)||1,Number(b.maxTier)||1)};
    delete rs.islay;
  }
  s.ver=18;return s;
}
// v5.7 決算書（製造費・熟成費・法人税・借入）。保存の形は sanitize で補うので、版だけ上げて移行前をバックアップする
function migrateV19(s){if((Number(s.ver)||0)>=19)return s;s.ver=19;return s;}
// v5.8 図鑑の「記録」の廃止（蔵出しした名樽の記録 caskLog を消す）・BGM の「環境音楽」をケルトに
function migrateV20(s){if((Number(s.ver)||0)>=20)return s;delete s.caskLog;if(s.opt&&s.opt.bgmMode==='ambient')s.opt.bgmMode='celtic';s.ver=20;return s;}
function placeAtSanitize(a){
  if(!a||typeof a!=='object'||typeof a.id!=='string')return null;
  if(a.k==='fac'&&['malting','mashing','fermentation','distillation','bottling'].includes(a.id))return {k:'fac',id:a.id};
  if(a.k==='lot')return {k:'lot',id:a.id.slice(0,40)};
  return null;
}
function parseSave(obj){
  if((Number(obj&&obj.ver)||0)>BALANCE.SCHEMA_VERSION)throw new Error('新しい版のセーブデータです');
  let m=(Number(obj.ver)||0)<7?migrateV7(obj):obj;
  m=migrateV8(m);
  m=migrateV9(m);
  m=migrateV10(m);
  m=migrateV11(m);
  m=migrateV12(m);
  m=migrateV13(m);
  m=migrateV14(m);
  m=migrateV15(m);
  m=migrateV16(m);
  m=migrateV17(m);
  m=migrateV18(m);
  m=migrateV19(m);
  m=migrateV20(m);
  return sanitize(m);
}

// 新規開始・移行・プレステージ・リセット直後の初期化
function postLoadInit(){
  try{placeSanitize();}catch(e){console.warn('placeSanitize',e);}
  if(!G.fresh)return;
  grantStarterLots();
  G.orders=[];
  ordFirst();
  G.fresh=false;
  prodInvalidate();
}

function load(){
  try{
    const raw=localStorage.getItem(storageKey());
    if(raw){
      const obj=JSON.parse(raw);
      if((Number(obj.ver)||0)<7){
        try{const bk=BALANCE.BACKUP_PREFIX+(LIFF_USER.id||'guest');if(!localStorage.getItem(bk))localStorage.setItem(bk,raw);}catch(e){}
      }else if((Number(obj.ver)||0)<BALANCE.SCHEMA_VERSION){
        try{const bk='we_v4_bak'+(Number(obj.ver)||0)+':'+(LIFF_USER.id||'guest');if(!localStorage.getItem(bk))localStorage.setItem(bk,raw);}catch(e){}
      }
      G=parseSave(obj);
    }else{
      G=defState();
    }
  }catch(e){
    console.warn('load failed:',e);
    _loadError=String(e&&e.message||e);
    _noSave=true; // 既存データを上書きしない
    G=defState();
  }
  if(G.randomEvent)G.randomEvent.sessionCount=0;
  initTicker();
  updateRepBar();
}

// v4.7 倉庫日誌の型と件数をそろえる
function jnlSanitize(x){
  const n=v=>{v=Number(v);return isFinite(v)&&v>0?v:0;};
  const ok=x&&typeof x==='object';
  const done=a=>Array.isArray(a)?a.filter(d=>d&&typeof d==='object'&&CASK_TYPES.some(c=>c.id===d.c)&&CASK_SIZES.some(z=>z.id===d.z)).slice(0,5).map(d=>({c:d.c,z:d.z,g:n(d.g),n:String(d.n||'').slice(0,12)})):[];
  const staff=a=>Array.isArray(a)?a.filter(t=>typeof t==='string').slice(0,5).map(t=>t.slice(0,80)):[];
  const list=ok&&Array.isArray(x.list)?x.list.filter(e=>e&&typeof e.d==='string').slice(0,14).map(e=>({d:e.d,fill:n(e.fill),btl:n(e.btl),ord:n(e.ord),earn:n(e.earn),angel:n(e.angel),done:done(e.done),dn:n(e.dn),staff:staff(e.staff),w:Math.floor(n(e.w))%5})):[];
  let cur=null;
  if(ok&&x.cur&&typeof x.cur==='object'&&typeof x.cur.d==='string'){const c=x.cur,s0=c.s0||{};cur={d:c.d,s0:{f:n(s0.f),b:n(s0.b),o:n(s0.o),e:n(s0.e)},angel:n(c.angel),done:done(c.done),dn:n(c.dn),staff:staff(c.staff)};}
  return {cur,list};
}

// v4.8 職人の型と範囲をそろえる
function staffSanitize(a){
  if(!Array.isArray(a))return [];
  const n=(v,d,lo,hi)=>{v=Number(v);if(!isFinite(v))v=d;return Math.max(lo,Math.min(hi,v));};
  const st=o=>{o=o&&typeof o==='object'?o:{};return {waza:Math.round(n(o.waza,1,1,10)),tegiwa:Math.round(n(o.tegiwa,1,1,10)),mekiki:Math.round(n(o.mekiki,1,1,10))};};
  const out=a.filter(x=>x&&typeof x==='object'&&typeof x.nm==='string').slice(0,17).map(x=>({id:String(x.id||('s_'+Math.random().toString(36).slice(2))),nm:x.nm.slice(0,12),seed:Math.floor(n(x.seed,0,0,1e9)),r:Math.round(n(x.r,1,1,3)),st:st(x.st),tr:STAFF_TRAITS.some(t=>t.id===x.tr)?x.tr:'calm',lv:Math.round(n(x.lv,1,1,10)),xp:n(x.xp,0,0,1e6),post:typeof x.post==='string'?x.post.slice(0,8):null,at:placeAtSanitize(x.at),hired:Number(x.hired)||0,train:Number(x.train)||0}));
  return out;
}
function staffCandSanitize(c){
  if(!c||typeof c!=='object'||typeof c.d!=='string'||!Array.isArray(c.list))return null;
  const L=staffSanitize(c.list.map(x=>Object.assign({},x,{id:'c'}))).slice(0,3).map(x=>({nm:x.nm,seed:x.seed,r:x.r,st:x.st,tr:x.tr}));
  return {d:c.d,list:L,free:c.free?1:0};
}
