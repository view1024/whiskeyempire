function getEventMult(type){
  const a=G.randomEvent&&G.randomEvent.active;
  if(!a)return 1;
  const e=a.effect||{};
  if(type==='passive'){if(e.passiveMult)return e.passiveMult;if(e.allMult)return e.allMult;}
  if(type==='tap'){if(e.allMult)return e.allMult;}
  if(type==='angelShare'&&e.angelShareMult)return e.angelShareMult;
  if(type==='agedPrice'&&e.agedPriceMult)return e.agedPriceMult;
  if(type==='caskCost'&&e.caskCostMult)return e.caskCostMult;
  return 1;
}
