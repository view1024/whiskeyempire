const { chromium } = require('playwright');
const path = require('path');
const STATE = require('fs').readFileSync('v43.js', 'utf8').match(/const STATE = (function \(mode\) \{[\s\S]*?\n\});/)[1];
(async () => {
  const browser = await chromium.launch(); const errors = [];
  for (const [W, H] of [[393, 760], [390, 667]]) {
    const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1.5 });
    const page = await ctx.newPage(); page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto('file://' + path.resolve('whisky_empire.html')); await page.waitForTimeout(1200);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(300);
    await page.evaluate(`(${STATE})('mid')`); await page.waitForTimeout(300); await page.evaluate(() => { celebrate = () => {}; _celebQ = []; celebClose(); const tt = document.getElementById('toast'); toast = () => {}; if (tt) tt.classList.remove('on'); });
    await page.evaluate(() => { _celebQ = []; celebClose(); closeM(); G.hg = { n: 2, got: 2, used: 0 }; document.querySelectorAll('.toast').forEach(t => t.classList.remove('on'));
      const l = G.lots.find(x => x.age >= 9); const o = G.orders.find(x => x.kind === 'product'); if (o && !ordInProgress(o)) { ordFulfill(o.id); } rall(); });
    await page.waitForTimeout(300);
    const pre = `v46_${W}x${H}`;
    for (const t of ['td', 'tb', 'tcel', 'tsale']) { await page.evaluate(t => { switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); } }, t); await page.waitForTimeout(250); await page.screenshot({ path: `${pre}_${t}.png` }); }
    if (W === 393) {
      await page.evaluate(() => { tap(null); }); await page.waitForTimeout(60); await page.evaluate(() => switchTab('td')); await page.screenshot({ path: `${pre}_tapfx.png` });
      await page.evaluate(() => { switchTab('tsale'); openBottleModal(''); }); await page.waitForTimeout(250); await page.screenshot({ path: `${pre}_bot.png` });
      await page.evaluate(() => { closeM(); switchTab('te'); _ui.encTab = 's'; renc(); const s = STORY_EPISODES[0].id; if (!G.story.unlocked.includes(s)) G.story.unlocked.push(s); openStoryModal(s); }); await page.waitForTimeout(250); await page.screenshot({ path: `${pre}_story.png` });
      await page.evaluate(() => { closeM(); _ui.encTab = 'r'; renc(); }); await page.waitForTimeout(200); await page.screenshot({ path: `${pre}_rec.png` });
      await page.evaluate(() => { switchTab('td'); openHgModal(); }); await page.waitForTimeout(200); await page.screenshot({ path: `${pre}_hg.png` });
      await page.evaluate(() => { hgUse(); }); await page.waitForTimeout(300); await page.screenshot({ path: `${pre}_hgrep.png` });
    }
    await ctx.close();
  }
  console.log('ERRORS', errors); await browser.close();
})();
