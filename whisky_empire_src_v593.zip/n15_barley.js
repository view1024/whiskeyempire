// ============================================================
// v4.4 大麦の仕入れ：製麦室は大麦の在庫（サイロ）から麦芽を作る
// ゲーム上は「大麦1kg＝麦芽1L分」として扱う（実際の比率とは異なる簡略化）
// ============================================================
// v5.9.2 サイロは製麦室の24時間分（8時間分から）。自動仕入れで戻す量は今までと同じ（上限の1/30＝0.8時間分/時）
const BARLEY={RATIO:0.2,SILO_H:24,SILO_MIN:2400,REFILL_PER_H:0.1/3};
const BARLEY_GRAIN_MULT={golden_promise:1.0,optic:0.85,concerto:1.0,corn_rich:1.3};
function fmtPk(v){return v<100?'$'+(Math.round(v*100)/100).toFixed(2):fmt(v);}
function fmtKg(v){if(!isFinite(v))return '∞kg';if(v>=1e7)return fmtN(v/1000)+'t';if(v>=1e4)return (v/1000).toFixed(1)+'t';return Math.floor(v).toLocaleString()+'kg';}
function barleyState(){
  if(!G.barley||typeof G.barley!=='object')G.barley={kg:null,auto:true};
  if(G.barley.kg===null||G.barley.kg===undefined||!isFinite(G.barley.kg))G.barley.kg=barleyCap();
  return G.barley;
}
function barleyCap(){const c=stageCap(0);return Math.max(BARLEY.SILO_MIN,Math.round(c*BARLEY.SILO_H));}
function barleyGrainMult(){const g=G.recipe&&G.recipe.grain;return BARLEY_GRAIN_MULT[g]||1;}
function barleyPrice(){return STAGES[0].price*BARLEY.RATIO*distMult()*barleyGrainMult()*mktFx('barley')*rawM('barley')*barleyGrade().p;}
// v5.1 大麦の等級（価格と、詰める樽の品質）
function barleyGrade(){return V51.GRADE.std;} // v5.4 等級は廃止（標準だけ）
// 在庫があるか、自動仕入れで今すぐ買えるなら製麦できる
function barleyOK(){const b=barleyState();return b.kg>=1||(b.auto&&G.cash>=barleyPrice());}
function barleyUsePh(){const f=prodFlows();return f.p[0]||0;}
function barleyCostPh(){return barleyUsePh()*barleyPrice();}
function barleyHoursLeft(){const u=barleyUsePh();return u>0?barleyState().kg/u:Infinity;}
// 必要量を在庫から使い、足りなければ自動仕入れで買う。実際に使えた量を返す
function barleyTake(need){
  const b=barleyState();if(!(need>0))return 0;
  let got=Math.min(need,b.kg);b.kg-=got;
  const pr=barleyPrice();
  if(b.auto){
    // 使った分は買い足し、在庫が減っていれば1時間あたり上限の10%ずつ戻す
    const short=need-got;
    const buyNow=Math.min(short,G.cash/pr);
    if(buyNow>0){acBarley(b.kg,buyNow,pr);got+=buyNow;barleyStat(buyNow,pr);}
  }
  return got;
}
function barleyAutoRefill(hours){
  const b=barleyState();if(!b.auto)return;
  const pr=barleyPrice();const cap=barleyCap();
  const used=Math.max(0,(b._used||0));b._used=0;
  const want=Math.min(cap-b.kg,used+cap*BARLEY.REFILL_PER_H*hours);
  const buy=Math.max(0,Math.min(want,G.cash/pr));
  if(buy>0){acBarley(b.kg,buy,pr);b.kg+=buy;barleyStat(buy,pr);}
}
function barleyStat(kg,pr){G.stats.barleyKg=(G.stats.barleyKg||0)+kg;G.stats.barleyCost=(G.stats.barleyCost||0)+kg*pr;}
function barleyBuyFull(){
  const b=barleyState();const pr=barleyPrice();const room=Math.max(0,barleyCap()-b.kg);
  const kg=Math.min(room,Math.floor(G.cash/pr));
  if(room<1){toast('サイロは満タンです');return 0;}
  if(kg<1){toast('資金が足りません（1kg '+fmtPk(pr)+'）');return 0;}
  acBarley(b.kg,kg,pr);b.kg+=kg;barleyStat(kg,pr);prodInvalidate();sndPurchase();
  toast('🌾 大麦 '+fmtKg(kg)+' を仕入れました −'+fmt(kg*pr),2500);return kg;
}
function barleyRowHtml(){
  const b=barleyState();const cap=barleyCap();const use=barleyUsePh();const hl=barleyHoursLeft();
  const starved=!barleyOK()&&stageCap(0)>0;
  const mk=mktFx('barley');const gd=barleyGrade();
  const sub=starved?'大麦が切れて製麦が止まっています':(b.auto?'':(use>0?'約'+(hl>=100?'99+':(Math.floor(hl*10)/10))+'時間分 ・ ':'')+'自動OFF ・ ')+fmtPk(barleyPrice())+'/kg'+(gd!==V51.GRADE.std?' ・ '+gd.nm:'')+(mk>1.001?' ・ 今月高い ×'+mk:mk<0.999?' ・ 今月安い ×'+mk:'');
  return `<div class="pst pbar-in${starved?' bn':''}" id="barleyBox"><div class="pmain" data-act="barleyOpen"><div class="pic ric">${ic('barley',26)}</div>
    <div class="ptx"><div class="pnm">大麦 <span class="plv">${fmtKg(b.kg)}</span></div>
    <div class="pbar brl"><i style="width:${Math.min(100,b.kg/cap*100)}%"></i></div>
    <div class="pcap"${starved?' style="color:var(--red)"':''}>${escapeHtml(sub)}</div></div></div>
    <button type="button" class="ub pbtn" data-act="barleyOpen"><span>大麦</span><b>仕入れ</b></button></div>
    <div class="pflow${use>0?' run '+flowSpd(use,Math.max(1,...prodFlows().cap)):''}"><span class="pband"></span><span class="pfl">大麦 ${use>0?fmtKg(use)+'/時':'—'}</span>${use>0?`<span class="psur pcost">原料費 −${fmt(barleyCostPh())}/時</span>`:''}</div>`;
}
function openBarleyModal(){
  const b=barleyState();const pr=barleyPrice();const cap=barleyCap();const room=Math.max(0,cap-b.kg);
  const g=rcpItem('grain',G.recipe.grain);const gm=barleyGrainMult();const mk=mktFx('barley');
  openModal(`<div class="mt">🌾 大麦の仕入れ</div><div class="ms">サイロには製麦室の24時間分まで置けます</div>
    <div class="card"><div class="row sb"><span class="tt">在庫</span><span class="vv">${fmtKg(b.kg)} / ${fmtKg(cap)}</span></div>
      <div class="pbar brl"><i style="width:${Math.min(100,b.kg/cap*100)}%"></i></div>
      <div class="sm">使う量 ${fmtKg(barleyUsePh())}/時 ・ 原料費 ${fmt(barleyCostPh())}/時</div></div>
    <div class="card"><div class="row sb"><span class="tt">価格</span><span class="vv">${fmtPk(pr)}/kg</span></div>
      <div class="sm">品種：${escapeHtml(g.name)}（×${gm}）${mk!==1?' ・ 今月の市場 ×'+mk+(mk>1?'（高い）':'（安い）'):''}</div></div>
    <div class="optrow"><span class="tt" style="font-size:15px">自動仕入れ</span><span class="seg"><button type="button" class="sb2 opt ${b.auto?'on':'gh'}" aria-pressed="${b.auto}" data-act="barleyAuto" data-v="1">${b.auto?'✓ ':''}ON</button><button type="button" class="sb2 opt ${!b.auto?'on':'gh'}" aria-pressed="${!b.auto}" data-act="barleyAuto" data-v="0">${!b.auto?'✓ ':''}OFF</button></span></div>
    ${b.auto?'':'<div class="sm" style="color:var(--amber);margin:4px 0">⚠ OFFのままだと、在庫が切れた時点で製麦が止まります（放置中も）</div>'}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button type="button" class="btn-cancel" data-act="closeM">閉じる</button>
      <button type="button" class="btn-ok" data-act="barleyBuy" ${room>=1&&G.cash>=pr?'':'disabled'}>満タンまで ${fmt(Math.min(room,Math.floor(G.cash/pr))*pr)}</button></div>`);
}
