const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const mode = process.argv[2] || 'mid';
  const H = Number(process.argv[3] || 740);
  const ctx = await browser.newContext({ viewport: { width: 390, height: H }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !m.text().includes('ERR_FAILED')) errors.push(m.text()); if (m.type()==='warning') errors.push('warn '+m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1500);
  await page.evaluate(()=>{titleStart(false);});await page.waitForTimeout(600);
  await page.evaluate((mode) => {
    if (_offlineGate) closeOfflineModal(); closeM();
    Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ=[]; celebClose();
    if (mode === 'mid') {
      G.dl = 3; G.cash = 8e7; G.te = 5e8; G.reputation = 60; G.stats.shipped = 2500; G.stats.orders = 22;
      FD.forEach((f, i) => { G.fac[f.id].p = true; G.fac[f.id].l = [24, 22, 26, 21, 18, 14][i]; });
      G.branch.malting = 1; G.branch.fermentation = 0; G.branch.distillation = null;
      G.uw = WL.slice(0, 14).map(w => w.id);
      const mk = (c, s, age) => { const l = makeLot(caskType(c), caskSize(s)); l.age = age; l.L = l.L0 * Math.pow(0.984, age); return l; };
      G.lots = [mk('sherry', 'hogshead', 12.4), mk('bourbon', 'hogshead', 9.1), mk('bourbon', 'quarter', 4.6), mk('wine', 'barrel', 2.2), mk('bourbon', 'butt', 7.8), mk('sherry', 'hogshead', 0.4)];
      for (let i = 0; i < 10; i++) G.lots.push(mk('bourbon', 'hogshead', 1 + i * 1.3));
      G.tank = 1800;
      const t = productSpec('glenlivid').target;
      invAdd('glenlivid', 140, 9, 1.05, t); invAdd('jack_d', 60, 5, 1.0, productSpec('jack_d').target); invAdd('johnnie_em', 25, 12, 1.1, productSpec('johnnie_em').target);
      G.orders = [];
      for (let i = 0; i < 5; i++) { const o = ordGenerate(); if (o) G.orders.push(o); }
      G.orders[0].reserve = true; G.orders[0].accepted = false;
      G.rel.local = { lv: 2, done: 9 }; G.rel.bar = { lv: 1, done: 4 };
      G.shipLog = { glenlivid: { t: Date.now(), maxAge: 9 }, jack_d: { t: Date.now(), maxAge: 5 } };
      G.bq = [{ id: 'q_x', pid: 'glenlivid', n: 300, done: 120, moved: 120, age: 9, q: 1.05, fl: t, blend: null, oid: null }];
      G.blendHistory = [{ t: Date.now(), target: 'classic_blend', score: 0.82, n: 120 }];
      G.lots[0].name='はじまりの一樽'; G.lots[1].fin={from:'bourbon',at:8}; G.caskLog=[{name:'祖父の樽',cask:'sherry',age:21.3,t:Date.now()-864e5}];
      G.records={speyside:{bestUnit:4200,maxAge:22.4,tierDays:{2:6.9,3:18.5},runs:0}};
    }
    prodInvalidate(); rall();
  }, mode);
  const tabs = ['td', 'tb', 'tcel', 'tsale', 'te', 'tp'];
  for (const t of tabs) {
    await page.evaluate(t => switchTab(t), t);
    await page.waitForTimeout(300);
    await page.screenshot({ path: `v42_${mode}_${t}${H > 900 ? '_tall' : ''}.png` });
  }
  if (mode === 'mid') {
    for (const et of ['c','r']) { await page.evaluate(et => { switchTab('te'); _ui.encTab = et; renc(); }, et); await page.waitForTimeout(200); await page.screenshot({ path: `v42_${mode}_enc_${et}.png` }); }
    const modals=[['lot',"openLotModal(G.lots[0].id)"],['fin',"openFinishModal(G.lots[2].id)"],['chap',"openChapModal()"],['rel',"(()=>{closeM();G.relEvQ=[{cid:'bar',lv:3}];relEventTick();})()"],['tk',"(()=>{closeM();openTickerModal();})()"],['cel',"(()=>{closeM();celebrate({icon:'🏭',title:'地方蒸留所に昇格',sub:'Tier3 ・ 設備の上限Lv30'});})()"],['card',"(()=>{celebClose();celebrate({card:{em:WL[3].em,name:WL[3].name,rg:WL[3].rg},title:'図鑑に登録：'+WL[3].name,sub:'はじめて出荷した銘柄です'});})()"]];
    for (const [n,js] of modals){ await page.evaluate(js); await page.waitForTimeout(n==='card'?1800:500); await page.screenshot({ path: `v42_m_${n}.png` }); }
    await page.evaluate(()=>{celebClose();closeM();});
    for (const st of ['inv', 'rel', 'comp', 'rg']) {
      await page.evaluate(st => { switchTab('tsale'); _ui.sellTab = st; rShip(); }, st);
      await page.waitForTimeout(200);
      await page.screenshot({ path: `v42_${mode}_sale_${st}${H > 900 ? '_tall' : ''}.png` });
    }
  }
  console.log('ERRORS:', errors.length ? errors.join('\n') : 'none');
  await browser.close();
})();
