# v4.8 の変更に合わせて v4.7 までのテストを置き換える
R2("const ok = s.bytes <= 780000 &&","const ok = s.bytes <= 820000 &&")
R2("rec(105, '配布版は780KB以下（v4.7 で+40KBまで）：","rec(105, '配布版は820KB以下（v4.7・v4.8 で各+40KBまで）：")
R2("'tier=' + tok + '/' + ts.length, 'hg=2/3'];","'tier=' + tok + '/' + ts.length, 'hg=2/' + V47.HG_MAX].concat(staffOn() ? ['staff=' + G.staff.length + '/' + staffCap()] : []);")
R2("r.icons === 'hi_chap,hi_daily,hi_mkt,hi_tier,hi_hg'","r.icons.replace(',hi_staff', '') === 'hi_chap,hi_daily,hi_mkt,hi_tier,hi_hg'")
