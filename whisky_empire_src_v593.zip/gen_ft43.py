exec(open('gen_ft42.py').read().replace("open('functest42.js','w').write(s)","pass"))
def R2(a,b):
    global s
    assert a in s, a[:70]
    s=s.replace(a,b)
R2("await page.click('#fl [data-act=\"facUp\"][data-id=\"malting\"]');","await page.click('#lineView [data-act=\"facUp\"][data-id=\"malting\"]');")
R2("rec('30b', 'UI操作: 設備一覧のボタン1回で強化'","rec('30b', 'UI操作: 生産ラインのボタン1回で強化'")
R2("const blend1 = document.getElementById('blendWrap').style.display;","const blend1 = document.getElementById('btnBlend').style.display;")
R2("[...document.querySelectorAll('#fl .lk, #fl .frow')]","[...document.querySelectorAll('#lineView .pst')]")
R2("document.querySelector('#td .sm')","document.querySelector('#tcel .thead .sm')")
R2("const bb = await page.evaluate(() => { switchTab('td'); const r = document.getElementById('bb').getBoundingClientRect(); return { w: Math.round(r.width), cx: Math.round(r.left + r.width / 2), vw: window.innerWidth }; });",
   "const bb = await page.evaluate(() => { switchTab('td'); const r = document.getElementById('bb').getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height), cx: Math.round(r.left + r.width / 2), vw: window.innerWidth }; });")
R2("rec(45, '樽画像を画面中央に大きく（幅200px以上・中心が画面中央±10px）', bb.w >= 200 &&","rec(45, '樽画像を画面中央に大きく（高さ200px以上・押せる範囲は瓶の幅に合わせる・中心が画面中央±10px）', bb.h >= 200 && bb.w >= 100 && bb.w <= bb.h * 0.7 &&")
import os
if os.path.exists('functest43_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest43_add.js').read()+s[a:]
open('functest43.js','w').write(s)
