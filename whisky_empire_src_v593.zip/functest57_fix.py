# v5.6.1・v5.7 の変更に合わせて v5.6 までのテストを置き換える
# #60b：寝かせるは見出しの下（#celBody）だけがスクロールする（v5.6.1）
R2("tc = document.getElementById('tcel'); const inner = w.scrollHeight", "tc = document.getElementById('celBody'); const inner = w.scrollHeight")
R2("&& lc.top >= hd.bottom - 1 && hd.top >= tc.getBoundingClientRect().top - 1;", "&& lc.top >= hd.bottom - 1 && hd.bottom <= tc.getBoundingClientRect().top + 1;")
R2("rec('60b', '寝かせる：棚と倉庫の枠に内部スクロールがなく、タブを一番下まで動かすと最後の樽が見える（見出しは上に貼り付く）", "rec('60b', '寝かせる：棚と倉庫の枠に内部スクロールがなく、見出しの下を一番下まで動かすと最後の樽が見える（見出しは固定・v5.6.1）")
# #88：①②③は #celBody の中
R2("const vis = () => [...document.getElementById('tcel').children].filter(", "const vis = () => [document.querySelector('#tcel .thead'), ...document.getElementById('celBody').children].filter(")
# #153：売るは見出しの下（#saleBody）だけがスクロールし、切り替えのチップはその上端に貼り付く（v5.6.1）
R2("_ui.sellTab = 'ord'; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 80));\n      const t = document.getElementById('tsale'); const o = {};", "_ui.sellTab = 'ord'; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 80));\n      const t = document.getElementById('saleBody'); const o = {};")
R2("const tr = t.getBoundingClientRect(), hr = t.querySelector('.shead').getBoundingClientRect();\n      o.sticky = Math.abs(hr.top - tr.top) <= 2 && !!t.querySelector('.shead #sellChips');", "const tr = t.getBoundingClientRect(), hr = t.querySelector('#sellChips').getBoundingClientRect();\n      o.sticky = Math.abs(hr.top - tr.top) <= 2 && document.querySelector('#tsale .thead').getBoundingClientRect().bottom <= tr.top + 1;")
R2("rec(153, '売る：注文20件でタブ全体がスクロールし、中に内部スクロールがない・見出しと切り替えのチップは上に貼り付く・", "rec(153, '売る：注文20件で見出しの下がスクロールし（v5.6.1）、その中に内部スクロールがない・見出しは固定、切り替えのチップは上端に貼り付く・")
# #86：樽の原価＝新酒（大麦単価＋製造費）＋樽代（v5.7）
R2("const fillOk = Math.abs(c0 - G.cash - cc) < 1e-6 && Math.abs(lot.c - (250 * bA + cc)) < 1e-6;", "const fillOk = Math.abs(c0 - G.cash - cc) < 1e-6 && Math.abs(lot.c - (250 * (bA + tankMfgU()) + cc)) < 1e-6;")
R2("rec(86, '原価：樽＝新酒（大麦単価）＋樽代、", "rec(86, '原価：樽＝新酒（大麦単価＋製造費・v5.7）＋樽代、")
# #118：樽を叩いても樽の状態は変わらない（毎秒の熟成費で原価 c は増えるので比べない）
R2("const lsig = () => JSON.stringify(G.lots.map(l => ({ ...l, age: 0, L: 0 })));", "const lsig = () => JSON.stringify(G.lots.map(l => ({ ...l, age: 0, L: 0, c: 0, c0: 0 })));")
# #141：「うち原材料費」は大麦・空き樽・瓶の資材（製造費・熟成費は別の行）
R2("const raw = sumO(p.pur); const html = finRows(p, 'pl');", "const raw = (p.pur.barley || 0) + (p.pur.cask || 0) + (p.pur.bottle || 0); const html = finRows(p, 'pl');")
