const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 740 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !m.text().includes('ERR_FAILED')) errors.push(m.type() + ': ' + m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1500);
  const t0 = Date.now();
  for (let k = 0; k < 12; k++) {
    const info = await page.evaluate(() => _tut ? { id: _tut.id, i: _tut.i, do: !!(tutStep() && tutStep().do), sel: tutStep() && tutStep().sel } : null);
    if (!info) break;
    await page.waitForTimeout(500);
    await page.screenshot({ path: `tw_${k}.png` });
    if (info.do) {
      const box = await page.evaluate(() => { const el = tutEl(tutStep()); if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
      if (box) await page.mouse.click(box.x, box.y); else await page.waitForTimeout(1600);
    } else {
      await page.mouse.click(195, 90);
    }
    await page.waitForTimeout(700);
  }
  const st = await page.evaluate(() => ({ tut: G.tut, cash: G.cash, orders: G.stats.orders, malt: facLv('malting'), shipped: G.stats.shipped, tab: document.querySelector('.tab.on').id }));
  console.log(JSON.stringify(st), 'sec', (Date.now() - t0) / 1000);
  console.log('ERRORS:', errors.length ? errors.join('\n') : 'none');
  await browser.close();
})();
