  // ================= v5.8 追加テスト =================
  // ---------- #171 BGM「ケルト」5曲（v5.8）：ABC 譜の読み取り・各曲の小節と和音の数・60〜130秒・同時に鳴る音は16まで・乱数で編成が変わる・環境音楽の廃止・保存の移行・⚙️・TIPS ----------
  try {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      // ABC：調号（ホ短調ドリア F#・C#）・臨時記号は小節の中の同じ高さで続く（=C は C4 だけ。c' は調号どおり C#）・オクターブ・付点・タイ・三連符・前打音・装飾（上の音）
      const P = abcParse("E2 ^G G B,|{c}B TB F/>F/ (3ABc|A4- A2 =C c'|", 'Edor');
      o.abc = P.n.map(x => [+x.t.toFixed(3), +x.len.toFixed(3), x.m, x.g]);
      o.abcSeg = P.seg.map(s => Math.round(s[1] * 1000) / 1000).join(); o.abcLen = P.len;
      o.abcOk = JSON.stringify(o.abc) === JSON.stringify([[0, 2, 64, 0], [2, 1, 68, 0], [3, 1, 68, 0], [4, 1, 59, 0], [5, 0.15, 73, 1], [5.15, 0.85, 71, 0], [6, 0.15, 73, 1], [6.15, 0.85, 71, 0], [7, 0.75, 66, 0], [7.75, 0.25, 66, 0], [8, 0.667, 69, 0], [8.667, 0.667, 71, 0], [9.333, 0.667, 73, 0], [10, 6, 69, 0], [16, 1, 60, 0], [17, 1, 85, 0]]) && o.abcSeg === '5,5,8' && o.abcLen === 18;
      // 各曲の譜：区間（小節）の数＝和音の数、小節の長さ
      const T = [[CEL_MAG_A, 'Edor', CEL_MAG_CA, 8], [CEL_MAG_B, 'Edor', CEL_MAG_CB, 8], [CEL_WAS_A, 'F', CEL_WAS_CA, 6], [CEL_WAS_B, 'F', CEL_WAS_CB, 6], [CEL_HH_A, 'D', CEL_HH_CA, 8], [CEL_HH_B, 'D', CEL_HH_CB, 8], [CEL_SB_A, 'D', CEL_SB_CA, 6], [CEL_SB_B, 'D', CEL_SB_CB, 6], [CEL_ST_A + 'z C/E/|', 'Fsm', CEL_ST_CA, 8], [CEL_ST_B, 'Fsm', CEL_ST_CB, 8], [CEL_ST_C + 'F4|', 'Fsm', CEL_ST_CB, 8]];
      o.tunes = T.map(([s, k, ch, b]) => { const P = abcParse(s, k); const inner = P.seg.slice(1, -1).every(x => Math.abs(x[1] - b) < 1e-9); const chordsOk = ch.every(c => c.split(/\s+/).filter(Boolean).every(x => !!celChord(x))); return [P.seg.length === ch.length, inner, chordsOk, Math.abs(P.len % b) < 1e-9]; });
      // 曲：60〜130秒・同時に鳴る音は16まで・値の範囲・乱数で編成が変わる
      const poly = N => { let mx = 0; N.forEach((n, j) => { let c = 0; for (let k = Math.max(0, j - 600); k < N.length && N[k][0] <= n[0]; k++) { const m = N[k]; if (m[0] + m[1] + BGM_TAIL[m[4]] > n[0]) c++; } if (c > mx) mx = c; }); return mx; };
      let s2 = 5; const rnd = () => { s2 = (s2 * 16807) % 2147483647; return s2 / 2147483647; };
      o.len = BGM_CELTIC.map((p, i) => { let mn = 1e9, mx = 0, pm = 0, bad = 0; const ins = new Set(); for (let k = 0; k < 4; k++) { const N = bgmBuild(i, rnd, BGM_CELTIC); const d = bgmDur(N); mn = Math.min(mn, d); mx = Math.max(mx, d); pm = Math.max(pm, poly(N)); N.forEach(n => ins.add(n[4])); bad += N.filter(n => !(n[0] >= 0 && n[1] > 0 && n[2] >= 24 && n[2] <= 108 && n[3] > 0 && n[3] <= 1)).length; } return [p.id, Math.round(mn), Math.round(mx), pm, bad, [...ins].sort((a, b) => a - b).join('')]; });
      o.vary = BGM_CELTIC.map((p, i) => JSON.stringify(bgmBuild(i, () => 0.01, BGM_CELTIC)) !== JSON.stringify(bgmBuild(i, () => 0.99, BGM_CELTIC)));
      o.tail = BGM_TAIL.length;
      // 音色：7〜10 を OfflineAudioContext で鳴らして、音が出て音割れしない
      const ctxO = new OfflineAudioContext(1, 8000 * 3, 8000); const save = _bgm.master; const m = ctxO.createGain(); m.gain.value = 0.22; m.connect(ctxO.destination); _bgm.master = m; _bgmNoise = null;
      [7, 8, 9, 10].forEach((ins, k) => bgmPlay(ctxO, ins, 64, 0.1 + k * 0.7, 0.4, 1));
      const buf = await ctxO.startRendering(); _bgm.master = save; _bgmNoise = null; const d = buf.getChannelData(0);
      o.voice = [0, 1, 2, 3].map(k => { let pk = 0; for (let j = Math.floor((0.1 + k * 0.7) * 8000); j < Math.floor((0.65 + k * 0.7) * 8000); j++) pk = Math.max(pk, Math.abs(d[j])); return +pk.toFixed(3); });
      // シャッフル：ケルトでは5曲を1回ずつ
      opt().bgmMode = 'celtic'; _bgmc.bag = []; _bgmc.i = -1; const seq = []; for (let k = 0; k < 10; k++) { const i = bgmNext(); seq.push(i); _bgmc.i = i; }
      o.shuffle = [new Set(seq.slice(0, 5)).size, new Set(seq.slice(5)).size, seq.every(i => i < 5), !seq.some((x, j) => j && seq[j - 1] === x)];
      o.list = [bgmList() === BGM_CELTIC, (opt().bgmMode = 'ambient', bgmMode()), (opt().bgmMode = 'classic', bgmList() === BGM_PIECES)];
      _bgmc.bag = []; _bgmc.i = -1;
      // 環境音楽の生成は削除
      o.noAmb = ['bgmBar', 'bgmVoice', 'BGM_CHORDS', 'BGM_PENTA'].every(k => { try { return eval('typeof ' + k) === 'undefined'; } catch (e) { return true; } });
      // 保存の移行：環境音楽 → ケルト
      const s = JSON.parse(JSON.stringify(G)); s.opt.bgmMode = 'ambient'; o.mig = sanitize(s).opt.bgmMode;
      // ⚙️：クラシック／ケルト／なし
      switchTab('tp'); rall(); await new Promise(r => setTimeout(r, 50));
      o.ui = [...document.querySelectorAll('[data-act="optSet"][data-k="bgmMode"]')].map(b => b.dataset.v + ':' + b.textContent.replace('✓', '').trim()).join();
      const tip = (TIPS.find(t => t.id === 'bgm') || {}).b || '';
      o.tip = ['ケルト', 'ドラウジー・マギー', 'ウォッシャーウーマン', 'ハーベスト・ホーム', 'シー・ベグ', 'カウンティ・ダウン', 'オキャロラン', 'ハープ', 'フィドル', 'ティンホイッスル', 'バウロン'].filter(w => !tip.includes(w));
      return o;
    });
    const ok = r.abcOk && r.tunes.every(t => t.every(Boolean)) && r.len.length === 5 && r.len.every(x => x[1] >= 60 && x[2] <= 130 && x[3] <= 16 && x[4] === 0) && r.len.every(x => x[5].includes('7')) && r.vary.every(Boolean) && r.tail === 11 && r.voice.every(v => v > 0.003 && v < 0.5)
      && r.shuffle.join() === '5,5,true,true' && r.list.join() === 'true,celtic,true' && r.noAmb && r.mig === 'celtic' && r.ui === 'classic:クラシック,celtic:ケルト,off:なし' && r.tip.length === 0;
    rec(171, 'BGM「ケルト」5曲（v5.8）：ABC 譜の読み取り（調号・臨時記号・オクターブ・付点・タイ・三連符・前打音・装飾）・各曲の小節と和音の数が合う・各曲60〜130秒・同時に鳴る音は16まで・乱数で編成が変わる・ハープ・フィドル・ホイッスル・バウロンの音が出て音割れしない・5曲をシャッフル・環境音楽の生成を削除し保存の「環境音楽」はケルトに・⚙️はクラシック／ケルト／なし・TIPSに曲と楽器', ok, JSON.stringify(r));
    if (errors.length) rec('E116', 'ケルトのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C171', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
  // ---------- #172 軽量化（v5.8）：配布版は v5.7（895,453 B）より小さい・未使用の CSS の規則を除く・使っていないクエストと販売地域の説明文を外す・更新履歴は v5.0 以降 ----------
  try {
    const fs = require('fs');
    const out = fs.readFileSync('whisky_empire.html', 'utf8'), dev = fs.readFileSync('whisky_empire.dev.html', 'utf8');
    const dead = JSON.parse((fs.readFileSync('assemble.py', 'utf8').match(/DEAD_CSS = (\[[^\]]*\])/) || [])[1].replace(/'/g, '"'));
    const st = (out.match(/<style>([\s\S]*?)<\/style>/) || [])[1] || '';
    // 未使用のクラスだけを指す規則（セレクタのどれもがそのクラスを含む）が残っていない。使っているセレクタと並んだ規則は残る（.smoke など）
    const pre = [...st.matchAll(/([^{}]+)\{/g)].map(m => m[1]).filter(p => !p.startsWith('@'));
    const s = { bytes: Buffer.byteLength(out), dead: dead.length, left: dead.filter(c => { const re = new RegExp('\\.' + c.replace(/-/g, '\\-') + '($|[^\\w-])'); return pre.some(p => p.split(',').every(x => re.test(x))); }) };
    s.quests = !/QUESTS|checkQuests|updateQuestPanel/.test(dev);
    const rg = (dev.match(/const REGIONS=\{[^\n]*\}/) || [''])[0], rx = (dev.match(/const REGIONS_EX=\[[^\n]*\]/) || [''])[0];
    s.regions = rg.length > 0 && rx.length > 0 && !/desc|name|cost/.test(rg + rx);
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = { vs: CHANGELOG.map(c => c.v), top: CHANGELOG[0].v === BALANCE.APP_VERSION };
      o.mult = [REGIONS.scotland.mult, REGIONS.japan.mult, REGIONS_EX.find(x => x.id === 'global').mult].join();
      // 買った地域の倍率は今までどおり（スコットランド×1.5・台湾×2.2）
      const g0 = [G.regions, G.regionsEx]; G.regions = {}; G.regionsEx = []; const m0 = saleMult(); G.regions = { scotland: true }; G.regionsEx = ['taiwan']; o.sale = +(saleMult() / m0).toFixed(3); [G.regions, G.regionsEx] = g0;
      openChangelog(); o.note = document.getElementById('mc2').textContent.includes('v4.9 以前の更新履歴は省略'); closeM();
      return o;
    });
    const ok = s.bytes < 895453 && s.left.length === 0 && s.dead >= 50 && s.quests && s.regions && r.vs.every(v => Number(v.split('.')[0]) >= 5) && r.top && r.mult === '1.5,2,3.5' && r.sale === 3.3 && r.note;
    rec(172, '軽量化（v5.8）：配布版は v5.7（895,453 B）より小さい（ケルトを加えても）・未使用の CSS のクラスだけを指す規則が残っていない・使っていないクエストと販売地域の説明文を外し、倍率は今までどおり・更新履歴は v5.0 以降で、それより前は省略と書く', ok, JSON.stringify({ ...s, ...r }));
    if (errors.length) rec('E117', '軽量化のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C172', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
  // ---------- #173 図鑑の「記録」の廃止（v5.8）：アイコンは7つで幅360pxでも1つ44px以上・名樽の記録はない・称号「初仕込み」と章の目標「ブレンドを完成させる」は今どおり・名前を付ける説明の文 ----------
  try {
    const { page, errors, ctx } = await pageW(360, 740, 'mid', false);
    const r = await page.evaluate(async () => {
      const o = {};
      switchTab('te'); _ui.encTab = 'w'; renc(); await new Promise(r => setTimeout(r, 80));
      const ic = [...document.querySelectorAll('#encGrid .eic')]; o.n = ic.length; o.w = Math.min(...ic.map(e => e.getBoundingClientRect().width)); o.h = Math.min(...ic.map(e => e.getBoundingClientRect().height));
      o.gone = ['ei_r', 'ep_r', 'caskHist', 'blendHist'].every(id => !document.getElementById(id)) && ['trackNamed', 'rencC', 'rencB'].every(k => eval('typeof ' + k) === 'undefined') && G.caskLog === undefined && !('caskLog' in defState());
      // 名前を付けて蔵出ししても記録は作らない・2秒ごとの処理は例外なく回る
      const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 5; G.lots.push(l); lotName(l.id, '記念の樽'); let err = ''; try { v42Tick(); } catch (e) { err = e.message; } G.lots = G.lots.filter(x => x !== l); try { v42Tick(); } catch (e) { err = e.message; } o.tick = err === '' && G.caskLog === undefined;
      // ブレンドの記録（データ）は残し、称号と章の目標が使う
      const s = JSON.parse(JSON.stringify(G)); s.stats.filled = 0; s.blendHistory = [{ t: Date.now(), target: BLEND_TARGETS[0].id, score: 0.9, n: 2 }];
      const t19 = TT.find(t => t.id === 't19'); o.t19 = !!t19 && t19.lb === '初仕込み' && !!t19.ch(s); const c31 = CHAPTERS.flatMap(c => c.goals || []).find(g => g.id === 'c3_1'); o.c31 = !!c31 && !!c31.ck(s);
      // 名前を付ける説明の文
      openNameModal && G.lots.length && openNameModal(G.lots[0].id); o.modal = document.getElementById('mc2').textContent; closeM();
      o.tip = (TIPS.find(t => t.id === 'named') || {}).b || '';
      o.prest = openPrestigeModal.toString().includes('名樽の記録');
      return o;
    });
    const ok = r.n === 7 && r.w >= 44 && r.h >= 44 && r.gone && r.tick && r.t19 && r.c31 && r.modal.includes('★') && !r.modal.includes('記録') && r.tip.includes('★') && !r.tip.includes('記録') && !r.prest;
    rec(173, '図鑑の「記録」の廃止（v5.8）：アイコンは7つで、幅360pxでも1つ44px以上・「記録」のページと名樽の記録はなく、名前のある樽を蔵出ししても記録を作らない・ブレンドの記録のデータは残り、称号「初仕込み」と章の目標「ブレンドを完成させる」は今どおり・名前を付ける小窓と TIPS は「棚の札に★」・再創業の引き継ぎに名樽の記録がない', ok, JSON.stringify(r));
    if (errors.length) rec('E118', '記録の廃止のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C173', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
  // ---------- #174 v5.7（schema19）からの移行：名樽の記録を消す・BGM の「環境音楽」はケルトに・移行前をバックアップ ----------
  try {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const old = JSON.parse(JSON.stringify(G)); old.ver = 19; old.caskLog = [{ name: '古い名樽', cask: 'bourbon', age: 12, t: Date.now() }]; old.opt.bgmMode = 'ambient';
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, log: m.caskLog, bgm: m.opt.bgmMode, lots: m.lots.length === old.lots.length, cash: m.cash === old.cash };
      const old2 = JSON.parse(raw); old2.opt.bgmMode = 'classic'; o.keep = parseSave(old2).opt.bgmMode;
      const key = storageKey(); const bk = 'we_v4_bak19:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver; o.g = G.caskLog === undefined && G.opt.bgmMode === 'celtic';
      return o;
    });
    const ok = r.ver === SCHEMA && SCHEMA === 20 && r.log === undefined && r.bgm === 'celtic' && r.keep === 'classic' && r.lots && r.cash && r.bk && r.loaded === SCHEMA && r.g;
    rec(174, 'v5.7（schema19）からの移行：名樽の記録（caskLog）を消す・BGM の「環境音楽」はケルトに（クラシックはそのまま）・樽と資金はそのまま・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E119', '移行（v20）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C174', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
