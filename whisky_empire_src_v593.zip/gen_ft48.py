exec(open('gen_ft47.py').read().replace("open('functest47.js','w').write(s)","pass"))
import os
exec(open('functest48_fix.py').read())
if os.path.exists('functest48_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest48_add.js').read()+s[a:]
open('functest48.js','w').write(s)
