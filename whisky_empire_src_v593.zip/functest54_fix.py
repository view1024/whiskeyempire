# v5.4 の変更に合わせて v5.3 までのテストを置き換える
# #61：TIPS帯の速さの設定を廃止（⚙️に「TIPS帯」の行がない）
R2("&& o.opts === 'slow,mid,fast');", "&& o.opts === '');")
R2("rec(61, 'TIPS帯：「視差効果を減らす」の端末でも右から左へ流れ、最後の文字まで表示枠を通過する（減らす設定では約0.65倍の速さ・「流さない」は廃止）'", "rec(61, 'TIPS帯：「視差効果を減らす」の端末でも右から左へ流れ、最後の文字まで表示枠を通過する（減らす設定では約0.65倍の速さ・速さの設定は v5.4 で廃止）'")
# #106：砂時計の入手（節目は1日5樽・納品は1日4個・月の決算と取引先の★はなし）
R2("const mon = [hgMonth(), hgMonth()]; const month = G.hg.n - m1;", "const mon = [typeof hgMonth === 'undefined', V51.HG.month === undefined]; const month = G.hg.n - m1;")
R2("const ok = r.src.join() === 'true,false,true,false,true,true,true,false' && r.ord === 3 &&", "const ok = r.src.join() === 'true,false,true,false,true,true,true,true' && r.ord === 4 &&")
R2("&& r.mon.join() === 'true,false' && r.month === 3 && r.tier === 5 && r.rel === 2 &&", "&& r.mon.join() === 'true,true' && r.month === 0 && r.tier === 5 && r.rel === 0 &&")
R2("rec(106, '砂時計：1個1時間のまま・99個まで・1日24個まで・ログイン/デイリーは1日1回・節目の樽は1日3樽・納品3件ごとに1個（1日3個）・連続ログイン7日目に+3・月の決算+3（月1回）・昇格+5・取引先の★+2・日付が替わると戻る'", "rec(106, '砂時計：1個1時間のまま・99個まで・1日24個まで・ログイン/デイリーは1日1回・節目の樽は1日5樽・納品3件ごとに1個（1日4個）・連続ログイン7日目に+3・昇格+5・月の決算と取引先の★は v5.4 で廃止・日付が替わると戻る'")
# #118：差し入れを廃止（職人の吹き出しにボタンがない）
R2("G.hg.n = 0; G.hg.src.care = 0; hgDay(); G.hg.src.care = 0;", "G.hg.n = 0; hgDay();")
R2("""      const s = G.staff.find(x => x.id === g.dataset.sid); const xp0 = s.xp, lv0 = s.lv;
      bub.querySelector('[data-act="staffCare"]').click(); await new Promise(r => setTimeout(r, 80));
      o.c1 = { hg: G.hg.n, xp: +(s.xp - xp0 + (s.lv - lv0) * 24).toFixed(3), day: s.care === dayKey() };
      o.c2 = staffCare(s.id); const other = G.staff.find(x => x !== s); o.c3 = staffCare(other.id); o.hg2 = G.hg.n;""", """      o.gone = typeof staffCare === 'undefined' && !('care' in V51.HG) && !document.getElementById('wBub').textContent.includes('差し入れ');""")
R2("const ok = r.open && r.txt && r.care && r.c1.hg === 1 && Math.abs(r.c1.xp - 2) < 1e-6 && r.c1.day && r.c2 === false && r.c3 === true && r.hg2 === 1 && r.knock && r.same && r.closed;", "const ok = r.open && r.txt && !r.care && r.gone && r.knock && r.same && r.closed;")
R2("rec(118, '職人を押すと吹き出しで一言・差し入れは1人1日1回で経験+2、砂時計はその日最初の1回だけ・樽を押すと", "rec(118, '職人を押すと吹き出しで一言（差し入れは v5.4 で廃止）・樽を押すと")
# #138：入手の記録から差し入れが外れた
R2("r.src === '{\"login\":1,\"daily\":0,\"ms\":1,\"care\":0,\"ord\":0,\"tap\":0}'", "r.src === '{\"login\":1,\"daily\":0,\"ms\":1,\"ord\":0,\"tap\":0}'")
# #141：大麦の等級を廃止（小窓に等級のボタンがない・品質は標準のまま）
R2("""      openBarleyModal(); const btn = document.querySelector('#mc2 [data-act="barleyGrade"][data-v="best"]'); o.seg = document.querySelectorAll('#mc2 [data-act="barleyGrade"]').length === 3; btn.click(); await new Promise(r => setTimeout(r, 30));
      o.best = [G.barley.grade, +(barleyPrice() / p0).toFixed(6), +(Math.min(1.5, q0 * 1.08) / newmakeQuality()).toFixed(6)];""", """      openBarleyModal(); o.seg = document.querySelectorAll('#mc2 [data-act="barleyGrade"]').length === 0; G.barley.grade = 'best'; prodInvalidate();
      o.best = [barleyGrade() === V51.GRADE.std, +(barleyPrice() / p0).toFixed(6), +(q0 / newmakeQuality()).toFixed(6)];""")
R2("const ok = r.seg && r.best[0] === 'best' && r.best[1] === 2.5 && r.best[2] === 1 && r.lotQ", "const ok = r.seg && r.best[0] === true && r.best[1] === 1 && r.best[2] === 1 && r.lotQ")
R2("rec(141, '大麦の等級（最上は価格×2.5・品質×1.08、詰める樽に反映）・今月の相場", "rec(141, '大麦の等級は v5.4 で廃止（ボタンがなく、保存に最上があっても標準の価格と品質）・今月の相場")
# #145：曲の長さが短くなった（end>25 は維持）。曲順はシャッフル
# #150：v5.3 の長さ・曲順・曲名の表示のテストを v5.4 の形に置き換える（#153 で確認）
BLOCK("  // ---------- #150 BGM：ボレロを加えた6曲", "  await browser.close();\n  let pass = 0;", "")
# #106：節目の上限が5樽になり、24時間進めた間の節目の1個を受け取れる（6→7個）
R2("&& r.u1 && !r.u2 && r.afterUse.n === 6 && r.afterUse.useDay === 24", "&& r.u1 && !r.u2 && r.afterUse.n === 7 && r.afterUse.useDay === 24")
# #60・#80：売るも v5.4 でタブ全体のスクロールにしたので、1画面の確認はホーム・造るだけ
R2("for (const t of ['td', 'tb', 'tsale']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); o[t] = el.scrollHeight - el.clientHeight; }", "for (const t of ['td', 'tb']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); o[t] = el.scrollHeight - el.clientHeight; }")
R2("rec(60, 'ホーム・造る・売るはスクロールなし（390×667・390×740 × 開始直後・中盤・終盤 = 18通り。寝かせるはタブ全体でスクロール）', n === 18 &&", "rec(60, 'ホーム・造るはスクロールなし（390×667・390×740 × 開始直後・中盤・終盤 = 12通り。寝かせる・売るはタブ全体でスクロール）', n === 12 &&")
R2("if (['td', 'tb', 'tsale'].includes(t)) over[t] = el.scrollHeight - el.clientHeight;", "if (['td', 'tb'].includes(t)) over[t] = el.scrollHeight - el.clientHeight;")
R2("rec(80, '色：ダーク・ライトとも全タブの文字のコントラスト4.5以上（ライトでもホーム・造る・売るは1画面）'", "rec(80, '色：ダーク・ライトとも全タブの文字のコントラスト4.5以上（ライトでもホーム・造るは1画面）'")
# #103：デイリー全達成は3個・章の目標の砂時計は廃止
R2("&& r.n99 === 99 && r.daily === 2 && r.chap >= 1 &&", "&& r.n99 === 99 && r.daily === 3 && r.chap === 0 &&")
R2("rec(103, '砂時計：99個まで（あふれる分は受け取らない）・デイリー全達成で2個・章の目標で1個・", "rec(103, '砂時計：99個まで（あふれる分は受け取らない）・デイリー全達成で3個・章の目標の分は v5.4 で廃止・")
R2("見出しは上に貼り付く）・注文は枠の中で最後までスクロールできる'", "見出しは上に貼り付く）・注文の一覧は最後まで届く（v5.4 から売るはタブ全体でスクロール）'")
