// ============================================================
// v4.5 決算書（財務3表）・試飲会・瓶の資材費・寝かせるの流れ
//   会計の考え方：
//   ・現金の出入りはすべて科目付きで記録する（earn / pay / acRev / acOther）
//   ・在庫は原価で評価する（大麦＝移動平均、タンク＝大麦単価、樽＝詰めた新酒＋樽代、瓶＝原酒の按分＋資材）
//   ・売上原価＝期首在庫＋当期仕入−期末在庫（棚卸計算法）
//   ・設備は資産に計上し、定額法で償却（減価償却費＝期首簿価＋取得−期末簿価）
//     v4.5.1：耐用年数はゲーム内の10年＝実時間10日（熟成と同じ「実1日＝1年」。税法の「飲料製造業用設備」10年に合わせる）
//   これにより「期首純資産＋当期純利益＝期末純資産」「期首現金＋営業CF＋投資CF＝期末現金」が常に成り立つ
// ============================================================
const V45={TASTE_N:30,TASTE_MAX:5,TASTE_REP:1,TASTE_ORDER_MS:30*60000,TAP_TI:0.002,BTL_UNIT:8,FA_DAYS:10,FA_MONTHS:10/30.4375,HIST:12};
let _acctClock=()=>Date.now();

// ---------- 月 ----------
function acctMonthF(ts){const d=new Date(ts);const y=d.getFullYear(),mo=d.getMonth();const s=new Date(y,mo,1).getTime(),e=new Date(y,mo+1,1).getTime();return y*12+mo+(ts-s)/(e-s);}
function acctYm(m){return Math.floor(m/12)+'年'+(m%12+1)+'月';}
// v5.7 pur に製造費 mfg・熟成費 age、期間の支払利息 int（現金）・intAcc（払えず借入に加えた分）・法人税の支払い taxp・借入 bor・返済 rep
function acctZero(){return {rev:{ord:0,spot:0,ext:0,lot:0,tap:0,oth:0},pur:{barley:0,cask:0,bottle:0,mfg:0,age:0},sga:{comp:0,rcp:0,tier:0,rg:0,oth:0,hire:0,wage:0,train:0,sev:0},capex:0,int:0,intAcc:0,taxp:0,bor:0,rep:0};}
const AC_LBL={
  rev:{ord:'注文の納品',spot:'瓶の直販',ext:'麦芽・新酒などの外販',lot:'樽ごとの売却',tap:'試飲代（タップ・見学）',oth:'その他の収入（報酬など）'},
  pur:{barley:'大麦',cask:'空き樽',bottle:'瓶の資材',mfg:'製造費（燃料・電気・工場の人件費）',age:'熟成費（倉庫の管理・保険）'},
  sga:{comp:'品評会の参加費',rcp:'レシピの購入',tier:'Tier昇格',rg:'販売地域・輸出市場',oth:'その他の費用',hire:'採用費',wage:'給与',train:'研修費',sev:'退職金'}
};
function sumO(o){return Object.values(o||{}).reduce((a,v)=>a+(v||0),0);}

// ---------- 原価 ----------
function acctBAvg(){const a=G.acct;return (a&&a.bAvg>0)?a.bAvg:barleyPrice();}
function btlUnit(){return V45.BTL_UNIT*distMult()*rawM('bottle');}
function btlStd(){return BALANCE.BOTTLE_L*(acctBAvg()+5)+btlUnit();}
function lotC(l){if(!(l.c>=0)||!isFinite(l.c))l.c=l.L*acctBAvg()+caskCost(l.cask,l.size);return l.c;}
function lotDraw(l,L){const c=lotC(l);const k=l.L>0?Math.min(1,L/l.L):1;const mv=c*k;l.c=c-mv;l.L-=L;return mv;}
function rowC(r){if(!(r.c>=0)||!isFinite(r.c))r.c=r.n*btlStd();return r.c;}
function invBreak(){
  const bA=acctBAvg();const b=G.barley||{};const kg=(isFinite(b.kg)&&b.kg>0)?b.kg:0;
  let lot=0;G.lots.forEach(l=>{lot+=lotC(l);});
  let btl=0;
  G.bq.forEach(q=>{if(!(q.c>=0)||!isFinite(q.c))q.c=q.n*btlStd();btl+=q.c*Math.max(0,q.n-(q.moved||0))/q.n;});
  G.bottles.forEach(r=>{btl+=rowC(r);});
  return {barley:kg*bA,tank:(G.tank||0)*(bA+tankMfgU()),lot,bottle:btl}; // v5.7 タンクの新酒は大麦＋製造費
}

// ---------- 設備（定額法。月の単位で持つ。v5.7 耐用年数は建物（熟成庫）30年・機械15年＝実時間30日・15日。L は月数。L がない分は v5.6 までの10年） ----------
function faL(v){return v.L>0?v.L:V45.FA_MONTHS;}
function faNBV(at){const a=G.acct;if(!a)return 0;return (a.fa||[]).reduce((s,v)=>s+v.a*Math.max(0,1-Math.max(0,at-v.m)/faL(v)),0);}
function faLife(id){return (id==='maturation'?V57.LIFE_BLD:V57.LIFE_MACH)/30.4375;}
function faAdd(v,L){
  const a=G.acct;const mf=acctMonthF(_acctClock());const bm=Math.floor(mf);L=L||faLife('');
  const x=a.fa.find(f=>Math.floor(f.m)===bm&&Math.abs(faL(f)-L)<1e-9);
  if(x){x.m=(x.m*x.a+mf*v)/(x.a+v);x.a+=v;}else a.fa.push({m:mf,a:v,L});
}
// 移行時：これまでの購入・強化費用を、当時のTierの単価で推計する
function faEstimate(){
  const cur=G.dl||1;
  const dmT=t=>{const d=DL[clamp(t,1,DL.length)-1];return d.mult*(d.bonus||1);};
  let s=0;
  FD.forEach(f=>{
    const st=G.fac&&G.fac[f.id];if(!st||!st.p)return;
    if(f.id!=='malting'&&f.pur)s+=f.pur*dmT(1);
    for(let l=0;l<(st.l||0);l++)s+=f.bc*dmT(Math.min(cur,Math.floor(l/10)+1))*Math.pow(BALANCE.FAC_COST_MUL,l);
  });
  for(let k=0;k<(G.cl||0);k++)s+=BALANCE.TAP_COST_BASE*Math.pow(BALANCE.TAP_COST_MUL,k)*dmT(Math.min(cur,Math.floor(k/4)+1));
  return Math.round(s);
}

// ---------- 帳簿 ----------
function acctSnap(at){const ib=invBreak();const a=G.acct;return {cash:G.cash,inv:ib.barley+ib.tank+ib.lot+ib.bottle,ib,fa:faNBV(at),debt:(a&&a.loan&&a.loan.bal)||0,taxDue:(a&&a.taxDue)||0};}
// 純資産＝現金＋在庫＋設備−借入金−未払法人税（v5.7）
function naOf(s){return s.cash+s.inv+s.fa-(s.debt||0)-(s.taxDue||0);}
function acctEnsure(){
  if(G.fresh)return null;
  let a=G.acct;
  if(!a||!a.cur){
    barleyState();
    const now=_acctClock(),mf=acctMonthF(now);
    const prev=(a&&Array.isArray(a.prev))?a.prev:[];
    const mig=!!(a&&a.mig);
    a=G.acct={v:1,bAvg:barleyPrice(),fa:[],cap:0,per:((G.prestige&&G.prestige.level)||0)+1,hist:[],prev,tot:{R:0,ni:0},mig,cur:null,loan:{bal:0,pd:0},taxDue:0,lossCF:0};
    if(mig){const fe=faEstimate();if(fe>0)a.fa.push({m:mf,a:fe});a.faMig=fe;}
    const o=acctSnap(mf);a.cap=naOf(o);
    a.cur=Object.assign({m:Math.floor(mf),t0:now,o},acctZero());
    return a;
  }
  const now=_acctClock();const m=Math.floor(acctMonthF(now));
  if(m>a.cur.m)acctRoll(m,now);
  return a;
}
function acctRoll(m,now){
  const a=G.acct;const c=acctSnap(m);
  const rec=acctStatement(a.cur,c);rec.to=m-1;
  acctTax(rec); // v5.7 法人税：月を締めるときに確定し、未払法人税に入れる（次の月の初めに払う）
  a.tot.R+=rec.R;a.tot.ni+=rec.ni;
  a.hist.unshift(rec);if(a.hist.length>V45.HIST)a.hist.length=V45.HIST;
  a.fa=a.fa.filter(v=>m-v.m<faL(v));
  a.cur=Object.assign({m,t0:now,o:{cash:c.cash,inv:c.inv,ib:c.ib,fa:c.fa,debt:c.debt,taxDue:a.taxDue}},acctZero());
  taxPayNow();
}
// 税引前利益の30%。赤字は繰り越して、後の月の利益から差し引く
function acctTaxCalc(pre,lossCF){if(pre<=0)return {tax:0,loss:lossCF-pre};const use=Math.min(lossCF,pre);return {tax:V57.TAX*(pre-use),loss:lossCF-use};}
function acctTax(rec){
  const a=G.acct;const t=acctTaxCalc(rec.pretax,a.lossCF||0);
  a.lossCF=t.loss;a.taxDue=(a.taxDue||0)+t.tax;
  rec.tax=t.tax;rec.ni=rec.pretax-t.tax;rec.c.taxDue=a.taxDue;rec.lossCF=a.lossCF;
}
function taxPayNow(){
  const a=G.acct;if(!a||!a.cur||!(a.taxDue>0)||!(G.cash>0))return;
  const x=Math.min(G.cash,a.taxDue);G.cash-=x;a.taxDue-=x;a.cur.taxp+=x;if(a.taxDue<1e-6)a.taxDue=0;
}
function acctStatement(p,c){
  const rev={...p.rev},sga={...p.sga},pur={...p.pur};
  const P=sumO(pur);
  const fin=(p.bor||0)-(p.rep||0),ip=p.int||0,ia=p.intAcc||0,tp=p.taxp||0;
  const tagged=sumO(rev)-P-sumO(sga)-p.capex-ip-tp+fin;
  const unex=(c.cash-p.o.cash)-tagged; // 科目のない現金の増減（本来0。念のため「その他」に計上して3表をつなぐ）
  if(unex>0)rev.oth+=unex;else if(unex<0)sga.oth+=-unex;
  const R=sumO(rev),S=sumO(sga);
  const dep=p.o.fa+p.capex-c.fa;
  const cogs=p.o.inv+P-c.inv;
  const gp=R-cogs,op=gp-S-dep;
  const I=ip+ia,pretax=op-I;
  const o=Object.assign({debt:0,taxDue:0},p.o);
  return {m:p.m,to:p.m,o,c:{cash:c.cash,inv:c.inv,ib:c.ib,fa:c.fa,debt:c.debt||0,taxDue:c.taxDue||0},rev,pur,sga,capex:p.capex,P,R,S,dep,cogs,gp,op,int:I,intPaid:ip,intAcc:ia,pretax,tax:0,ni:pretax,taxp:tp,bor:p.bor||0,rep:p.rep||0,opcf:R-P-S-ip-tp,invcf:-p.capex,fincf:fin,unex};
}
function acctLive(){const a=acctEnsure();if(!a)return null;const r=acctStatement(a.cur,acctSnap(acctMonthF(_acctClock())));r.live=true;return r;}
function acctTick(){return !!acctEnsure();}

// ---------- 記録 ----------
function acRev(cat,v){if(!(v>0)||!isFinite(v))return;const a=acctEnsure();if(!a)return;if(!(cat in a.cur.rev))cat='oth';a.cur.rev[cat]+=v;}
function acOther(d){if(!d||!isFinite(d))return;const a=acctEnsure();if(!a)return;if(d>0)a.cur.rev.oth+=d;else a.cur.sga.oth+=-d;}
function pay(v,kind,cat){
  if(!(v>0)||!isFinite(v))return;
  const a=acctEnsure();
  G.cash-=v;
  if(!a)return;
  if(kind==='capex'){a.cur.capex+=v;faAdd(v,faLife(cat));return;}
  const g=kind==='pur'?a.cur.pur:a.cur.sga;
  if(!(cat in g))cat=kind==='pur'?'cask':'oth';
  g[cat]+=v;
}
function acBarley(stock,kg,pr){
  if(!(kg>0))return;
  const a=acctEnsure();
  if(a){const s=Math.max(0,stock||0);a.bAvg=(s*acctBAvg()+kg*pr)/(s+kg);}
  pay(kg*pr,'pur','barley');
}
function acctPrevSummary(){
  const a=G.acct;if(!a||!a.cur)return (a&&a.prev)||[];
  const lv=acctLive();
  const out=[{per:a.per,R:a.tot.R+lv.R,ni:a.tot.ni+lv.ni,na:naOf(lv.c),end:Date.now()}].concat(a.prev||[]);
  return out.slice(0,10);
}
function acctSanitize(x){
  if(!x||typeof x!=='object')return null;
  const n=v=>{v=Number(v);return isFinite(v)?v:0;};
  const zo=(o,tpl)=>{const r={};Object.keys(tpl).forEach(k=>{r[k]=n(o&&o[k]);});return r;};
  const Z=acctZero();
  const snap=o=>{o=o||{};const ib=o.ib||{};return {cash:n(o.cash),inv:n(o.inv),fa:n(o.fa),debt:n(o.debt),taxDue:n(o.taxDue),ib:{barley:n(ib.barley),tank:n(ib.tank),lot:n(ib.lot),bottle:n(ib.bottle)}};};
  const prev=Array.isArray(x.prev)?x.prev.filter(p=>p&&typeof p==='object').slice(0,10).map(p=>({per:n(p.per),R:n(p.R),ni:n(p.ni),na:n(p.na),end:n(p.end)})):[];
  if(!x.cur||typeof x.cur!=='object')return {prev,mig:!!x.mig};
  const per=c=>({m:Math.floor(n(c.m)),t0:n(c.t0),o:snap(c.o),rev:zo(c.rev,Z.rev),pur:zo(c.pur,Z.pur),sga:zo(c.sga,Z.sga),capex:n(c.capex),int:n(c.int),intAcc:n(c.intAcc),taxp:n(c.taxp),bor:n(c.bor),rep:n(c.rep)});
  const hist=Array.isArray(x.hist)?x.hist.filter(h=>h&&typeof h==='object').slice(0,V45.HIST).map(h=>{
    const r=per(h);r.c=snap(h.c);['to','P','R','S','dep','cogs','gp','op','ni','opcf','invcf','unex','pretax','tax','intPaid','fincf','lossCF'].forEach(k=>{r[k]=n(h[k]);});if(!r.to)r.to=r.m;if(!('pretax' in h))r.pretax=r.ni;r.int=n(h.int)+0;return r;}):[];
  const ln=x.loan&&typeof x.loan==='object'?x.loan:{};
  return {v:1,bAvg:n(x.bAvg),fa:Array.isArray(x.fa)?x.fa.filter(f=>f&&n(f.a)>0).slice(0,80).map(f=>{const o={m:n(f.m),a:n(f.a)};if(n(f.L)>0)o.L=n(f.L);return o;}):[],cap:n(x.cap),per:n(x.per)||1,
    hist,prev,tot:{R:n(x.tot&&x.tot.R),ni:n(x.tot&&x.tot.ni)},mig:!!x.mig,faMig:n(x.faMig),cur:per(x.cur),
    loan:{bal:Math.max(0,n(ln.bal)),pd:Math.max(0,n(ln.pd))},taxDue:Math.max(0,n(x.taxDue)),lossCF:Math.max(0,n(x.lossCF))};
}

// ---------- 瓶の資材費 ----------
function btlFreeAvail(){return !((G.stats.freeBtl||0)>0)&&!((G.stats.bottled||0)>0)&&!G.bq.length;}
function btlMatCost(n){const free=btlFreeAvail();const unit=btlUnit();return {n,unit,free,cost:free?0:unit*n};}
function btlMatPay(m){if(m.free){G.stats.freeBtl=1;return;}pay(m.cost,'pur','bottle');moneyFx(m.cost);}
function moneyFx(v){
  if(_offlineRunning||!(v>0)||typeof showFT!=='function')return;
  const el=$('hc');if(!el)return;const r=el.getBoundingClientRect();if(!r.width)return;
  showFT('−'+fmt(v),r.left+r.width/2,r.bottom+26,false);
  const ft=FT_POOL[(ftIdx-1+FT_MAX)%FT_MAX];if(ft){ft.style.color='var(--red)';ft.style.fontSize='17px';}
}
function casksFx(c,auto){if(!auto)moneyFx(c);}

// ---------- 樽タップ：事業規模連動・試飲会 ----------
function tapValue(){return cv()+V45.TAP_TI*ti();}
function tasteToday(){const d=new Date(_acctClock());return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();}
function tasteState(){
  let t=G.taste;if(!t||typeof t!=='object')t=G.taste={n:0,cnt:0,day:''};
  const td=tasteToday();if(t.day!==td){t.day=td;t.cnt=0;}
  return t;
}
function tasteTap(){
  const t=tasteState();if(t.cnt>=V45.TASTE_MAX)return false;
  t.n++;
  if(t.n<V45.TASTE_N)return false;
  t.n=0;t.cnt++;G.stats.tastings=(G.stats.tastings||0)+1;
  changeRep(V45.TASTE_REP,'試飲会');
  const now=Date.now();if(G.orderClock)G.orderClock=Math.max(now,G.orderClock-V45.TASTE_ORDER_MS);
  dmProgress('dm_taste');
  const dw=dwarfTaste(); // v5.5 試飲会のたびに小人が砂時計を置いていくことがある
  if(!_offlineRunning){
    sndQuest();toast(dw?'🥃 試飲会 評判+'+V45.TASTE_REP+'・次の注文が30分早まる\n'+dw.msg:'🥃 試飲会を開きました　評判+'+V45.TASTE_REP+' ・ 次の注文が30分早まります',dw?4200:3200);
    if(dw&&dw.got){try{setHtml($('homeIcons'),homeIconsHtml());}catch(e){}}
    const g=$('tgauge');if(g){g.classList.remove('pop');void g.offsetWidth;g.classList.add('pop');}
  }
  return true;
}
function tasteUi(){
  const t=tasteState();const done=t.cnt>=V45.TASTE_MAX;
  const f=$('tgFill');if(f){const s=(done?100:Math.round(t.n/V45.TASTE_N*100))+'%';if(f.style.width!==s)f.style.width=s;}
  const g=$('tgauge');if(g)g.classList.toggle('done',done);
  setText('tgTxt',done?'試飲会は今日はおしまい（'+V45.TASTE_MAX+'/'+V45.TASTE_MAX+'）':'試飲会まで あと'+(V45.TASTE_N-t.n)+'回（今日'+t.cnt+'/'+V45.TASTE_MAX+'）'); // v5.5 小人の回数はやめて試飲会にまとめた
}

// ============================================================
// 寝かせる：タンクの新酒 → 空き樽を仕入れて詰める → 倉庫で寝かせる（v5.9 ①②③をやめ、左に絵の列）
// ============================================================
const CT_LETTER={bourbon:'バ',sherry:'シ',wine:'ワ',mizunara:'ミ',port:'ポ'};
const SZ_LETTER={quarter:'Q',barrel:'B',hogshead:'H',butt:'Bt',puncheon:'P'};
function lotPct(l){return Math.max(0,Math.min(100,l.L/Math.max(1e-9,l.L0)*100));}
function caskCostPh(){
  const a=G.auto.fill;if(!a.on||!feat('tank'))return 0;
  const f=prodFlows();if(!(f.newmake>0))return 0;
  if(G.lots.length>=whSlots())return 0;
  return f.newmake/caskSize(a.size).litres*caskCost(a.cask,a.size);
}
function celTankHtml(){
  if(!feat('tank'))return `<div class="cst c1 off"><div class="pic ric">${ic('tank',26)}</div><div class="ptx" style="flex:1;min-width:0"><div class="pnm">タンクの新酒</div><div class="pcap">⚗️ 造るタブで蒸留器までそろうと、新酒がたまります</div></div></div>`;
  const cap=tankCap(),t=G.tank||0,sz=caskSize(G.auto.fill.size);const f=prodFlows();
  return `<div class="cst c1" data-act="goTab" data-tab="tb" role="button" aria-label="タンクの新酒（造るタブへ）"><div class="pic ric">${ic('tank',26)}</div><div class="ptx" style="flex:1;min-width:0">
      <div class="pnm">タンクの新酒 <span class="vv" id="clTank">${fmtL(t)} / ${fmtL(cap)}</span></div>
      <div class="pbar tk"><i id="clTankF" style="width:${Math.min(100,t/cap*100).toFixed(1)}%"></i></div>
      <div class="pcap" id="clTankN">${celTankNote(t,sz,f)}</div></div><span class="cgo">造る ›</span></div>`;
}
function celTankNote(t,sz,f){return escapeHtml(sz.name)+'で '+Math.floor(t/sz.litres)+'樽分 ・ '+(f.newmake>0?'造るから '+fmtL(f.newmake)+'/時':'新酒を造っていません');}
function celFlowHtml(kind){
  const f=prodFlows();
  if(kind===1){const on=feat('tank')&&f.newmake>0&&G.auto.fill.on;return `<div class="pflow cflow${on?' run s2':''}"><span class="pband"></span><span class="pfl">新酒を樽に詰める</span>${feat('tank')?`<span class="psur pcost" id="cpNote">${cpNote()}</span>`:''}</div>`;}
  const on=G.lots.length>0;return `<div class="pflow cflow${on?' run s1':''}"><span class="pband"></span><span class="pfl">倉庫で熟成</span></div>`;
}
function fillBoxHtml(){
  if(!feat('tank'))return `<div class="fbh"><div class="pic ric">${ic('cask',26)}</div><div class="ptx" style="flex:1;min-width:0"><span class="tt cst2">空き樽を仕入れて詰める</span><div class="sm">新酒がたまると、ここで樽を仕入れて詰めます</div></div></div>`;
  const a=G.auto.fill;
  const types=CASK_TYPES.filter(caskTypeUnlocked),sizes=CASK_SIZES.filter(caskSizeUnlocked);
  if(!types.some(t=>t.id===a.cask))a.cask=types[0].id;
  if(!sizes.some(s=>s.id===a.size))a.size=sizes[0].id;
  const sz=caskSize(a.size),ct=caskType(a.cask);
  const nT=caskNew('type'),nS=caskNew('size');
  return `<div class="fbh"><div class="pic ric">${ic('cask',26)}</div><span class="tt cst2" style="flex:1;min-width:0">空き樽を仕入れて詰める ${ib('fill')}</span><span class="cp1"><small>仕入れ値</small><b>1樽 ${fmt(caskCost(a.cask,a.size))}</b></span></div>
    <div class="fprow">
      <button type="button" class="fpick${nT?' new':''}" data-act="fillPickT"><span class="fpl">樽の種類${nT?' <b class="fnew">NEW</b>':''}</span><span class="fpv"><i class="ctdot ct-${ct.id}">${CT_LETTER[ct.id]}</i> ${escapeHtml(ct.name)}</span><span class="fpa">▾</span></button>
      <button type="button" class="fpick${nS?' new':''}" data-act="fillPickS"><span class="fpl">サイズ${nS?' <b class="fnew">NEW</b>':''}</span><span class="fpv">${escapeHtml(sz.name)}</span><span class="fpa">▾</span></button>
      <button type="button" class="sb2 fau ${a.on?'':'gh'}" data-act="autoFill" aria-pressed="${a.on}">自動<br>${a.on?'ON':'OFF'}</button>
      <button type="button" class="sb2 fgo" data-act="fillGo">今すぐ<br>詰める</button></div>`;
}
function cpNote(){
  const a=G.auto.fill;if(!a.on)return '自動OFF・詰めるときに支払い';
  if(G.lots.length>=whSlots())return '倉庫が満杯で自動停止中';
  const c=caskCostPh();return c>0?'自動 約'+fmt(c)+'/時':'たまると自動で詰めます';
}
// v5.0 見出しは2行に詰め、樽の一覧は棚（n20_v49.js sceneHtml）だけにする
function whHeadHtml(){
  const slots=whSlots();const n=G.lots.length;
  const oldest=G.lots.length?Math.max(...G.lots.map(l=>l.age)):0;
  const m=G.fac.maturation;const show=m&&(m.p||isUL('maturation'));
  return `<div class="whh" id="fac_maturation"><div class="pic ric">${ic('maturation',26)}${lotSeat()}</div><div class="ptx" style="flex:1;min-width:0" data-act="facInfo" data-id="maturation">
      <div class="pnm">倉庫 <span class="vv">${n} / ${slots}樽</span>${show&&m.p?' <span class="plv">Lv'+m.l+'</span>':''}${brBadge('maturation')}</div>
      <div class="pbar"><i style="width:${Math.min(100,n/Math.max(1,slots)*100)}%"></i></div>
      <div class="pcap">${n?(lotNextEta()?'<span class="lnx" data-lnext>'+lotNextTxt()+'</span>':'最古 <b style="color:var(--gold2)" data-lold>'+fmtAge(oldest)+'</b>'):show&&m.p?'熟成庫 Lv'+m.l:'熟成庫で上限が増える'}</div></div>
    ${show?facBtnHtml('maturation'):''}</div>`;
}
function whHtml(){
  if(!G.lots.length&&!whSlots())return `${whHeadHtml()}<div class="sm tc" style="padding:12px">樽はまだありません</div>`;
  return `${whHeadHtml()}${whSellRowHtml()}<div id="whScene"></div>`; // v5.5 「③ → 売る」の行はやめた
}

// ============================================================
// 決算書（PL・BS・CF）
// ============================================================
let _fin={i:0,v:'pl'};
function finPeriods(){const a=acctEnsure();if(!a)return [];return [acctLive()].concat(a.hist);}
function finLabel(p){if(p.live)return acctYm(p.m)+'（途中経過）';return p.to>p.m?acctYm(p.m)+'〜'+acctYm(p.to)+'（確定）':acctYm(p.m)+'（確定）';}
function fmtS(v){return (v<0?'−':'')+fmt(Math.abs(v));}
// ボックス図：借方（左）と貸方（右）。負の値は反対側へ移す
function boxDiagram(L,R,H,mini){
  const mv=(src,dst)=>src.forEach(x=>{if(x.v<0)dst.push({label:x.neg||x.label,v:-x.v,cls:x.cls+' ng'});});
  const l=L.filter(x=>x.v>0),r=R.filter(x=>x.v>0);mv(L,r);mv(R,l);
  const T=Math.max(1e-9,l.reduce((a,x)=>a+x.v,0),r.reduce((a,x)=>a+x.v,0));
  const col=arr=>arr.map(x=>{const h=Math.max(2,x.v/T*H);return `<div class="fbx ${x.cls}" style="height:${h.toFixed(1)}px">${mini?'':(h>=30?`<span>${x.label}</span><b>${fmtS(x.v)}</b>`:h>=15?`<span>${x.label} ${fmtS(x.v)}</span>`:'')}</div>`;}).join('');
  return `<div class="fbd${mini?' mini':''}" style="height:${H}px"><div class="fcol">${col(l)}</div><div class="fcol">${col(r)}</div></div>`;
}
function finBoxes(p,v,H,mini){
  const a=G.acct;
  if(v==='pl')return boxDiagram([{label:'売上原価',v:p.cogs,cls:'b-cost',neg:'在庫の評価増'},{label:'販管費',v:p.S-acctLabor(p),cls:'b-sga'},{label:'人件費',v:acctLabor(p),cls:'b-lab'},{label:'減価償却費',v:p.dep,cls:'b-dep'},{label:'利息',v:p.int||0,cls:'b-int'},{label:'法人税',v:p.tax||0,cls:'b-tax'},{label:'利益',v:p.ni,cls:'b-pro',neg:'損失'}],[{label:'売上高',v:p.R,cls:'b-rev'}],H,mini);
  if(v==='bs'){const na=naOf(p.c);return boxDiagram([{label:'現金',v:p.c.cash,cls:'b-cash'},{label:'棚卸資産',v:p.c.inv,cls:'b-inv'},{label:'設備',v:p.c.fa,cls:'b-fa'}],[{label:'借入金',v:p.c.debt||0,cls:'b-debt'},{label:'未払法人税',v:p.c.taxDue||0,cls:'b-tax'},{label:'元入金',v:a.cap,cls:'b-cap'},{label:'利益剰余金',v:na-a.cap,cls:'b-re',neg:'繰越損失'}],H,mini);}
  return boxDiagram([{label:'期首現金',v:p.o.cash,cls:'b-cash0'},{label:'営業CF',v:p.opcf,cls:'b-op',neg:'営業CF（支出超過）'},{label:'財務CF（借入）',v:p.fincf||0,cls:'b-debt',neg:'財務CF（返済）'}],[{label:'投資CF（設備）',v:p.capex,cls:'b-invc'},{label:'期末現金',v:p.c.cash,cls:'b-cash'}],H,mini);
}
function finDelta(cur,prev,good){
  if(prev===undefined||prev===null)return '';
  const d=cur-prev;if(Math.abs(d)<0.5)return '<span class="fdl">→</span>';
  const up=d>0;const ok=good==='down'?!up:up;
  const pc=Math.abs(prev)>0.5?Math.round(Math.abs(d)/Math.abs(prev)*100):null;
  return `<span class="fdl ${ok?'g':'r'}">${up?'▲':'▼'}${pc!==null&&pc<1000?pc+'%':''}</span>`;
}
function finRows(p,v,q){
  const a=G.acct;
  const row=(k,val,o)=>{o=o||{};return `<div class="frw${o.sub?' sub':''}${o.tot?' tot':''}"><span>${k}</span><span>${fmtS(val)}${o.d||''}</span></div>`;};
  const pct=(x)=>p.R>0.5?'（売上の'+(x/p.R*100).toFixed(1)+'%）':'';
  let h='';
  if(v==='pl'){
    h+=row('売上高',p.R,{tot:1,d:q?finDelta(p.R,q.R):''});
    Object.keys(AC_LBL.rev).forEach(k=>{if(p.rev[k]>0.5)h+=row(AC_LBL.rev[k],p.rev[k],{sub:1});});
    h+=row('売上原価'+pct(p.cogs),p.cogs);
    // 当期に在庫へ入れたもの（原材料・製造費・熟成費）。売上原価は在庫の増減を含むので、内訳として示す
    {const raw=(p.pur.barley||0)+(p.pur.cask||0)+(p.pur.bottle||0);if(raw>0.5){h+=row('うち原材料費'+pct(raw),raw,{sub:1});['barley','cask','bottle'].forEach(k=>{if(p.pur[k]>0.5)h+=row('　'+AC_LBL.pur[k],p.pur[k],{sub:1});});}
     if(p.pur.mfg>0.5)h+=row('当期の製造費'+pct(p.pur.mfg),p.pur.mfg,{sub:1});if(p.pur.age>0.5)h+=row('当期の熟成費'+pct(p.pur.age),p.pur.age,{sub:1});}
    h+=row('売上総利益',p.gp,{tot:1});
    h+=row('販管費',p.S);
    const LAB=['hire','wage','train','sev'];const lab=acctLabor(p);
    Object.keys(AC_LBL.sga).forEach(k=>{if(!LAB.includes(k)&&p.sga[k]>0.5)h+=row(AC_LBL.sga[k],p.sga[k],{sub:1});});
    if(lab>0.5){h+=row('うち人件費'+pct(lab),lab,{sub:1});LAB.forEach(k=>{if(p.sga[k]>0.5)h+=row('　'+AC_LBL.sga[k],p.sga[k],{sub:1});});}
    h+=row('減価償却費'+pct(p.dep),p.dep);
    h+=row('営業利益',p.op,{tot:1});
    if((p.int||0)>0.5)h+=row('支払利息',p.int);
    h+=row('税引前利益',p.pretax);
    if(p.live){const t=acctTaxCalc(p.pretax,(a&&a.lossCF)||0);h+=row('法人税（月末に確定・見込み）',t.tax,{sub:1});}
    else h+=row('法人税（30%）',p.tax||0);
    h+=row(p.live?'当期純利益（法人税の前）':'当期純利益',p.ni,{tot:1,d:q?finDelta(p.ni,q.ni):''});
    if(a&&a.lossCF>0.5)h+=row('繰越欠損金（次の黒字から差し引く）',a.lossCF,{sub:1});
  }else if(v==='bs'){
    const na=naOf(p.c),ta=p.c.cash+p.c.inv+p.c.fa,li=(p.c.debt||0)+(p.c.taxDue||0);
    h+=row('現金',p.c.cash);
    h+=row('棚卸資産',p.c.inv);
    [['barley','大麦'],['tank','タンクの新酒'],['lot','樽の原酒（熟成中）'],['bottle','瓶（瓶詰め中を含む）']].forEach(([k,l])=>{if(p.c.ib[k]>0.5)h+=row(l,p.c.ib[k],{sub:1});});
    h+=row('設備（償却後）',p.c.fa);
    h+=row('資産合計',ta,{tot:1,d:q?finDelta(ta,q.c.cash+q.c.inv+q.c.fa):''});
    h+=row('借入金',p.c.debt||0);
    h+=row('未払法人税',p.c.taxDue||0);
    h+=row('負債合計',li,{tot:1});
    h+=row('元入金',a.cap);
    h+=row('利益剰余金',na-a.cap);
    h+=row('純資産合計',na,{tot:1});
  }else{
    const dInv=p.c.inv-p.o.inv,dTax=(p.c.taxDue||0)-(p.o.taxDue||0);
    h+=row('営業CF',p.opcf,{tot:1,d:q?finDelta(p.opcf,q.opcf):''});
    h+=row('当期純利益',p.ni,{sub:1});
    h+=row('＋減価償却費（現金の出ない費用）',p.dep,{sub:1});
    h+=row(dInv>=0?'−在庫の増加':'＋在庫の減少',-dInv,{sub:1});
    if(Math.abs(dTax)>0.5)h+=row(dTax>=0?'＋未払法人税の増加':'−法人税の支払い（前の月の分）',dTax,{sub:1});
    if((p.intAcc||0)>0.5)h+=row('＋払えず借入に加えた利息',p.intAcc,{sub:1});
    h+=row('投資CF（設備の購入・強化）',p.invcf,{tot:1});
    h+=row('財務CF（借入−返済）',p.fincf||0,{tot:1});
    if((p.bor||0)>0.5)h+=row('借入',p.bor,{sub:1});
    if((p.rep||0)>0.5)h+=row('返済',-p.rep,{sub:1});
    h+=row('現金の増減',p.opcf+p.invcf+(p.fincf||0),{tot:1});
    h+=row('期首現金',p.o.cash,{sub:1});
    h+=row('期末現金',p.c.cash,{sub:1});
  }
  return h;
}
function finKpiHtml(p){
  const ta=p.c.cash+p.c.inv+p.c.fa;
  const opm=p.R>0.5?p.op/p.R*100:null;
  const invr=ta>0.5?p.c.inv/ta*100:null;
  const k=(l,v)=>`<div class="fk"><span>${l}</span><b>${v}</b></div>`;
  let h=`<div class="fks">${k('営業利益率',opm===null?'—':opm.toFixed(1)+'%')}${k('資産のうち在庫',invr===null?'—':invr.toFixed(0)+'%')}${k('営業CF',fmtS(p.opcf))}</div>`;
  const dInv=p.c.inv-p.o.inv;
  if(dInv>0.5&&p.opcf<p.ni)h+=`<div class="fnote">💡 現金が利益より少ないのは、在庫が <b>${fmt(dInv)}</b> 増えたため（うち樽の原酒 ${fmtS(p.c.ib.lot-((p.o.ib&&p.o.ib.lot)||0))}）。造った新酒と熟成費は、売れるまで在庫として資産に残ります。</div>`;
  else if(p.c.ib.lot>0.5&&p.c.inv>0.5)h+=`<div class="fnote">💡 樽の原酒 <b>${fmt(p.c.ib.lot)}</b> は棚卸資産の${Math.round(p.c.ib.lot/p.c.inv*100)}%。熟成で価値が上がっても、売るまでは利益にしません（原価で評価）。</div>`;
  return h;
}
function finHtml(){
  const ps=finPeriods();if(!ps.length)return '<div class="sm">まだ記録がありません</div>';
  _fin.i=clamp(_fin.i,0,ps.length-1);
  const p=ps[_fin.i],q=ps[_fin.i+1]||null,v=_fin.v;
  const a=G.acct;
  const tabs=[['pl','PL 損益'],['bs','BS 貸借'],['cf','CF 現金']];
  const thumbs=tabs.map(([k,l])=>`<button type="button" class="fth${v===k?' on':''}" data-act="fsView" data-v="${k}" aria-pressed="${v===k}"><span>${l}</span>${finBoxes(p,k,46,true)}</button>`).join('');
  const nt={pl:'左が費用と利益、右が売上。高さは金額に比例します',bs:'左が持っているもの（資産）、右がその元手（負債と純資産）',cf:'左が期首の現金・営業と借入で得た現金、右が設備への支払いと期末の現金'}[v];
  return `<div class="fnav"><button type="button" class="sb2 gh" data-act="fsPrev" ${_fin.i>=ps.length-1?'disabled':''} aria-label="前の月">‹</button><span class="fper">${escapeHtml(finLabel(p))}</span><button type="button" class="sb2 gh" data-act="fsNext" ${_fin.i<=0?'disabled':''} aria-label="次の月">›</button></div>
    <div class="fths">${thumbs}</div>
    <div class="fmain">${finBoxes(p,v,190,false)}<div class="sm tc" style="margin-top:4px">${nt}</div></div>
    <div class="frows">${finRows(p,v,q)}</div>
    ${finKpiHtml(p)}
    ${v==='bs'&&_fin.i===0?finLoanHtml():''}
    ${q?`<div class="sm" style="margin-top:4px">▲▼は前の期間（${escapeHtml(finLabel(q))}）との比較${p.live?'。途中経過は月の途中までの数字です':''}</div>`:''}
    ${a.mig&&a.faMig>0&&_fin.i===ps.length-1?`<div class="sm" style="margin-top:4px">※ 最初の期の設備 ${fmt(a.faMig)} は、これまでの購入・強化費用から推計した額です</div>`:''}
    ${a.prev&&a.prev.length?`<details class="fold" style="margin-top:6px"><summary><span class="sm">これまでの事業（再創業前）</span></summary>${a.prev.map(x=>`<div class="frw sub"><span>第${x.per}期の事業</span><span>売上 ${fmt(x.R)} ・ 利益 ${fmtS(x.ni)}</span></div>`).join('')}</details>`:''}`;
}
function finRender(){const b=$('finBox');if(b)b.innerHTML=finHtml();}

// 注文の詳細：詰めて納品するときの資材費と差し引き
function ordMatHtml(o,m){
  if(m.ok||ordInProgress(o))return '';
  const pl=ordFulfillPlan(o);if(!pl.ok)return '';
  const est=ordEstimate(o);const mat=btlMatCost(pl.n);
  if(mat.free)return `<div class="sm" style="margin-top:2px">瓶の資材 無料（前のオーナーが残した瓶）</div>`;
  return `<div class="sm" style="margin-top:2px">瓶の資材 −${fmt(mat.cost)}（${fmtPk(mat.unit)}×${fmtN(pl.n)}本） ／ 差し引き 約${fmt(est-mat.cost)}</div>`;
}
