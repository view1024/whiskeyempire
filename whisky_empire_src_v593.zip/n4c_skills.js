const PRESTIGE_SKILLS=[
  {id:'ps_tap_cap',    name:'試飲代の段階+2',     cost:1, tree:'basic', desc:'樽のタップの額の段階が+2'},
  {id:'ps_capacity',   name:'生産能力×1.2',       cost:1, tree:'basic', desc:'全工程の能力が1.2倍'},
  {id:'ps_fac_cost',   name:'施設コスト-10%',     cost:2, tree:'basic', desc:'施設強化コストが10%安くなる'},
  {id:'ps_cask_cost',  name:'樽代-20%',           cost:1, tree:'craft', desc:'樽詰めの樽代が20%安くなる'},
  {id:'ps_aging',      name:'樽熟成速度×1.5',     cost:1, tree:'craft', desc:'樽の熟成が1.5倍速く進む'},
  {id:'ps_order_slot', name:'注文ボード+1',       cost:2, tree:'craft', desc:'同時に並ぶ注文が1件増える'},
  {id:'ps_rep_decay',  name:'評判減衰 停止',      cost:1, tree:'rep',   desc:'評判の自然減衰がなくなる'},
  {id:'ps_comp_rate',  name:'品評会スコア+0.15',  cost:1, tree:'rep',   desc:'品評会の採点に+0.15'},
  {id:'ps_cooldown',   name:'品評会CD-30%',       cost:2, tree:'rep',   desc:'品評会のクールダウンが30%短縮'},
  {id:'ps_t1_cost',    name:'Tier1施設コスト-30%',cost:1, tree:'speed', desc:'Tier1施設の強化コストが30%安くなる'},
  {id:'ps_t2_unlock',  name:'Tier2昇格費-50%',    cost:1, tree:'speed', desc:'Tier2への昇格コストが50%安くなる'},
];
