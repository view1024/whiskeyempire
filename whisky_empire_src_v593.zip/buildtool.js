// ビルド後処理（v4.6.3）: 未使用関数の除去と JS/CSS の最小化
// usage:
//   node buildtool.js strip <file.js> <name1,name2,...>        … モジュールから関数宣言を削除（上書き）
//   node buildtool.js post <in.html> <dev.html> <out.html> [name1,name2,...] [class1,class2,...]
//        … 本体 <script> から関数を除去し、本体 <style> から未使用のクラスだけを指す規則を除いて dev.html に、さらに最小化して out.html に書き出す
// CSS は csso の再構成（restructure）あり。CSSO_RESTRUCTURE=0 で無効化できる。
// 対象は属性なしの <script> のうち最大のもの（ゲーム本体）と、属性なしの最初の <style>。
// <script id="liff-config"> は利用者が LIFF ID を書き換える場所なので触らない。
const fs = require('fs');
const acorn = require('acorn');

function strip(src, names, where) {
  if (!names.length) return src;
  const ast = acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script' });
  const cut = [];
  for (const nm of names) {
    const hits = ast.body.filter(n => n.type === 'FunctionDeclaration' && n.id.name === nm);
    if (hits.length !== 1) { console.error('STRIP NOT FOUND (or duplicated): ' + nm + ' in ' + where + ' hits=' + hits.length); process.exit(1); }
    let { start, end } = hits[0];
    while (end < src.length && (src[end] === ';' || src[end] === ' ')) end++;
    if (src[end] === '\n') end++;
    // 行頭から始まる宣言なら行ごと消す
    while (start > 0 && (src[start - 1] === ' ' || src[start - 1] === '\t')) start--;
    cut.push([start, end]);
  }
  cut.sort((a, b) => b[0] - a[0]);
  for (const [a, b] of cut) src = src.slice(0, a) + src.slice(b);
  acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script' }); // 構文が壊れていないこと
  return src;
}

function findMain(html) {
  const ms = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
  const m = ms.reduce((a, b) => (b[1].length > a[1].length ? b : a));
  return { start: m.index + '<script>'.length, end: m.index + '<script>'.length + m[1].length, body: m[1] };
}

// v5.8 未使用の CSS 規則の除去：セレクタのどれもが未使用のクラス（dead）を含む規則だけを消す。
// dead のクラスが本体の JS・HTML に出てきたら（また使い始めたら）止める
function stripCss(html, dead) {
  if (!dead.length) return html;
  const csstree = require('css-tree');
  const sm = html.match(/<style>([\s\S]*?)<\/style>/); const css = sm[1]; const st = sm.index + '<style>'.length;
  const corpus = html.slice(0, sm.index) + html.slice(sm.index + sm[0].length);
  const D = new Set(dead);
  for (const c of dead) if (new RegExp('(^|[^\\w-])' + c.replace(/-/g, '\\-') + '($|[^\\w-])').test(corpus)) { console.error('DEAD_CSS のクラスが使われています: ' + c); process.exit(1); }
  const ast = csstree.parse(css, { positions: true, parseValue: false, parseAtrulePrelude: false });
  const cut = []; let hit = new Set();
  csstree.walk(ast, { visit: 'Rule', enter(node) {
    const sels = node.prelude.children ? node.prelude.children.toArray() : [];
    const dd = sels.map(x => { const cl = []; csstree.walk(x, { visit: 'ClassSelector', enter(n) { if (D.has(n.name)) cl.push(n.name); } }); return cl; });
    if (sels.length && dd.every(x => x.length)) { cut.push([node.loc.start.offset, node.loc.end.offset]); dd.flat().forEach(c => hit.add(c)); }
  } });
  const miss = dead.filter(c => !hit.has(c)); if (miss.length) { console.error('DEAD_CSS のクラスを指す規則がありません: ' + miss.join(',')); process.exit(1); }
  cut.sort((a, b) => b[0] - a[0]); let c2 = css;
  for (const [a, b] of cut) c2 = c2.slice(0, a) + c2.slice(b);
  csstree.parse(c2); // 構文が壊れていないこと
  return html.slice(0, st) + c2 + html.slice(st + css.length);
}

async function post(inFile, devFile, outFile, names, deadCss) {
  const { minify } = require('terser');
  const csso = require('csso');
  let html = fs.readFileSync(inFile, 'utf8');
  // 1) 未使用関数の除去 → 開発版
  let s = findMain(html);
  html = html.slice(0, s.start) + strip(s.body, names, 'main script') + html.slice(s.end);
  html = stripCss(html, deadCss || []);
  fs.writeFileSync(devFile, html);
  // 2) JS の最小化（トップレベル名は保持：LIFF 設定・テスト・data-act から名前で参照するため）
  s = findMain(html);
  const r = await minify(s.body, {
    ecma: 2020,
    toplevel: false,
    compress: { passes: 2, toplevel: false, keep_infinity: true },
    mangle: { toplevel: false },
    format: { comments: false, ascii_only: false, semicolons: false },
  });
  if (!r.code) throw new Error('terser failed');
  let out = html.slice(0, s.start) + '\n' + r.code + '\n' + html.slice(s.end);
  // 3) CSS の最小化（本体の <style>。data URI の画像を含む）
  const sm = out.match(/<style>([\s\S]*?)<\/style>/);
  const css = csso.minify(sm[1], { restructure: process.env.CSSO_RESTRUCTURE !== '0' }).css;
  out = out.slice(0, sm.index) + '<style>' + css + '</style>' + out.slice(sm.index + sm[0].length);
  fs.writeFileSync(outFile, out);
  const kb = n => (n / 1024).toFixed(1) + 'KB';
  console.log(JSON.stringify({ dev: kb(Buffer.byteLength(html)), out: kb(Buffer.byteLength(out)), js: kb(Buffer.byteLength(s.body)) + '→' + kb(Buffer.byteLength(r.code)), css: kb(Buffer.byteLength(sm[1])) + '→' + kb(Buffer.byteLength(css)) }));
}

const [cmd, a, b, c, d, e] = process.argv.slice(2);
if (cmd === 'strip') {
  fs.writeFileSync(a, strip(fs.readFileSync(a, 'utf8'), b.split(','), a));
} else if (cmd === 'post') {
  post(a, b, c, d ? d.split(',').filter(Boolean) : [], e ? e.split(',').filter(Boolean) : []).catch(e => { console.error(e); process.exit(1); });
} else {
  console.error('usage: see header'); process.exit(1);
}
