# v5.5 の変更に合わせて v5.4 までのテストを置き換える
def BLOCK(start, end, new):
    global s
    a = s.index(start); b = s.index(end, a)
    s = s[:a] + new + s[b:]
# #64・#65：設備の歩みは図鑑へ（造るのボタンはなし）・①②は常に開いている
R2("const gone = ['fl', 'recipeWrap', 'facEncEl'].filter(id => document.getElementById(id));", "const gone = ['fl', 'recipeWrap'].filter(id => document.getElementById(id)).concat(document.querySelector('#tb #facEncEl') ? ['facEncEl'] : []);")
R2("const fc = (() => { _ui.celOpen = true; rCellar();", "const fc = (() => { rCellar();")
R2("const hist = (() => { switchTab('tb'); document.querySelector('[data-act=\"facHist\"]').click(); const ok = document.querySelectorAll('#mc2 #facEncEl > div').length === FD.length; closeM(); return ok; })();", "const hist = (() => { switchTab('tb'); const noBtn = !document.querySelector('[data-act=\"facHist\"]'); _ui.encTab = 'f'; switchTab('te'); const ok = noBtn && document.querySelectorAll('#te #facEncEl > div').length === FD.length; _ui.encTab = 'w'; return ok; })();")
R2("・レシピ・ブレンド・樽の選択・設備の歩みはボタンから開く'", "・レシピ・ブレンド・樽の選択はボタンから開く・設備の歩みは図鑑（v5.5）'")
# #82・#83：樽の下の1行（試飲会まで あと◯回（今日 n/5））・見学ツアーの強化はなし
R2("const tc = document.querySelector('.tgauge .tgtxt'); o.fs = parseFloat(getComputedStyle(tc).fontSize);", "const tc = document.getElementById('tgTxt'); o.fs = parseFloat(getComputedStyle(tc).fontSize);")
R2("rec(82, 'タップ：1回の額＝見学ツアー額＋毎時の外販収入×0.2%'", "rec(82, 'タップ：1回の額＝試飲代（v5.5 Tierと評判の段階）＋毎時の外販収入×0.2%'")
R2("r.ui.txt.includes('0/30') && r.ui.txt.includes('1/5') && r.cap.cnt === 5 && r.cap.txt.includes('本日終了')", "r.ui.txt.includes('あと30回') && r.ui.txt.includes('1/5') && r.cap.cnt === 5 && r.cap.txt.includes('おしまい')")
# #42：図鑑の種類の絞り込みのボタンも44px以上（確認はそのまま）
# #63：市況の小窓
R2("['mkt', '今月の市場'], ['tier', '昇格の条件']", "['mkt', '市況'], ['tier', '昇格の条件']")
R2("rec(63, 'ホーム：章・デイリー・市場・Tier・砂時計はアイコン＋バッジ", "rec(63, 'ホーム：章・デイリー・市況・Tier・砂時計はアイコン＋バッジ")
# #81：景色の下に樽の1行（tapline）
R2("rec(81, 'ホーム：上から「生産の流れ → アイコン列 → 景色と樽」・お知らせと各タブ冒頭の「次にやること」の行はない', r.order.join() === 'flow,homeIcons,stage' && r.stageH >= 300 && Math.abs(r.stageBottom - r.navTop) <= 12",
   "rec(81, 'ホーム：上から「生産の流れ → アイコン列 → 景色と樽 → 樽の1行（v5.5）」・お知らせと各タブ冒頭の「次にやること」の行はない', r.order.join() === 'flow,homeIcons,stage,tapline' && r.stageH >= 300 && r.stageBottom < r.navTop")
# #84：見学ツアーの強化はなくなった
R2("upgFac('malting'); upgClick(); purchaseRegion(", "upgFac('malting'); purchaseRegion(")
# #88：①②は常に開いている（たたむのは v5.5 で廃止）・倉庫日誌は図鑑へ
R2("      document.querySelector('#celTank [data-act=\"celOpen\"]').click();\n", "      o.noFold = !document.querySelector('[data-act=\"celOpen\"]');\n")
R2("rec(88, '寝かせる：自動で詰めている間は ①② を1行にたたみ（押すと開く）、開くと「① タンクの新酒", "rec(88, '寝かせる：①②は常に開いて（v5.5 たたむのをやめ、倉庫日誌は図鑑へ）「① タンクの新酒")
R2("r.fold === 'thead,celJnl,celTank,whSummary' && r.fno === '①②' && r.ftxt && r.open === 'thead,celJnl,celTank,celF1,fillBox,celF2,whSummary'", "r.noFold && r.fold === 'thead,celTank,celF1,fillBox,celF2,whSummary' && r.fno === '①' && !r.ftxt && r.open === r.fold")
# #90・#100：決算書は図鑑の入口のアイコン「決算書」から
R2("switchTab('te'); _ui.encTab = 'r'; renc(); const badge = document.querySelector('#recList .frec') ? '記録' : '';\n      document.querySelector('#recList .frec').click();", "switchTab('te'); renc(); const badge = document.querySelector('#ei_fin') ? '記録' : '';\n      document.querySelector('#ei_fin').click();")
R2("rec(90, '決算書の画面：図鑑の「記録」から開き、", "rec(90, '決算書の画面：図鑑のアイコン「決算書」から開き、")
R2("_ui.encTab = 'r'; renc(); const card = document.querySelector('#recList .frec'); const first = document.getElementById('recList').firstElementChild === card;", "renc(); const card = document.getElementById('ei_fin'); const first = document.getElementById('encGrid').firstElementChild === card;")
R2("・決算書は図鑑の記録の先頭から開き、ホームのアイコンは章・デイリー・市場・Tier・砂時計'", "・決算書は図鑑の入口の先頭のアイコンから開き、ホームのアイコンは章・デイリー・市況・Tier・砂時計'")
# #95・#96：樽は景色−28px（上限270px）・見学ツアーの強化をやめ、試飲代の段階は Tier と評判で決まる
R2("rec(95, '樽：393×760で高さ300px・390×667で景色−70px・", "rec(95, '樽：高さ＝景色−28px（上限270px・v5.5 樽の下の帯を外へ出した）・")
R2("a.h === 300 && Math.abs(b.h - (b.stageH - 70)) <= 1 &&", "Math.abs(a.h - Math.min(270, a.stageH - 28)) <= 1 && Math.abs(b.h - Math.min(270, b.stageH - 28)) <= 1 &&")
R2("const r = await page.evaluate(() => { const o = []; for (const [dl, cl] of [[1, 0], [1, 3], [2, 4], [2, 7], [3, 8], [3, 9]]) { G.dl = dl; G.cl = cl; o.push(cuc()); } G.dl = 1; G.cl = 4; o.push(cuc()); return o; });\n    const exp = [12000, 127776, 773302, 8229000, 39510000, 86920000];\n    rec(96, '見学ツアーの費用＝$12,000×2.2^Lv×Tier倍率（上限Lvでは強化不可）', r.slice(0, 6).every((v, i) => Math.abs(v - exp[i]) / exp[i] < 0.002) && r[6] === Infinity, JSON.stringify(r));",
   "const r = await page.evaluate(() => { const o = []; G.cl = 9; for (const [dl, rep] of [[1, 0], [1, 30], [1, 200], [2, 0], [2, 60], [3, 100], [5, 400]]) { G.dl = dl; G.reputation = rep; o.push(tapLv()); } G.dl = 2; G.reputation = 10; const v1 = cv(); G.reputation = 25; const v2 = cv(); o.push(+(v2 / v1).toFixed(6)); o.push(!document.getElementById('cub') && typeof upgClick === 'undefined' && typeof cuc === 'undefined'); return o; });\n    rec(96, '試飲代の段階（v5.5）＝(Tier−1)×4＋評判10・25・50・100に届いた数（上限は Tier×4 と10の小さい方）・1段で×1.5・見学ツアーの強化のボタンはない', r.slice(0, 7).join() === '0,2,4,4,7,10,10' && r[7] === 1.5 && r[8] === true, JSON.stringify(r));")
# #109：倉庫日誌は図鑑の「倉庫日誌」。未読は図鑑のタブとアイコンに「新」
R2("      switchTab('tcel'); rCellar(); const card = document.getElementById('celJnl'); const newMark = card.textContent.includes('新');\n      card.querySelector('.jnl').click(); await new Promise(r => setTimeout(r, 60)); const modal = document.getElementById('mc2').textContent; closeM(); rCellar();\n      const newAfter = document.getElementById('celJnl').textContent.includes('新');",
   "      G.encSeen = G.uw.slice(); switchTab('td'); updNavBadges(); const newMark = document.getElementById('bd_te').textContent === '新' && !document.getElementById('celJnl');\n      _ui.encTab = 'j'; switchTab('te'); await new Promise(r => setTimeout(r, 60)); const modal = '倉庫日誌' + document.getElementById('jnlList').textContent; renc(); updNavBadges();\n      const newAfter = document.getElementById('bd_te').textContent.includes('新') || !!document.querySelector('#ei_j .eib'); _ui.encTab = 'w';")
R2("・14日分・寝かせるの先頭に「新」・開くと既読・保存しても同じ'", "・14日分・図鑑のタブに「新」（v5.5 日誌は図鑑へ）・開くと既読・保存しても同じ'")
# #120：日誌は図鑑の「倉庫日誌」で読む
R2("openJnlModal(); const t = document.getElementById('mc2').textContent; closeM();", "_ui.encTab = 'j'; switchTab('te'); const t = document.getElementById('jnlList').textContent; _ui.encTab = 'w';")
R2("その日の職人の様子が1行記録され、日誌の小窓に出る'", "その日の職人の様子が1行記録され、図鑑の倉庫日誌に出る'")
# #137：「③ → 売る」の帯は廃止
R2("bubClose(); const fl = document.querySelector('#whSummary .sflow'); o.flow = !!fl && fl.textContent.includes('売る'); fl.click(); await new Promise(r => setTimeout(r, 50)); o.flowGo = document.querySelector('.tab.on').id === 'tsale';", "bubClose(); o.flow = !document.querySelector('#whSummary .sflow'); o.flowGo = true;")
R2("押すと棚の樽・棚の下の帯から売るへ'", "押すと棚の樽（「③ → 売る」の帯は v5.5 で廃止）'")
# #146：小人のタップの回数は v5.5 で数えなくなった
R2("const ok = r.ver === SCHEMA && r.tap === '{\"n\":0,\"miss\":0}' && r.cancel === 0", "const ok = r.ver === SCHEMA && r.tap === undefined && r.cancel === 0")
R2("rec(146, 'v5.1（schema15）からの移行：小人の記録・予約の取り消しの件数を用意", "rec(146, 'v5.1（schema15）からの移行：小人のタップの記録は v5.5 で外す・予約の取り消しの件数を用意")
# #143：小人は試飲会のたびに抽選（v5.5）
BLOCK("  // ---------- #143 樽の小人", "  // ---------- #144", r"""  // ---------- #143 樽の小人（v5.5）：試飲会のたびに20%・1日5個・トーストと演出・タップの回数の表示はない・99個のときは受け取らない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); switchTab('td');
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off; const rr = Math.random; let rv = 0.99; Math.random = () => rv;
      const o = {}; G.hg = { n: 0, got: 0, used: 0 }; hgDay(); G.taste = { n: 0, cnt: 0, day: tasteToday() };
      let msg = ''; const t0 = toast; toast = (m, d) => { msg = m; t0(m, d); };
      for (let i = 0; i < 30; i++) tap(); o.miss = [G.taste.cnt, G.hg.n, msg.includes('小人'), !document.getElementById('tgTxt').textContent.includes('🧝')];
      rv = 0.19; for (let i = 0; i < 30; i++) tap(); o.hit = [G.taste.cnt, G.hg.n, G.hg.src.tap, msg.includes('小人が砂時計を置いていきました（今日 1/5）'), !!document.getElementById('dwarf'), !!document.querySelector('.hgfly') || lowMotion()];
      rv = 0; for (let i = 0; i < 30 * 5; i++) tap(); o.cap = [G.taste.cnt, G.hg.n, G.hg.src.tap, tapHgCapped()];
      off = 24 * 3600000; G.ls = Date.now(); hgDay(); o.day = [G.hg.src.tap, tapHgCapped()];
      G.taste = { n: 29, cnt: 0, day: tasteToday() }; G.hg.n = V47.HG_MAX; tap(); o.full = [G.hg.n, G.hg.src.tap, msg.includes('持ち帰りました')];
      toast = t0; Math.random = rr; Date.now = rn;
      o.k = [V55.DWARF_P, V51.HG.tap.cap, typeof tapHgStep, typeof dwarfTxt, G.tapHg === undefined];
      return o;
    });
    const ok = r.miss.join() === '1,0,false,true' && r.hit[0] === 2 && r.hit[1] === 1 && r.hit[2] === 1 && r.hit[3] && r.hit[4] && r.hit[5] && r.cap.join() === '5,4,4,false' && r.day.join() === '0,false' && r.full.join() === '99,0,true' && r.k.join() === '0.2,5,undefined,undefined,true';
    rec(143, '樽の小人（v5.5）：試飲会のたびに20%で砂時計1個（トースト「小人が砂時計を置いていきました（今日 n/5）」と小人・砂時計が飛ぶ演出）・試飲会は1日5回なので5個まで・「あと◯回」の表示はない・99個のときは受け取らない', ok, JSON.stringify(r));
    if (errors.length) rec('E93', '小人テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
""")
# #155：選ぶイベントは廃止・効果の続く間はホームの「市況」に残り分・小窓に出来事
BLOCK("  // ---------- #155 偶発イベント", "  // ---------- #156", r"""  // ---------- #155 偶発イベント（v5.5）：帯がない・選ぶイベントはない・続く効果は「市況」に残り分と小窓・終わると日数に戻る ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); switchTab('td');
      const o = { banner: !document.getElementById('eventBanner'), choice: RAND_EVENTS.every(e => e.type !== 'choice' && !e.choices), noEv: !document.getElementById('hi_ev') };
      const badge = () => { rall(); const b = document.querySelector('#hi_mkt .hib'); return b ? b.textContent : ''; };
      o.none = badge() === mktDaysLeft() + '日';
      const good = RAND_EVENTS.find(e => e.id === 're_festival'); showEventBanner(good); o.active = [!!G.randomEvent.active, /^\d+分$/.test(badge()), document.getElementById('hi_mkt').classList.contains('hl')];
      document.getElementById('hi_mkt').click(); await new Promise(r => setTimeout(r, 50)); const t = document.getElementById('mc2').textContent; o.modal = [t.includes('市況'), t.includes('いま起きている出来事'), t.includes(good.name), t.includes('今月の市場')]; closeM(); rall();
      o.seen = !document.getElementById('hi_mkt').classList.contains('hl') || hsState().mkt !== mkt().name;
      G.randomEvent.active.expiresAt = Date.now() - 1; tickActiveEvent(); o.end = [G.randomEvent.active, badge() === mktDaysLeft() + '日'];
      o.san = sanitize(Object.assign(JSON.parse(JSON.stringify(G)), { randomEvent: { lastAt: 0, sessionCount: 0, active: null, ask: 're_buyout' } })).randomEvent.ask === undefined;
      o.icons = [...document.querySelectorAll('#homeIcons .hi')].length <= 6;
      return o;
    });
    const ok = r.banner && r.choice && r.noEv && r.none && r.active.join() === 'true,true,true' && r.modal.every(Boolean) && r.seen && r.end[0] === null && r.end[1] && r.san && r.icons;
    rec(155, '偶発イベント（v5.5）：帯はない・選ぶイベント（買収・協力・コラボ）は廃止・効果が続く間はホームの「市況」のバッジに残り分、小窓に出来事・終わると今月の残り日数に戻る・アイコンは6つまで', ok, JSON.stringify(r));
    if (errors.length) rec('E105', '偶発イベントのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
""")
