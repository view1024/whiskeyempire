// ============================================================
// v4 中核ロジック（詳細設計書 第5・6章）
// ============================================================
let _prodCache = null;
let _offlineRunning = false;
let _msHit = [];
let _noSave = false, _loadError = null;

function psk(id){return (G.prestige&&G.prestige.skills&&G.prestige.skills[id])||0;}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function rnd(a,b){return a+Math.random()*(b-a);}
function rndi(a,b){return Math.floor(rnd(a,b+1));}
function pick(arr){return arr[Math.floor(Math.random()*arr.length)];}
function uid(p){G.seq=(G.seq||0)+1;return p+'_'+Date.now().toString(36)+'_'+G.seq;}
function facLv(id){const s=G.fac&&G.fac[id];return s&&s.p?(s.l||0):0;}
function climate(){return CLIMATES.find(c=>c.id===G.climate)||CLIMATES[0];}
function prestigeBonus(){return (G.prestige&&G.prestige.bonus)||1;}
function fmtL(v){if(!isFinite(v))return '∞L';if(v>=1e6)return (v/1e6).toFixed(2)+'ML';if(v>=1e4)return (v/1e3).toFixed(1)+'kL';return (v>=100?Math.round(v):Math.round(v*10)/10).toLocaleString()+'L';}
function fmtN(v){if(!isFinite(v))return '∞';if(v>=1e9)return (v/1e9).toFixed(2)+'B';if(v>=1e6)return (v/1e6).toFixed(2)+'M';if(v>=1e4)return (v/1e3).toFixed(1)+'K';return Math.floor(v).toLocaleString();}
function fmtAge(a){return (Math.floor(a*10)/10).toFixed(1)+'年';}
// v5.0.1 注文の期限：1日以上は日だけ（「あと4日」）、1日未満は時間と分
function ordDueTxt(ms){return ms>=86400000?'あと'+Math.floor(ms/86400000)+'日':'あと'+fmtRemain(ms);}
function fmtRemain(ms){if(ms<=0)return '0分';const m=Math.floor(ms/60000);const d=Math.floor(m/1440),h=Math.floor((m%1440)/60),mm=m%60;if(d>0)return d+'日'+h+'時間';if(h>0)return h+'時間'+mm+'分';return mm+'分';}

function earn(amount,cat){
  if(!(amount>0)||!isFinite(amount))return;
  acRev(cat||'oth',amount);
  G.cash+=amount;G.te+=amount;
  const m=G.daily&&G.daily.missions&&G.daily.missions.find(x=>x.id==='dm_earn');
  if(m&&!m.done){if(!G._dmProgress)G._dmProgress={};G._dmProgress['dm_earn']=(G._dmProgress['dm_earn']||0)+amount;}
}

function cv(){
  return BALANCE.TAP_BASE*distMult()*Math.pow(BALANCE.TAP_MUL,tapLv())*saleMult()*prestigeBonus()*getEventMult('tap')*mktFx('tour');
}

function purFac(id){
  if(!isUL(id))return;
  const c=fpc(id);
  if(G.cash<c){toast('資金不足');return;}
  pay(c,'capex',id);G.fac[id].p=true;
  prodInvalidate();
  sndPurchase();
  chkT();chkUnlocks();rMake();rdistLight();updHdr();
  toast(`${FD.find(f=>f.id===id).name}を購入!`);
  renderFacEncyclopedia();
}

// ---------- 設備の分岐 ----------
function brOpt(facId){const b=G.branch&&G.branch[facId];if(b===null||b===undefined)return null;return (FAC_BRANCH[facId]||[])[b]||null;}
function brMod(facId,key){const o=brOpt(facId);if(!o||o[key]===undefined)return 1;return o[key];}
function brPending(facId){return !!FAC_BRANCH[facId]&&facLv(facId)>=BALANCE.BRANCH_LV&&(G.branch[facId]===null||G.branch[facId]===undefined);}
function brRetoolCost(facId){
  const f=FD.find(x=>x.id===facId);const l=facLv(facId);
  return Math.round(f.bc*distMult()*Math.pow(BALANCE.FAC_COST_MUL,Math.max(0,l-1)));
}
function brChoose(facId,idx){
  const opts=FAC_BRANCH[facId];if(!opts||!opts[idx])return false;
  if(facLv(facId)<BALANCE.BRANCH_LV){toast('Lv'+BALANCE.BRANCH_LV+'で選択できます');return false;}
  const cur=G.branch[facId];
  if(cur===idx){toast('導入済みの設備です');return false;}
  let cost=0;
  if(cur!==null&&cur!==undefined){
    cost=brRetoolCost(facId);
    if(G.cash<cost){toast('資金不足: 再設備費 '+fmt(cost),2500);return false;}
    pay(cost,'capex',facId);
  }
  G.branch[facId]=idx;prodInvalidate();sndUpgrade();
  toast('🔧 '+opts[idx].name+' を導入'+(cost?'（再設備費 '+fmt(cost)+'）':''),3000);
  save();return true;
}
function fmtMods(o){
  if(!o)return '';
  const parts=[];
  Object.keys(BRANCH_KEY_LABEL).forEach(k=>{if(o[k]!==undefined&&o[k]!==1)parts.push(BRANCH_KEY_LABEL[k]+'×'+o[k]);});
  if(o.fl)Object.entries(o.fl).forEach(([k,v])=>parts.push(FL_KEY_MAP[k]+(v>=0?'+':'')+v));
  return parts.join(' / ');
}

// ---------- 蒸留所レシピ ----------
function rcpList(kind){return kind==='peat'?PEAT_LEVELS:(RAW_MATERIALS[kind]||[]);}
function rcpItem(kind,id){return rcpList(kind).find(x=>x.id===id)||rcpList(kind)[0];}
function rcpUnlocked(kind,it){if(kind==='peat')return (G.dl||1)>=(it.unlockTier||1);return (G.te||0)>=(it.unlockSales||0);}
function rcpCost(kind,it){const base=kind==='peat'?(PEAT_COST[PEAT_LEVELS.indexOf(it)]||0):(it.cost||0);return Math.round(base*distMult());}
function rcpMods(){
  const g=rcpItem('grain',G.recipe.grain),w=rcpItem('water',G.recipe.water),y=rcpItem('yeast',G.recipe.yeast),p=rcpItem('peat',G.recipe.peat);
  const fl={};
  [g,w,y].forEach(it=>Object.entries(it.flavorMod||{}).forEach(([k,v])=>{fl[k]=(fl[k]||0)+v;}));
  fl.smoky=(fl.smoky||0)+(p.smokyMod||0);
  return {cap:[(g.yieldMod||1)*(1-(p.ppm||0)/250),w.incMod||1,y.fermentMod||1,1],fl,peatPrice:p.incMod||1};
}
function rcpBuy(kind,id){
  const it=rcpList(kind).find(x=>x.id===id);if(!it)return false;
  if(G.recipeOwned.includes(id))return true;
  if(!rcpUnlocked(kind,it)){toast('まだ解禁されていません');return false;}
  const c=rcpCost(kind,it);
  if(G.cash<c){toast('資金不足: '+fmt(c));return false;}
  pay(c,'sga','rcp');G.recipeOwned.push(id);sndPurchase();
  return true;
}
function rcpSet(kind,id){
  if(!G.recipeOwned.includes(id))return false;
  G.recipe[kind]=id;prodInvalidate();save();
  toast('🧪 レシピ変更: '+rcpItem(kind,id).name,2500);
  return true;
}

// ---------- 生産ライン・タンク ----------
function prodInvalidate(){_prodCache=null;}
function priceMultBase(){return distMult()*saleMult()*prestigeBonus();}
function stageCapAt(i,lv){
  const st=STAGES[i];const s=G.fac&&G.fac[st.fac];
  if(!s||!s.p||lv<=0)return 0;
  return st.base*Math.pow(BALANCE.CAP_MUL,lv-1)*rcpMods().cap[i]*brMod(st.fac,'cap')*(1+0.2*psk('ps_capacity'))*(G.dbgMul||1)*mktFx('cap')*facMult(st.fac); // v5.0 配置された職人の倍率
}
function stageCap(i){return stageCapAt(i,facLv(STAGES[i].fac));}
function prodFlows(){
  const bok=typeof barleyOK==='function'?barleyOK():true;
  if(_prodCache&&_prodCache.bok===bok)return _prodCache;
  const cap=STAGES.map((s,i)=>stageCap(i));
  const p=[bok?cap[0]:0];for(let i=1;i<4;i++)p[i]=Math.min(cap[i],p[i-1]);
  const s=[0,0,0];for(let i=0;i<3;i++)s[i]=Math.max(0,p[i]-p[i+1]);
  const pm=priceMultBase();
  const surplusPh=s.reduce((a,v,i)=>a+v*STAGES[i].price*pm,0);
  let bottleneck=-1;
  if(cap[3]>0){let mn=Infinity;cap.forEach((c,i)=>{if(c<mn){mn=c;bottleneck=i;}});}
  _prodCache={cap,p,s,newmake:p[3],surplusPh,bottleneck,bok};
  return _prodCache;
}
function ti(){return prodFlows().surplusPh*getEventMult('passive');}
function nmPrice(){return STAGES[3].price*priceMultBase();}
function tankCap(){return BALANCE.TANK_BASE_L+BALANCE.TANK_PER_TIER_L*((G.dl||1)-1);}
function prodTick(dtMs){
  staffTick(dtMs);
  const f=prodFlows();const h=dtMs/3600000;
  // v4.4 大麦：使えた割合 r だけ生産が進む
  const need=f.p[0]*h;const got=barleyTake(need);const r=need>0?Math.min(1,got/need):1;
  if(need>0){barleyState()._used=(barleyState()._used||0)+got;barleyAutoRefill(h);if(r<1)prodInvalidate();}
  const inc=f.surplusPh*getEventMult('passive')*h*r;
  if(inc>0)earn(inc,'ext');
  if(f.newmake>0)G.tank=(G.tank||0)+mfgPay(f.newmake*h*r); // v5.7 製造費を払えた分だけ新酒になる
  autoFillTick();
  const cap=tankCap();
  if(G.tank>cap){const over=G.tank-cap;G.tank=cap;earn(over*nmPrice(),'ext');}
}
function sellNewmake(L){
  L=Math.min(L,G.tank||0);if(L<=0){toast('タンクが空です');return 0;}
  const v=L*nmPrice();G.tank-=L;earn(v,'ext');sndPurchase();
  toast('🫗 ニューメイク '+fmtL(L)+' を外販 +'+fmt(v),2500);
  return v;
}

// ---------- 樽・原酒ロット ----------
function whSlots(){return Math.floor((BALANCE.WH_BASE+BALANCE.WH_PER_LV*facLv('maturation'))*brMod('maturation','slots'))+(G.whBonus||0);} // v5.0 旧「樽詰め」の枠を恒久化した分
function caskType(id){return CASK_TYPES.find(x=>x.id===id)||CASK_TYPES[0];}
function caskSize(id){return CASK_SIZES.find(x=>x.id===id)||CASK_SIZES[2];}
function caskTypeUnlocked(ct){return !ct.unlockSales||(G.te||0)>=ct.unlockSales;}
function caskSizeUnlocked(sz){return (sz.unlockTier||1)<=(G.dl||1);}
function caskCost(t,s){return Math.round(caskType(t).costPerL*caskSize(s).litres*(1-0.2*psk('ps_cask_cost'))*getEventMult('caskCost')*rawM('cask'));}
// v5.1 原材料の倍率：Tier1 は 1（v5.0 と同じ）。Tier3 以降は 売値の倍率÷今の式の倍率×K（大麦と瓶は Tier の倍率を今も掛けている）
function rawM(kind){if(G&&G._rawOff)return 1;const t=G.dl||1;const r=t<=1?0:t===2?V51.RAW.RAMP2:1;if(r<=0)return 1;const old=kind==='cask'?1:distMult();return Math.pow(Math.max(1,priceMultBase()/old)*(V51.RAW.K[kind]||1),r);}
function newmakeFlavor(){
  const b={...BASE_FLAVOR};
  const add=o=>Object.entries(o||{}).forEach(([k,v])=>{b[k]=(b[k]||0)+v;});
  add(rcpMods().fl);
  FD.forEach(f=>{const o=brOpt(f.id);if(o)add(o.fl);});
  add(climate().fl);
  FL_KEYS.forEach(k=>b[k]=clamp(Math.round(b[k]),0,100));
  return b;
}
function newmakeQuality(){let q=barleyGrade().q;FD.forEach(f=>{q*=brMod(f.id,'q');});return clamp(q,0.8,1.5);}
function makeLot(ct,sz,extra){
  return Object.assign({id:uid('l'),cask:ct.id,size:sz.id,L0:sz.litres,L:sz.litres,age:0,fl0:newmakeFlavor(),q:newmakeQuality(),at:Date.now(),src:'prod'},extra||{});
}
function fillCask(t,s,auto){
  const ct=caskType(t),sz=caskSize(s);
  if(!caskTypeUnlocked(ct)||!caskSizeUnlocked(sz)){if(!auto)toast('未解禁の樽です');return false;}
  if(G.lots.length>=whSlots()){if(!auto)toast('熟成庫が満杯です（熟成庫Lvで拡張）',2500);return false;}
  if((G.tank||0)<sz.litres){if(!auto)toast('タンクの原酒が足りません（'+sz.litres+'L必要）',2500);return false;}
  const c=caskCost(t,s);
  if(G.cash<c){if(!auto)toast('樽代が足りません: '+fmt(c));return false;}
  pay(c,'pur','cask');const lc=sz.litres*(acctBAvg()+tankMfgU())+c;G.tank-=sz.litres; // v5.7 新酒の原価に製造費
  const nl=makeLot(ct,sz,{c:lc});G.lots.push(nl);casksFx(c,auto);fxFill(nl,auto);
  G.stats.filled++;dmProgress('dm_fill');
  if(!auto){sndPurchase();toast('🛢️ '+ct.name+'×'+sz.name+' に詰めました',2000);}
  return true;
}
function autoFillTick(){
  const a=G.auto&&G.auto.fill;if(!a||!a.on)return 0;
  let n=0;while(n<50&&fillCask(a.cask,a.size,true))n++;
  return n;
}
function agingRate(lot){return agingRateBase(lot)*lotMult(lot);} // v5.0 担当の職人の倍率
function agingRateBase(lot){return (caskSize(lot.size).agingSpeed||1)*brMod('maturation','aging')*climate().aging*(1+0.5*psk('ps_aging'));}
function angelRate(lot){return Math.min(0.5,(caskSize(lot.size).angelShare||0.016)*brMod('maturation','angel')*climate().angel*getEventMult('angelShare')*mktFx('angel'));}
function lotAdvance(lot,dtMs){
  const dy=dtMs/BALANCE.GAME_YEAR_MS;const before=lot.age,L0=lot.L;
  // v5.0 天使の分け前は熟成の経過年数に比例（担当がいて速く熟成しても、熟成1年あたりの減り方は同じ）
  const m=lotMult(lot);
  lot.age+=dy*agingRateBase(lot)*m;
  lot.L=lot.L*Math.pow(1-angelRate(lot),dy*m);
  lotGoalStep(lot,before,L0);
  AGE_MILESTONES.forEach(m=>{if(before<m&&lot.age>=m)_msHit.push(m);});
}
function lotTick(dtMs){
  let maxA=G.stats.maxAge||0;
  G.lots.forEach(l=>{lotAdvance(l,dtMs);if(l.age>maxA)maxA=l.age;});
  ageCostTick(G.lots,dtMs); // v5.7 熟成費（倉庫の管理・保険）を樽の原価に積む
  G.stats.maxAge=maxA;
  if(G.lots.some(l=>l.L<BALANCE.BOTTLE_L))G.lots=G.lots.filter(l=>l.L>=BALANCE.BOTTLE_L);
  if(_msHit.length&&!_offlineRunning&&_goalUI.some(g=>g.q===1))_msHit=[];
  if(_msHit.length&&!_offlineRunning){const m=Math.max(..._msHit);_msHit=[];toast('🛢️ 原酒が'+m+'年に達しました',3000);}
}
function lotFlavor(lot){
  const ct=caskType(lot.cask);const r=lot.fin?Math.min(1,Math.max(0,lot.age-lot.fin.at)/BALANCE.FINISH_YEARS):Math.min(1,lot.age/BALANCE.CASK_FLAVOR_FULL_YEARS);const o={};
  FL_KEYS.forEach(k=>{o[k]=clamp(((lot.fl0&&lot.fl0[k])||0)+(((ct.flavorMod||{})[k])||0)*r,0,100);});
  return o;
}
// v5.1 樽の価値：その樽で詰められる一番高い銘柄を直販した額（瓶の単価×80%×本数）の V51.CASK_RATE。
// 「樽ごと売る」はこの CASK_SPOT_MULT 倍（＝直販額の55%）。詰められる銘柄がない樽は v5.0 までの式（年数に比例）
function lotValueOld(lot){return (lot.L/BALANCE.BOTTLE_L)*100*Math.max(lot.age,1)/3*lot.q*distMult()*saleMult()*repMult()*prestigeBonus();}
function lotValue(lot){
  const n=lot.L/BALANCE.BOTTLE_L;const fl=lotFlavor(lot);let u=0;
  lotProductsH(lot).forEach(p=>{const v=priceUnit(p,Math.floor(lot.age),lot.q,fl);if(v>u)u=v;});
  return Math.max(lotValueOld(lot),u*BALANCE.SPOT_MULT*n*V51.CASK_RATE/BALANCE.CASK_SPOT_MULT);
}
function sellLot(id){
  const i=G.lots.findIndex(l=>l.id===id);if(i<0)return 0;
  // v5.1 樽ごと売るのは3年以上（スコッチの最低熟成年数）
  if(G.lots[i].age<V51.SELL_AGE){toast(V51.SELL_AGE+'年で売れます（あと'+fmtRemain(lotEtaAge(G.lots[i],V51.SELL_AGE))+'）',2500);return 0;}
  const v=lotValue(G.lots[i])*BALANCE.CASK_SPOT_MULT;
  fxSale(v,true,document.querySelector(`#wScene .wcask[data-id="${id}"]`));G.lots.splice(i,1);earn(v,'lot');sndPurchase();
  toast('🛢️ 樽ごと売却 +'+fmt(v),2500);
  return v;
}
function grantStarterLots(){
  STARTER_LOTS.forEach(s=>{
    const ct=caskType(s.cask),sz=caskSize(s.size);
    G.lots.push({id:uid('l'),cask:ct.id,size:sz.id,L0:sz.litres,L:s.L,age:s.age,fl0:{...BASE_FLAVOR},q:1.0,at:Date.now(),src:'starter'});
  });
  G.stats.maxAge=Math.max(G.stats.maxAge||0,...STARTER_LOTS.map(s=>s.age));
}

// ---------- 製品・単価 ----------
function wlFlavor(w){const o={};FL_KEYS.forEach(k=>{o[k]=(w&&w.fl&&w.fl[FL_KEY_MAP[k]])||0;});return o;}
function productSpec(pid){
  if(!pid)return null;
  if(pid.indexOf('blend:')===0){
    const t=BLEND_TARGETS.find(x=>'blend:'+x.id===pid);if(!t)return null;
    return {pid,name:t.name,icon:t.icon,minAge:3,casks:null,target:t.target,minMatch:0,base:t.basePrice/100,tp:'ブレンデッド',blend:t,tol:t.tolerance};
  }
  if(pid===V53.HOUSE)return houseSpec();
  const w=WL.find(x=>x.id===pid);if(!w)return null;
  return {pid,name:w.name,icon:w.em+'🥃',minAge:w.yr,casks:w.tp==='バーボン'?['bourbon']:null,target:wlFlavor(w),minMatch:w.st===3?BALANCE.STAR3_MIN_MATCH:0,base:w.bs*w.ck,tp:w.tp,w};
}
function flavorMatch(fl,t){const d=FL_KEYS.reduce((a,k)=>a+Math.abs((fl[k]||0)-(t[k]||0)),0)/5;return Math.max(0,1-d/BALANCE.FLAVOR_TOL);}
function blendScoreFl(fl,t,tol){const d=FL_KEYS.reduce((a,k)=>a+Math.abs((fl[k]||0)-(t[k]||0)),0)/5;return Math.max(0,1-d/Math.max(1,tol));}
function priceUnit(pid,age,q,fl){
  const sp=productSpec(pid);if(!sp)return 0;
  const a=Math.max(1,Math.floor(age));
  let fm;
  if(sp.blend){const sc=blendScoreFl(fl,sp.target,sp.tol);fm=sc*sc;}
  else fm=sp.house?1:0.7+0.6*flavorMatch(fl,sp.target); // v5.3 ハウスモルトは風味を問わない
  const peat=((fl&&fl.smoky)||0)>=40?rcpMods().peatPrice:1;
  const aged=a>=12?getEventMult('agedPrice'):1;
  const award=(G.awardMult&&G.awardMult[pid])||1;
  const mk=mktFx('price')*(a<10?mktFx('young'):1)*(a>=12?mktFx('aged'):1);
  return sp.base*Math.pow(a/3,BALANCE.YEAR_EXP)*q*fm*peat*distMult()*saleMult()*repMult()*award*brMod('bottling','price')*aged*prestigeBonus()*mk*originPriceMult(sp,a);
}
function lotEligible(lot,sp){
  if(!sp||lot.L<=0.01)return false;
  if(lot.age<sp.minAge)return false;
  if(sp.casks&&!sp.casks.includes(lot.cask))return false;
  if(sp.minMatch>0&&flavorMatch(lotFlavor(lot),sp.target)<sp.minMatch)return false;
  return true;
}
function lotsFor(pid){const sp=productSpec(pid);if(!sp||sp.blend)return [];return G.lots.filter(l=>lotEligible(l,sp));}
function lotProducts(lot){return G.uw.filter(id=>{const sp=productSpec(id);return sp&&lotEligible(lot,sp);});}

// ---------- 瓶詰め ----------
function botRate(){
  const lv=facLv('bottling');
  const base=lv>0?BALANCE.BOT_BASE_BPH*Math.pow(BALANCE.CAP_MUL,lv-1):BALANCE.BOT_HAND_BPH;
  return base*brMod('bottling','bph')*(G.dbgMul||1)*facMult('bottling');
}
function botQueueBottles(){return G.bq.reduce((a,q)=>a+(q.n-q.done),0);}
function botPreview(pid,n,mode,lotIds,minAge){
  const sp=productSpec(pid);if(!sp||sp.blend)return {ok:false,reason:'銘柄を選んでください',maxN:0};
  if(!G.uw.includes(pid)&&!isHouse(pid))return {ok:false,reason:'未解禁の銘柄です',maxN:0};
  let cands=lotsFor(pid);
  if(minAge>0)cands=cands.filter(l=>l.age>=minAge);
  if(mode==='manual'){const set=new Set(lotIds||[]);cands=cands.filter(l=>set.has(l.id));}
  if(mode==='old')cands.sort((a,b)=>b.age-a.age);else cands.sort((a,b)=>a.age-b.age);
  const avail=cands.reduce((a,l)=>a+l.L,0);
  const maxN=Math.floor(avail/BALANCE.BOTTLE_L+1e-9);
  n=Math.floor(n);
  if(!(n>0))return {ok:false,reason:maxN>0?'本数を指定してください':'条件を満たす原酒がありません',maxN};
  const need=n*BALANCE.BOTTLE_L;let rem=need;const draws=[];
  for(const l of cands){if(rem<=1e-9)break;const take=Math.min(l.L,rem);draws.push({id:l.id,L:take});rem-=take;}
  if(rem>1e-6)return {ok:false,reason:'条件を満たす原酒が足りません（最大'+maxN+'本）',maxN};
  let age=Infinity,qs=0;const fl={};FL_KEYS.forEach(k=>fl[k]=0);
  draws.forEach(d=>{const l=G.lots.find(x=>x.id===d.id);age=Math.min(age,l.age);qs+=l.q*d.L;const lf=lotFlavor(l);FL_KEYS.forEach(k=>fl[k]+=lf[k]*d.L);});
  FL_KEYS.forEach(k=>fl[k]=fl[k]/need);
  const q=Math.min(1.5,qs/need),ageI=Math.floor(age);
  const unit=priceUnit(pid,ageI,q,fl);
  const hours=(botQueueBottles()+n)/botRate();
  return {ok:true,pid,n,draws,age:ageI,q,fl,unit,hours,maxN,match:flavorMatch(fl,sp.target)};
}
function botStart(pid,n,mode,lotIds,opts){
  opts=opts||{};
  const pv=botPreview(pid,n,mode,lotIds,opts.minAge||0);
  if(!pv.ok){toast(pv.reason,3000);return false;}
  if(G.bq.length>=20){toast('瓶詰め待ちが上限（20件）です');return false;}
  const mat=btlMatCost(pv.n);
  if(G.cash<mat.cost){toast('瓶の資材代が足りません（−'+fmt(mat.cost)+'）',3000);return false;}
  btlMatPay(mat);
  let lc=mat.cost;
  pv.draws.forEach(d=>{const l=G.lots.find(x=>x.id===d.id);if(l){lc+=lotDraw(l,d.L);}});
  G.lots=G.lots.filter(l=>l.L>=BALANCE.BOTTLE_L-1e-9); // 1本に満たない端数は空け樽として処分
  G.bq.push({id:uid('q'),pid,n:pv.n,done:0,moved:0,age:pv.age,q:pv.q,fl:pv.fl,blend:null,oid:opts.oid||null,c:lc,sell:opts.sell?1:0});
  dmProgress('dm_bottle');sndPurchase();
  if(!opts.quiet)toast('🍾 瓶詰め開始: '+productSpec(pid).name+' '+pv.n+'本',2500);
  save();return true;
}
function botTick(dtMs){
  if(!G.bq.length)return 0;
  let cap=botRate()*dtMs/3600000;let completed=0;
  while(G.bq.length){
    const q=G.bq[0];
    if(cap>0){const d=Math.min(q.n-q.done,cap);q.done+=d;cap-=d;}
    const whole=Math.min(q.n,Math.floor(q.done+1e-9));
    const k=whole-(q.moved||0);
    // v5.1 「瓶で売る」の印があれば、詰め終わった分をその場で直販（自動直販の設定に関係なく）
    if(k>0){if(q.sell)bqSellNow(q,k);else invAdd(q.pid,k,q.age,q.q,q.fl,(q.c||0)*k/q.n);q.moved=(q.moved||0)+k;G.stats.bottled+=k;completed+=k;}
    if(q.moved>=q.n){G.bq.shift();if(!q.sell)fxBottled(q.n);if(!_offlineRunning)toast(q.sell?'💰 瓶で売りました: '+((productSpec(q.pid)||{}).name||'')+' '+q.n+'本 +'+fmt(q.sold||0):'🍾 瓶詰め完了: '+((productSpec(q.pid)||{}).name||'')+' '+q.n+'本',2500);}
    else break;
  }
  return completed;
}

// ---------- 瓶の在庫 ----------
function invAdd(pid,n,age,q,fl,c){
  if(!(n>0))return;
  c=c>0?c:0;
  const qq=Math.round(q/BALANCE.INV_Q_STEP)*BALANCE.INV_Q_STEP;
  let row=G.bottles.find(r=>r.pid===pid&&r.age===age&&Math.abs(r.q-qq)<1e-6);
  if(row){FL_KEYS.forEach(k=>row.fl[k]=(row.fl[k]*row.n+(fl[k]||0)*n)/(row.n+n));row.n+=n;row.c=(row.c||0)+c;}
  else G.bottles.push({id:uid('b'),pid,n,age,q:qq,fl:{...fl},c});
}
function rowUnit(r){return priceUnit(r.pid,r.age,r.q,r.fl);}
function shipCount(pid,n,age){
  if(pid.indexOf('blend:')!==0&&!isHouse(pid)){ // v5.3 ハウスモルトは図鑑・販売数に数えない
    G.cw[pid]=(G.cw[pid]||0)+n;
    if(!G.shipLog)G.shipLog={};
    if(!G.shipLog[pid]){const w=WL.find(x=>x.id===pid);if(w&&!_offlineRunning)celebrate({card:{em:w.em,name:w.name,rg:w.rg},title:'図鑑に登録：'+w.name,sub:'はじめて出荷した銘柄です'});}
    const lg=G.shipLog[pid]||(G.shipLog[pid]={t:Date.now(),maxAge:0});
    if(age>lg.maxAge)lg.maxAge=age;
  }
  G.stats.shipped+=n;dmProgress('dm_ship',n);
}
function takeRow(r,n){if(r.c>0&&r.n>0)r.c=r.c*Math.max(0,r.n-n)/r.n;r.n-=n;if(r.n<=0)G.bottles=G.bottles.filter(x=>x!==r);}
function spotSell(rowId,n,silent){
  const r=G.bottles.find(x=>x.id===rowId);if(!r)return 0;
  n=Math.min(Math.floor(n),r.n);if(n<=0)return 0;
  const v=rowUnit(r)*BALANCE.SPOT_MULT*n;recordUnit(rowUnit(r));
  const pid=r.pid,age=r.age;takeRow(r,n);earn(v,'spot');shipCount(pid,n,age);fxSale(v,!silent,null);
  if(!silent){sndPurchase();toast('💰 直販 '+n+'本 +'+fmt(v),2200);}
  return v;
}
// 注文ボードに載っている銘柄の本数は自動直販で売らない
function orderReserveFor(pid){return G.orders.filter(o=>o.kind==='product'&&o.pid===pid).reduce((a,o)=>a+o.qty,0)+G.orders.filter(o=>o.kind==='type'&&(productSpec(pid)||{}).tp===o.tp).reduce((a,o)=>a+o.qty,0);}
function invTotal(pid){return G.bottles.filter(r=>r.pid===pid).reduce((a,r)=>a+r.n,0);}
function autoSpotTick(){
  const a=G.auto&&G.auto.spot;if(!a||!a.on)return 0;
  let tot=0;
  const pids=[...new Set(G.bottles.map(r=>r.pid))];
  pids.forEach(pid=>{
    const keep=Math.max((a.keep&&a.keep[pid]!==undefined)?a.keep[pid]:(a.defKeep||0),orderReserveFor(pid));
    let excess=invTotal(pid)-keep;if(excess<=0)return;
    const rows=G.bottles.filter(r=>r.pid===pid).sort((x,y)=>rowUnit(x)-rowUnit(y));
    for(const r of rows){if(excess<=0)break;const k=Math.min(r.n,excess);tot+=spotSell(r.id,k,true);excess-=k;}
  });
  return tot;
}

// ---------- 注文・取引先 ----------
function boardSize(){return BALANCE.ORDER_BOARD_BASE+((G.dl||1)-1)+psk('ps_order_slot');}
function custById(id){return CUSTOMERS.find(c=>c.id===id);}
function custAvailable(){return CUSTOMERS.filter(c=>(G.dl||1)>=c.tier&&(G.reputation||0)>=(c.rep||0));}
function relLv(cid){return (G.rel&&G.rel[cid]&&G.rel[cid].lv)||0;}
function relAdd(cid,d){
  if(!G.rel[cid])G.rel[cid]={lv:0,done:0};
  const r=G.rel[cid];r.done=Math.max(0,r.done+d);
  const nl=BALANCE.REL_THRESH.filter(t=>r.done>=t).length;
  if(nl>r.lv){for(let v=r.lv+1;v<=nl;v++){relLevelUp(cid,v);}if(!_offlineRunning){const c=custById(cid);toast('🤝 '+c.name+' との関係が★'+nl+'になりました',3000);}}
  r.lv=nl;
}
function qtyScale(){return (1+0.5*((G.dl||1)-1))*Math.max(1,Math.sqrt(botRate()/BALANCE.BOT_BASE_BPH));}
function maxStockAge(){
  let m=0;G.lots.forEach(l=>{if(l.age>m)m=l.age;});G.bottles.forEach(r=>{if(r.age>m)m=r.age;});
  return m;
}
function ordGenerate(opts){
  opts=opts||{};
  const custs=custAvailable();if(!custs.length)return null;
  let c=opts.cid?custById(opts.cid):null;
  if(!c){
    const ws=custs.map(x=>1+0.2*relLv(x.id));let r=Math.random()*ws.reduce((a,b)=>a+b,0);
    for(let i=0;i<custs.length;i++){r-=ws[i];if(r<=0){c=custs[i];break;}}
    c=c||custs[0];
  }
  const now=Date.now();
  const kinds=c.kinds.filter(k=>k!=='newmake'||((G.dl||1)===1&&facLv('distillation')>0));
  const kind=pick(kinds.length?kinds:['product']);
  const o={id:uid('o'),cid:c.id,kind,pid:null,tp:null,target:null,minAge:0,qty:0,mult:1,reserve:false,accepted:false,createdAt:now,dueAt:0,stretch:false};
  const sc=qtyScale();
  const baseQ=rndi(c.qty[0],c.qty[1]);
  o.rq=baseQ; // 評判計算用（規模補正前の本数）
  o.qty=Math.max(1,Math.round(baseQ*sc*mktFx('orderQty')));
  const uw=G.uw.length?G.uw.slice():['glenlivid'];
  const maxA=maxStockAge();
  if(kind==='product'){
    const withAge=uw.map(id=>({id,need:(productSpec(id)||{minAge:0}).minAge+(c.ageAdd||0)}));
    const feasible=withAge.filter(x=>x.need<=maxA);
    const stretch=withAge.filter(x=>x.need>maxA&&x.need<=maxA+3);
    let ch;
    if(stretch.length&&(Math.random()<BALANCE.STRETCH_RATE||!feasible.length)){ch=originPick(stretch,x=>(productSpec(x.id)||{}).tp);o.stretch=true;}
    else if(feasible.length)ch=originPick(feasible,x=>(productSpec(x.id)||{}).tp); // v5.6 地元の種類は出やすい
    else{ch=withAge.sort((a,b)=>a.need-b.need)[0];o.stretch=true;}
    o.pid=ch.id;o.minAge=ch.need;
  }else if(kind==='newmake'){
    o.qty=Math.max(10,Math.round(rndi(50,200)*sc));
  }else if(kind==='type'){
    const tps=[...new Set(uw.map(id=>(productSpec(id)||{}).tp).filter(Boolean))];
    o.tp=originPick(tps,x=>x);o.minAge=8;
  }else if(kind==='flavor'){
    const ts=BLEND_TARGETS.filter(t=>(t.unlockTier||1)<=(G.dl||1));
    o.target=(pick(ts.length?ts:BLEND_TARGETS)).id;o.minAge=3;
  }else if(kind==='cask'){
    o.minAge=c.minAge||18;o.qty=1;o.mult=pick(c.priceMult);
  }
  let dueH=rnd(c.dueH[0],c.dueH[1]);
  const canReserve=kind!=='newmake'&&kind!=='cask';
  if(canReserve&&(opts.special||((G.dl||1)>=2&&Math.random()<BALANCE.RESERVE_RATE))){
    o.reserve=true;o.qty*=2;o.rq*=2;o.mult=opts.special?1.6:BALANCE.RESERVE_MULT;dueH=rnd(72,168);
    if(o.kind==='product'){const sp=productSpec(o.pid);if(sp)o.minAge=Math.max(o.minAge,Math.min(sp.minAge+(c.ageAdd||0)+2,Math.floor(maxA)+4));}
  }
  o.dueAt=now+dueH*3600000;
  return o;
}
function ordSpawnTick(now){
  now=now||Date.now();
  if(!G.orderClock)G.orderClock=now+BALANCE.ORDER_INTERVAL_MS;
  let n=0,guard=0;
  while(now>=G.orderClock&&guard<200){
    guard++;
    if(G.orders.length<boardSize()){const o=ordGenerate();if(o){G.orders.push(o);n++;}}
    G.orderClock+=BALANCE.ORDER_INTERVAL_MS;
    if(G.orders.length>=boardSize()&&now>=G.orderClock){G.orderClock=now+BALANCE.ORDER_INTERVAL_MS;break;}
  }
  if(guard>=200)G.orderClock=now+BALANCE.ORDER_INTERVAL_MS;
  if(n&&!_offlineRunning)toast('📜 新しい注文が'+n+'件届きました',2500);
  return n;
}
function ordRep(o){const c=custById(o.cid);if(o.kind==='cask')return c.repFlat||10;if(o.kind==='newmake')return 1;return (o.rq||o.qty)*(c.repPerBtl||0)*(o.reserve?1.5:1);}
function ordExpireTick(now){
  now=now||Date.now();let expired=0,failed=0;
  G.orders=G.orders.filter(o=>{
    if(o.dueAt>now)return true;
    if(o.reserve&&o.accepted){
      failed++;G.stats.failed++;
      changeRep(-ordRep(o)*0.5,'予約注文の期限切れ');relAdd(o.cid,-3);
      if(!_offlineRunning)toast('⚠️ 予約注文の期限が切れました（評判低下）',3500);
    }else expired++;
    return false;
  });
  return {expired,failed};
}
function ordLabel(o){
  if(o.kind==='product'){const sp=productSpec(o.pid);return (sp?sp.name:'?')+' '+o.minAge+'年以上';}
  if(o.kind==='newmake')return 'ニューメイク';
  if(o.kind==='type')return o.tp+' '+o.minAge+'年以上';
  if(o.kind==='flavor'){const t=BLEND_TARGETS.find(x=>x.id===o.target);return (t?t.name:'?')+'系 一致70%以上';}
  if(o.kind==='cask')return o.minAge+'年以上の樽';
  return '';
}
function ordRowPred(o){
  if(o.kind==='product')return r=>r.pid===o.pid&&r.age>=o.minAge;
  if(o.kind==='type')return r=>{const sp=productSpec(r.pid);return sp&&!sp.blend&&sp.tp===o.tp&&r.age>=Math.max(o.minAge,sp.minAge);};
  if(o.kind==='flavor'){const t=BLEND_TARGETS.find(x=>x.id===o.target);return r=>t&&r.age>=o.minAge&&flavorMatch(r.fl,t.target)>=0.7;}
  return ()=>false;
}
function ordMatch(o,lotId){
  const c=custById(o.cid);
  const pm=o.kind==='cask'?o.mult:c.priceMult*(1+BALANCE.REL_PRICE_STEP*relLv(o.cid))*o.mult;
  if(o.kind==='newmake'){
    const have=G.tank||0;const ok=have>=o.qty;
    return {ok,have,need:o.qty,cash:o.qty*nmPrice()*BALANCE.NEWMAKE_ORDER_MULT*(1+BALANCE.REL_PRICE_STEP*relLv(o.cid)),rep:ordRep(o),take:[]};
  }
  if(o.kind==='cask'){
    const lots=G.lots.filter(l=>l.age>=o.minAge);
    const nb=l=>(c.limited&&l.name)?1.2:1;
    const lot=lotId?lots.find(l=>l.id===lotId):lots.sort((a,b)=>lotValue(b)*nb(b)-lotValue(a)*nb(a))[0];
    return {ok:!!lot,have:lots.length,need:1,lots,lot,cash:lot?caskOrdCash(o,lot,pm,nb(lot)):0,rep:ordRep(o),take:[]};
  }
  const pred=ordRowPred(o);
  const rows=G.bottles.filter(pred).sort((a,b)=>rowUnit(a)-rowUnit(b));
  const have=rows.reduce((a,r)=>a+r.n,0);
  let rem=o.qty,cash=0;const take=[];
  for(const r of rows){if(rem<=0)break;const k=Math.min(r.n,rem);take.push({row:r,n:k});cash+=rowUnit(r)*k*pm;rem-=k;}
  return {ok:rem<=0,have,need:o.qty,cash,rep:ordRep(o),take};
}
// v5.1 樽の注文の報酬：v5.0 までの式（年数に比例・注文の倍率 1.5〜2.5）。ただし「樽ごと売る」額は下回らない。
// 樽の価値（直販額の55%）を注文の倍率で掛けると、瓶詰めを通さずに現金になる量が増えすぎる（ボットで純利益が約50倍）ため
function caskOrdCash(o,lot,pm,nb){return Math.max(lotValueOld(lot)*pm,lotValue(lot)*BALANCE.CASK_SPOT_MULT)*nb;}
function ordAccept(id){
  const o=G.orders.find(x=>x.id===id);if(!o||!o.reserve||o.accepted)return false;
  const n=G.orders.filter(x=>x.reserve&&x.accepted).length;
  if(n>=BALANCE.RESERVE_MAX_ACCEPT){toast('同時に受けられる予約は'+BALANCE.RESERVE_MAX_ACCEPT+'件までです',2500);return false;}
  o.accepted=true;sndQuest();toast('📝 予約注文を受注しました',2200);save();return true;
}
function ordDismiss(id){
  const o=G.orders.find(x=>x.id===id);if(!o)return false;
  if(o.reserve&&o.accepted){toast('受注済みの予約は見送れません');return false;}
  G.orders=G.orders.filter(x=>x!==o);save();return true;
}
function ordDeliver(id,lotId){
  const o=G.orders.find(x=>x.id===id);if(!o)return false;
  if(o.reserve&&!o.accepted){toast('先に受注してください');return false;}
  const m=ordMatch(o,lotId);
  if(!m.ok){toast('在庫が条件に足りません',2500);return false;}
  if(o.kind==='newmake'){G.tank-=o.qty;}
  else if(o.kind==='cask'){G.lots=G.lots.filter(l=>l!==m.lot);}
  else{m.take.forEach(t=>{const pid=t.row.pid,age=t.row.age;recordUnit(rowUnit(t.row));takeRow(t.row,t.n);shipCount(pid,t.n,age);});}
  if(o.reserve)G.stats.reserveDone=(G.stats.reserveDone||0)+1;
  if(o.kind==='cask')G.stats.limited=(G.stats.limited||0)+1;
  earn(m.cash,'ord');
  const c=custById(o.cid);
  changeRep(m.rep,c.name+'へ納品');
  relAdd(o.cid,1);
  G.stats.orders++;dmProgress('dm_order');hgOrdDone();fxDeliver(o,m.cash,m.rep);
  G.orders=G.orders.filter(x=>x!==o);
  sndQuest();toast('📦 '+c.name+'へ納品 +'+fmt(m.cash),3000);
  chkT();chkUnlocks();save();
  return true;
}
function ordFirst(){
  chkUnlocks();
  if(G.orders.length)return;
  const a=ordGenerate({cid:'local'});if(a){a.kind='product';a.pid='glenlivid';a.minAge=8;a.qty=12;a.rq=12;a.stretch=false;a.dueAt=Date.now()+36*3600000;G.orders.push(a);}
  const b=ordGenerate({cid:'local'});if(b&&b.kind==='product'){G.orders.push(b);}
  G.orderClock=Date.now()+BALANCE.ORDER_INTERVAL_MS;
}

// ---------- 施設強化・Tier昇格 ----------
function upgFac(id){
  if(!G.fac[id]||!G.fac[id].p||G.fac[id].l>=facMaxLv())return;
  if(brPending(id)){closeM();_brUp=id;openBranchModal(id);return;}
  const c=fuc(id);
  if(G.cash<c){toast('資金不足');return;}
  const fx0=fxProdSnap();
  pay(c,'capex',id);G.fac[id].l++;
  prodInvalidate();
  dmProgress('dm_upg');
  sndUpgrade();
  chkT();chkUnlocks();rMake();rdistLight();updHdr();
  const _upgName=FD.find(f=>f.id===id).name;
  if(G.fac[id].l===BALANCE.BRANCH_LV&&FAC_BRANCH[id])toast('🔧 '+_upgName+' Lv'+G.fac[id].l+'! 設備を選べます',4000);
  else toast(_upgName+' Lv'+G.fac[id].l+'に強化!');
  closeM();
  renderFacEncyclopedia();
  fxUpg(id,fx0);
}
function tierCost(tier){let c=DL[tier-1].unlock;if(tier===2&&psk('ps_t2_unlock'))c*=0.5;return c;}
function tierReqStatus(tier){
  const r=DL_REQ[tier-1];if(!r)return [];
  const out=[];
  out.push({label:'出荷本数',cur:G.stats.shipped,need:r.shipped});
  out.push({label:'評判',cur:G.reputation||0,need:r.rep});
  out.push({label:r.casks.age+'年以上の樽（倉庫内）',cur:G.lots.filter(l=>l.age>=r.casks.age).length,need:r.casks.n});
  if(r.orders)out.push({label:'注文達成',cur:G.stats.orders,need:r.orders});
  if(r.rels)out.push({label:'関係Lv'+r.rels.lv+'以上の取引先',cur:CUSTOMERS.filter(c=>relLv(c.id)>=r.rels.lv).length,need:r.rels.n});
  if(r.awards)out.push({label:'品評会の受賞',cur:G.stats.awardsWon||0,need:r.awards});
  out.push({label:'昇格費用',cur:G.cash,need:tierCost(tier),money:true});
  out.forEach(o=>o.ok=o.cur>=o.need);
  return out;
}
function canUpgDist(){if(G.dl>=DL.length)return false;return tierReqStatus(G.dl+1).every(o=>o.ok);}
function doUpgDist(cost,tier){
  if(tier!==G.dl+1||!canUpgDist()){toast('条件が未達成です');closeM();return;}
  cost=tierCost(tier);
  if(G.cash<cost){toast('資金不足');closeM();return;}
  pay(cost,'sga','tier');G.dl=tier;hgAdd(V51.HG.tier.k,'Tier'+tier+'に昇格','tier',true);
  prodInvalidate();
  sndTierUp();recordTier(tier);
  chkT();chkUnlocks();rall();closeM();updHdr();
  const next=DL[tier-1];
  celebrate({icon:'🏭',title:next.name+'に昇格',sub:'Tier'+tier+' ・ 設備の上限Lv'+facMaxLv()+' ・ 注文枠'+boardSize()+'件'});
  save();
}

// ---------- ブレンド ----------
function blendPreview(targetId,picks){
  const t=BLEND_TARGETS.find(x=>x.id===targetId);
  if(!t)return {ok:false,reason:'レシピを選んでください'};
  if((G.dl||1)<3)return {ok:false,reason:'Tier3で解禁'};
  if((t.unlockTier||1)>(G.dl||1))return {ok:false,reason:'Tier'+t.unlockTier+'で解禁のレシピです'};
  const used=new Set();const ps=[];
  (picks||[]).forEach(p=>{if(!p||!p.lotId||!(p.L>0)||used.has(p.lotId))return;const l=G.lots.find(x=>x.id===p.lotId);if(!l)return;used.add(p.lotId);ps.push({lot:l,L:Math.min(p.L,l.L)});});
  const tot=ps.reduce((a,p)=>a+p.L,0);
  if(!ps.length)return {ok:false,reason:'原酒を選んでください'};
  const n=Math.floor(tot/BALANCE.BOTTLE_L+1e-9);
  const fl={};FL_KEYS.forEach(k=>fl[k]=0);let q=0,age=Infinity;
  ps.forEach(p=>{const lf=lotFlavor(p.lot);FL_KEYS.forEach(k=>fl[k]+=lf[k]*p.L);q+=p.lot.q*p.L;age=Math.min(age,p.lot.age);});
  FL_KEYS.forEach(k=>fl[k]=fl[k]/tot);q=q/tot;
  const score=blendScoreFl(fl,t.target,t.tolerance);
  const res={ok:true,t,ps,tot,n,fl,q,age:Math.floor(age),score,unit:0,hours:0};
  if(n<1)return Object.assign(res,{ok:false,reason:'量が足りません'});
  if(age<3)return Object.assign(res,{ok:false,reason:'3年未満の原酒は使えません'});
  if(score<0.3)return Object.assign(res,{ok:false,reason:'マッチ率が低すぎます（30%以上）'});
  res.unit=priceUnit('blend:'+t.id,res.age,q,fl);
  res.hours=(botQueueBottles()+n)/botRate();
  return res;
}
function blendStart(targetId,picks){
  const pv=blendPreview(targetId,picks);
  if(!pv.ok){toast(pv.reason,2500);return false;}
  if(G.bq.length>=20){toast('瓶詰め待ちが上限（20件）です');return false;}
  const mat=btlMatCost(pv.n);
  if(G.cash<mat.cost){toast('瓶の資材代が足りません（−'+fmt(mat.cost)+'）',3000);return false;}
  btlMatPay(mat);
  let lc=mat.cost;
  pv.ps.forEach(p=>{lc+=lotDraw(p.lot,p.L);});
  G.lots=G.lots.filter(l=>l.L>=BALANCE.BOTTLE_L-1e-9); // 1本に満たない端数は空け樽として処分
  G.bq.push({id:uid('q'),pid:'blend:'+pv.t.id,n:pv.n,done:0,moved:0,age:pv.age,q:pv.q,fl:pv.fl,blend:pv.t.id,c:lc});
  if(!G.blendHistory)G.blendHistory=[];
  G.blendHistory.unshift({t:Date.now(),target:pv.t.id,score:pv.score,n:pv.n});
  if(G.blendHistory.length>20)G.blendHistory.length=20;
  if(pv.score>=0.8)changeRep(1,'ブレンド完成');
  if(pv.score>=0.95)changeRep(5,'傑作ブレンド');
  dmProgress('dm_blend');sndPurchase();
  toast('🔀 ブレンド完成: '+pv.t.name+' '+pv.n+'本を瓶詰めへ',3000);
  chkT();save();return true;
}

// ---------- 品評会 ----------
const JUDGES=[
  {name:'熟成を重んじる審査員',w:[0.5,0.25,0.25]},
  {name:'品質に厳しい審査員',w:[0.25,0.5,0.25]},
  {name:'香味を重視する審査員',w:[0.25,0.25,0.5]},
];
const JUDGE_WORDS={
  good:['熟成の深みが際立つ','造りが丁寧で雑味がない','銘柄の個性が見事に表れている'],
  bad:['熟成がまだ若い','仕上げに粗さが残る','狙いの香味から外れている'],
};
function compFactors(r){
  const sp=productSpec(r.pid);
  const A=Math.min(1,r.age/12),Q=clamp((r.q-0.9)/0.3,0,1);
  const F=sp?(sp.blend?blendScoreFl(r.fl,sp.target,sp.tol):flavorMatch(r.fl,sp.target)):0;
  return [A,Q,F];
}
function compExpected(r){const f=compFactors(r);const base=JUDGES.reduce((a,j)=>a+j.w[0]*f[0]+j.w[1]*f[1]+j.w[2]*f[2],0)/3;return base+0.15*psk('ps_comp_rate')+Math.min(0.1,(G.reputation||0)/3000);}
function enterComp(compId,rowId){
  const comp=COMPETITIONS.find(x=>x.id===compId);const r=G.bottles.find(x=>x.id===rowId);
  if(!comp||!r)return null;
  if(isHouse(r.pid)){toast('ハウスモルトは品評会に出せません');return null;}
  if((G.reputation||0)<comp.unlockRep){toast('評判'+comp.unlockRep+'で解禁');return null;}
  const cd=(G.compCooldowns||{})[compId]||0;if(Date.now()<cd){toast('再出品まで '+fmtRemain(cd-Date.now()));return null;}
  const ec=compCost(comp);
  if(G.cash<ec){toast('参加費が足りません');return null;}
  if(r.n<BALANCE.COMP_BOTTLES){toast(BALANCE.COMP_BOTTLES+'本以上の在庫が必要です');return null;}
  pay(ec,'sga','comp');takeRow(r,BALANCE.COMP_BOTTLES);G.stats.compEntered=(G.stats.compEntered||0)+1;
  const f=compFactors(r);
  const judges=JUDGES.map(j=>{
    const s=j.w[0]*f[0]+j.w[1]*f[1]+j.w[2]*f[2]+rnd(-0.04,0.04);
    let bi=0,wi=0;f.forEach((v,i)=>{if(v*j.w[i]>f[bi]*j.w[bi])bi=i;if(v<f[wi])wi=i;});
    return {name:j.name,score:s,comment:JUDGE_WORDS.good[bi]+(wi!==bi&&f[wi]<0.7?'が、'+JUDGE_WORDS.bad[wi]:'')+'。'};
  });
  const S=judges.reduce((a,j)=>a+j.score,0)/3+0.15*psk('ps_comp_rate')+Math.min(0.1,(G.reputation||0)/3000);
  const win=S>=comp.qualThreshold;
  if(win){
    changeRep(comp.repReward,comp.name+' 受賞');
    if(!G.awards.includes(compId))G.awards.push(compId);
    G.stats.awardsWon=(G.stats.awardsWon||0)+1;
    G.awardMult[r.pid]=Math.max(G.awardMult[r.pid]||1,comp.priceMult);
    sndTierUp();
  }else{
    changeRep(-Math.max(1,Math.round(comp.repReward*0.3)),comp.name+' 落選');
    sndError();
  }
  if(!G.compCooldowns)G.compCooldowns={};
  G.compCooldowns[compId]=Date.now()+comp.cooldownMs*(psk('ps_cooldown')?0.7:1);
  dmProgress('dm_comp');
  chkT();save();
  return {comp,win,S,judges,pid:r.pid,age:r.age,q:r.q};
}

// ---------- 検証モード：時間を進める ----------
function shiftTime(ms){
  G.orders.forEach(o=>{o.dueAt-=ms;o.createdAt-=ms;});
  if(G.orderClock)G.orderClock-=ms;
  Object.keys(G.compCooldowns||{}).forEach(k=>{G.compCooldowns[k]-=ms;});
  if(G.randomEvent&&G.randomEvent.active)G.randomEvent.active.expiresAt-=ms;
  G.lots.forEach(l=>{l.at-=ms;});
  G.ls=(G.ls||Date.now())-ms;
  offline();
}


// ============================================================
// v4.1 注文を1画面で完結させる（改善計画 5.4）
// ============================================================
function ordInProgress(o){return G.bq.some(q=>q.oid===o.id);}
// 注文に足りない分を瓶詰めする計画
function ordFulfillPlan(o){
  if(!o)return {ok:false,reason:''};
  if(o.kind!=='product'&&o.kind!=='type')return {ok:false,reason:''};
  const m=ordMatch(o);
  const need=Math.max(0,o.qty-m.have);
  if(need<=0)return {ok:false,ready:true,reason:''};
  let pids=[];
  if(o.kind==='product')pids=[o.pid];
  else pids=G.uw.filter(id=>{const sp=productSpec(id);return sp&&!sp.blend&&sp.tp===o.tp;});
  let best=null;
  pids.forEach(pid=>{
    const sp=productSpec(pid);if(!sp)return;
    const minAge=Math.max(o.minAge||0,sp.minAge||0);
    const pv=botPreview(pid,need,'young',null,minAge);
    if(pv.ok&&(!best||pv.unit>best.pv.unit))best={pid,n:need,minAge,pv};
  });
  if(!best){
    const age=o.kind==='product'?o.minAge:Math.max(o.minAge,8);
    return {ok:false,reason:age+'年以上の原酒が足りません'};
  }
  return {ok:true,pid:best.pid,n:best.n,minAge:best.minAge,hours:best.pv.hours};
}
function ordFulfill(id,opts){
  const o=G.orders.find(x=>x.id===id);if(!o)return false;
  if(o.reserve&&!o.accepted){toast('先に受注してください');return false;}
  if(ordMatch(o).ok)return ordDeliver(id,null);
  if(ordInProgress(o)){toast('瓶詰め中です。終わると自動で納品します',2200);return false;}
  const pl=ordFulfillPlan(o);
  if(!pl.ok){toast(pl.reason||'この注文は詰められません',2500);return false;}
  if(!botStart(pl.pid,pl.n,'young',null,{oid:o.id,minAge:pl.minAge,quiet:true}))return false;
  o.autoDel=true;
  if(opts&&opts.instant){botTick(pl.hours*3600000+60000);ordAutoTick();}
  else toast('🍾 瓶詰めを開始。終わると自動で納品します（あと'+fmtRemain(pl.hours*3600000)+'）',3000);
  save();
  return true;
}
// 瓶詰めが終わった注文を自動で納品する
function ordAutoTick(){
  let n=0;
  G.orders.slice().forEach(o=>{
    if(!o.autoDel||(o.reserve&&!o.accepted)||ordInProgress(o))return;
    if(ordMatch(o).ok){if(ordDeliver(o.id,null))n++;}
    else o.autoDel=false;
  });
  return n;
}

// ============================================================
// v4.1 段階的な解放（改善計画 8.2）
// ============================================================
function recipeAvailable(){
  if((G.recipeOwned||[]).length>4)return true;
  // 最初のレシピを買えるだけの総売上に届いたら出す
  const te=G.te||0;
  return ['grain','water','yeast','peat'].some(k=>rcpList(k).some(it=>!G.recipeOwned.includes(it.id)&&rcpUnlocked(k,it)&&te>=rcpCost(k,it)));
}
function feat(k){
  const dl=G.dl||1;
  switch(k){
    case 'tank': return !!(G.fac.distillation&&G.fac.distillation.p)||(G.tank||0)>0;
    case 'caskChoice': return CASK_TYPES.filter(caskTypeUnlocked).length>1||CASK_SIZES.filter(caskSizeUnlocked).length>1;
    case 'recipe': return recipeAvailable();
    case 'rel': return dl>=2;
    case 'comp': return dl>=2||(G.stats.awardsWon||0)>0||(G.awards||[]).length>0;
    case 'blend': return dl>=3;
    case 'daily': return !!(G.tut&&(G.tut.done.first||G.tut.done.upd||!G.tut.q.includes('first')));
    case 'prestige': return (typeof canPrestige==='function'&&canPrestige())||((G.prestige&&G.prestige.level)||0)>0;
    case 'branch': return FD.some(f=>brPending(f.id)||brOpt(f.id));
    case 'finish': return dl>=2;
  }
  return true;
}
