// v4.7 の画面確認用スクリーンショット（寝かせる・樽の小窓・砂時計・倉庫日誌）
const { chromium } = require('playwright');
const path = require('path');
const STATE = require('fs').readFileSync('v43.js', 'utf8').match(/const STATE = (function \(mode\) \{[\s\S]*?\n\});/)[1];
const OUT = process.argv[2] || '.';
(async () => {
  const b = await chromium.launch(); const errs = [];
  for (const theme of ['dark', 'light']) {
    const ctx = await b.newContext({ viewport: { width: 393, height: 760 }, deviceScaleFactor: 1.5 }); const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(e.message));
    await p.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await p.goto('file://' + path.resolve('whisky_empire.html')); await p.waitForTimeout(1000);
    await p.evaluate(() => titleStart(false)); await p.waitForTimeout(300);
    await p.evaluate(`(${STATE})('late')`); await p.waitForTimeout(300);
    await p.evaluate(th => { celebrate = () => {}; _celebQ = []; celebClose(); toast = () => {}; Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); opt().theme = th; applyOpt();
      G.lots = G.lots.slice(0, 16); const ag = [24.3, 21.6, 19.1, 16.4, 13.9, 11.2, 8.6, 6.1, 3.4, 1.2, 0.3, 14.8, 9.9, 4.9, 2.2, 7.4]; G.lots.forEach((l, i) => { l.age = ag[i]; delete l.goal; lotGoalInit(l); l.gs = Math.max(0, l.gs - 1.5); });
      G.lots[6].gd = 8; G.lots[6].gt = Date.now(); G.lots[6].age = 8.02; G.lots[6].goal = 12; G.lots[6].gs = 8;
      G.jnl = { cur: null, list: [] }; const rn = Date.now.bind(Date); let off = -24 * 3600000; Date.now = () => rn() + off; jnlRoll(); G.stats.filled += 6; G.stats.bottled += 840; G.stats.orders += 5; G.te += 3.2e7; jnlAdd('angel', 12.4); jnlDone(G.lots[6], 8); off = 0; jnlRoll(); Date.now = rn; G.hs.jnl = '';
      G.hg.n = 3; }, theme);
    await p.evaluate(() => { switchTab('tcel'); rCellar(); document.getElementById('tcel').scrollTop = 0; }); await p.waitForTimeout(400);
    await p.screenshot({ path: `${OUT}/v47_${theme}_tcel.png` });
    await p.setViewportSize({ width: 393, height: 1500 }); await p.evaluate(() => rCellar()); await p.waitForTimeout(300);
    const wh = await p.$('#whSummary'); await wh.screenshot({ path: `${OUT}/v47_${theme}_wh.png` });
    await p.setViewportSize({ width: 393, height: 760 });
    if (theme === 'dark') {
      await p.evaluate(() => openLotModal(G.lots[4].id)); await p.waitForTimeout(200); await p.screenshot({ path: `${OUT}/v47_lot.png` });
      await p.evaluate(() => { closeM(); openHgModal(); }); await p.waitForTimeout(200); await p.screenshot({ path: `${OUT}/v47_hg.png` });
      await p.evaluate(() => { closeM(); openJnlModal(); }); await p.waitForTimeout(200); await p.screenshot({ path: `${OUT}/v47_jnl.png` });
    }
    await ctx.close();
  }
  console.log('ERRORS', errs); await b.close();
})();
