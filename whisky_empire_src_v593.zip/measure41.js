const { chromium } = require('playwright'); const path = require('path');
async function measure(page){
  return await page.evaluate(async()=>{
    if(_offlineGate)closeOfflineModal(); closeM();
    const out=[];
    for(const t of ['td','tb','tcel','tsale','te','tp']){
      switchTab(t); await new Promise(r=>setTimeout(r,200));
      const el=document.getElementById(t);
      const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let chars=0,n;
      while(n=walker.nextNode()){const p=n.parentElement;if(!p)continue;if(p.getClientRects().length===0)continue;const st=getComputedStyle(p);if(st.visibility==='hidden')continue;chars+=n.textContent.replace(/\s/g,'').length;}
      const btns=[...el.querySelectorAll('button,select,input,[data-act]')].filter(b=>b.getClientRects().length>0).length;
      out.push({tab:t,chars,controls:btns,screens:+(el.scrollHeight/el.clientHeight).toFixed(1)});
    }
    return out;
  });
}
(async()=>{
  const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:390,height:740}})).newPage();
  await p.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1200);
  await p.evaluate(()=>{Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}});
  const fresh=await measure(p);
  await p.evaluate(()=>{G.dl=3;G.cash=8e7;G.te=5e8;G.reputation=60;FD.forEach((f,i)=>{G.fac[f.id].p=true;G.fac[f.id].l=[24,22,26,21,18,14][i];});FD.forEach(f=>G.branch[f.id]=0);G.uw=WL.slice(0,14).map(w=>w.id);
    for(let i=0;i<12;i++){const l=makeLot(caskType('bourbon'),caskSize('hogshead'));l.age=2+i;G.lots.push(l);}
    const t=productSpec('glenlivid').target;invAdd('glenlivid',140,9,1.05,t);invAdd('jack_d',60,5,1,productSpec('jack_d').target);
    G.orders=[];for(let i=0;i<5;i++){const o=ordGenerate();if(o)G.orders.push(o);} prodInvalidate();});
  const mid=await measure(p);
  const chrome=await p.evaluate(()=>['hdr','nav'].map(id=>document.getElementById(id).getBoundingClientRect().height).reduce((a,b)=>a+b,0));
  console.log(JSON.stringify({fresh,mid,chromePx:chrome}));
  await b.close();
})();
