// v5.5 選ぶイベント（買収・協力・コラボ）は廃止
const RAND_EVENTS=[
  {id:'re_critic',  type:'good',  icon:'🎙️',name:'著名評論家来訪',       effect:{rep:25},             dur:0},
  {id:'re_export',  type:'good',  icon:'✈️', name:'輸出商談成立',          effect:{cashBonus:'2h'},      dur:0},
  {id:'re_harvest', type:'good',  icon:'🌾', name:'麦芽豊作（外販収入×1.5）', effect:{passiveMult:1.5}, dur:1800},
  {id:'re_festival',type:'good',  icon:'🎉', name:'地元の酒祭り（タップ・外販×2）', effect:{allMult:2.0}, dur:3600},
  {id:'re_boom',    type:'good',  icon:'📈', name:'熟成原酒ブーム（12年以上の単価×1.3）', effect:{agedPriceMult:1.3,orderNow:1}, dur:21600},
  {id:'re_bigorder',type:'good',  icon:'🤝', name:'大口商談（特別な予約注文）', effect:{specialReserve:true}, dur:0},
  {id:'re_cost_up', type:'bad',   icon:'📉', name:'樽材の高騰（樽代×1.5）',  effect:{caskCostMult:1.5},   dur:3600},
  {id:'re_cask_short',type:'bad', icon:'🪵', name:'樽不足（樽代×2）',       effect:{caskCostMult:2.0},   dur:21600},
  {id:'re_review',  type:'bad',   icon:'📰', name:'辛口レビュー掲載',       effect:{rep:-10},             dur:0},
  {id:'re_heat',    type:'bad',   icon:'🌡️', name:'猛暑・エンジェルズシェア増加', effect:{angelShareMult:1.5},  dur:21600},
];
