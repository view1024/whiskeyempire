#!/bin/bash
# usage: runbal46.sh N DAYS TAPS MODE HG OUTPREFIX
N=${1:-10}; D=${2:-100}; T=${3:-50}; M=${4:-x}; HG=${5:-x}; O=${6:-/tmp/claude-0/b46}
mkdir -p $O
for i in $(seq 1 $N); do (node balance47.js $D $T $M $HG > $O/raw_$i.txt 2>&1; grep -o '"day":[0-9.]*,"ev":"Tier[0-9]"' $O/raw_$i.txt | sed 's/"day":\([0-9.]*\),"ev":"\(Tier[0-9]\)"/\2=\1/' | tr '\n' ' '; echo) > $O/bal_$i.txt & done
wait
cat $O/bal_*.txt
