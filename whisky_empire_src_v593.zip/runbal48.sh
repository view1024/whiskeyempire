#!/bin/bash
# usage: runbal48.sh N DAYS TAPS MODE HG STAFF(none|one|full) OUTPREFIX
N=${1:-10}; D=${2:-100}; T=${3:-50}; M=${4:-x}; HG=${5:-x}; ST=${6:-none}; O=${7:-/tmp/claude-0/b48}; W=${8:-0}
mkdir -p $O
for i in $(seq 1 $N); do (node balance48.js $D $T $M $HG $ST $W > $O/raw_$i.txt 2>&1; grep -o '"day":[0-9.]*,"ev":"Tier[0-9]"' $O/raw_$i.txt | sed 's/"day":\([0-9.]*\),"ev":"\(Tier[0-9]\)"/\2=\1/' | tr '\n' ' '; grep -o '"staff":{[^}]*}' $O/raw_$i.txt; echo) > $O/bal_$i.txt & done
wait
cat $O/bal_*.txt
