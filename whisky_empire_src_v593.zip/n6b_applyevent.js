function applyEventEffect(ev){
  const effect=ev.effect; // v5.5 選ぶイベントは廃止
  if(!effect)return;
  if(effect.rep!==undefined)changeRep(effect.rep,ev.name);
  if(effect.cash!==undefined){const d=Math.max(0,G.cash+effect.cash)-G.cash;acOther(d);G.cash+=d;}
  if(effect.cashBonus==='2h'){const f=prodFlows();const v=(ti()+f.newmake*nmPrice())*2;earn(v,'oth');toast(ev.icon+' 2時間分の生産額 +'+fmt(v),4000);}
  if(effect.cashMult){const d=G.cash*effect.cashMult-G.cash;acOther(d);G.cash+=d;}
  if(effect.orderNow){const o=ordGenerate();if(o){G.orders.push(o);toast('📜 注文が届きました',2500);}}
  if(effect.specialReserve){let o=null;for(let i=0;i<8&&!(o&&o.reserve);i++)o=ordGenerate({special:true});if(o&&o.reserve){G.orders.push(o);toast('🤝 特別な予約注文が届きました（単価×1.6）',3500);}}
  if(ev.dur>0){G.randomEvent.active={id:ev.id,effect,expiresAt:Date.now()+ev.dur*1000};}
  prodInvalidate();
  save();
}
