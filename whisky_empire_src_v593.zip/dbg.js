const { chromium } = require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message+' '+(e.stack||'').split('\n')[1]));p.on('console',m=>errs.push(m.type()+': '+m.text()));
await p.route(/fonts/,r=>r.abort());await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(2000);
console.log(await p.evaluate(()=>({title:document.getElementById('title').className,btns:document.getElementById('titleBtns').innerHTML.length,ld:document.getElementById('ld').style.display})));
console.log(errs.join('\n'));await b.close();})();
