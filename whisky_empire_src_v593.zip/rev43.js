const { chromium } = require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();
for (const rm of ['no-preference','reduce']){
const ctx=await b.newContext({viewport:{width:390,height:740},reducedMotion:rm});const p=await ctx.newPage();
await p.route(/fonts/,r=>r.abort());await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1500);
await p.evaluate(()=>{titleStart(false);});await p.waitForTimeout(800);
await p.evaluate(()=>{Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}});
const a=await p.evaluate(()=>{const el=document.getElementById('tkTxt');const r=el.getBoundingClientRect();return {cls:el.className,x:Math.round(r.left),w:Math.round(el.scrollWidth),track:document.getElementById('tkTrack').offsetWidth,anim:getComputedStyle(el).animationName,still:tkStill(),text:el.textContent.slice(0,20)};});
await p.waitForTimeout(2000);
const b2=await p.evaluate(()=>{const el=document.getElementById('tkTxt');return {x:Math.round(el.getBoundingClientRect().left),cls:el.className};});
console.log(rm,JSON.stringify(a),JSON.stringify(b2));
await ctx.close();}
await b.close();})();
