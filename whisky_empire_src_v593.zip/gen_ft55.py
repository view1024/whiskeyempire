exec(open('gen_ft54.py').read().replace("open('functest54.js','w').write(s)","pass"))
import os, re
exec(open('functest55_fix.py').read())
if os.path.exists('functest55_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest55_add.js').read()+s[a:]
# v5.5 1つのテストの例外で全体が止まらないように、各ブロックを try で包む（例外は C<番号> の失敗として記録）
pat=re.compile(r'\n  // -{3,} #(\d+)[^\n]*\n  \{\n')
out='';pos=0
while True:
    m=pat.search(s,pos)
    if not m: out+=s[pos:];break
    j=s.index('\n  }\n',m.end()-1)
    out+=s[pos:m.end()-4]+'  try {\n'+s[m.end():j]+"\n  } catch (e) { rec('C"+m.group(1)+"', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }"
    pos=j+4
s=out
open('functest55.js','w').write(s)
