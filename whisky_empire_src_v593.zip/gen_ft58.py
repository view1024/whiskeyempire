# v5.7 の生成（try で包む前）まで → v5.8 の書き換え → 追加 → try で包む
s57=open('gen_ft57.py').read()
exec(s57[:s57.rindex("exec(src[cut:]")])
exec(open('functest58_fix.py').read())
if os.path.exists('functest58_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest58_add.js').read()+s[a:]
exec(src[cut:].replace("open('functest55.js','w').write(s)","pass"))
open('functest58.js','w').write(s)
