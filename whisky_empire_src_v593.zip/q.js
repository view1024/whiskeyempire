const { chromium } = require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const p=await b.newPage();await p.route(/fonts/,r=>r.abort());
await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1200);
const r=await p.evaluate(process.argv[2]);console.log(JSON.stringify(r,null,0));await b.close();})();
