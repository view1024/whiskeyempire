  // ================= v4.3 追加テスト =================
  const STATE = function (mode) {
    if (_offlineGate) closeOfflineModal(); closeM();
    Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose();
    _mktOff = true;
    if (mode === 'fresh') { prodInvalidate(); rall(); return; }
    const late = mode === 'late';
    G.dl = late ? 5 : 3; G.cash = late ? 5e11 : 8e7; G.te = late ? 5e12 : 5e8; G.reputation = late ? 260 : 60;
    G.stats.shipped = late ? 150000 : 2500; G.stats.orders = late ? 120 : 22;
    FD.forEach((f, i) => { G.fac[f.id].p = true; G.fac[f.id].l = (late ? [48, 46, 49, 45, 40, 38] : [24, 22, 26, 21, 18, 14])[i]; });
    G.branch.malting = 1; G.branch.fermentation = 0; G.branch.distillation = late ? 1 : null;
    G.uw = WL.slice(0, late ? 40 : 14).map(w => w.id);
    const mk = (c, s, age) => { const l = makeLot(caskType(c), caskSize(s)); l.age = age; l.L = l.L0 * Math.pow(0.984, age); return l; };
    G.lots = [mk('sherry', 'hogshead', 12.4), mk('bourbon', 'hogshead', 9.1), mk('bourbon', 'quarter', 4.6), mk('wine', 'barrel', 2.2), mk('bourbon', 'butt', 7.8), mk('sherry', 'hogshead', 0.4)];
    const nl = late ? whSlots() - 6 : 10;
    for (let i = 0; i < nl; i++) G.lots.push(mk('bourbon', 'hogshead', 1 + (i % 25) * 1.1));
    G.tank = late ? tankCap() * 0.7 : 1800;
    const t = productSpec('glenlivid').target;
    invAdd('glenlivid', 140, 9, 1.05, t); invAdd('jack_d', 60, 5, 1.0, productSpec('jack_d').target); invAdd('johnnie_em', 25, 12, 1.1, productSpec('johnnie_em').target);
    if (late) { invAdd('hibikue', 80, 17, 1.12, productSpec('hibikue') ? productSpec('hibikue').target : t); }
    G.orders = [];
    for (let i = 0; i < boardSize(); i++) { const o = ordGenerate(); if (o) G.orders.push(o); }
    if (G.orders[0]) { G.orders[0].reserve = true; G.orders[0].accepted = false; }
    G.rel.local = { lv: 2, done: 9 }; G.rel.bar = { lv: 1, done: 4 };
    G.shipLog = { glenlivid: { t: Date.now(), maxAge: 9 }, jack_d: { t: Date.now(), maxAge: 5 } };
    G.bq = [{ id: 'q_x', pid: 'glenlivid', n: 300, done: 120, moved: 120, age: 9, q: 1.05, fl: t, blend: null, oid: null }];
    G.blendHistory = [{ t: Date.now(), target: 'classic_blend', score: 0.82, n: 120 }];
    G.lots[0].name = 'はじまりの一樽'; G.lots[1].fin = { from: 'bourbon', at: 8 };
    G.chap.seed = true; checkChapters();
    prodInvalidate(); rall();
  };
  async function page43(H, rm, mode) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: H }, reducedMotion: rm || 'no-preference' });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
    if (mode) { await page.evaluate(`(${STATE.toString()})(${JSON.stringify(mode)})`); await page.waitForTimeout(500); await page.evaluate(() => { _celebQ = []; celebClose(); closeM(); }); }
    return { page, errors, ctx };
  }
  // ---------- #60 よく使う4タブはスクロールなし（2画面×3状態×4タブ） ----------
  {
    const bad = []; const errs = []; let n = 0; const lists = [];
    for (const H of [667, 740]) for (const mode of ['fresh', 'mid', 'late']) {
      const { page, errors, ctx } = await page43(H, null, mode);
      const r = await page.evaluate(async () => { const o = {}; for (const t of ['td', 'tb', 'tcel', 'tsale']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); o[t] = el.scrollHeight - el.clientHeight; }
        switchTab('tcel'); await new Promise(r => setTimeout(r, 100)); const w = document.getElementById('whSummary'); w.scrollTop = 1e6; const wEnd = w.scrollTop + w.clientHeight >= w.scrollHeight - 2;
        switchTab('tsale'); await new Promise(r => setTimeout(r, 100)); const ob = document.getElementById('orderBoard'); ob.scrollTop = 1e6; const oEnd = ob.scrollTop + ob.clientHeight >= ob.scrollHeight - 2; const last = ob.lastElementChild; const lr = last && last.getBoundingClientRect(), obr = ob.getBoundingClientRect();
        return { o, wEnd, oEnd, lastVisible: !last || (lr.bottom <= obr.bottom + 1), cards: ob.children.length, casks: document.querySelectorAll('#whSummary .ck').length }; });
      Object.keys(r.o).forEach(t => { n++; if (r.o[t] > 0) bad.push(mode + H + ':' + t + '+' + r.o[t]); });
      if (mode === 'late') lists.push(r);
      errs.push(...errors); await ctx.close();
    }
    rec(60, 'よく使う4タブはスクロールなし（390×667・390×740 × 開始直後・中盤・終盤 = 24通り）', n === 24 && bad.length === 0, JSON.stringify({ n, bad }));
    rec('60b', '件数が多い一覧（樽・注文）は枠の中で最後までスクロールできる', lists.length === 2 && lists.every(l => l.wEnd && l.oEnd && l.lastVisible && l.casks >= 20), JSON.stringify(lists));
    if (errs.length) rec('E20', '1画面テスト中のエラー', false, errs.slice(0, 3).join(' | '));
  }
  // ---------- #61-62 TIPS帯は常に流れる ----------
  {
    const out = [];
    for (const rm of ['no-preference', 'reduce']) {
      const { page, errors, ctx } = await page43(740, rm);
      await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } });
      await page.evaluate(() => { const L = TICKER_MSGS.slice().sort((a, b) => b.text.length - a.text.length)[0]; tkPick = () => L; nextTicker(); });
      await page.waitForTimeout(300);
      if (rm === 'reduce') {
        const box = await page.locator('#ticker').boundingBox();
        await page.mouse.move(box.x + 200, box.y + 10); await page.mouse.down();
        const h1 = await page.evaluate(() => tkTxt.getBoundingClientRect().left); await page.waitForTimeout(700); const h2 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.up(); await page.waitForTimeout(250); const longOpen = await page.evaluate(() => !mo.classList.contains('h'));
        await page.waitForTimeout(500); const h3 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.click(box.x + 200, box.y + 10); await page.waitForTimeout(250); const tapOpen = await page.evaluate(() => !mo.classList.contains('h'));
        rec(62, 'TIPS帯：押している間は止まり、離すと再開・短いタップで全文、長押しでは開かない', Math.abs(h1 - h2) < 3 && h3 < h2 - 8 && !longOpen && tapOpen, JSON.stringify({ h1, h2, h3, longOpen, tapOpen }));
      }
      const a = await page.evaluate(() => { const el = tkTxt; const tr = tkTrack.getBoundingClientRect(); const an = el.getAnimations()[0]; const x0 = el.getBoundingClientRect().left;
        const dur = an ? an.effect.getComputedTiming().duration : 0; if (an) { an.pause(); an.currentTime = dur - 1; }
        const r = el.getBoundingClientRect(); const res = { run: el.classList.contains('run'), anim: getComputedStyle(el).animationName, ell: getComputedStyle(el).textOverflow, w: Math.round(el.offsetWidth), track: Math.round(tr.width), x0: Math.round(x0), endRight: Math.round(r.right), trackLeft: Math.round(tr.left), dur: Math.round(dur), speed: Math.round((tr.width + el.offsetWidth) / (dur / 1000)) };
        return res; });
      await page.evaluate(() => nextTicker()); await page.waitForTimeout(400);
      out.push({ rm, ...a });
      const opts = await page.evaluate(() => { switchTab('tp'); return [...document.querySelectorAll('#optBox [data-k="tk"]')].map(b => b.dataset.v).join(','); });
      out[out.length - 1].opts = opts;
      if (errors.length) rec('E21', 'TIPS帯テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    const ok = out.every(o => o.run && o.anim === 'tkScroll' && o.ell !== 'ellipsis' && o.w > o.track && o.endRight <= o.trackLeft + 2 && o.opts === 'slow,mid,fast');
    const sp = out.map(o => o.speed);
    rec(61, 'TIPS帯：「視差効果を減らす」の端末でも右から左へ流れ、最後の文字まで表示枠を通過する（減らす設定では約0.65倍の速さ・「流さない」は廃止）', ok && sp[1] < sp[0] && sp[1] >= sp[0] * 0.55, JSON.stringify(out));
    const { page, ctx } = await page43(740);
    const mig = await page.evaluate(() => { const s = JSON.parse(JSON.stringify(G)); s.opt.tk = 'still'; return sanitize(s).opt.tk; });
    rec('61b', '保存済みの「流さない」は読込時に「遅い」へ置き換える', mig === 'slow', mig);
    await ctx.close();
  }
  // ---------- #63 ホームのアイコン列 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      switchTab('td'); pushNews('テスト1'); pushNews('テスト2'); rdistLight();
      const icons = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id.replace('hi_', '') + '=' + (b.querySelector('.hib') ? b.querySelector('.hib').textContent : ''));
      const c = chapCur(), st = chapState(); const cn = c.goals.filter(g => st.done[g.id]).length;
      const dn = G.daily.missions.filter(m => m.done).length; const ts = tierReqStatus(G.dl + 1); const tok = ts.filter(o => o.ok).length;
      const expect = ['chap=' + cn + '/4', 'daily=' + dn + '/' + G.daily.missions.length, 'mkt=' + mktDaysLeft() + '日', 'tier=' + tok + '/' + ts.length, 'news=' + _newsUnread];
      const modals = {};
      for (const [k, word] of [['chap', '章の目標'], ['daily', 'デイリーミッション'], ['mkt', '今月の市場'], ['tier', '昇格の条件'], ['news', 'お知らせ']]) {
        closeM(); document.getElementById('hi_' + k).click(); await new Promise(r => setTimeout(r, 80));
        modals[k] = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes(word);
      }
      closeM(); rdistLight();
      const newsAfter = document.querySelector('#hi_news .hib') ? document.querySelector('#hi_news .hib').textContent : '';
      const gone = ['chapCard', 'mktCard', 'tierCard', 'dailyBox', 'homeNews', 'nextUnlock'].filter(id => document.getElementById(id));
      return { icons, expect, modals, newsAfter, gone, nextH: Math.round(document.getElementById('nextCard').getBoundingClientRect().height) };
    });
    rec(63, 'ホーム：章・デイリー・市場・Tier・お知らせはアイコン＋バッジ（数字は内部状態と一致）で、押すとそれぞれの詳細が開く', r.icons.join() === r.expect.join() && Object.values(r.modals).every(Boolean) && r.newsAfter === '' && r.gone.length === 0 && r.nextH <= 80, JSON.stringify(r));
    if (errors.length) rec('E22', 'アイコン列テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #64 生産ライン ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      switchTab('tb'); const f = prodFlows();
      const flows = [...document.querySelectorAll('#lineView .pflow .pfl')].map(e => e.textContent);
      const expFlows = [0, 1, 2].map(i => STAGES[i].out + ' ' + fmtL(f.p[i + 1]) + '/時').concat(['新酒 ' + fmtL(f.newmake) + '/時']);
      const sur = [...document.querySelectorAll('#lineView .pflow')].map(e => { const s = e.querySelector('.psur'); return s ? s.textContent : ''; });
      const pm = priceMultBase() * getEventMult('passive');
      const expSur = [0, 1, 2].map(i => f.s[i] > 0.05 ? '余剰 ' + fmtL(f.s[i]) + ' → +' + fmt(f.s[i] * STAGES[i].price * pm) + '/時' : '').concat(['']);
      const bnIdx = [...document.querySelectorAll('#lineView .pst')].findIndex(e => e.classList.contains('bn'));
      const caps = [...document.querySelectorAll('#lineView .pst .pcap')].map(e => e.textContent);
      const tank = document.getElementById('tkAmt').textContent === fmtL(G.tank) + ' / ' + fmtL(tankCap());
      const gone = ['fl', 'recipeWrap', 'facEncEl'].filter(id => document.getElementById(id));
      const mat = document.querySelector('#tb #fac_maturation, #tb #fac_bottling');
      return { flows, expFlows, sur, expSur, bnIdx, bn: f.bottleneck, capOk: caps.every((c, i) => c.startsWith('能力 ' + fmtL(f.cap[i]) + '/時')), tank, gone, mat: !!mat };
    });
    const ok = r.flows.join('|') === r.expFlows.join('|') && r.sur.join('|') === r.expSur.join('|') && r.bnIdx === r.bn && r.capOk && r.tank && r.gone.length === 0 && !r.mat;
    rec(64, '生産ライン：工程間の流量・余剰と外販収入・能力・いちばん遅い工程・タンク量が計算値と一致', ok, JSON.stringify(r));
    // 熟成庫とボトリングは各タブで強化できる
    const r2 = await page.evaluate(async () => {
      G.cash = 1e15; G.branch.maturation = 0; G.branch.bottling = 0; rall(); switchTab('tcel'); await new Promise(r => setTimeout(r, 100));
      const m0 = G.fac.maturation.l; document.querySelector('#tcel #fac_maturation [data-act="facUp"]').click();
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const b0 = G.fac.bottling.l; document.querySelector('#tsale #fac_bottling [data-act="facUp"]').click();
      const rc = (() => { switchTab('tb'); document.querySelector('[data-act="rcpBox"]').click(); const ok = !mo.classList.contains('h') && document.querySelectorAll('#mc2 .rc').length === 4; closeM(); return ok; })();
      const bl = (() => { switchTab('tcel'); document.getElementById('btnBlend').click(); const ok = !mo.classList.contains('h') && !!document.querySelector('#mc2 #blendRadar'); closeM(); return ok; })();
      const fc = (() => { document.querySelector('#fillBox [data-act="fillChoose"]').click(); const ok = document.querySelectorAll('#mc2 select').length === 2; closeM(); return ok; })();
      const hist = (() => { switchTab('tb'); document.querySelector('[data-act="facHist"]').click(); const ok = document.querySelectorAll('#mc2 #facEncEl > div').length === FD.length; closeM(); return ok; })();
      return { mat: G.fac.maturation.l - m0, bot: G.fac.bottling.l - b0, rc, bl, fc, hist };
    });
    rec(65, '熟成庫は「寝かせる」、ボトリングは「売る」で強化できる・レシピ・ブレンド・樽の選択・設備の歩みはボタンから開く', r2.mat === 1 && r2.bot === 1 && r2.rc && r2.bl && r2.fc && r2.hist, JSON.stringify(r2));
    if (errors.length) rec('E23', '生産ラインテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #66 見学のお客さん ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('td'); G.hs.vis = 0; _vis.list.forEach(v => { const e = document.getElementById(v.id); if (e) e.remove(); }); _vis.list = []; _vis.next = 0;
      const r0 = Math.random; Math.random = () => 0.5; visitorTick(); Math.random = r0;
      await new Promise(r => setTimeout(r, 600));
      const v = _vis.list[0]; const el = document.getElementById(v.id); const r = el.getBoundingClientRect(); const bb = document.getElementById('bb').getBoundingClientRect();
      const toastTxt = _news.map(n => n.t).join('|');
      const txt = el.textContent; const expect = '試飲 +' + fmt(cv() * 15);
      const c0 = G.cash; el.click(); await new Promise(r => setTimeout(r, 50));
      return { txt, expect, overlap: !(r.right <= bb.left || r.left >= bb.right || r.bottom <= bb.top || r.top >= bb.bottom), h: Math.round(r.height), gain: G.cash - c0, cv15: cv() * 15, firstToast: toastTxt.includes('見学のお客さん'), seen: G.hs.vis };
    });
    rec(66, '見学のお客さん：吹き出しに「何者か」と報酬額を表示・樽の押せる範囲と重ならない・初回だけ説明が出る', r.txt.includes('見学させて') && r.txt.includes(r.expect) && !r.overlap && r.h >= 44 && Math.abs(r.gain - r.cv15) < 1e-6 && r.firstToast && r.seen === 1, JSON.stringify(r));
    if (errors.length) rec('E24', '見学テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #67 注文カード ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const hs = [...document.querySelectorAll('#orderBoard .oc2')].map(e => Math.round(e.getBoundingClientRect().height));
      const o = G.orders.find(x => !(x.reserve && x.accepted)); const n0 = G.orders.length;
      document.querySelector(`#orderBoard .oc2[data-id="${o.id}"] .ocl`).click(); await new Promise(r => setTimeout(r, 50));
      const modal = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes('見送る') && document.getElementById('mc2').textContent.includes(custById(o.cid).name);
      document.querySelector('#mc2 [data-act="ordDismissM"]').click(); await new Promise(r => setTimeout(r, 50));
      return { hs, modal, removed: G.orders.length === n0 - 1 && !G.orders.some(x => x.id === o.id), closed: mo.classList.contains('h') };
    });
    rec(67, '注文カード：1枚100px以下に圧縮・押すと詳細（人物・会話・見送る）が開き、見送ると消える', r.hs.length > 0 && r.hs.every(h => h <= 100) && r.modal && r.removed && r.closed, JSON.stringify(r));
    if (errors.length) rec('E25', '注文カードテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #68 生産の流れ（ホーム上部）の単位 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => { switchTab('td'); G.bq = []; rdistLight(); return [...document.querySelectorAll('#flow .fnode .fv')].map(e => e.textContent).concat([fmtL(prodFlows().newmake), fmtL(G.tank), G.lots.length + '/' + whSlots(), fmtN(G.bottles.reduce((a, r) => a + r.n, 0)) + '本', G.orders.length + '件']); });
    const got = r.slice(0, 5), exp = r.slice(5);
    rec(68, 'ホーム上部の流れ：生産L/時・タンクL・樽数/上限・瓶の本数・注文件数を単位つきで表示', got.join('|') === exp.join('|'), JSON.stringify({ got, exp }));
    await ctx.close();
  }
  // ---------- #69 v4.2 からの更新案内・金額の単位 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      const s = JSON.parse(JSON.stringify(G)); s.tut.done = { first: true }; s.tut.q = []; delete s.hs;
      const g = sanitize(s); const old = TUTS.u43.cond.call(null);
      const G0 = G; G = g; const condOld = TUTS.u43.cond(); G = G0;
      const fresh = defState(); G = fresh; fresh.tut.done.first = true; const condFresh = TUTS.u43.cond(); G = G0;
      const en = fmtEn(3.1e19), en2 = fmtEn(4.2e15), en3 = fmtEn(5e12);
      G.opt.money = 'ja'; const ja = fmt(3.1e19), ja2 = fmt(2.5e22); G.opt.money = 'en';
      return { condOld, condFresh, en, en2, en3, ja, ja2 };
    });
    rec(69, 'v4.2のセーブには変更点の案内を1回出し、新規には出さない', r.condOld === true && r.condFresh === false, JSON.stringify(r));
    rec(70, '大きな金額の単位（$31.00Qi・$4.20Qa・$5.00T／$3,100京・$250垓）', r.en === '$31.00Qi' && r.en2 === '$4.20Qa' && r.en3 === '$5.00T' && r.ja === '$3,100京' && r.ja2 === '$250垓', JSON.stringify(r));
    if (errors.length) rec('E26', '更新案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
