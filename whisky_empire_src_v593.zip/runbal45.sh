#!/bin/bash
# usage: runbal45.sh N DAYS TAPS
N=${1:-10}; D=${2:-100}; T=${3:-50}
mkdir -p /tmp/claude-0/b45
for i in $(seq 1 $N); do (node balance45.js $D $T > /tmp/claude-0/b45/raw_$i.txt 2>&1; grep -o '"day":[0-9.]*,"ev":"Tier[0-9]"' /tmp/claude-0/b45/raw_$i.txt | sed 's/"day":\([0-9.]*\),"ev":"\(Tier[0-9]\)"/\2=\1/' | tr '\n' ' '; tail -2 /tmp/claude-0/b45/raw_$i.txt | head -1 | cut -c1-200; echo) > /tmp/claude-0/b45/bal_$i.txt & done
wait
cat /tmp/claude-0/b45/bal_*.txt
