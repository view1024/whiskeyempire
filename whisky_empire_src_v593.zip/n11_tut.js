// ============================================================
// v4.1 ヒント帳とチュートリアル（改善計画 第6・7章）
// ============================================================
const TIPS=[
  {id:'line',    cat:'造る',   t:'生産ライン',   b:'製麦→糖化→発酵→蒸留の順に流れ、いちばん遅い工程（赤）が生産量を決めます。処理しきれない中間品は自動で外販されます。'},
  {id:'fac',     cat:'造る',   t:'設備',         b:'製麦室から順に解禁されます。Lv10で設備を2つから選べ、Tierを上げると上限Lvが上がります。'},
  {id:'tank',    cat:'造る',   t:'タンク',       b:'蒸留した新酒がたまります。満杯になると溢れた分は安く外販されます。自動樽詰めがONなら放置中も樽に詰めます。', f:'tank'},
  {id:'recipe',  cat:'造る',   t:'レシピ',       b:'原料・水・酵母・ピートで新酒の風味と工程の速さが変わります。変更後に詰めた樽から反映されます。', f:'recipe'},
  {id:'cellar',  cat:'寝かせる',t:'熟成',        b:'樽は実際の1日で1年熟成します（放置中も最大3日分）。小さい樽ほど速く熟成し、目減り（天使の分け前）も大きくなります。倉庫の樽は、上の色の帯が樽の種類、文字がサイズ（Q・B・H・Bt・P）、液面が詰めたときからの残量です。'},
  {id:'age',     cat:'寝かせる',t:'年数と日数', b:'棚の札はその樽の年数です。実際の1日でおよそ1年進みます。小さい樽、暑い創業地、担当の職人、砂時計で速く進むので、年数と詰めてからの日数は一致しません。節目（3・8・12・18・25年）に届くと札が12時間金色になり、その日最初の1樽で砂時計がもらえます。樽の小窓で、受けている注文の年数を「次の節目」に選ぶこともできます。3年未満の札は薄い色です。'},
  {id:'celflow', cat:'寝かせる',t:'寝かせるの流れ',b:'上から下へ流れます。造るから届いた新酒がタンクにたまる → 空き樽を仕入れて詰める（自動ONなら勝手に詰める） → ③ 倉庫の棚で寝かせる。自動で詰めている間は①②が1行にたたまれ、押すと開きます。'},
  {id:'fill',    cat:'寝かせる',t:'樽詰め',      b:'「空き樽を仕入れて詰める」で空き樽の種類とサイズを選びます。詰めるたびに空き樽の仕入れ値を払います。自動ONなら、タンクに樽1つ分たまるたびに詰めます。置ける樽の数は熟成庫のLvで増えます。', f:'tank'},
  {id:'agelabel',cat:'寝かせる',t:'年数の表記',  b:'複数の樽を混ぜて瓶詰めすると、年数は最も若い原酒に合わせます。'},
  {id:'star',    cat:'寝かせる',t:'★3銘柄・バーボン',b:'★3の銘柄は風味の一致が50%以上の原酒が必要です。バーボン銘柄はバーボン樽の原酒だけで詰められます。'},
  {id:'blend',   cat:'寝かせる',t:'ブレンド',    b:'最大4樽の原酒を混ぜ、目標の風味に近いほど高く売れます。使った原酒は減ります。', f:'blend'},
  {id:'order',   cat:'売る',   t:'注文',         b:'通常の注文は見送っても罰はありません。予約注文は単価が高めですが、受注後に期限を過ぎると評判が下がります。'},
  {id:'sellflow',cat:'売る',  t:'売るの流れ', b:'上から瓶詰め → 瓶の在庫 → 注文 の順に流れます。在庫に詰めた瓶は「瓶の在庫」へ、注文のために詰めた瓶は終わると自動で納品されます。注文のバーは用意できた本数（緑＝在庫、縞＝瓶詰め中）です。'},
  {id:'fillorder',cat:'売る',  t:'詰めて納品',   b:'条件に合う樽を若い順に使って瓶詰めし、終わると自動で納品します。古い樽は温存されます。'},
  {id:'bottle',  cat:'売る',   t:'瓶詰めの選び方',b:'★の付いた銘柄は、注文に足りない分です。注文に使うだけなら、注文の「詰めて納品」が最短です（終わると自動で納品）。使う原酒は既定で若い順（古い樽を温存）。年数表記はいちばん若い原酒に合わせ、品質と風味の一致で単価が変わります。'},
  {id:'btlmat',  cat:'売る',   t:'瓶の資材',     b:'瓶詰めを始めるときに、本数分の瓶・栓・ラベルの資材代を払います（Tier1で1本$8、Tierとともに上がる）。最初の1回だけは前のオーナーが残した瓶を使うので無料です。'},
  {id:'spot',    cat:'売る',   t:'自動直販',     b:'残す本数を超えた瓶を定価の80%で自動で売ります。注文ボードに載っている分は売りません。'},
  {id:'rel',     cat:'売る',   t:'取引先',       b:'納品するほど関係が深まり、★1つごとに単価が5%上がります。', f:'rel'},
  {id:'rep',     cat:'売る',   t:'評判',         b:'納品・受賞・ブレンドで上がり、時間とともに少しずつ下がります。高いほど単価が上がり、品評会に出られます。'},
  {id:'comp',    cat:'売る',   t:'品評会',       b:'瓶6本を出品し、3人の審査員が年数（12年で満点）・品質・風味を採点します。受賞した銘柄は単価がずっと上がります。', f:'comp'},
  {id:'tour',    cat:'成長',   t:'樽のタップと試飲会',b:'樽をタップすると試飲代が入ります。1回の額は「試飲代＋毎時の外販収入の0.2%」です。試飲代は Tier が上がるごとに4段、評判が10・25・50・100に届くごとに1段上がります（最大10段・1段で×1.5、強化のボタンはありません）。30回タップすると試飲会が開かれ、評判+1・次の注文が30分早まります（1日5回まで、0時に再開）。試飲会のたびに20%の確率で小人が来て、熟成の砂時計を1個置いていきます。'},
  {id:'tier',    cat:'成長',   t:'Tier昇格',     b:'出荷本数・評判・倉庫の樽などの条件をすべて満たすと昇格できます。樽と瓶の在庫は引き継ぎます。'},
  {id:'offline', cat:'成長',   t:'放置',         b:'閉じている間も、生産は24時間分、熟成は72時間分進みます。注文も届きます。戻ったときの報告は、閉じるを押すまで次の起動でも出し直します。'},
  {id:'homeicons',cat:'成長',  t:'ホームのアイコン',b:'章・デイリー・市場・Tier・砂時計は、ホームのアイコンから開きます。数字は達成数や残り日数、光っているのは新しい動きがあるものです。'},
  {id:'fin',     cat:'成長',   t:'決算書',       b:'実際の暦の1か月ごとに、損益計算書（PL）・貸借対照表（BS）・キャッシュフロー計算書（CF）をボックス図で見られます。在庫（大麦・新酒・樽の原酒・瓶）は原価（原材料・製造費・熟成費）で評価し、売れたときに売上原価になります。設備の購入・強化は資産に計上し、熟成庫はゲーム内の30年、ほかの設備は15年（実時間30日・15日）で均等に減価償却します。月が変わると前の月が確定し、税引前利益の30%の法人税が決まります。Tier3 からは BS の画面で借入ができます。図鑑の「決算書」から開けます。'},
  {id:'hourglass',cat:'成長',  t:'熟成の砂時計', b:'1個で1時間分をその場で進めます（生産・熟成・瓶詰め・注文の到着と期限が、閉じていた1時間と同じように進む）。99個まで持て、1日に24個まで使えます。「まとめて使う」で何個かを一度に使うと、その時間を1回で進めて報告します。手に入る機会：ログイン1（連続7日ごとに+3）、デイリー全達成3、節目の年数になった樽1（1日5樽まで）、納品3件ごとに1（1日4個まで）、樽の小人1（1日6個まで）、Tierの昇格5、再創業10。上限の99個のときに手に入った分は受け取れません。'},
  {id:'chapter', cat:'成長',   t:'章の目標',     b:'Tierごとに4つの目標があり、1つ達成するごとに資金、章を終えると評判が上がり物語が進みます。'},
  {id:'market',  cat:'売る',   t:'月替わりの市場',b:'実際の月ごとに市場の動きが変わります（例：12月は単価と注文の本数が上がる）。月末の5日間は翌月が予告されます。'},
  {id:'visitor', cat:'成長',   t:'見学ツアーの来客',b:'ホームの景色の左右に「見学させて！」の吹き出しが出ます。12秒以内にタップすると試飲代が入ります。まれに来るバイヤーは注文をくれます。'},
  {id:'finish',  cat:'寝かせる',t:'仕上げの樽',  b:'2年以上熟成した樽を別の種類の樽に移すと、その樽の風味が2年かけて加わります。1樽につき1回。バーボン樽以外に移すとバーボン銘柄には使えません。', f:'finish'},
  {id:'named',   cat:'寝かせる',t:'名樽',        b:'樽に名前を付けると、棚の札に★が付き、名前は樽の吹き出しや売るの一覧に出ます。Tier3から来るウイスキー愛好会は、名前のある樽を1.2倍で買い取ります。'},
  {id:'backup',  cat:'成長',   t:'セーブの保全', b:'この端末に6時間ごとに自動でバックアップします（最大3つ）。機種を変えるときは⚙️の「引き継ぎコード」を使ってください。'},
  {id:'prestige',cat:'成長',   t:'再創業', b:'Tier5 で資金がそろうと、図鑑の「創業地」から再創業できます。次の創業地が1つ開き、開いている地から選べます。収益ボーナスとスキルを得ます。', f:'prestige'},
];
function tipVisible(t){return !t.f||feat(t.f);}
function openTip(id){
  const t=TIPS.find(x=>x.id===id);if(!t)return;
  openModal(`<div class="mt">💡 ${escapeHtml(t.t)}</div><div class="tipb" style="margin-top:8px">${escapeHtml(t.b)}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px"><button type="button" class="btn-cancel" data-act="closeM">閉じる</button><button type="button" class="btn-ok" data-act="tipBook">ヒント帳</button></div>`,true);
}
function openTipBook(){
  const cats=['造る','寝かせる','売る','成長'];
  let h='<div class="mt">💡 ヒント帳</div><div class="ms">解放された機能のヒント</div>';
  cats.forEach(c=>{
    const ts=TIPS.filter(t=>t.cat===c&&tipVisible(t));if(!ts.length)return;
    h+=`<div class="tipcat">${c}</div>`+ts.map(t=>`<details class="tiprow"><summary class="tt" style="font-size:13px">${escapeHtml(t.t)}</summary><div class="tipb" style="margin-top:6px">${escapeHtml(t.b)}</div></details>`).join('');
  });
  const seen=Object.keys(TUTS).filter(id=>G.tut.done[id]);
  if(seen.length)h+='<div class="tipcat">案内をもう一度見る</div>'+seen.map(id=>`<div class="tiprow row sb" data-act="tutReplay" data-id="${id}"><span class="tt" style="font-size:13px">🎓 ${escapeHtml(TUTS[id].name)}</span><span class="sm">▶</span></div>`).join('');
  h+='<button type="button" class="btn-cancel" style="width:100%;margin-top:10px" data-act="closeM">閉じる</button>';
  openModal(h);
}

// ---------- チュートリアルの定義 ----------
// v5.0.1 版の変更の案内（upd・u43〜u50 など）はやめた。案内は機能が使えるようになったときの1回だけ。仕組みの説明は TIPS へ
function tutBase(){return !!(G.tut.done.first||G.tut.done.upd);}
const TUTS={
  // v4.4 案内はタブを自分で切り替えない。次のタブはナビを指し示し、プレイヤーが押したら続きを出す
  first:{name:'はじめての案内',steps:[
    {tab:'td',text:'ようこそ。蒸留所を引き継ぎました。<br>前のオーナーが遺した<b>樽3つ</b>と<b>大麦</b>があります。'},
    {tab:'td',sel:'#bb',do:true,tap:true,until:()=>(G.tt||0)>=3,text:'<b>樽を3回タップ</b>。試飲代が入ります。'},
    {tab:'td',sel:'#nav .nb[data-tab="tsale"]',do:true,nav:'tsale',until:()=>curTabId()==='tsale',text:'最初の注文が届いています。<b>「売る」</b>を押してください。'},
    {tab:'tsale',prep:()=>{_ui.sellTab='ord';},sel:'#orderBoard [data-act="ordFill"],#orderBoard [data-act="ordGo"]',do:true,instant:true,until:()=>G.stats.orders>=1,text:'<b>「詰めて納品」</b>で、樽から瓶詰めして届けます。'},
    {tab:'tsale',text:'納品できました！<br>ふだんは瓶詰めに時間がかかり、終わると自動で納品されます。'},
    {tab:'tsale',sel:'#nav .nb[data-tab="tb"]',do:true,nav:'tb',until:()=>curTabId()==='tb',text:'売上で設備を動かします。<b>「造る」</b>を押してください。'},
    {tab:'tb',sel:'#barleyBox',text:'製麦室は<b>大麦</b>から麦芽を作ります。大麦は自動で仕入れます。'},
    {tab:'tb',sel:'#fac_malting [data-act="facUp"]',do:true,until:()=>facLv('malting')>=1,text:'<b>製麦室を稼働</b>させましょう。'},
    {tab:'tb',sel:'#nav',text:'やることがあるタブには<b>数字</b>や<b>「!」</b>が付きます。'},
  ]},
  u_age:{name:'寝かせるの流れ',cond:()=>tutBase(),steps:[
    {tab:'tcel',sel:'#celTank',text:'上から下へ流れます。<b>タンクの新酒</b>は「造る」から届きます。'},
    {tab:'tcel',sel:'#fillBox',text:'<b>空き樽を仕入れて詰める</b>。自動ONなら勝手に詰めます。'},
    {tab:'tcel',sel:'#whSummary',text:'<b>倉庫で寝かせる</b>。札はその樽の年数です。樽を押すと様子が見られます。'}]},
  u_hg:{name:'熟成の砂時計',cond:()=>!!(G.hg&&G.hg.got>0),steps:[
    {tab:'td',sel:'#hi_hg',text:'<b>熟成の砂時計</b>。押すと1時間分を進めます。注文の期限も進みます。'}]},
  u_line:{name:'工程をつなぐ',cond:()=>isUL('mashing'),steps:[
    {tab:'tb',sel:'#fac_mashing',text:'<b>糖化槽</b>が買えます。工程がつながると後ろまで流れます。'}]},
  u_still:{name:'新酒の誕生',cond:()=>!!G.fac.distillation.p,steps:[
    {tab:'tb',sel:'#tankBox',text:'<b>新酒</b>が生まれ、タンクから自動で樽に詰められます。'}]},
  u_tank:{name:'タンクが満杯に近い',cond:()=>feat('tank')&&prodFlows().newmake>0&&(G.tank||0)>=tankCap()*0.8,steps:[
    {tab:'tcel',sel:'#whSummary',text:'タンクが満杯に近づいています。倉庫は<b>熟成庫</b>の強化で広がります。'}]},
  u_wh:{name:'熟成庫',cond:()=>!!G.fac.maturation.p,steps:[
    {tab:'tcel',sel:'#fac_maturation',text:'<b>熟成庫</b>はここで強化します。置ける樽が増えます。'}]},
  u_bot:{name:'ボトリング',cond:()=>!!G.fac.bottling.p,steps:[
    {tab:'tsale',prep:()=>{_ui.sellTab='ord';},sel:'#fac_bottling',text:'<b>ボトリング</b>はここで強化します。瓶詰めが速くなります。'}]},
  u_recipe:{name:'レシピ',cond:()=>feat('recipe'),steps:[
    {tab:'tb',sel:'#btnRecipe',text:'<b>レシピ</b>を選べます。原料で風味と工程の速さが変わります。'}]},
  u_branch:{name:'設備の2択',cond:()=>FD.some(f=>brPending(f.id)),steps:[
    {tab:'tb',sel:'.pst [data-act="brOpen"]',text:'Lv10です。<b>設備を2つから選べます</b>（あとで変更可）。'}]},
  u_t2:{name:'Tier2',cond:()=>(G.dl||1)>=2,steps:[
    {tab:'tsale',prep:()=>{_ui.sellTab='ord';},sel:'#sellChips',text:'<b>取引先・品評会</b>はここで切り替えます。瓶の在庫は在庫の行を押すと内訳が開きます。'},
    {tab:'tsale',sel:'#orderBoard',text:'<b>予約注文</b>は単価が高め。受けたら期限を守りましょう。'}]},
  u_comp:{name:'品評会',cond:()=>feat('comp'),steps:[
    {tab:'tsale',prep:()=>{_ui.sellTab='comp';},sel:'#compList',text:'<b>品評会</b>で受賞すると、その銘柄の単価がずっと上がります。'}]},
  u_t3:{name:'ブレンド',cond:()=>(G.dl||1)>=3,steps:[
    {tab:'tcel',sel:'#btnBlend',text:'<b>ブレンド</b>で複数の樽を混ぜ、目標の風味に近づけます。'}]},
  u_12y:{name:'12年もの',cond:()=>(G.stats.maxAge||0)>=12,steps:[
    {tab:'tcel',sel:'#whSummary',text:'<b>12年もの</b>が生まれました。長期熟成の樽は高く売れます。'}]},
  u_chap:{name:'章の目標',cond:()=>tutBase(),steps:[
    {tab:'td',sel:'#hi_chap',text:'<b>章の目標</b>はここから。達成ごとに報酬があります。'}]},
  u_finish:{name:'仕上げと名樽',cond:()=>feat('finish')&&G.lots.some(l=>l.age>=2),steps:[
    {tab:'tcel',sel:'#whSummary',text:'樽の［詳細］から<b>仕上げ</b>と<b>名前を付ける</b>ができます。'}]},
  u_prestige:{name:'プレステージ',cond:()=>typeof canPrestige==='function'&&canPrestige(),steps:[
    {tab:'te',prep:()=>{_ui.encTab='g';},sel:'#prestigePanel',text:'<b>再創業</b>で、次の創業地に新しい蒸留所を開けます。'}]},
};
let _tut=null;
let _tutPoll=null;

function tutCanShow(){
  if(!_titleDone||_celebOn)return false;
  if(_offlineGate)return false;
  const mo=$('mo');if(mo&&!mo.classList.contains('h'))return false;
  const cf=$('confirmDlg');if(cf&&cf.classList.contains('on'))return false;
  return !document.hidden;
}
function curTabId(){const c=document.querySelector('.tab.on');return c?c.id:'td';}
// 案内待ちのタブ（ナビに「新」を付ける）
function tutWaitingTabs(){
  const o={};if(!G.tut||_tut)return o;
  G.tut.q.forEach(id=>{const d=TUTS[id];if(!d||G.tut.done[id]||id==='first')return;const tb=d.steps[0].tab;if(tb!==curTabId())o[tb]=true;});
  return o;
}
function tutCheck(){
  if(!G.tut)return;
  const t=G.tut;
  if(t.seed){Object.keys(TUTS).forEach(id=>{const d=TUTS[id];if(d.cond&&d.cond())t.done[id]=true;});t.seed=false;save();}
  // v5.0.1 版の案内 upd は廃止。待っていた人（v4.0 以前からの移行）は見終えた扱いにする
  if(t.q.includes('upd')){t.done.upd=true;t.q=t.q.filter(x=>x!=='upd');}
  Object.keys(TUTS).forEach(id=>{const d=TUTS[id];if(d.cond&&!t.done[id]&&!t.q.includes(id)&&d.cond())t.q.push(id);});
  t.q=t.q.filter(id=>TUTS[id]&&!t.done[id]);
  try{updNavBadges();}catch(e){}
  if(!_tut&&t.q.length&&tutCanShow()){
    // 今開いているタブの案内だけを始める（タブを勝手に切り替えない）。はじめての案内だけは最優先
    const cur=curTabId();
    const id=t.q.includes('first')?'first':t.q.find(x=>TUTS[x].steps[0].tab===cur);
    if(id)tutStart(id,false);
  }
}
function tutStart(id,replay){
  if(!TUTS[id])return;
  if(_tut)tutHide();
  closeM();
  _tut={id,i:0,replay:!!replay,miss:0};
  tutShow();
  clearInterval(_tutPoll);
  _tutPoll=setInterval(tutPoll,350);
}
function tutStep(){return _tut&&TUTS[_tut.id].steps[_tut.i];}
function tutEl(st){
  if(!st||!st.sel)return null;
  if(typeof st.sel==='function')return st.sel();
  const list=document.querySelectorAll(st.sel);
  for(const el of list){if(el.offsetParent!==null)return el;}
  return null;
}
function tutShow(){
  const st=tutStep();if(!st){tutEnd(true);return;}
  if(st.prep)st.prep();
  const cur=document.querySelector('.tab.on');
  // 案内がタブを切り替えるのは、ヒント帳から「もう一度見る」を選んだときだけ
  if((!cur||cur.id!==st.tab)&&(_tut.replay||_tut.i===0&&_tut.id==='first'))switchTab(st.tab);else rall();
  const el=tutEl(st);
  if(el&&el.scrollIntoView)el.scrollIntoView({block:'center'});
  $('cTxt').innerHTML=st.text;
  const n=TUTS[_tut.id].steps.length;
  setText('cStep',n>1?(_tut.i+1)+' / '+n:'');
  const nb=$('cNext');
  nb.style.visibility=(st.do&&!_tut.replay)?'hidden':'visible';
  nb.textContent=_tut.i+1>=n?'はじめる':'次へ';
  $('coach').classList.remove('h');document.body.classList.add('coaching');
  _tut.shownAt=Date.now();
  tutPlace();
}
function tutPlace(){
  const st=tutStep();if(!st)return;
  const hole=$('cHole'),bub=$('cBub');
  const el=tutEl(st);
  const H=window.innerHeight;
  if(!el){
    hole.className='c-hole none';hole.style.cssText='';
    bub.style.top='34%';bub.style.bottom='';
    return;
  }
  const r=el.getBoundingClientRect();const p=6;
  const top=Math.max(4,r.top-p),bot=Math.min(H-4,r.bottom+p);
  hole.className='c-hole';
  hole.style.left=(r.left-p)+'px';hole.style.top=top+'px';hole.style.width=(r.width+p*2)+'px';hole.style.height=Math.max(10,bot-top)+'px';
  if((top+bot)/2<H*0.5){bub.style.top=Math.min(H-150,bot+12)+'px';bub.style.bottom='';}
  else{bub.style.bottom=Math.min(H-150,H-top+12)+'px';bub.style.top='';}
}
function tutPoll(){
  if(!_tut){clearInterval(_tutPoll);return;}
  const co=$('coach');
  const st=tutStep();
  const blocked=!tutCanShow();
  co.classList.toggle('h',blocked);
  if(blocked)return;
  if(st&&st.do&&st.until&&st.until()){tutAdvanceFrom(_tut.i);return;}
  if(st&&st.sel&&!tutEl(st)){
    if(Date.now()-(_tut.shownAt||0)>1500){tutAdvanceFrom(_tut.i);return;}
  }
  tutPlace();
}
function tutNext(){
  if(!_tut)return;
  _tut.i++;
  if(_tut.i>=TUTS[_tut.id].steps.length){tutEnd(true);return;}
  tutShow();
}
function tutAdvanceFrom(i){if(_tut&&_tut.i===i)tutNext();}
function tutHide(){$('coach').classList.add('h');document.body.classList.remove('coaching');clearInterval(_tutPoll);}
function tutEnd(completed){
  if(!_tut)return;
  const id=_tut.id,replay=_tut.replay;
  _tut=null;tutHide();
  G.tut.done[id]=true;
  if(id==='u43'&&G.hs)G.hs.new43=1;
  if(id==='u44'&&G.hs)G.hs.new44=1;
  if((id==='u45'||id==='u_cel45')&&G.hs&&G.tut.done.u45&&G.tut.done.u_cel45)G.hs.new45=1;
  if(id==='u46'&&G.hs)G.hs.new46=1;
  if(id==='first'&&completed){G.tut.done.u_barley=true;G.tut.done.u44=true;G.tut.done.u_line43=true;G.tut.done.u45=true;G.tut.done.u_cel45=true;G.tut.done.u46=true;if(G.hs){G.hs.new44=1;G.hs.new43=1;G.hs.new45=1;G.hs.new46=1;}}
  G.tut.q=G.tut.q.filter(x=>x!==id);
  if(id==='first'&&completed&&!replay&&!G.tut.rewarded){
    G.tut.rewarded=true;acRev('oth',BALANCE.TUT_REWARD);G.cash+=BALANCE.TUT_REWARD;sndQuest();toast('🎓 案内を完了しました +'+fmt(BALANCE.TUT_REWARD),3000);
  }
  if(id==='first'){generateDailyMissions();}
  save();rall();
}
// コーチマーク表示中のタップ：対象の内側なら対象を押す、読むだけの手順なら次へ
function tutClick(e){
  if(!_tut)return;
  if(e.target.closest('#cBub'))return;
  e.preventDefault();e.stopPropagation();
  const st=tutStep();
  if(st&&st.do){
    const el=tutEl(st);if(!el)return;
    const r=el.getBoundingClientRect();
    if(e.clientX>=r.left-6&&e.clientX<=r.right+6&&e.clientY>=r.top-6&&e.clientY<=r.bottom+6){
      const i0=_tut.i;if(st.tap)tap(e);else el.click();
      setTimeout(()=>{if(_tut&&st.until&&st.until())tutAdvanceFrom(i0);},250);
    }
    return;
  }
  if(Date.now()-(_tut.shownAt||0)>300)tutNext();
}
