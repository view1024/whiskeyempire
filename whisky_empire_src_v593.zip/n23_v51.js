// ============================================================
// v5.1 売り方（3年以上の樽はいつでも外販）・倉庫と注文をつなぐ
// ============================================================
// 実装計画：https://claude.ai/code/artifact/1e31d814-c84b-4728-bbb2-2d88bf23f09a（施策3）
//  - 3年未満の樽は売れない（樽ごと売る・瓶詰めとも。瓶詰めは銘柄の年数が3年以上なので、もともと同じ条件）
//  - 棚の樽を押すと、注文に使う（使えるときだけ先頭）・瓶詰めして在庫へ・瓶詰めして瓶で売る・樽ごと売る を金額つきで並べる
//  - 瓶詰めは樽1つを丸ごと。銘柄は詰められるもののうち単価が一番高いもの（「変える」で瓶詰めの小窓）
//  - 確認は、名前付き・次の Tier の条件に要る・受けた予約注文に使える樽のときだけ

// ---------- 年数と金額 ----------
function lotEtaAge(l,age){if(l.age>=age)return 0;const r=agingRate(l);return r>0?(age-l.age)/r*BALANCE.GAME_YEAR_MS:Infinity;}
function lotSellable(l){return !!l&&l.age>=V51.SELL_AGE;}
function lotBottles(l){return Math.floor(l.L/BALANCE.BOTTLE_L+1e-9);}
// 取引先の単価の倍率のうち一番高いもの（樽の注文だけの取引先は除く）
function custMaxPm(){let m=1;custAvailable().forEach(c=>{if(Array.isArray(c.priceMult)||c.limited)return;m=Math.max(m,(Number(c.priceMult)||1)*(1+BALANCE.REL_PRICE_STEP*relLv(c.id)));});return m;}
// 樽1つを丸ごと瓶詰めする計画（銘柄は単価が一番高いもの）
function lotBotPlan(l,pid){
  const n=lotBottles(l);if(!lotSellable(l)||n<=0)return null;
  const pids=pid?[pid]:lotProducts(l);let best=null;
  pids.forEach(p=>{const pv=botPreview(p,n,'manual',[l.id],0);if(pv.ok&&(!best||pv.unit>best.unit))best=pv;});
  // v5.3 25銘柄に詰められないときだけハウスモルト
  if(!best&&!pid){const pv=botPreview(V53.HOUSE,n,'manual',[l.id],0);if(pv.ok)best=pv;}
  if(!best)return null;
  const mat=btlMatCost(best.n);const mc=mat.free?0:mat.cost;
  return {pid:best.pid,n:best.n,unit:best.unit,hours:best.hours,mat,stockMax:best.unit*best.n*custMaxPm()-mc,spotNet:best.unit*BALANCE.SPOT_MULT*best.n-mc};
}
// この樽で用意できる注文（足りない分をこの樽だけで詰められるもの・樽の注文）。報酬の高い順
function lotOrdPlans(l){
  if(!lotSellable(l))return [];
  const out=[];
  G.orders.forEach(o=>{
    if(!ordUsable(o)||ordInProgress(o))return;
    if(o.kind==='cask'){if(l.age>=o.minAge){const m=ordMatch(o,l.id);if(m.ok)out.push({o,kind:'cask',val:m.cash});}return;}
    if(o.kind!=='product'&&o.kind!=='type')return;
    const m=ordMatch(o);const need=Math.max(0,o.qty-m.have);if(need<=0||lotBottles(l)<need)return;
    const pids=o.kind==='product'?[o.pid]:G.uw.filter(id=>{const sp=productSpec(id);return sp&&!sp.blend&&sp.tp===o.tp;});
    const c=custById(o.cid);const pm=c.priceMult*(1+BALANCE.REL_PRICE_STEP*relLv(o.cid))*o.mult;
    let best=null;
    pids.forEach(pid=>{const sp=productSpec(pid);if(!sp||!lotEligible(l,sp))return;const minAge=Math.max(o.minAge||0,sp.minAge||0);if(l.age<minAge)return;
      const pv=botPreview(pid,need,'manual',[l.id],minAge);if(pv.ok&&(!best||pv.unit>best.pv.unit))best={pid,minAge,pv};});
    if(best)out.push({o,kind:'bot',pid:best.pid,minAge:best.minAge,need,val:m.cash+best.pv.unit*need*pm});
  });
  return out.sort((a,b)=>b.val-a.val);
}
function lotServes(l,o){return lotOrdPlans(l).some(p=>p.o.id===o.id);}
// 注文が変わったかを見る署名
function ordSig(){return G.orders.map(o=>o.id+(o.accepted?'a':'')+(ordInProgress(o)?'p':'')+(o.kind==='product'||o.kind==='type'?(ordMatch(o).ok?'r':''):'')).join(',')+'|'+G.uw.length;}
// 確認が要る理由（なければ ''）
function lotSellWarn(l,oid){
  if(l.name)return '名前の付いた樽です';
  const r=DL_REQ[G.dl];
  if(r&&r.casks&&l.age>=r.casks.age&&G.lots.filter(x=>x.age>=r.casks.age).length<=r.casks.n)return 'Tier'+(G.dl+1)+'の条件（'+r.casks.age+'年以上の樽 '+r.casks.n+'つ）に要る樽です';
  if(G.orders.some(o=>o.reserve&&o.accepted&&o.id!==oid&&lotServes(l,o)))return '受けた予約注文に使える樽です';
  return '';
}

// ---------- 瓶で売る：詰め終わった分をその場で直販（botTick から） ----------
function bqSellNow(q,k){
  const qq=Math.round(q.q/BALANCE.INV_Q_STEP)*BALANCE.INV_Q_STEP;
  const unit=priceUnit(q.pid,q.age,qq,q.fl);const v=unit*BALANCE.SPOT_MULT*k;
  recordUnit(unit);earn(v,'spot');shipCount(q.pid,k,q.age);q.sold=(q.sold||0)+v;fxSale(v,false,null);
  return v;
}

// ---------- 売り方の実行 ----------
function lotRoute(id,r,oid){
  const l=G.lots.find(x=>x.id===id);if(!l)return false;
  if(!lotSellable(l)){toast(V51.SELL_AGE+'年で売れます（あと'+fmtRemain(lotEtaAge(l,V51.SELL_AGE))+'）',2500);return false;}
  let ok=false;
  if(r==='cask'){ok=sellLot(id)>0;}
  else if(r==='ord'){
    const p=lotOrdPlans(l).find(x=>x.o.id===oid);if(!p){toast('この樽では用意できません',2200);return false;}
    if(p.kind==='cask')ok=ordDeliver(p.o.id,l.id);
    else{ok=botStart(p.pid,p.need,'manual',[l.id],{oid:p.o.id,minAge:p.minAge,quiet:true});if(ok){p.o.autoDel=true;toast('🍾 '+custById(p.o.cid).name+'の注文のために瓶詰め。終わると自動で納品します',3000);}}
    if(ok&&_hl&&_hl.oid===oid)hlEnd();
  }else if(r==='stock'||r==='spot'){
    const pl=lotBotPlan(l,_ui.lotPid&&_ui.lotPid.id===id?_ui.lotPid.pid:null);if(!pl){toast('この樽で詰められる銘柄がありません',2500);return false;}
    ok=botStart(pl.pid,pl.n,'manual',[l.id],{sell:r==='spot',quiet:true});
    if(ok)toast(r==='spot'?'🍾 瓶詰めして、詰め終わった分から直販します（'+pl.n+'本）':'🍾 瓶詰めして在庫へ（'+productSpec(pl.pid).name+' '+pl.n+'本）',2800);
  }
  if(ok){_ui.lotPid=null;bubClose();save();rall();}
  return ok;
}
function lotRouteAsk(id,r,oid){
  const l=G.lots.find(x=>x.id===id);if(!l)return;
  const why=lotSellWarn(l,r==='ord'?oid:null);
  if(!why){lotRoute(id,r,oid);return;}
  const lbl={ord:'注文に使う',stock:'瓶詰めして在庫へ',spot:'瓶詰めして瓶で売る',cask:'樽ごと売る'}[r]||'売る';
  showConfirm({title:lbl,msg:`${escapeHtml(lotShort(l))} ${fmtAge(l.age)}<br>${escapeHtml(why)}。${escapeHtml(lbl)}と、この樽はなくなります。`,icon:'🛢️',danger:true,yesLabel:lbl,onYes:()=>{lotRoute(id,r,oid);closeM();}});
}

// ---------- 吹き出しの売り方 ----------
function lotSellHtml(l){
  if(!lotSellable(l))return `<div class="wsr0">${V51.SELL_AGE}年で売れます（あと${fmtRemain(lotEtaAge(l,V51.SELL_AGE))}）</div>`+nextBrandHtml(l);
  const plans=lotOrdPlans(l);const pref=_hl?plans.find(p=>p.o.id===_hl.oid):null;const op=pref||plans[0];
  const pl=lotBotPlan(l,_ui.lotPid&&_ui.lotPid.id===l.id?_ui.lotPid.pid:null);
  const btn=(r,t,sub,cls,oid)=>`<button type="button" class="wsb${cls?' '+cls:''}" data-act="lotRoute" data-id="${l.id}" data-r="${r}"${oid?` data-oid="${oid}"`:''}><b>${t}</b><span>${sub}</span></button>`;
  let h='<div class="wsr">';
  if(op)h+=btn('ord','注文に使う',escapeHtml(custById(op.o.cid).name)+' ・ '+(op.kind==='cask'?'':'約')+fmt(op.val),'ord',op.o.id);
  if(pl&&isHouse(pl.pid)){
    // v5.3 25銘柄にまだ詰められない樽：ハウスモルトとして瓶詰め（注文には使えない）
    h+=btn('stock','ハウスモルトとして瓶詰め',fmtN(pl.n)+'本を在庫へ ・ 約'+fmtShort(pl.hours*3600000));
    h+=btn('spot','ハウスモルトにして瓶で売る','直販 '+fmt(pl.spotNet));
  }else if(pl){
    h+=btn('stock','瓶詰めして在庫へ',escapeHtml(productSpec(pl.pid).name)+' '+fmtN(pl.n)+'本 ・ 注文なら最大'+fmt(pl.stockMax)+' ・ 約'+fmtShort(pl.hours*3600000),op?'':'top');
    h+=btn('spot','瓶詰めして瓶で売る','直販 '+fmt(pl.spotNet));
  }
  h+=btn('cask','樽ごと売る','すぐ '+fmt(lotValue(l)*BALANCE.CASK_SPOT_MULT));
  return h+'</div>'+nextBrandHtml(l);
}
// 吹き出しの下のボタン列に足す「銘柄を変える」
function lotPidBtn(l){return lotSellable(l)&&lotProductsH(l).length>1?`<button type="button" class="sb2 gh" data-act="lotPid" data-id="${l.id}">銘柄を変える</button>`:'';
}

// ---------- 注文に使える樽を光らせる（注文 → 倉庫） ----------
let _hl=null;
function hlStart(oid){
  const o=G.orders.find(x=>x.id===oid);if(!o)return false;
  const ids=G.lots.filter(l=>lotServes(l,o)).map(l=>l.id);
  if(!ids.length){toast('この注文に使える樽はありません',2200);return false;}
  _hl={oid,ids};closeM();document.body.classList.add('hlon');switchTab('tcel');rCellar();hlBar();
  setTimeout(()=>{const c=document.querySelector(`#wScene .wcask[data-id="${ids[0]}"]`);if(c)try{c.scrollIntoView({block:'center'});}catch(e){}},50);
  return true;
}
function hlEnd(){_hl=null;document.body.classList.remove('hlon');const b=$('hlBar');if(b)b.remove();try{rCellar();}catch(e){}}
function hlBar(){
  if(!_hl)return;const o=G.orders.find(x=>x.id===_hl.oid);if(!o){hlEnd();return;}
  let b=$('hlBar');if(!b){b=document.createElement('div');b.id='hlBar';b.className='pmbar';b.setAttribute('role','status');document.body.appendChild(b);}
  const h=`<span class="pmt">🧾 <b>${escapeHtml(custById(o.cid).name)}</b>の注文に使える樽 ${_hl.ids.length}樽<small>光っている樽を押してください</small></span><button type="button" class="sb2" data-act="hlEnd">やめる</button>`;
  if(b._h!==h){b.innerHTML=h;b._h=h;}
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&_hl)hlEnd();});

// ---------- 売れる樽の一覧（倉庫 → 売る） ----------
function sellableLots(){return G.lots.filter(lotSellable).sort((a,b)=>lotValue(b)-lotValue(a));}
function openSellList(){
  const L=sellableLots();
  openModal(`<div class="mt">💰 売れる樽（${V51.SELL_AGE}年以上）${ib('sellhow')}</div><div class="ms">${L.length}樽 ・ 樽ごとの金額の高い順。押すと棚の樽へ</div>`+
    (L.length?L.slice(0,40).map(l=>`<button type="button" class="card slr" data-act="sellPick" data-id="${l.id}"><span class="tt" style="font-size:13px">${l.name?'★':''}${escapeHtml(lotShort(l))} ${fmtAge(l.age)}</span><span class="vv">${fmt(lotValue(l)*BALANCE.CASK_SPOT_MULT)}</span></button>`).join(''):'<div class="sm tc" style="padding:12px">まだありません</div>')+
    `<button type="button" class="cb" data-act="closeM">閉じる</button>`);
}
function sellPick(id){
  closeM();switchTab('tcel');rCellar();
  setTimeout(()=>{const c=document.querySelector(`#wScene .wcask[data-id="${id}"]`);if(!c)return;try{c.scrollIntoView({block:'center'});}catch(e){}caskKnock(id,c);},60);
}
// 寝かせるの見出しの下（売れる樽の数。v5.5 年数の条件は一覧の見出しに）
function whSellRowHtml(){const n=G.lots.filter(lotSellable).length;return n?`<button type="button" class="sb2 gh wsellb" data-act="sellList">💰 売れる樽 ${n} ›</button>`:'';}
// 注文カード：倉庫の樽で詰められる数
function ordLotCount(o){if(!ordUsable(o)||ordInProgress(o)||(o.kind!=='product'&&o.kind!=='type'))return 0;return G.lots.filter(l=>lotServes(l,o)).length;}

// ---------- data-act ----------
function extAct51(act,b,id){
  switch(act){
    case 'lotRoute': lotRouteAsk(id,b.dataset.r,b.dataset.oid||null); return true;
    case 'lotPid': {const l=G.lots.find(x=>x.id===id);if(!l)return true;bubClose();const pl=lotBotPlan(l);_ui.bot={pid:pl?pl.pid:null,n:lotBottles(l),mode:'manual',sel:[l.id],minAge:0};renderBottleModal(false);return true;}
    case 'ordLots': hlStart(id); return true;
    case 'hlEnd': hlEnd(); return true;
    case 'sellList': openSellList(); return true;
    case 'sellPick': sellPick(id); return true;
  }
  if(typeof extAct52==='function'&&extAct52(act,b,id))return true;
  if(typeof extAct53==='function'&&extAct53(act,b,id))return true;
  if(typeof extAct55==='function'&&extAct55(act,b,id))return true;
  if(typeof extAct57==='function'&&extAct57(act,b,id))return true;
  if(typeof extAct59==='function'&&extAct59(act,b,id))return true;
  return false;
}
function v51Tick(){try{if(_hl)hlBar();}catch(e){console.warn('v51Tick',e);}try{idleChipsUpd();seatTipTick();}catch(e){console.warn('v59',e);}}

TIPS.push({id:'sellhow',cat:'売る',t:'売り方の比べ方',b:'3年以上の樽は棚から売れます。瓶詰めして在庫へ：後から来る注文や自動直販に回ります（金額は一番高い取引先の注文に使った場合の上限）。瓶詰めして瓶で売る：詰め終わった分から定価の80%で直販します（自動直販の設定に関係なく）。樽ごと売る：瓶詰めの時間と瓶の資材代がかからず、すぐ現金になります。金額は、その樽で詰められる一番高い銘柄を直販した額の55%です。瓶詰めの2つは瓶の資材代を引いた額です。樽の価値は年数にほぼ比例するので、長く寝かせるほど高く売れます。'});
TIPS.push({id:'grade',cat:'造る',t:'大麦の相場',b:'大麦の価格は月ごとの市場で上下します（大麦の行に「今月高い」「今月安い」）。安い月にサイロを満タンにしておくと原料費を抑えられます。'});
TIPS.push({id:'raw',cat:'成長',t:'原材料と原価率',b:'大麦・空き樽・瓶の資材の価格は、Tier1 は据え置き、Tier2 から売値の倍率（Tier・再創業）に合わせて上がり、Tier3 以降で売上のおよそ1割になります。決算書の損益計算書に「うち原材料費（売上の◯%）」として出ます。所持金が大麦1時間分を下回ると造るタブに警告が出ます（買える分だけ仕入れて生産は続きます）。'});
