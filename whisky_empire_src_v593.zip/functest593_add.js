  // ================= v5.9.3 追加テスト =================
  // ---------- #181 小人を設備に置いても、ほかの担当のいない設備の「＋」は消えない（v5.9.3） ----------
  try {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {}; G.staff = []; G.ownerAt = null; placeInvalidate();
      const facs = V50.FACS.filter(f => placeOk({ k: 'fac', id: f }));
      switchTab('tb'); rall(); _ui.sellTab = 'ord'; rShip(); await new Promise(r => setTimeout(r, 40));
      const seatsOf = () => facs.filter(f => !!document.querySelector('#fac_' + f + ' .wseat'));
      o.before = seatsOf().length;
      // あなたを製麦室に置く（待機は0人）
      placeSet(OWNER, { k: 'fac', id: 'malting' }); placeInvalidate(); switchTab('tb'); rall(); _ui.sellTab = 'ord'; rShip(); await new Promise(r => setTimeout(r, 40));
      o.after = seatsOf(); o.idle = idleList().length;
      o.malting = !document.querySelector('#fac_malting .wseat');
      // 残りの「＋」を押すと、あなた（今は製麦室）を選べる → 選ぶと移る
      document.querySelector('#fac_mashing .wseat').click(); await new Promise(r => setTimeout(r, 40));
      const b = document.querySelector('#mo [data-act="placeSet"][data-sid="owner"]'); o.pick = !!b && b.textContent.includes('今は'); b.click(); await new Promise(r => setTimeout(r, 40));
      o.moved = placeKey(G.ownerAt) === 'fac:mashing'; switchTab('tb'); rall(); rShip(); await new Promise(r => setTimeout(r, 40));
      o.after2 = seatsOf();
      return o;
    });
    const ok = r.before === 5 && r.idle === 0 && r.malting && r.after.length === r.before - 1 && r.pick && r.moved && r.after2.length === r.before - 1 && r.after2.includes('malting') && !r.after2.includes('mashing');
    rec(181, '小人の空き席（v5.9.3）：あなたを設備に置いて待機が0人になっても、ほかの担当のいない設備（売るのボトリングを含む）の「＋」は消えない・「＋」から働いている人（今は…）を選ぶと移り、元の設備に「＋」が戻る', ok, JSON.stringify(r));
    if (errors.length) rec('E126', '空き席（v5.9.3）のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C181', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
