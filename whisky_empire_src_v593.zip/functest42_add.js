  // ================= v4.2 追加テスト =================
  // ---------- 表示の基準（P1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      const out = { small: [], tiny: [], chars: [] };
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 200));
        const el = document.getElementById(t);
        el.querySelectorAll('button,[data-act],select,input,summary').forEach(b => {
          if (b.getClientRects().length === 0) return;
          const r = b.getBoundingClientRect();
          if (b.classList.contains('ib') || b.classList.contains('visitor')) return; // ⓘは疑似要素で44px、来客は動きのある要素（56px）
          if (r.height < 43.5 || (r.width < 43.5 && b.tagName !== 'INPUT')) out.small.push(t + ':' + (b.dataset.act || b.tagName) + ':' + Math.round(r.width) + 'x' + Math.round(r.height));
        });
        const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n, chars = 0;
        while (n = w.nextNode()) { const p = n.parentElement; if (!p || p.getClientRects().length === 0 || !n.textContent.trim()) continue; const fs = parseFloat(getComputedStyle(p).fontSize); if (fs < 12) out.tiny.push(t + ':' + fs + ':' + n.textContent.trim().slice(0, 10)); chars += n.textContent.replace(/\s/g, '').length; }
        out.chars.push(t + ':' + chars);
      }
      const sm = parseFloat(getComputedStyle(document.querySelector('#td .sm')).fontSize);
      const L = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
      const muted = getComputedStyle(document.documentElement).getPropertyValue('--muted').trim();
      const cr = (L(muted) + 0.05) / (L('#241c13') + 0.05);
      const chrome = ['hdr', 'ticker', 'nav'].map(id => document.getElementById(id).getBoundingClientRect().height);
      return { ...out, sm, cr: +cr.toFixed(2), chrome };
    });
    rec(42, '押す対象がすべて44px以上・文字は12px以上（本文14px）・補足色のコントラスト4.5以上', r.small.length === 0 && r.tiny.length === 0 && r.sm >= 14 && r.cr >= 4.5, JSON.stringify({ small: r.small.slice(0, 8), tiny: r.tiny.slice(0, 8), sm: r.sm, cr: r.cr, chrome: r.chrome, chars: r.chars }));
    if (errors.length) rec('E11', '表示基準テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- タイトル・TIPS帯・樽・設定（P1） ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 740 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1500);
    const t0 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id, note: document.querySelector('.t-note').textContent.includes('20歳未満'), se: G.opt.se, bgm: G.opt.bgm }));
    await page.click('#titleBtns .btn-ok'); await page.waitForTimeout(900);
    const t1 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id }));
    rec(43, '起動時にタイトルと注意書き（音なしが既定）→ 閉じると初回案内が始まる', t0.title && !t0.tut && t0.note && t0.se === 0 && t0.bgm === 0 && !t1.title && t1.tut === 'first', JSON.stringify({ t0, t1 }));
    const tk = await page.evaluate(() => {
      const seq = []; _tk.hist = []; _tk.sinceHealth = 0;
      for (let i = 0; i < 120; i++) seq.push(tkPick());
      let maxGap = 0, gap = 0; seq.forEach(m => { if (m.cat === 'health') gap = 0; else { gap++; maxGap = Math.max(maxGap, gap); } });
      const locked = seq.filter(m => m.cat === 'tips' && m.f && !feat(m.f)).length;
      const srcOk = TICKER_MSGS.filter(m => m.cat === 'trivia' && m.src !== 'idea').every(m => SRC[m.src]);
      const bar = document.getElementById('ticker').getBoundingClientRect();
      return { maxGap, locked, srcOk, barTop: Math.round(bar.top), hdrBottom: Math.round(document.getElementById('hdr').getBoundingClientRect().bottom), n: TICKER_MSGS.length, triv: TICKER_MSGS.filter(m => m.cat === 'trivia').length, health: TICKER_MSGS.filter(m => m.cat === 'health').length, wrong: TICKER_MSGS.some(m => /京都・山崎|コンボ|プロフタブ/.test(m.text)) };
    });
    await page.evaluate(() => { if (_tut) { tutEnd(false); } });
    await page.waitForTimeout(200);
    await page.click('#ticker'); await page.waitForTimeout(300);
    const modal = await page.evaluate(() => ({ open: !document.getElementById('mo').classList.contains('h'), paused: _tk.paused, txt: document.getElementById('mc2').textContent }));
    rec(44, 'TIPS帯：ヘッダー直下に常設・健康は6件に1件以上・未解放のTIPSは出ない・豆知識は全件出典つき・誤記修正・タップで全文と出典', tk.barTop === tk.hdrBottom && tk.maxGap <= 5 && tk.locked === 0 && tk.srcOk && !tk.wrong && modal.open && modal.paused && (modal.txt.includes('出典') || modal.txt.includes('提案') || modal.txt.length > 5), JSON.stringify({ tk, modal: { open: modal.open, paused: modal.paused } }));
    await page.evaluate(() => closeM());
    const bb = await page.evaluate(() => { switchTab('td'); const r = document.getElementById('bb').getBoundingClientRect(); return { w: Math.round(r.width), cx: Math.round(r.left + r.width / 2), vw: window.innerWidth }; });
    rec(45, '樽画像を画面中央に大きく（幅200px以上・中心が画面中央±10px）', bb.w >= 200 && Math.abs(bb.cx - bb.vw / 2) <= 10, JSON.stringify(bb));
    const op = await page.evaluate(() => {
      const a = fmt(1234567); G.opt.money = 'ja'; const b = fmt(1234567), c = fmt(3.2e9), d = fmt(999); G.opt.money = 'en';
      G.opt.fs = 'l'; applyOpt(); const big = document.documentElement.classList.contains('fs-l'); G.opt.fs = 'm'; applyOpt();
      return { a, b, c, d, big };
    });
    rec(46, '設定：金額の表記（$1.23M / $123万 / $32億）と文字：大', op.a === '$1.23M' && op.b === '$123万' && op.c === '$32億' && op.d === '$999' && op.big, JSON.stringify(op));
    await ctx.close();
    if (errors.length) rec('E12', 'P1テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 遊びの厚み（P3）と保全（P2） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      // #47 章の目標
      const c0 = G.cash; G.stats.orders = 1; G.fac.distillation.p = true; G.stats.filled = 1; G.stats.shipped = 100;
      checkChapters();
      const st = G.chap; const claimed = !!st.claimed[1]; const gain = G.cash - c0;
      T(47, '章の目標：達成ごとに報酬・4つで章完了（演出を予約）', claimed && Math.abs(gain - 8000) < 1e-6 && _celebQ.length + (_celebOn ? 1 : 0) >= 1, 'gain=' + gain + ' claimed=' + claimed);
      _celebQ = []; celebClose();
      // #48 仕上げの樽
      G.dl = 2; G.cash = 1e7; G.te = 1e9; G.uw = ['jack_d'];
      const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 6; G.lots = [l];
      const f0 = lotFlavor(l); const elig0 = lotsFor('jack_d').length;
      const ok = lotFinish(l.id, 'sherry'); const f1 = lotFlavor(l);
      l.age = 7; const f2 = lotFlavor(l); l.age = 9; const f3 = lotFlavor(l);
      const again = lotFinish(l.id, 'wine');
      const sh = caskType('sherry').flavorMod.fruity;
      T(48, '仕上げ：風味を引き継ぎ、移した樽の風味が2年で満ちる・1回のみ・バーボン銘柄から外れる', ok && Math.abs(f1.fruity - f0.fruity) < 1e-6 && Math.abs(f2.fruity - (f0.fruity + sh / 2)) < 1e-6 && Math.abs(f3.fruity - Math.min(100, f0.fruity + sh)) < 1e-6 && !again && elig0 === 1 && lotsFor('jack_d').length === 0 && G.stats.finishes === 1, JSON.stringify({ f0: f0.fruity, f1: f1.fruity, f2: f2.fruity, f3: f3.fruity, again }));
      // #49 名樽と愛好会
      const n1 = makeLot(caskType('bourbon'), caskSize('hogshead')); n1.age = 14;
      const n2 = makeLot(caskType('bourbon'), caskSize('hogshead')); n2.age = 14;
      G.lots = [n1, n2]; lotName(n1.id, 'はじまりの一樽'); trackNamed();
      const o = { id: 'o_s', cid: 'society', kind: 'cask', minAge: 12, qty: 1, rq: 1, mult: 2, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o]; const m = ordMatch(o);
      const ratio = m.cash / (lotValue(n2) * 2);
      const lim0 = G.stats.limited || 0;
      ordDeliver('o_s', null); trackNamed();
      T(49, '名樽：名前を付けると愛好会が1.2倍で買い取り、蔵出しで記録に残る', m.lot === n1 && Math.abs(ratio - 1.2) < 1e-6 && G.stats.named === 1 && G.stats.limited === lim0 + 1 && G.caskLog.length === 1 && G.caskLog[0].name === 'はじまりの一樽', JSON.stringify({ ratio, log: G.caskLog }));
      // #50 取引先の人物
      G.relEvQ = []; G.rel.local = { lv: 2, done: 14 }; relAdd('local', 1);
      const q = G.relEvQ.slice(); const b0 = G.orders.length;
      relEventApply('local', 3);
      T(50, '取引先：関係★3で人物の会話が予約され、特別な予約注文が届く', q.length === 1 && q[0].lv === 3 && G.orders.length === b0 + 1 && G.orders[G.orders.length - 1].reserve, JSON.stringify(q));
      // #51 月替わりの市場
      _mktOff = false; G.awardMult = {};
      const u = (m) => { _mktForce = m; prodInvalidate(); return priceUnit('glenlivid', 8, 1, productSpec('glenlivid').target); };
      const base = u(2), dec = u(12), jul = u(7), nov = u(11);
      const nov12 = (() => { _mktForce = 11; return priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target); })();
      _mktForce = 2; const nov12b = priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target);
      _mktForce = 4; const tour = cv(); _mktForce = 2; const tour0 = cv();
      _mktForce = 0; _mktOff = true;
      T(51, '月替わりの市場：12月は単価×1.12、7月は10年未満×1.15、11月は12年以上だけ×1.12、4月はツアー×2', Math.abs(dec / base - 1.12) < 1e-9 && Math.abs(jul / base - 1.15) < 1e-9 && Math.abs(nov / base - 1) < 1e-9 && Math.abs(nov12 / nov12b - 1.12) < 1e-9 && Math.abs(tour / tour0 - 2) < 1e-9, [dec / base, jul / base, nov12 / nov12b, tour / tour0].map(x => x.toFixed(3)).join(','));
      // #52 記録
      G.records = {}; G.runStart = Date.now() - 5 * 864e5; recordTier(2); recordUnit(1234);
      const rc = G.records[G.climate];
      T(52, '気候ごとの記録：昇格までの日数と最高単価', rc && rc.tierDays[2] === 5 && rc.bestUnit === 1234, JSON.stringify(rc));
      // #53 来客
      const cash0 = G.cash; const el = document.createElement('button'); el.dataset.vip = ''; el.id = 'vis_t'; document.body.appendChild(el);
      visitorTap(el);
      T(53, '見学ツアーの来客をタップするとチップ（タップ15回分）', Math.abs(G.cash - cash0 - cv() * 15) < 1e-6, G.cash - cash0);
      // #54 景色
      const s1 = sceneSvg(); G.fac.mashing.p = true; G.fac.maturation.p = true; G.fac.maturation.l = 12; const s2 = sceneSvg();
      const cnt = s => (s.match(/<rect x="\d+(\.\d+)?" y="\d+(\.\d+)?" width="\d+" height="\d+" fill="#2e2216"/g) || []).length;
      T(54, '景色：購入した設備と熟成庫のLvで建物が増える', cnt(s2) > cnt(s1), cnt(s1) + '→' + cnt(s2));
      // #55 引き継ぎコード
      const code = encodeCode(JSON.stringify({ a: 1, t: 'ウイスキー' }));
      const back = decodeCode(code);
      let tamper = ''; try { decodeCode(code.slice(0, 10) + (code[10] === 'A' ? 'B' : 'A') + code.slice(11)); } catch (e) { tamper = e.message; }
      let cut = ''; try { decodeCode(code.slice(0, 20)); } catch (e) { cut = e.message; }
      T(55, '引き継ぎコード：往復で一致・改変や欠けは検出して理由を示す', back.t === 'ウイスキー' && /変更|切れ/.test(tamper) && cut.length > 0, tamper + ' / ' + cut);
      // #56 自動バックアップ
      for (let i = 0; i < 3; i++) localStorage.removeItem(bkKey(i));
      const a1 = autoBackup(false), a2 = autoBackup(false), a3 = autoBackup(true), a4 = autoBackup(true), a5 = autoBackup(true);
      const list = bkList();
      T(56, '自動バックアップ：6時間おき・最大3つを入れ替え', a1 && !a2 && a3 && a4 && a5 && list.length === 3, JSON.stringify([a1, a2, a3, a4, a5, list.length]));
      // #57 独自銘柄
      const real = ['Glenlivet', 'Glenfiddich', 'Johnnie Walker', 'Chivas', 'Macallan', 'Laphroaig', 'Ardbeg', 'Talisker', 'Balvenie', 'Dalmore', 'Jameson', 'Bushmills', "Jack Daniel", "Maker's Mark", 'Buffalo Trace', 'Pappy', 'Yamazaki', 'Hakushu', 'Hibiki', 'Nikka', 'Suntory', 'Crown Royal'];
      const names = WL.map(w => w.name + ' ' + w.rg).join('|');
      const hit = real.filter(n => names.toLowerCase().includes(n.toLowerCase()));
      T(57, '25銘柄が独自の名前（実在ブランド名・蒸留所名を含まない）', hit.length === 0 && WL.every(w => WL_RENAME[w.id]), hit.join(','));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E13', 'P2/P3テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- schema 8 → 9 の移行 ----------
  {
    const v8 = { ver: 8, cash: 777, te: 5000, dl: 2, uw: ['glenlivid'], lots: [], bottles: [], orders: [], stats: { orders: 3, shipped: 150, filled: 2 }, fac: { malting: { l: 3, p: true }, distillation: { l: 1, p: true } }, tut: { done: { first: true }, q: [], seed: false }, auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: true, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('z')){sessionStorage.setItem('z','1');localStorage.setItem('we_sound','off');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v8))});}`;
    const { page, errors } = await newPage(browser, pre);
    await page.waitForTimeout(2600);
    const r = await page.evaluate(() => ({ ver: G.ver, se: G.opt.se, bgm: G.opt.bgm, bk: !!localStorage.getItem('we_v4_bak8:guest'), claimed: G.chap.claimed, done: Object.keys(G.chap.done).length, cash: G.cash, seed: G.chap.seed, fill: G.auto.fill.on }));
    rec(58, 'v4.1（schema8）からの移行：バックアップ・音はOFFを引き継ぐ・達成済みの章目標は報酬なしで既読', r.ver === 9 && r.se === 0 && r.bgm === 0 && r.bk && r.claimed[1] === true && r.cash < 2000 && !r.seed && !r.fill, JSON.stringify(r));
    if (errors.length) rec('E14', '移行テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 文字：大 で横スクロールしない ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      G.opt.fs = 'l'; applyOpt(); const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth }); }
      return res;
    });
    const bad = r.filter(x => x.over > 1 || x.doc > 1);
    rec(59, '文字：大・幅360pxでも横スクロールなし', bad.length === 0, JSON.stringify(bad));
    if (errors.length) rec('E15', '文字：大テスト中のエラー', false, errors.join(' | '));
  }
