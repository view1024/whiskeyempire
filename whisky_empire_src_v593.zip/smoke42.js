const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 740 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if ((m.type() === 'error' && !m.text().includes('ERR_FAILED')) || m.type()==='warning') errors.push(m.type() + ': ' + m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1500);
  await page.screenshot({ path: 'b_title.png' });
  await page.click('#titleBtns .btn-ok');
  await page.waitForTimeout(1200);
  await page.screenshot({ path: 'b_home_tut.png' });
  await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } rall(); });
  await page.waitForTimeout(500);
  await page.screenshot({ path: 'b_home.png' });
  for (const t of ['tb','tcel','tsale','te','tp']) { await page.evaluate(t=>switchTab(t),t); await page.waitForTimeout(300); await page.screenshot({ path: `b_${t}.png` }); }
  console.log('ERRORS:', errors.length ? errors.join('\n') : 'none');
  await browser.close();
})();
