// ============================================================
// v4.2 遊びの厚み（章・仕上げ・名樽・市場・記録・取引先の人物・来客）と保全（バックアップ・引き継ぎコード・不具合報告）
// ============================================================

// ---------- G6 月替わりの市場 ----------
let _mktOff=false,_mktForce=0; // 自動テスト・バランス検証用
function mktAt(m){return MARKETS.find(x=>x.m===m)||MARKETS[0];}
function mkt(){return mktAt(_mktForce||new Date().getMonth()+1);}
function mktNext(){return mktAt((new Date().getMonth()+1)%12+1);}
function mktFx(k){if(_mktOff)return 1;const v=mkt().fx[k];return v===undefined?1:v;}
function mktDaysLeft(){const d=new Date();const end=new Date(d.getFullYear(),d.getMonth()+1,1);return Math.ceil((end-d)/864e5);}
let _mktMonth=new Date().getMonth();
function mktTick(){const m=new Date().getMonth();if(m!==_mktMonth){_mktMonth=m;prodInvalidate();if(!_mktOff)toast('📅 今月の市場：'+mkt().name+'（'+mkt().desc+'）',4000);}}
function compCost(comp){return Math.round(comp.entryCost*mktFx('compCost'));}

// ---------- G1 章立ての目標 ----------
function chapState(){if(!G.chap)G.chap={done:{},claimed:{}};return G.chap;}
function chapCur(){
  const st=chapState();
  const open=CHAPTERS.filter(c=>c.tier<=(G.dl||1)&&!st.claimed[c.tier]);
  return open[0]||CHAPTERS.find(c=>c.tier===(G.dl||1))||CHAPTERS[0];
}
function checkChapters(){
  const st=chapState();let changed=false;
  if(st.seed){CHAPTERS.forEach(c=>{if(c.tier>(G.dl||1))return;c.goals.forEach(g=>{try{if(g.ck(G))st.done[g.id]=true;}catch(e){}});if(c.goals.every(g=>st.done[g.id]))st.claimed[c.tier]=true;});st.seed=false;save();return true;}
  CHAPTERS.forEach(c=>{
    if(c.tier>(G.dl||1)||st.claimed[c.tier])return;
    c.goals.forEach(g=>{
      if(st.done[g.id])return;
      let ok=false;try{ok=g.ck(G);}catch(e){}
      if(ok){st.done[g.id]=true;changed=true;if(c.reward.cash){acRev('oth',c.reward.cash);G.cash+=c.reward.cash;}if(!_offlineRunning)toast('📘 目標達成：'+g.label+'　+'+fmt(c.reward.cash||0),3500);}
    });
    if(c.goals.every(g=>st.done[g.id])&&!st.claimed[c.tier]){
      st.claimed[c.tier]=true;changed=true;
      if(c.bonus&&c.bonus.rep)changeRep(c.bonus.rep,c.name+' 完了');
      celebrate({icon:'📘',title:c.name+' 完了',sub:c.story});sndTierUp();
    }
  });
  if(changed)save();
  return changed;
}
function openChapModal(){
  const st=chapState();
  openModal(`<div class="mt">📘 章の目標</div><div class="ms">目標ごとに報酬、章をすべて達成すると評判が上がり物語が進みます</div>`+
    CHAPTERS.filter(c=>c.tier<=(G.dl||1)+1).map(c=>{
      const locked=c.tier>(G.dl||1);
      return `<div class="card ${st.claimed[c.tier]?'hl':''}" style="opacity:${locked?.55:1}"><div class="row sb"><span class="tt">${escapeHtml(c.name)}</span><span class="sm">${locked?'Tier'+c.tier+'で開始':'1つにつき '+fmt(c.reward.cash)}</span></div>
      ${c.goals.map(g=>`<div class="goal ${st.done[g.id]?'ok':''}">${st.done[g.id]?'✅':'⬜'} ${escapeHtml(g.label)}</div>`).join('')}
      ${st.claimed[c.tier]?`<div class="sm" style="margin-top:6px;color:var(--text2)">${escapeHtml(c.story)}</div>`:''}</div>`;
    }).join('')+`<button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}

// ---------- G3 仕上げの樽（フィニッシュ） ----------
function finishable(l){return l&&!l.fin&&l.age>=2;}
function openFinishModal(id){
  const l=G.lots.find(x=>x.id===id);if(!l)return;
  const types=CASK_TYPES.filter(t=>caskTypeUnlocked(t)&&t.id!==l.cask);
  openModal(`<div class="mt">🪵 仕上げの樽へ移す</div><div class="ms">${escapeHtml(caskLabel(l))} ${fmtAge(l.age)}。移した樽の風味が${BALANCE.FINISH_YEARS}年で加わる</div>
    ${types.length?types.map(t=>`<div class="card"><div class="row sb"><span class="tt">${t.icon} ${escapeHtml(t.name)}</span><span class="vv">${fmt(caskCost(t.id,l.size))}</span></div><div class="sm">${escapeHtml(t.desc)}</div><button type="button" class="sb2" style="width:100%;margin-top:8px" data-act="finGo" data-id="${l.id}" data-type="${t.id}" ${G.cash>=caskCost(t.id,l.size)?'':'disabled'}>この樽で仕上げる</button></div>`).join(''):'<div class="sm">移せる樽がありません（ほかの種類の樽は総売上で解禁）</div>'}
    <div class="sm" style="margin:6px 0">バーボン樽以外に移すと、バーボン銘柄には使えなくなります。仕上げは1樽につき1回です。</div>
    <button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}
function lotFinish(id,type){
  const l=G.lots.find(x=>x.id===id);if(!finishable(l))return false;
  const c=caskCost(type,l.size);if(G.cash<c){toast('資金不足');return false;}
  pay(c,'pur','cask');l.c=lotC(l)+c;
  l.fl0=lotFlavor(l);l.fin={from:l.cask,at:l.age};l.cask=type;
  G.stats.finishes=(G.stats.finishes||0)+1;
  sndUpgrade();toast('🪵 '+caskType(type).name+'で仕上げを始めました',2500);save();return true;
}

// ---------- G4 名樽 ----------
function openNameModal(id){
  const l=G.lots.find(x=>x.id===id);if(!l)return;
  openModal(`<div class="mt">🏷️ 樽に名前を付ける</div><div class="ms">名前を付けた樽は棚の札に★が付き、名前は樽の吹き出しや売るの一覧に出ます。ウイスキー愛好会が高く評価します</div>
    <input id="lotNameIn" maxlength="12" value="${escapeHtml(l.name||'')}" placeholder="例：はじまりの一樽" style="width:100%;padding:12px;font-size:16px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;color:var(--text)">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px"><button type="button" class="btn-cancel" data-act="closeM">やめる</button><button type="button" class="btn-ok" data-act="nameGo" data-id="${l.id}">決定</button></div>`);
  setTimeout(()=>{const i=$('lotNameIn');if(i)i.focus();},60);
}
function lotName(id,name){
  const l=G.lots.find(x=>x.id===id);if(!l)return false;
  name=String(name||'').trim().slice(0,12);if(!name){toast('名前を入力してください');return false;}
  if(!l.name)G.stats.named=(G.stats.named||0)+1;
  l.name=name;save();toast('🏷️ 「'+name+'」と名付けました',2500);return true;
}

// ---------- G7 創業地ごとの記録（v5.6 通算の売上 te・到達した Tier maxTier を追加） ----------
function recCur(){if(!G.records)G.records={};const k=G.climate||'speyside';if(!G.records[k])G.records[k]={bestUnit:0,maxAge:0,tierDays:{},runs:0,te:0,maxTier:1};return G.records[k];}
function recordUnit(u){const r=recCur();if(u>r.bestUnit)r.bestUnit=u;}
function recordTick(){const r=recCur();if((G.stats.maxAge||0)>r.maxAge)r.maxAge=G.stats.maxAge;}
function recordTier(t){const r=recCur();r.maxTier=Math.max(r.maxTier||1,t);const d=+(((Date.now()-(G.runStart||Date.now()))/864e5).toFixed(1));if(!r.tierDays[t]||d<r.tierDays[t])r.tierDays[t]=d;}

// ---------- G5 取引先の人物 ----------
function relLevelUp(cid,lv){if(!G.relEvQ)G.relEvQ=[];G.relEvQ.push({cid,lv});}
function relEventTick(){
  if(!G.relEvQ||!G.relEvQ.length)return;
  if(!_titleDone||_tut||_offlineGate)return;
  const mo=$('mo');if(mo&&!mo.classList.contains('h'))return;
  const ev=G.relEvQ.shift();const p=CUST_PERSONA[ev.cid];const c=custById(ev.cid);const e=REL_EVENTS[ev.lv];
  if(!p||!c||!e){save();return;}
  let rw='';
  if(e.reward&&e.reward.rep)rw='評判 +'+e.reward.rep;
  if(e.reward&&e.reward.special)rw='特別な予約注文';
  if(e.reward&&e.reward.gift)rw='お礼 '+fmt(relGift());
  openModal(`<div class="row" style="gap:12px;margin-bottom:10px">${avatar(ev.cid,52)}<div><div class="tt" style="font-size:18px">${escapeHtml(p.pname)}</div><div class="sm">${escapeHtml(c.name)}・${escapeHtml(p.role)}　関係 ${'★'.repeat(ev.lv)}</div></div></div>
    <div class="quote">「${escapeHtml(e.line)}」</div>
    ${rw?`<div class="sm" style="margin-top:10px;color:var(--green)">🎁 ${escapeHtml(rw)}</div>`:''}
    <button type="button" class="cb" data-act="relEvOk" data-cid="${ev.cid}" data-lv="${ev.lv}">${rw?'受け取る':'閉じる'}</button>`,true);
}
function relGift(){return Math.max(10000,Math.round(tierCost(Math.min(DL.length,(G.dl||1)+1))*0.02));}
function relEventApply(cid,lv){
  const e=REL_EVENTS[lv];if(!e||!e.reward){save();return;}
  const r=e.reward;
  if(r.rep)changeRep(r.rep,(CUST_PERSONA[cid]||{}).pname+'との関係');
  if(r.gift)earn(relGift(),'oth');
  if(r.special){const o=ordGenerate({cid,special:true});if(o){if(G.orders.length>=boardSize()){const i=G.orders.findIndex(x=>!x.reserve||!x.accepted);if(i>=0)G.orders.splice(i,1);}G.orders.push(o);toast('📜 '+(CUST_PERSONA[cid]||{}).pname+'から特別な注文が届きました',3000);}}
  save();
}

// ---------- G10 見学ツアーの来客 ----------
let _vis={next:0,list:[]};
function visitorTick(){
  const home=$('td');if(!home||!home.classList.contains('on')||document.hidden||!_titleDone)return;
  const now=Date.now();
  _vis.list=_vis.list.filter(v=>{if(now>v.until){const el=$(v.id);if(el)el.remove();return false;}return true;});
  if(now<_vis.next||_vis.list.length>=2)return;
  _vis.next=now+rnd(15000,30000);
  const box=$('visitors');if(!box)return;
  const vip=Math.random()<0.12;const side=_vis.list.length?(_vis.list[0].side==='l'?'r':'l'):(Math.random()<0.5?'l':'r'); // v5.5 2人目は必ず反対側
  const id='vis_'+now;
  const el=document.createElement('button');el.type='button';el.id=id;el.className='visitor '+side+(vip?' vip':'');
  const vipOrder=vip&&G.orders.length<boardSize()&&custAvailable().length;
  const sub=vipOrder?'注文 単価×1.2':'試飲 +'+fmt(cv()*(vip?40:15));
  el.dataset.act='visTap';el.dataset.vip=vip?'1':'';
  el.setAttribute('aria-label',(vip?'バイヤー来訪':'見学のお客さん')+'（'+sub+'）');
  el.innerHTML=`<span class="vav">${ic('visitor',20)}</span><span class="vtx"><b>${vip?'バイヤー来訪':'見学させて！'}</b><span>${sub}</span></span><i class="vtm"></i>`;
  el.style.top=(4+Math.random()*34)+'%';
  box.appendChild(el);visFit(el); // v5.5 樽に重ならない幅に
  const hs=hsState();if(!hs.vis){hs.vis=1;save();toast('👤 見学のお客さんが来ました。タップすると試飲代が入ります（12秒で帰ります）',4500);}
  _vis.list.push({id,until:now+12000,side});
}
function visitorTap(el){
  if(!el||el._done)return;el._done=true;
  const vip=el.dataset.vip==='1';
  const r=el.getBoundingClientRect();
  if(vip&&G.orders.length<boardSize()&&custAvailable().length){
    const o=ordGenerate();if(o){o.mult=+(o.mult*1.2).toFixed(2);G.orders.push(o);toast('🎩 バイヤーから注文が届きました（単価×1.2）',3000);sndQuest();}
  }else{
    const v=cv()*(vip?40:15);earn(v,'tap');showFT('+'+fmt(v),r.left+r.width/2,r.top,vip);sndCoin();
  }
  vib(15);
  el.classList.add('gone');setTimeout(()=>el.remove(),400);
  _vis.list=_vis.list.filter(x=>x.id!==el.id);
  updHdr();
}

// ---------- R3 セーブの保全 ----------
const BK_N=3,BK_INTERVAL=6*3600000;
function bkKey(i){return 'we_v4_auto:'+(LIFF_USER.id||'guest')+':'+i;}
function bkList(){const out=[];for(let i=0;i<BK_N;i++){try{const s=localStorage.getItem(bkKey(i));if(s){const o=JSON.parse(s);o.slot=i;out.push(o);}}catch(e){}}return out.sort((a,b)=>b.t-a.t);}
function autoBackup(force){
  if(_noSave)return false;
  const list=bkList();const last=list[0];
  if(!force&&last&&Date.now()-last.t<BK_INTERVAL)return false;
  const slot=list.length<BK_N?[0,1,2].find(i=>!list.some(b=>b.slot===i)):list[list.length-1].slot;
  try{localStorage.setItem(bkKey(slot),JSON.stringify({t:Date.now(),ver:BALANCE.APP_VERSION,dl:G.dl,cash:G.cash,data:JSON.stringify(G)}));return true;}catch(e){return false;}
}
function openBackupModal(){
  const list=bkList();
  openModal(`<div class="mt">🗂️ 自動バックアップ</div><div class="ms">6時間ごとに、この端末に最大${BK_N}つまで自動で保存しています</div>
    ${list.length?list.map(b=>{const d=new Date(b.t);return `<div class="card"><div class="row sb"><span class="tt">${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}</span><span class="sm">Tier${b.dl}・${fmt(b.cash)}</span></div><button type="button" class="sb2 gh" style="width:100%;margin-top:8px" data-act="bkRestore" data-slot="${b.slot}">この時点に戻す</button></div>`;}).join(''):'<div class="sm tc" style="padding:12px">まだバックアップがありません</div>'}
    <button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}
function bkRestore(slot){
  let b=null;try{b=JSON.parse(localStorage.getItem(bkKey(slot)));}catch(e){}
  if(!b){toast('バックアップを読めませんでした');return;}
  showConfirm({title:'バックアップから戻す',msg:'現在の進行を、この時点の状態に置き換えます。',icon:'🗂️',danger:true,yesLabel:'戻す',onYes:()=>{
    try{G=parseSave(JSON.parse(b.data));}catch(e){toast('復元に失敗しました: '+e.message,3000);return;}
    postLoadInit();prodInvalidate();save();closeM();rall();toast('✓ バックアップから戻しました',2500);
  }});
}
function crc32(s){let c,crc=0xFFFFFFFF;for(let i=0;i<s.length;i++){c=(crc^s.charCodeAt(i))&0xFF;for(let k=0;k<8;k++)c=c&1?(c>>>1)^0xEDB88320:c>>>1;crc=(crc>>>8)^c;}return ((crc^0xFFFFFFFF)>>>0).toString(16).padStart(8,'0');}
function encodeCode(s){const b=btoa(unescape(encodeURIComponent(s)));return 'WE2.'+b+'.'+crc32(b);}
function decodeCode(t){
  t=String(t||'').replace(/\s+/g,'');
  if(t.indexOf('WE2.')===0){
    const body=t.slice(4);const i=body.lastIndexOf('.');if(i<0)throw new Error('コードが途中で切れているか、形式が正しくありません');
    const b=body.slice(0,i),sum=body.slice(i+1);
    if(crc32(b)!==sum)throw new Error('コードが途中で切れているか、変更されています');
    return JSON.parse(decodeURIComponent(escape(atob(b))));
  }
  return JSON.parse(decodeURIComponent(escape(atob(t))));
}

// ---------- U9 更新履歴・不具合の報告 ----------
const _errLog=[];
window.addEventListener('error',e=>{_errLog.push((e.message||'error')+' @'+(e.lineno||''));if(_errLog.length>5)_errLog.shift();});
function openChangelog(){
  hsState().cl=BALANCE.APP_VERSION;clBadge();save();
  openModal(`<div class="mt">📰 更新履歴</div>`+CHANGELOG.map(c=>`<div class="card"><div class="row sb"><span class="tt">v${c.v}</span><span class="sm">${c.d}</span></div>${c.items.map(x=>'<div class="sm" style="color:var(--text2)">・'+escapeHtml(x)+'</div>').join('')}</div>`).join('')+`<div class="sm" style="color:var(--text2);text-align:center;margin:6px 0 10px">v4.9 以前の更新履歴は省略しています</div><button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}
function bugReportText(){
  return ['Whisky Empire 不具合の報告','版: v'+BALANCE.APP_VERSION+' (schema '+BALANCE.SCHEMA_VERSION+')','日時: '+new Date().toLocaleString('ja-JP'),'状態: Tier'+G.dl+' / 樽'+G.lots.length+' / 注文'+G.orders.length+' / 出荷'+G.stats.shipped,'環境: '+navigator.userAgent.slice(0,120),'直近のエラー: '+(_errLog.join(' | ')||'なし'),'起動と保存の記録（新しいものが下）:',diagText()||'なし','','起きたこと：','（ここに書いてください）'].join('\n');
}
function openBugReport(){
  openModal(`<div class="mt">🐞 不具合を報告</div><div class="ms">下の文章に起きたことを書き足し、コピーして開発者に送ってください</div>
    <textarea id="ioText" style="width:100%;min-height:180px;padding:10px;background:var(--bg3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:14px">${escapeHtml(bugReportText())}</textarea>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px"><button type="button" class="btn-cancel" data-act="closeM">閉じる</button><button type="button" class="btn-ok" data-act="ioCopy">📋 コピー</button></div>`);
}
function openCredits(){
  openModal(`<div class="mt">📄 クレジット・素材</div>
    <div class="card"><div class="sm" style="color:var(--text2)">・フォント：Playfair Display／Crimson Text／JetBrains Mono（Google Fonts、SIL Open Font License）<br>・アイコン・BGM・効果音：本作のための自作（コードで生成）<br>・ホームの蒸留所の絵・造る／寝かせる／売るの背景の絵・タップする樽の絵：本作のために用意した画像（時間帯の色味はコードで調整）<br>・樽の画像：制作者に確認中の素材<br>・豆知識の出典：TIPS帯をタップすると表示</div></div>
    <div class="card"><div class="sm" style="color:var(--text2)">20歳未満の者の飲酒は法律で禁じられています。妊娠中や授乳期の飲酒は、胎児・乳児の発育に悪影響を与えるおそれがあります。このゲームは飲酒を勧めるものではありません。登場する銘柄・人物はすべて架空のものです。</div></div>
    <button type="button" class="btn-cancel" style="width:100%" data-act="closeM">閉じる</button>`);
}

// ---------- 2秒ごとの処理（v4.2） ----------
function v42Tick(){
  try{mktTick();}catch(e){}
  try{checkChapters();}catch(e){console.warn(e);}
  try{recordTick();}catch(e){}
  try{relEventTick();}catch(e){}
  try{visitorTick();}catch(e){}
  try{tabBgSet();}catch(e){}
  try{autoBackup(false);}catch(e){}
  try{if(_tk.paused){const mo=$('mo');if(mo&&mo.classList.contains('h'))tkResume();}}catch(e){}
}
