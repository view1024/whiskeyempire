// ============================================================
// v5.7 決算書のリアリティ（第3回）：製造費・熟成費・CF の間接法・耐用年数・法人税・在庫を担保にした借入
// ============================================================
// 実装計画：https://claude.ai/code/artifact/293b44c8-9442-4602-b501-77ec0f0ad3fe
//  M1 製造費：新酒を造るときに1Lあたり MFG_K×新酒の外販価格を払い、タンク・樽の原価に入れる（払えない分は造らない）
//  M2 熟成費：樽1つ・ゲーム内1年ごとに、詰めたときの原価×AGE_R を払い、その樽の原価に積む（払えない分は積まない）
//  M3 CF：営業CF を「当期純利益＋減価償却費−在庫の増加＋未払法人税の増加＋未払の利息」で示す（n16 の finRows）
//  M4 耐用年数：熟成庫（建物）30年・ほかの設備（機械）15年（n16 の faLife）
//  M5 法人税：月の税引前利益の30%。赤字は繰り越す（n16 の acctTax）。月を締めた次の月の初めに払う
//  M7 借入（Tier3〜）：上限は樽の原価の LTV、金利はゲーム内の年4%、元金はゲーム内10年で自動返済
const V57={MFG_K:[0.1,0.3,0.7,0.8,0.9],AGE_R:0.04,LIFE_BLD:30,LIFE_MACH:15,TAX:0.3,LTV:[0,0,0.5,0.6,0.7],LOAN_R:0.04,LOAN_YEARS:10,LOAN_STEP:0.25};

// ---------- M1 製造費 ----------
function mfgUnit(){return V57.MFG_K[clamp((G.dl||1)-1,0,V57.MFG_K.length-1)]*nmPrice();}
function tankMfgU(){return (G.tank||0)>0?(G.tankMfg||0):0;}
let _mfgWarnAt=0;
function mfgPay(L){
  if(!(L>0))return 0;
  const u=mfgUnit();if(!(u>0))return L;
  let cost=L*u;
  if(G.cash<cost){const L2=Math.max(0,G.cash)/u;if(!_offlineRunning&&Date.now()-_mfgWarnAt>600000){_mfgWarnAt=Date.now();try{toast('💸 製造費が足りず、蒸留が一部止まっています（造る：新酒1Lあたり '+fmt(u)+'）',4000);}catch(e){}}L=L2;cost=L*u;}
  if(cost>0){pay(cost,'pur','mfg');G.stats.mfgCost=(G.stats.mfgCost||0)+cost;}
  const t=G.tank||0;G.tankMfg=t+L>0?(t*(G.tankMfg||0)+L*u)/(t+L):0;
  return L;
}
function acctMfgPaid(){return G.stats.mfgCost||0;}

// ---------- M2 熟成費 ----------
function ageCostTick(lots,ms){
  const dy=ms/BALANCE.GAME_YEAR_MS;if(!(dy>0)||!lots.length)return 0;
  let tot=0;const cs=lots.map(l=>{if(!(l.c0>0))l.c0=lotC(l);const c=V57.AGE_R*l.c0*dy;tot+=c;return c;});
  if(!(tot>0))return 0;
  const k=G.cash>=tot?1:Math.max(0,G.cash)/tot;if(!(k>0))return 0;
  lots.forEach((l,i)=>{l.c=lotC(l)+cs[i]*k;});
  pay(tot*k,'pur','age');G.stats.ageCost=(G.stats.ageCost||0)+tot*k;
  return tot*k;
}
function acctAgePaid(){return G.stats.ageCost||0;}

// ---------- M7 借入 ----------
function loanState(){const a=G.acct;if(!a||!a.cur)return null;if(!a.loan||typeof a.loan!=='object')a.loan={bal:0,pd:0};return a.loan;}
function loanOn(){return (G.dl||1)>=3;}
function loanLimit(){return (V57.LTV[clamp((G.dl||1)-1,0,4)]||0)*invBreak().lot;}
function loanAvail(){const l=loanState();return l&&loanOn()?Math.max(0,loanLimit()-l.bal):0;}
function loanBorrow(x){
  if(!loanOn()||!acctEnsure())return 0;const l=loanState();
  x=Math.min(x,loanAvail());if(!(x>0))return 0;
  G.cash+=x;G.acct.cur.bor+=x;l.bal+=x;l.pd=l.bal/V57.LOAN_YEARS;return x;
}
function loanRepay(x){
  if(!acctEnsure())return 0;const l=loanState();if(!l)return 0;
  x=Math.min(x,Math.max(0,G.cash),l.bal);if(!(x>0))return 0;
  G.cash-=x;G.acct.cur.rep+=x;l.bal-=x;if(l.bal<1e-6){l.bal=0;l.pd=0;}else l.pd=Math.min(l.pd,l.bal);return x;
}
// 利息（ゲーム内の年4%）と元金の返済。払えない利息は借入に加え、払えない元金は後に回す
function loanTick(ms){
  const out={i:0,p:0};const l=loanState();if(!l||!(l.bal>0))return out;
  if(!acctEnsure())return out;const a=G.acct;const dy=ms/BALANCE.GAME_YEAR_MS;
  const I=l.bal*V57.LOAN_R*dy;const ip=Math.min(Math.max(0,G.cash),I);G.cash-=ip;a.cur.int+=ip;if(I>ip){a.cur.intAcc+=I-ip;l.bal+=I-ip;}out.i=ip;
  const P=Math.min(l.bal,l.pd*dy);const pp=Math.min(Math.max(0,G.cash),P);G.cash-=pp;a.cur.rep+=pp;l.bal-=pp;out.p=pp;
  if(l.bal<1e-6){l.bal=0;l.pd=0;}
  return out;
}
function prestigeCash(){const a=G.acct;return (G.cash||0)-((a&&a.loan&&a.loan.bal)||0)-((a&&a.taxDue)||0);}
function finLoanHtml(){
  if(!loanOn())return `<div class="card floan"><div class="row sb"><span class="tt">🏦 借入</span>${ib('loan')}</div><div class="sm">Tier3 から、熟成中の樽を担保に借りられます</div></div>`;
  const l=loanState()||{bal:0,pd:0};const lim=loanLimit(),av=loanAvail();const step=Math.max(0,Math.min(av,lim*V57.LOAN_STEP));
  return `<div class="card floan"><div class="row sb"><span class="tt">🏦 借入</span>${ib('loan')}</div>
    <div class="msr"><div class="msl">借入金</div><div class="msv">${fmt(l.bal)}</div></div>
    <div class="msr"><div class="msl">上限（樽の原価の${Math.round(V57.LTV[(G.dl||1)-1]*100)}%）</div><div class="msv">${fmt(lim)}</div></div>
    <div class="sm">金利はゲーム内の年${Math.round(V57.LOAN_R*100)}%（実1日）・元金は${V57.LOAN_YEARS}年で自動返済${l.bal>0?'（1日あたり約'+fmt(l.pd+l.bal*V57.LOAN_R)+'）':''}</div>
    <div class="row" style="gap:6px;margin-top:6px"><button type="button" class="sb2" style="flex:1;min-height:44px" data-act="loanBor" ${step>0.5?'':'disabled'}>借りる ${step>0.5?'+'+fmt(step):''}</button><button type="button" class="sb2 gh" style="flex:1;min-height:44px" data-act="loanRep" ${l.bal>0.5&&G.cash>0.5?'':'disabled'}>返す ${l.bal>0.5?fmt(Math.min(l.bal,Math.max(0,G.cash))):''}</button></div></div>`;
}

// ---------- data-act ----------
function extAct57(act,b,id){
  switch(act){
    case 'loanBor':{const x=loanBorrow(Math.min(loanAvail(),loanLimit()*V57.LOAN_STEP));if(x>0){toast('🏦 '+fmt(x)+' を借りました',2200);save();}finRender();updHdr();return true;}
    case 'loanRep':{const x=loanRepay(Infinity);if(x>0){toast('🏦 '+fmt(x)+' を返しました',2200);save();}finRender();updHdr();return true;}
  }
  return false;
}

TIPS.push({id:'mfg',cat:'造る',t:'製造費',b:'新酒を造るときに、燃料・電気・工場の人件費などの製造費を払います。1Lあたりの額は新酒の外販価格の一部で、Tier が上がると割合も上がります。製造費は新酒と樽の原価に入り、瓶を売るまでは費用になりません（決算書では在庫として資産に残ります）。お金が足りないと、その分だけ蒸留が止まります。'});
TIPS.push({id:'agecost',cat:'寝かせる',t:'熟成費',b:'倉庫の管理費と保険として、樽1つ・ゲーム内の1年（実1日）ごとに、詰めたときの原価の4%を払います。熟成費は樽の原価に積まれ、売るまで在庫として資産に残ります。'});
TIPS.push({id:'tax',cat:'成長',t:'法人税',b:'月を締めるときに、その月の税引前利益の30%が法人税として確定し、次の月の初めに払います。赤字の月があれば、その分を後の月の利益から差し引きます（繰越欠損金）。'});
TIPS.push({id:'loan',cat:'成長',t:'借入',b:'Tier3 から、熟成中の樽を担保にお金を借りられます。上限は樽の原価の50%（Tier4 は60%、Tier5 は70%）。金利はゲーム内の年4%（実1日で4%）で、元金はゲーム内の10年で毎日少しずつ自動で返します。決算書の BS の「借入」から借りる・返すを選べます。再創業の条件は、借入金と未払の法人税を除いた現金で判定します。'});
