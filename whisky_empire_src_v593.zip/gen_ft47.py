exec(open('gen_ft46.py').read().replace("open('functest46.js','w').write(s)","pass"))
import os
exec(open('functest47_fix.py').read())
if os.path.exists('functest47_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest47_add.js').read()+s[a:]
open('functest47.js','w').write(s)
