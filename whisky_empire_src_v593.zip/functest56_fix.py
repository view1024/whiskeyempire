# v5.5.1・v5.6 の変更に合わせて v5.5 までのテストを置き換える
# #42：図鑑のアイコンは1行に8つ（v5.5.1 利用者の指定）。幅は38px以上・高さ48px以上を条件にする
R2("if (b.classList.contains('ib') || b.classList.contains('visitor')) return; // ⓘは疑似要素で44px、来客は動きのある要素（56px）",
   "if (b.classList.contains('ib') || b.classList.contains('visitor')) return; // ⓘは疑似要素で44px、来客は動きのある要素（56px）\n          if (b.classList.contains('eic') && r.width >= 38 && r.height >= 48) return; // v5.5.1 図鑑のアイコンは1行に8つ（幅38px以上・高さ48px以上）")
# #90・#100：決算書は図鑑の画面に出す（小窓ではない）
R2("const o = { badge, title: document.getElementById('mc2').textContent.includes('決算書') };", "const o = { badge, title: document.getElementById('ep_fin').textContent.includes('決算書') && mo.classList.contains('h') && _ui.encTab === 'fin' };")
R2("const mc = document.getElementById('mc2'); o.hscroll = mc.scrollWidth - mc.clientWidth;", "const mc = document.getElementById('finBox'); o.hscroll = mc.scrollWidth - mc.clientWidth;")
R2("rec(90, '決算書の画面：図鑑のアイコン「決算書」から開き、", "rec(90, '決算書の画面：図鑑のアイコン「決算書」で図鑑の画面に出し（v5.5.1 小窓をやめた）、")
R2("card.click(); await new Promise(r => setTimeout(r, 60)); const fin = document.getElementById('mc2').textContent.includes('決算書') && !!document.getElementById('finBox'); closeM();", "card.click(); await new Promise(r => setTimeout(r, 60)); const fin = document.getElementById('ep_fin').textContent.includes('決算書') && !!document.querySelector('#ep_fin #finBox .fnav') && mo.classList.contains('h'); _ui.encTab = 'w';")
R2("・決算書は図鑑の入口の先頭のアイコンから開き、", "・決算書は図鑑の入口の先頭のアイコンで図鑑の画面に出し、")
# #109：日誌の名前
R2("const modal = '倉庫日誌' + document.getElementById('jnlList').textContent;", "const modal = (document.getElementById('ei_j').textContent.includes('日誌') ? '倉庫日誌' : '') + document.getElementById('jnlList').textContent;")
# #134：棚の🧾の印は v5.5.1 で廃止
R2("o.mark = !!document.querySelector(`#wScene .wcask[data-id=\"${l.id}\"] .wom`);", "o.mark = !document.querySelector('#wScene .wom');")
# #143：小人の絵と砂時計の演出は v5.5.1 で廃止（トーストだけ）
R2("!!document.getElementById('dwarf'), !!document.querySelector('.hgfly') || lowMotion()];", "!document.getElementById('dwarf'), !document.querySelector('.hgfly')];")
R2("（トースト「小人が砂時計を置いていきました（今日 n/5）」と小人・砂時計が飛ぶ演出）", "（トースト「小人が砂時計を置いていきました（今日 n/5）」だけ。小人の絵と砂時計が飛ぶ演出は v5.5.1 で廃止）")
# #157：決算書は図鑑のページとして確認する
R2("['hiMkt', 'hiFin', 'hgOpen', 'hiTier', 'hiChap'].forEach(a => v.push(['modal', a]));", "['hiMkt', 'hgOpen', 'hiTier', 'hiChap'].forEach(a => v.push(['modal', a]));")
R2("encTabs().forEach(([k]) => { if (k !== 'fin') v.push(['enc', k]); });", "encTabs().forEach(([k]) => v.push(['enc', k]));")
# #160：図鑑の入口は1行に8つ（日誌・設備に改名）・決算書も画面に出す・アイコンの下からスクロール
R2("const o = { lbs: ic.map(e => e.querySelector('.eil').textContent).join(), rows: new Set(rs.map(r => Math.round(r.top))).size, cols: new Set(rs.map(r => Math.round(r.left))).size, chips: !document.getElementById('encChips') };",
   "const o = { lbs: ic.map(e => e.querySelector('.eil').textContent).join(), rows: new Set(rs.map(r => Math.round(r.top))).size, cols: new Set(rs.map(r => Math.round(r.left))).size, chips: !document.getElementById('encChips') };\n      const eb = document.getElementById('encBody'); o.scroll = getComputedStyle(eb).overflowY === 'auto' && getComputedStyle(document.getElementById('te')).overflowY === 'hidden' && eb.getBoundingClientRect().top >= rs[0].bottom;")
R2("for (const k of ['w', 't', 'g', 'j', 'f', 's', 'r']) { document.getElementById('ei_' + k).click(); await new Promise(r => setTimeout(r, 40)); const p = document.getElementById('ep_' + k); pages[k] = !!p && p.getClientRects().length > 0 && p.textContent.trim().length > 0 && ['w', 't', 'g', 'j', 'f', 's', 'r'].filter",
   "for (const k of ['fin', 'w', 't', 'g', 'j', 'f', 's', 'r']) { document.getElementById('ei_' + k).click(); await new Promise(r => setTimeout(r, 40)); const p = document.getElementById('ep_' + k); pages[k] = !!p && p.getClientRects().length > 0 && p.textContent.trim().length > 0 && mo.classList.contains('h') && ['fin', 'w', 't', 'g', 'j', 'f', 's', 'r'].filter")
R2("document.getElementById('ei_fin').click(); await new Promise(r => setTimeout(r, 50)); o.fin = document.getElementById('mc2').textContent.includes('決算書') && _ui.encTab === 'w'; closeM();",
   "document.getElementById('ei_fin').click(); await new Promise(r => setTimeout(r, 50)); o.fin = !!document.querySelector('#ep_fin #finBox .fnav') && _ui.encTab === 'fin' && mo.classList.contains('h');")
R2("const ok = r.lbs === '決算書,銘柄,称号,創業地,倉庫日誌,設備の歩み,物語,記録' && r.rows === 2 && r.cols === 4 && r.chips",
   "const ok = r.lbs === '決算書,銘柄,称号,創業地,日誌,設備,物語,記録' && r.rows === 1 && r.cols === 8 && r.scroll && r.chips")
R2("rec(160, '図鑑（v5.5）：入口は4×2のアイコン（決算書・銘柄・称号・創業地／倉庫日誌・設備の歩み・物語・記録）で、押したページだけを出す・決算書は小窓・",
   "rec(160, '図鑑（v5.5.1）：入口は1行に8つのアイコン（決算書・銘柄・称号・創業地・日誌・設備・物語・記録）で、押したページだけをアイコンの下に出し、その下だけがスクロールする・決算書も同じ画面に出す・")
R2("使える注文があれば「注文に使う」が先頭で🧾の印・押すと", "使える注文があれば「注文に使う」が先頭（棚の🧾の印は v5.5.1 で廃止）・押すと")
# #116：決算書は図鑑の画面で確認する
R2("openFinModal(); await new Promise(r => setTimeout(r, 80)); const t = document.getElementById('mc2').textContent; o.rows = ['うち人件費'", "_fin.i = 0; _ui.encTab = 'fin'; switchTab('te'); await new Promise(r => setTimeout(r, 80)); const t = document.getElementById('ep_fin').textContent; o.rows = ['うち人件費'")
R2("const cols = [...document.querySelectorAll('#mc2 .fbd .fcol')]", "const cols = [...document.querySelectorAll('#ep_fin .fbd .fcol')]")
# #12：スコットランドではスコッチの単価×1.2（v5.6 その地の市場）
R2("const expect = 100 * 8 / 3 * 1.0 * (0.7 + 0.6 * m) * distMult() * saleMult() * repMult();\n      T(12, 'Glenvivid 8年・q1・一致0.5 ≈ $267', near(m, 0.5, 1e-3) && near(u, 266.67, 1e-3) && near(u, expect)",
   "const expect = 100 * 8 / 3 * 1.0 * (0.7 + 0.6 * m) * distMult() * saleMult() * repMult() * 1.2;\n      T(12, 'Glenvivid 8年・q1・一致0.5 ≈ $267×1.2（v5.6 スコットランドではスコッチの単価×1.2）', near(m, 0.5, 1e-3) && near(u, 320, 1e-3) && near(u, expect)")
# #39：販売地域・輸出市場の機能はなくなった（売るの切り替えは最大4つ）
R2("const f1 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));", "const f1 = ['tank', 'rel', 'comp', 'blend', 'recipe'].map(k => feat(k));")
R2("const f2 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));", "const f2 = ['tank', 'rel', 'comp', 'blend', 'recipe'].map(k => feat(k));")
R2("f2.join() === 'true,true,true,true,true,false,true' && chips2 === 5", "f2.join() === 'true,true,true,true,true' && chips2 === 4")
# #84・#85：販売地域・輸出市場の購入はなくなった
R2("      upgFac('malting'); purchaseRegion(Object.keys(REGIONS).find(id => !G.regions[id]) || 'x');\n      const rx = REGIONS_EX.find(x => !G.regionsEx.includes(x.id)); if (rx) buyExRegion(rx.id);\n", "      upgFac('malting');\n")
R2(" && r.cats.includes('rcp') && r.cats.includes('rg'), JSON.stringify({ cats: r.cats", " && r.cats.includes('rcp'), JSON.stringify({ cats: r.cats")
