function offline(){
  if(_offlineGate)return;
  const now=Date.now();
  const raw=Math.max(0,now-(G.ls||now));
  G.ls=now;
  if(raw<OFFLINE_MIN_MS){
    // v4.6 まだ閉じていない放置の報告があれば出し直す（ページの再読込・バツで閉じた場合）
    if(!_hgRun){const p=offRepGet();if(p&&!p.skip&&$('mo')&&$('mo').classList.contains('h')){diagLog('offline-reshow');showOfflineSummaryModal(p);}}
    return;
  }
  const H=Math.min(raw,BALANCE.OFFLINE_CAP_H*3600000);
  const A=Math.min(raw,BALANCE.AGING_OFFLINE_CAP_H*3600000);
  let info={elapsedMs:raw,prodMs:H,ageMs:A,capP:raw>H,capA:raw>A};
  const te0=G.te;
  _offlineRunning=true;_msHit=[];_goalOff=0;_goalOffIds=[];
  try{
    const f=prodFlows();let hH=H/3600000;
    // v4.4 大麦：在庫と自動仕入れで賄えた時間だけ生産する
    const c0=G.stats.barleyCost||0;const p0=f.bok?f.p[0]:stageCap(0);const need=p0*hH;const got=barleyTake(need);const r=need>0?Math.min(1,got/need):1;
    info.barleyStopH=need>0?hH*(1-r):0;hH*=r;
    const surplus=f.surplusPh*getEventMult('passive')*hH;
    earn(surplus,'ext');info.surplus=surplus;
    if(need>0){barleyState()._used=got;barleyAutoRefill(H/3600000);}
    info.barleyCost=(G.stats.barleyCost||0)-c0;prodInvalidate();
    const mf0=acctMfgPaid();const N=mfgPay(f.newmake*hH);info.newmake=N;info.mfgCost=acctMfgPaid()-mf0; // v5.7 製造費を払えた分だけ
    const ag0=acctAgePaid();G.lots.forEach(l=>lotAdvance(l,A));ageCostTick(G.lots,A);info.ageCost=acctAgePaid()-ag0;
    G.lots=G.lots.filter(l=>l.L>=BALANCE.BOTTLE_L);
    let tank=G.tank||0,filled=0;
    const a=G.auto&&G.auto.fill;
    if(a&&a.on&&N>0){
      const ct=caskType(a.cask),sz=caskSize(a.size);
      if(caskTypeUnlocked(ct)&&caskSizeUnlocked(sz)){
        const c=caskCost(a.cask,a.size);
        const free=Math.max(0,whSlots()-G.lots.length);
        const k=Math.max(0,Math.min(free,Math.floor((tank+N)/sz.litres),c>0?Math.floor(G.cash/c):free));
        for(let j=1;j<=k;j++){
          const tj=Math.max(0,(j*sz.litres-tank)/f.newmake)*3600000;
          pay(c,'pur','cask');
          const lot=makeLot(ct,sz,{at:now-raw+tj,c:sz.litres*(acctBAvg()+tankMfgU())+c});
          if(A>tj)lotAdvance(lot,A-tj);
          G.lots.push(lot);filled++;
        }
        tank=tank+N-k*sz.litres;
        G.stats.filled+=filled;if(filled)dmProgress('dm_fill',filled);
      }else tank+=N;
    }else tank+=N;
    const cap=tankCap();let over=0;
    if(tank>cap){over=tank-cap;tank=cap;earn(over*nmPrice(),'ext');}
    G.tank=tank;info.filled=filled;info.overflowL=over;info.goals=_goalOff;info.goalIds=_goalOffIds.slice();
    G.stats.maxAge=Math.max(G.stats.maxAge||0,...G.lots.map(l=>l.age));
    info.bottled=botTick(H);
    info.delivered=ordAutoTick();
    const ex=ordExpireTick(now);info.expired=ex.expired;info.failed=ex.failed;
    info.arrived=ordSpawnTick(now);
    info.spot=autoSpotTick();
    info.milestones=[...new Set(_msHit)].sort((x,y)=>x-y);
    {const sw=staffTick(H);info.wage=sw.paid;info.offH=sw.offH;}
    {const lt=loanTick(H);info.interest=lt.i;info.repaid=lt.p;} // v5.7 借入の利息と返済
  }finally{
    _offlineRunning=false;_msHit=[];
  }
  info.earned=G.te-te0;
  info.urgent=G.orders.filter(o=>o.dueAt-now<6*3600000).length;
  if(_hgRun)info.skip=true;
  else{info=offRepMerge(info);offRepSet(info);}
  diagLog('offline',Math.round(raw/60000)+'分'+(info.skip?' 砂時計':''));
  showOfflineSummaryModal(info);
}
function showOfflineSummaryModal(info){
  const mo=document.getElementById('mo'),mc2=document.getElementById('mc2');
  if(!mo||!mc2)return;
  _offlineGate=true;
  const row=(k,v,col)=>`<div class="msr"><div class="msl">${k}</div><div class="msv" style="color:${col||'var(--cream)'}">${v}</div></div>`;
  let h='';
  h+=row(info.skip?'進めた時間':'不在時間',fmtDuration(info.elapsedMs));
  h+=row('売上（外販・直販・納品）','+'+fmt(info.earned),'var(--green)');
  if(info.barleyCost>0)h+=row('原料費（大麦）','−'+fmt(info.barleyCost),'var(--amber)');
  if(info.mfgCost>0)h+=row('製造費','−'+fmt(info.mfgCost),'var(--amber)');
  if(info.ageCost>0)h+=row('熟成費（倉庫）','−'+fmt(info.ageCost),'var(--amber)');
  if(info.interest>0||info.repaid>0)h+=row('借入の利息・返済','−'+fmt((info.interest||0)+(info.repaid||0)),'var(--amber)');
  if(info.barleyStopH>0.05)h+=row('大麦が切れて止まっていた時間',fmtDuration(info.barleyStopH*3600000),'var(--red)');
  if(info.newmake>0)h+=row('蒸留したニューメイク',fmtL(info.newmake));
  if(info.filled>0)h+=row('自動で詰めた樽',info.filled+'樽');
  if(info.overflowL>0)h+=row('タンクから溢れて外販',fmtL(info.overflowL));
  if(info.bottled>0)h+=row('瓶詰め完了',fmtN(info.bottled)+'本');
  if(info.delivered>0)h+=row('自動で納品した注文',info.delivered+'件','var(--green)');
  if(info.milestones&&info.milestones.length)h+=row('節目に達した原酒',info.milestones.map(m=>m+'年').join('・'),'var(--gold2)');
  if(info.arrived>0)h+=row('届いた注文',info.arrived+'件','var(--gold2)');
  if(info.expired>0)h+=row('期限切れの注文',info.expired+'件','var(--muted)');
  if(info.failed>0)h+=row('期限切れの予約（評判低下）',info.failed+'件','var(--red)');
  let note='';
  if(info.capP)note+=`<div style="margin-top:6px">※ 生産は上限の${BALANCE.OFFLINE_CAP_H}時間分のみ計算しました。</div>`;
  if(info.capA)note+=`<div style="margin-top:2px">※ 熟成は上限の${BALANCE.AGING_OFFLINE_CAP_H}時間分（ゲーム内${(BALANCE.AGING_OFFLINE_CAP_H/24).toFixed(0)}年）のみ進みました。</div>`;
  mc2.innerHTML=`<div class="mt">${info.skip?'⏳ '+Math.round(info.elapsedMs/3600000)+'時間進めました':'🌙 おかえりなさい！'}</div>
    <div class="ms">${info.skip?'熟成の砂時計を1個使いました':'蒸留所は不在の間も稼働していました'}</div>
    <div style="margin-top:8px">${h}</div>
    ${note?`<div style="font-family:var(--fm);font-size:12px;color:var(--muted);margin-top:8px;line-height:1.5">${note}</div>`:''}
    ${info.urgent>0?`<div style="margin-top:10px;padding:8px 10px;border:1px solid var(--amber);border-radius:8px;font-family:var(--fm);font-size:12px;color:var(--amber)">⏰ 期限が6時間以内の注文が${info.urgent}件あります</div>`:''}
    <div style="display:grid;grid-template-columns:${info.urgent>0?'1fr 1fr':'1fr'};gap:8px;margin-top:14px">
      <button type="button" onclick="closeOfflineModal()" style="width:100%;background:var(--gold);border:none;border-radius:8px;padding:10px;font-family:var(--fm);font-size:13px;color:var(--bg);font-weight:700;cursor:pointer">受け取る</button>
      ${info.urgent>0?`<button type="button" onclick="closeOfflineModal();switchTab('tsale')" style="width:100%;background:var(--bg3);border:1px solid var(--gold);border-radius:8px;padding:10px;font-family:var(--fm);font-size:13px;color:var(--gold2);cursor:pointer">売るへ</button>`:''}
    </div>
    ${info.skip?'':'<div style="font-family:var(--fm);font-size:12px;color:var(--muted);margin-top:10px;line-height:1.5;text-align:center">20歳未満の者の飲酒は法律で禁じられています。</div>'}`;
  const closeBtn=document.getElementById('moClose');
  if(closeBtn)closeBtn.onclick=closeOfflineModal;
  mo.classList.remove('ctr');mo.classList.remove('h');
  rall();
  save();
}
function closeOfflineModal(){
  const mo=document.getElementById('mo');
  if(mo)mo.classList.add('h');
  const closeBtn=document.getElementById('moClose');
  if(closeBtn)closeBtn.onclick=closeM;
  _offlineGate=false;offRepClear();
  if(_pendingMigModal){_pendingMigModal=false;setTimeout(showMigrateModal,200);}
}
