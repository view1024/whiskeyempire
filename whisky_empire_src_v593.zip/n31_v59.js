// ============================================================
// v5.9 売るタブの統合・行の形の統一・小人（職人）の空き席
// ============================================================
// 実装計画：https://claude.ai/code/artifact/737b5630-27e3-4a4a-9e0d-d9af190f8521
//  1 売る：「出荷」（瓶詰め → 在庫 → 注文）を1画面に。在庫の内訳は在庫の行を押すと開く（_ui.invOpen。タブを移るとたたむ）
//  2 強化：設備の選択が未決でも「強化 $…」を出し、押すと先に選ぶ小窓 → 選んだら続けて強化（_brUp）。名前の横に「設備を選べます」
//  3・4 ①②③をやめ、どの行も左に幅52pxの絵の列（.ric）→ 名前（幅390で左から81px）
//  5 ホームの瓶は常に在庫の本数（v5.9.1 瓶詰め中の「詰め中」の表記はやめた）
//  6 空き席：（v5.9.3 から常に）担当のいない設備の絵に点線の小人と「＋」（.wseat）。
//    （v5.9.2 点線の小人はやめ「＋」だけ）見出しに「待機 n」（押すとそのタブの空き席が3秒光る）。初めて職人を雇ったあと、空き席に1回だけ「押すとここで働きます」
const V59={INV_TOP:4,GLOW_MS:3000,TIP_MS:6000};

// ---------- 1 在庫の内訳 ----------
function invToggle(on){_ui.invOpen=on===undefined?!_ui.invOpen:!!on;if(!_ui.invOpen)_ui.invAll=false;rShip();}
function invDetailHtml(){
  const a=G.auto.spot;
  let h=`<div class="invk"><span class="sm">自動直販 ${ib('spot')}</span><button type="button" class="sb2 ${a.on?'':'gh'}" data-act="autoSpot" aria-pressed="${a.on}">${a.on?'ON':'OFF'}</button>
    <span class="sm" style="margin-left:auto">各銘柄 <b style="color:var(--gold2)">${a.defKeep}本</b>を残す</span><button type="button" class="sb2 gh" data-act="keepDec" aria-label="残す本数を減らす">−</button><button type="button" class="sb2 gh" data-act="keepInc" aria-label="残す本数を増やす">＋</button></div>`;
  if(!G.bottles.length)return h+`<div class="sm tc" style="padding:8px">瓶の在庫はありません</div><button type="button" class="invfold" data-act="invToggle">たたむ ▴</button>`;
  const pids=[...new Set(G.bottles.map(r=>r.pid))].sort((p,q)=>invTotal(q)-invTotal(p));
  const show=_ui.invAll?pids:pids.slice(0,V59.INV_TOP);
  show.forEach(pid=>{
    const sp=productSpec(pid)||{icon:'🍾',name:'?'};const rows=G.bottles.filter(r=>r.pid===pid).sort((x,y)=>y.age-x.age);
    h+=`<div class="invb"><div class="row sb"><span class="tt" style="font-size:13px">${sp.icon} ${escapeHtml(sp.name)}</span><span class="vv">${fmtN(invTotal(pid))}本</span></div>`;
    rows.forEach(r=>{
      h+=`<div class="row sb" style="margin-top:4px"><span class="sm">${r.age}年 ${starQ(r.q)} ・ ${fmtN(r.n)}本 ・ ${fmt(rowUnit(r)*BALANCE.SPOT_MULT)}/本</span><span class="row" style="gap:4px"><button type="button" class="sb2 gh" data-act="spotSell" data-id="${r.id}" data-n="10">10本</button><button type="button" class="sb2 gh" data-act="spotSell" data-id="${r.id}" data-n="all">全部</button></span></div>`;
    });
    h+='</div>';
  });
  if(pids.length>show.length)h+=`<button type="button" class="invfold" data-act="invAll">すべて見る（${pids.length}銘柄）</button>`;
  return h+`<button type="button" class="invfold" data-act="invToggle">たたむ ▴</button>`;
}

// ---------- 2 設備の選択と強化 ----------
let _brUp=null; // 強化を押して選ぶ小窓を開いた設備（選んだら続けて強化する）
function brBadge(id){return brPending(id)?` <span class="pbr" data-act="brOpen" data-fac="${id}" role="button" aria-label="設備を選べます">設備選択</span>`:'';}

// ---------- 5 数の短い表記（1万以上は「1.2万」） ----------
function cntShort(n){n=Math.floor(n||0);return n>=1e8?(n/1e8).toFixed(1).replace(/\.0$/,'')+'億':n>=1e4?(n/1e4).toFixed(1).replace(/\.0$/,'')+'万':fmtN(n);}

// ---------- 6 空き席・待機の札 ----------
function idleList(){return [OWNER].concat(staffList()).filter(w=>!placeOf(w));}
// v5.9.3 担当のいない設備には常に「＋」（あなたは必ずいて、人は置き場所を移せるので、待機がいなくても置ける）
function seatOk(fac){return placeOk({k:'fac',id:fac})&&!placeWho('fac',fac);}
const SEAT_SVG='<svg class="seatw" viewBox="0 0 20 30" width="20" height="30" aria-hidden="true"><path d="M3 12L10 2L17 12z"/><circle cx="10" cy="16" r="4.5"/><rect x="3.5" y="21" width="13" height="8" rx="2"/></svg>';
function seatHtml(k,id){return `<span class="wseat" data-act="seatTap" data-k="${k}" data-id="${id}" role="button" aria-label="空き席：押すと人を置く"><b class="seatp">＋</b></span>`;} // v5.9.2 点線の小人はやめ「＋」だけ
function facSeat(fac){return seatOk(fac)?seatHtml('fac',fac):'';}
// 倉庫の行：樽があれば空き席を1つ（押すと配置モード。置ける樽が光る。v5.9.3 待機がいなくても出す）
function lotSeat(){return G.lots.length?seatHtml('lot',''):'';}
function seatTap(k,id){
  const idle=idleList();
  if(k==='fac'){openPlacePick({k:'fac',id},'close');return;}
  if(idle.length===1){pmStart(idle[0]);switchTab('tcel');return;}
  // v5.9.3 待機がいなければ全員から選ぶ（働いている人は「今は…」を添え、選ぶと移る）
  const pool=idle.length?idle:[OWNER].concat(staffList());
  openModal(`<div class="mt">👷 誰を樽に置く？</div><div class="ms">選んだあと、樽を押してください</div>${pool.map(w=>`<button type="button" class="brr" data-act="pmStart" data-sid="${w.id}"><span class="brr1">${escapeHtml(wName(w))}${placeOf(w)?'（今は'+escapeHtml(placeName(placeOf(w)))+'）':''}</span><span class="brr2">${w===OWNER?'×1.10':'技'+w.st.waza+' ・ Lv'+w.lv}</span></button>`).join('')}<button type="button" class="cb" data-act="closeM">閉じる</button>`);
}
function idleChipHtml(){const n=idleList().length;return n?`<button type="button" class="idlec" data-act="idleGlow" aria-label="待機中の人 ${n}（押すと空き席が光る）" title="待機中の人">${SEAT_SVG}<b>${n}</b></button>`:'';}
let _glowT=null;
function idleGlow(){
  const t=curTabId();const sts=document.querySelectorAll('#'+t+' .wseat');
  if(!sts.length){toast(t==='tcel'||!G.lots.length?'このタブに空き席はありません':'このタブに空き席はありません（樽は「寝かせる」）',2200);return;}
  document.body.classList.add('seatglow');clearTimeout(_glowT);_glowT=setTimeout(()=>document.body.classList.remove('seatglow'),V59.GLOW_MS);
  sts[0].scrollIntoView({block:'nearest'});
}
function idleChipsUpd(){
  const h=idleChipHtml();
  ['idleTb','idleCel','idleSale'].forEach(id=>{const e=$(id);if(e&&e._h!==h){e.innerHTML=h;e._h=h;}});
}
// 初めて職人を雇ったあと、見えている空き席に1回だけ吹き出し
function seatTipTick(){
  const hs=hsState();if(hs.seatTip||!staffList().length)return;
  const s=[...document.querySelectorAll('.tab.on .wseat')].find(e=>e.getClientRects().length);if(!s)return;
  hs.seatTip=1;save();
  const b=document.createElement('span');b.className='seattip';b.textContent='押すとここで働きます';s.appendChild(b);
  setTimeout(()=>b.remove(),V59.TIP_MS);
}

// ---------- data-act ----------
function extAct59(act,b,id){
  switch(act){
    case 'invToggle': invToggle(); return true;
    case 'invAll': _ui.invAll=true; rShip(); return true;
    case 'seatTap': seatTap(b.dataset.k,id); return true;
    case 'idleGlow': idleGlow(); return true;
  }
  return false;
}
