# v4.9.1〜v5.0 の変更に合わせて v4.9 までのテストを置き換える
# v4.9.1 タイムラプス廃止：#119 を削除（#121 で「どこにもない」ことを確かめる）
a=s.index("  // ---------- #119 タイムラプス"); b=s.index("  // ---------- #120 倉庫日誌に職人の出来事")
s=s[:a]+s[b:]
# #84 は「40日後」の月またぎで、実行日が月末でないと2か月にまたがらず失敗していた（日付に依存しない判定に）
R2("rec0.m === mBefore && rec0.to === mBefore + 1;","rec0.m === mBefore && rec0.to === G.acct.cur.m - 1;")

# ===== v5.0 職人の配置・熟成庫の棚 =====
def BLOCK(start, end, new):
    global s
    a = s.index(start); b = s.index(end, a)
    s = s[:a] + new + s[b:]
# 3人の職人：1人目は目標が近い樽、2人目は待機（通路）、3人目は蒸留器
R2("G.staff[0].post = 'watch'; G.staff[1].post = 'fill'; G.staff[2].post = 'still'; prodInvalidate(); })()`",
   "G.staff.forEach(s => s.at = null); G.ownerAt = null; placeInvalidate(); const L0 = G.lots.filter(l => lotGoalEta(l) > 0).sort((a, b) => lotGoalEta(a) - lotGoalEta(b)); G.staff[0].at = { k: 'lot', id: L0[0].id }; G.staff[2].at = { k: 'fac', id: 'distillation' }; placeInvalidate(); prodInvalidate(); })()`")
# #60：倉庫の一覧は棚（枠の中でスクロール）
R2("const w = document.querySelector('#whSummary .whgw');", "const w = document.getElementById('wScroll');")
R2("casks: document.querySelectorAll('#whSummary .ck2:not(.em)').length", "casks: document.querySelectorAll('#wScene .wcask').length")
# #105
R2("rec(105, '配布版は860KB以下（v4.7〜v4.9 で各+40KBまで）：", "rec(105, '配布版は860KB以下（v4.7〜v5.0 で各+40KBまで）：")
# #88-89：①②のたたみ・棚
BLOCK("  // ---------- #88-89 寝かせる", "  // ---------- #90 ", r'''  // ---------- #88-89 寝かせる：①→③の流れ（自動で詰めている間は①②をたたむ）・棚の樽の見た目 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const vis = () => [...document.getElementById('tcel').children].filter(e => e.getClientRects().length).map(e => e.id || e.className).join();
      hsState().casks = CASK_TYPES.map(t => t.id).concat(CASK_SIZES.map(z => z.id)); G.auto.fill.on = true; _ui.celOpen = false; switchTab('tcel'); rCellar();
      const o = { fold: vis(), fno: (document.querySelector('#celTank .cno') || {}).textContent, ftxt: document.getElementById('celTank').textContent.includes('自動で樽詰め中') };
      document.querySelector('#celTank [data-act="celOpen"]').click();
      o.open = vis(); o.ys = ['celTank', 'fillBox', 'whSummary'].map(id => document.getElementById(id).getBoundingClientRect().top); o.nos = ['celTank', 'fillBox', 'whSummary'].map(id => (document.querySelector('#' + id + ' .cno') || {}).textContent);
      o.price = document.querySelector('#fillBox .cp1').textContent; o.cc = fmt(caskCost(G.auto.fill.cask, G.auto.fill.size));
      _ui.celOpen = false; G.auto.fill.on = false; rCellar(); o.off = vis(); G.auto.fill.on = true; rCellar();
      // 棚：1段6樽・樽の色帯＝種類・大きさ＝サイズ・線＝残量・札＝目標までの残り
      const cells = [...document.querySelectorAll('#wScene .wcask')]; const bad = [];
      const order = shelfLots().map(l => l.id).join() === cells.map(c => c.dataset.id).join();
      const wOf = c => { const b = [...c.querySelectorAll('svg g path, path')].filter(p => p.closest('.wkx') === null && !p.classList.contains('pmk')).map(p => p.getBBox()); return Math.max(...b.map(x => x.x + x.width)) - Math.min(...b.map(x => x.x)); };
      cells.forEach(c => { const l = G.lots.find(x => x.id === c.dataset.id); const fills = [...c.querySelectorAll('path')].map(p => p.getAttribute('fill'));
        const has = c0 => [c0, pxMix(c0, '#000000', .28), pxMix(c0, '#ffffff', .2)].some(x => fills.includes(x)); if (!has(PX_CT[l.cask] || '#6a6a6a') || !has(WOOD[lotAgeStep(l)])) bad.push('col:' + l.id);
        const g = c.querySelector('[data-lgg]'); if (Math.abs(+g.getAttribute('width') - Math.round(36 * lotPct(l) / 100)) > 0) bad.push('gauge:' + l.id);
        const lb = document.querySelector(`#wScene [data-wse="${l.id}"]`); if (!lb || lb.textContent !== shelfLabel(l)) bad.push('lbl:' + l.id); });
      const q = G.lots.find(l => l.size === 'quarter'), bt = G.lots.find(l => l.size === 'butt');
      const cq = cells.find(c => c.dataset.id === q.id), cb = cells.find(c => c.dataset.id === bt.id);
      const xs = cells.map(c => +c.querySelector('rect').getAttribute('x')); const cols = new Set(xs).size;
      const l0 = G.lots[0]; const g0 = +document.querySelector(`[data-lgg="${l0.id}"]`).getAttribute('width'); l0.L = l0.L * 0.5; sceneLight(); const g1 = +document.querySelector(`[data-lgg="${l0.id}"]`).getAttribute('width');
      return Object.assign(o, { n: cells.length, lots: G.lots.length, order, bad, cols, sizeOk: wOf(cq) < wOf(cb), dec: g1 < g0, noGrid: !document.querySelector('.whg2,.ck2,.whkey,.lgd') });
    });
    rec(88, '寝かせる：自動で詰めている間は ①② を1行にたたみ（押すと開く）、開くと「① タンクの新酒 → ② 空き樽を仕入れて詰める（仕入れ値）→ ③ 倉庫」を流れる矢印でつなぐ・自動OFFは開いたまま', r.fold === 'thead,celJnl,celTank,whSummary' && r.fno === '①②' && r.ftxt && r.open === 'thead,celJnl,celTank,celF1,fillBox,celF2,whSummary' && r.ys[0] < r.ys[1] && r.ys[1] < r.ys[2] && r.nos.join() === '①,②,③' && r.price.includes(r.cc) && r.off === r.open, JSON.stringify(r));
    rec(89, '倉庫の棚：全部の樽を年数の順に1段6樽で並べる・帯の色で種類・木の色で熟成・大きさでサイズ・札の下の線で残量（天使の分け前で減る）・札に目標までの残り時間・樽のマスの一覧は廃止', r.n === r.lots && r.order && r.bad.length === 0 && r.cols === 6 && r.sizeOk && r.dec && r.noGrid, JSON.stringify({ n: r.n, order: r.order, bad: r.bad, cols: r.cols, sizeOk: r.sizeOk, dec: r.dec, noGrid: r.noGrid }));
    if (errors.length) rec('E44', '寝かせるテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
''')
# #108：棚の樽の色つや・完成・小窓で目標を変える
BLOCK("  // ---------- #108 ", "  // ---------- #109 ", r'''  // ---------- #108 棚の樽：色つや10段階・完成の印・札は目標までの残り・小窓で目標を変える・次の目標までの時間 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('tcel');
      const l0 = G.lots[0], l1 = G.lots[1]; l0.age = 0.5; l0.goal = 3; l0.gs = 0; l1.age = 10.2; l1.goal = 12; l1.gs = 8; l1.gd = 8; l1.gt = Date.now();
      rCellar(); await new Promise(r => setTimeout(r, 50));
      const c0 = document.querySelector(`#wScene .wcask[data-id="${l0.id}"]`), c1 = document.querySelector(`#wScene .wcask[data-id="${l1.id}"]`);
      const f = c => [...c.querySelectorAll('path')].map(p => p.getAttribute('fill'));
      const o = { w0: f(c0).includes(WOOD[0]), w1: f(c1).includes(WOOD[4]), done: c1.classList.contains('wdone'), lb1: document.querySelector(`[data-wse="${l1.id}"]`).textContent, lb0: document.querySelector(`[data-wse="${l0.id}"]`).textContent, exp0: fmtShort(lotGoalEta(l0)), next: (document.querySelector('[data-lnext]') || {}).textContent };
      openLotModal(l0.id); const mt = document.getElementById('mc2').textContent; o.modal = mt.includes('熟成の目標') && mt.includes('担当'); o.noDup = ![...document.querySelectorAll('#mc2 .msl')].some(e => e.textContent === '次の節目');
      const chip = [...document.querySelectorAll('#mc2 [data-act="lotGoal"]')].find(b => b.dataset.v === '8'); chip.click(); await new Promise(r => setTimeout(r, 50));
      o.setGoal = [l0.goal, +l0.gs.toFixed(2)]; closeM();
      return o;
    });
    const ok = r.w0 && r.w1 && r.done && r.lb1 === '完成' && r.lb0 === r.exp0 && /次の目標まで あと/.test(r.next) && r.modal && r.noDup && r.setGoal[0] === 8 && r.setGoal[1] === 0.5;
    rec(108, '棚の樽：年数で木の色が10段階に変わる・届いた樽は「完成」の札と枠・札は目標までの残り時間・小窓で目標を選べ担当も出る・倉庫の見出しに次の目標までの時間', ok, JSON.stringify(r));
    if (errors.length) rec('E59', '棚の樽テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
''')
# #112：採用（空いている配置先へ自動で入る）・在籍の上限・画面
BLOCK("  // ---------- #112 ", "  // ---------- #113 ", r'''  // ---------- #112 採用・在籍の上限・自動で空いている配置先へ・採用費の計上・画面 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; G.bq = []; const o = { cap: staffCap() };
      const c = staffCandState(); const fee = staffHireFee(c.list[0]); const h0 = G.acct.cur.sga.hire; const cash0 = G.cash;
      prodInvalidate(); const bn = STAGES[prodFlows().bottleneck].fac;
      o.hire = staffHire(0); o.fee = [Math.round(G.acct.cur.sga.hire - h0), fee, Math.round(cash0 - G.cash)];
      o.first = placeKey(G.staff[0].at) === 'fac:' + bn;
      let g = 0; while (G.staff.length < staffCap() && g++ < 40) { const cc = staffCandState(); if (!cc.list.length) { cc.free = 1; staffRefresh(); } staffHire(0); }
      o.n = G.staff.length; o.over = staffHire(0);
      const keys = G.staff.filter(s => s.at).map(s => placeKey(s.at)); o.uniq = new Set(keys).size === keys.length; o.lots = keys.filter(k => k.startsWith('lot:')).length;
      openStaffModal('post'); o.ui = document.querySelectorAll('#mc2 .plc').length >= 5 && !!document.querySelector('#mc2 [data-act="placeAuto"]'); openStaffModal('list'); o.ui2 = document.querySelectorAll('#mc2 .sfc').length; openStaffModal('hire'); const t = document.getElementById('mc2').textContent; o.ui3 = t.includes('求人を出し直す') || t.includes('今日の候補者はいません'); closeM();
      return o;
    });
    const ok = r.cap === 17 && r.hire && r.fee[0] === r.fee[1] && r.fee[2] === r.fee[1] && r.first && r.n === 17 && r.over === false && r.uniq && r.lots > 0 && r.ui && r.ui2 === 17 && r.ui3;
    rec(112, '採用：採用費（時給24時間分）を払い、空いている配置先（いちばん遅い工程→瓶詰めの予約があればボトリング→目標が近い樽）に入る・在籍は17人まで・1か所1人・配置/在籍/採用の画面', ok, JSON.stringify(r));
    if (errors.length) rec('E63', '採用テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
''')
# #113：配置の倍率
BLOCK("  // ---------- #113 ", "  // ---------- #114 ", r'''  // ---------- #113 配置の倍率：1.10〜1.50（能力とLv）・設備は工程の能力と瓶詰め・樽は熟成・研修中と休業中は1.00・宙に浮く効果はない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (at, st, lv) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st, tr: 'calm', lv: lv || 1, xp: 0, at, hired: 0, train: 0, care: '' });
      const S = (w, t, m) => ({ waza: w, tegiwa: t, mekiki: m });
      prodInvalidate(); const base = { cap0: stageCap(0), cap3: stageCap(3), slots: whSlots(), board: boardSize(), bph: botRate(), nm: prodFlows().newmake };
      const l = G.lots[0]; const ar0 = agingRate(l);
      const set = L => { G.staff = L; G.ownerAt = null; placeInvalidate(); prodInvalidate(); };
      set([mk({ k: 'fac', id: 'malting' }, S(1, 10, 5))]); const m1 = stageCap(0) / base.cap0;           // 目利き5・Lv1
      set([mk({ k: 'fac', id: 'distillation' }, S(1, 8, 1), 5)]); const m2 = stageCap(3) / base.cap3;    // 手際8・Lv5
      set([mk({ k: 'fac', id: 'bottling' }, S(1, 10, 1), 10)]); const m3 = botRate() / base.bph;         // 手際10・Lv10
      set([mk({ k: 'lot', id: l.id }, S(10, 1, 1), 10)]); const m4 = agingRate(l) / ar0;                // 技10・Lv10
      const tr = mk({ k: 'lot', id: l.id }, S(10, 1, 1), 10); tr.train = Date.now() + 3600000; set([tr]); const mTr = agingRate(l) / ar0;
      set([mk({ k: 'lot', id: l.id }, S(10, 1, 1), 10)]); G.staffOff = true; const mOff = agingRate(l) / ar0; G.staffOff = false;
      // 17人を置いても、樽の枠・注文枠・歩留まり・品質は変わらない
      const L = []; for (let i = 0; i < 17; i++) L.push(mk(null, S(10, 10, 10), 10)); set(L); placeAuto(true);
      const pv = botPreview(G.uw[0], 1, 'old', [], 0); const pv0q = pv.ok ? pv.q : null;
      const none = { slots: whSlots() - base.slots, board: boardSize() - base.board };
      set([]); const pv2 = botPreview(G.uw[0], 1, 'old', [], 0);
      return { m1, m2, m3, m4, mTr, mOff, none, q: [pv0q, pv2.ok ? pv2.q : null], fn: typeof staffFx === 'undefined' && typeof POSTS === 'undefined' };
    });
    const e = (st, lv) => 1.1 + 0.4 * (0.5 * (st - 1) / 9 + 0.5 * (lv - 1) / 9);
    const ok = Math.abs(r.m1 - e(5, 1)) < 1e-9 && Math.abs(r.m2 - e(8, 5)) < 1e-9 && Math.abs(r.m3 - 1.5) < 1e-9 && Math.abs(r.m4 - 1.5) < 1e-9 && r.mTr === 1 && r.mOff === 1 && r.none.slots === 0 && r.none.board === 0 && r.q[0] === r.q[1] && r.fn;
    rec(113, '配置の倍率：m＝1.10＋0.40×(0.5×(能力−1)/9＋0.5×(Lv−1)/9)（製麦室は目利き・ほかの設備は手際・樽は技）・設備は工程の能力と瓶詰めの速さ・樽は熟成の速さ・研修中と休業中は1.00・17人置いても樽の枠・注文枠・品質は変わらない', ok, JSON.stringify(r));
    if (errors.length) rec('E64', '配置の倍率テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
''')
# #114：給与（配置先で）
R2("G.dl = 3; const mk = (post) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv: 1, xp: 0, post, hired: 0, train: 0, care: '' });\n      G.staff = [mk('still'), mk('buy')]; prodInvalidate();",
   "G.dl = 3; const mk = (at) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv: 1, xp: 0, at, hired: 0, train: 0, care: '' });\n      G.staff = [mk({ k: 'fac', id: 'distillation' }), mk({ k: 'fac', id: 'malting' })]; placeInvalidate(); prodInvalidate();")
R2("Math.abs(r.off.cap - 1 / 1.075) < 0.001", "Math.abs(r.off.cap - 1 / (1.1 + 0.4 * 0.5 * 4 / 9)) < 0.001")
# #115：熟練度（配置先で）
R2("G.dl = 3; const mk = (post, lv) => ({ id: uid('s'), nm: 'T' + lv, seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv, xp: 0, post, hired: 0, train: 0, care: '' });\n      G.staff = [mk('still', 1), mk(null, 1), mk('fill', 4)]; prodInvalidate();",
   "G.dl = 3; const mk = (at, lv) => ({ id: uid('s'), nm: 'T' + lv, seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv, xp: 0, at, hired: 0, train: 0, care: '' });\n      G.staff = [mk({ k: 'fac', id: 'malting' }, 1), mk(null, 1), mk({ k: 'lot', id: G.lots[0].id }, 4)]; placeInvalidate(); prodInvalidate();")
R2("keep[0].lv === 4 && keep[0].post === null;", "keep[0].lv === 4 && keep[0].at === null;")
R2("rec(115, '熟練度：持ち場で1時間1経験（Lv2まで24）・持ち場なしは伸びない", "rec(115, '熟練度：配置先で1時間1経験（Lv2まで24）・待機は伸びない")
# #117：棚の景色
BLOCK("  // ---------- #117 ", "  // ---------- #118 ", r'''  // ---------- #117 倉庫の棚の景色：樽の担当は樽の横・待機の人と「あなた」は通路・寝かせるを開いている間だけ動く・動きを減らす設定で止まる ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 200));
      const sc = document.getElementById('wScene'); const wk = [...sc.querySelectorAll('.wk')];
      const o = { ids: wk.map(g => g.dataset.sid + (g.dataset.act ? '+' : '')).join(), exp: ['owner+', G.staff[1].id + '+', G.staff[0].id].sort().join() };
      o.ids = wk.map(g => g.dataset.sid + (g.dataset.act ? '+' : '')).sort().join();
      const cell = sc.querySelector(`.wcask[data-id="${G.staff[0].at.id}"]`); o.inCell = !!cell.querySelector(`.wk[data-sid="${G.staff[0].id}"]`);
      o.facNot = !sc.querySelector(`.wk[data-sid="${G.staff[2].id}"]`);
      o.run = _scene.anims.filter(a => a.playState === 'running').length;
      switchTab('tsale'); scenePlay(); o.paused = _scene.anims.length > 0 && _scene.anims.every(a => a.playState === 'paused');
      switchTab('tcel'); scenePlay(); o.again = _scene.anims.some(a => a.playState === 'running');
      G.ownerAt = { k: 'lot', id: G.lots[3].id }; placeInvalidate(); sceneLight(); o.ownerCell = !!sc.ownerDocument.querySelector(`#wScene .wcask[data-id="${G.lots[3].id}"] .wk[data-sid="owner"]`);
      opt().motion = 'low'; applyOpt(); sceneMount(); o.low = _scene.anims.length; opt().motion = 'std'; applyOpt();
      return o;
    });
    const ok = r.ids === r.exp && r.inCell && r.facNot && r.run > 0 && r.paused && r.again && r.ownerCell && r.low === 0;
    rec(117, '倉庫の棚の景色：樽の担当は担当の樽の横で働く・待機の職人と配置していない「あなた」は通路（押せる）・設備の担当は出ない・寝かせるを開いている間だけ動く・動きを減らす設定では止まる', ok, JSON.stringify(r));
    if (errors.length) rec('E68', '倉庫の景色テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
''')
# #118：押せる職人は通路の人
R2("const g = document.querySelector('#wScene .wk'); g.dispatchEvent(", "const g = document.querySelector('#wScene .wk[data-act=\"wkTap\"]:not([data-sid=\"owner\"])'); g.dispatchEvent(")
# #65：①②はたたまれているので開いてから樽の種類を選ぶ
R2("const fc = (() => { document.querySelector('#fillBox [data-act=\"fillPickT\"]').click();", "const fc = (() => { _ui.celOpen = true; rCellar(); document.querySelector('#fillBox [data-act=\"fillPickT\"]').click();")
# #97：寝かせるは①②をたたむので、開いて流れの帯を数える
R2("for (const t of ['tb', 'tcel', 'tsale']) { switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); }", "for (const t of ['tb', 'tcel', 'tsale']) { _ui.celOpen = true; switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); }")
# #116：移行先の版は最新
R2("const ok = r.mig[0] === 13 && r.mig[1] && r.mig[2]", "const ok = r.mig[0] === SCHEMA && r.mig[1] && r.mig[2]")
