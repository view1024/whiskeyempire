const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1200);
  await page.evaluate(() => {
    if (_offlineGate) closeOfflineModal(); closeM();
    G.dl = 3; G.cash = 8e7; G.te = 5e8; G.reputation = 60; G.stats.shipped = 2500; G.stats.orders = 22;
    FD.forEach((f, i) => { G.fac[f.id].p = true; G.fac[f.id].l = [24, 22, 26, 21, 18, 14][i]; });
    G.branch.malting = 1; G.branch.fermentation = 0; G.branch.distillation = null;
    G.uw = WL.slice(0, 14).map(w => w.id);
    const mk = (c, s, age, fl) => { const l = makeLot(caskType(c), caskSize(s)); l.age = age; l.L = l.L0 * Math.pow(0.984, age); if (fl) Object.assign(l.fl0, fl); return l; };
    G.lots = [mk('sherry', 'hogshead', 12.4), mk('bourbon', 'hogshead', 9.1), mk('bourbon', 'quarter', 4.6), mk('wine', 'barrel', 2.2), mk('bourbon', 'butt', 7.8), mk('sherry', 'hogshead', 0.4)];
    G.tank = 1800;
    const t = productSpec('glenlivid').target;
    invAdd('glenlivid', 140, 9, 1.05, t); invAdd('jack_d', 60, 5, 1.0, productSpec('jack_d').target); invAdd('johnnie_em', 25, 12, 1.1, productSpec('johnnie_em').target);
    G.orders = [];
    for (let i = 0; i < 5; i++) { const o = ordGenerate(); if (o) G.orders.push(o); }
    G.orders[0].reserve = true; G.orders[0].accepted = false;
    G.rel.local = { lv: 2, done: 9 }; G.rel.bar = { lv: 1, done: 4 };
    G.bq = [{ id: 'q_x', pid: 'glenlivid', n: 300, done: 120, moved: 120, age: 9, q: 1.05, fl: t, blend: null }];
    prodInvalidate(); rall();
  });
  const tabs = ['td', 'tb', 'tcel', 'tsale', 'te', 'tp'];
  for (const t of tabs) {
    await page.click(`#nav .nb[data-tab="${t}"]`);
    await page.waitForTimeout(300);
    await page.screenshot({ path: `v_${t}.png`, fullPage: false });
    if (t === 'tb' || t === 'tcel' || t === 'tsale') {
      await page.evaluate(id => { document.getElementById(id).scrollTop = 700; }, t);
      await page.waitForTimeout(150);
      await page.screenshot({ path: `v_${t}_2.png` });
      await page.evaluate(id => { document.getElementById(id).scrollTop = 1500; }, t);
      await page.waitForTimeout(150);
      await page.screenshot({ path: `v_${t}_3.png` });
    }
  }
  const modals = {
    m_bottle: () => openBottleModal('glenlivid'),
    m_tier: () => openTierModal(),
    m_branch: () => openBranchModal('distillation'),
    m_recipe: () => openRecipeModal('peat'),
    m_lot: () => openLotModal(G.lots[0].id),
    m_order: () => { const o = G.orders.find(x => ordMatch(x).ok && !x.reserve) || G.orders[1]; openOrderModal(o.id); },
    m_comp: () => openCompModal('local_award'),
    m_whisky: () => openWhiskyModal('glenlivid'),
    m_upg: () => openUpgModal('mashing'),
  };
  for (const [name, fn] of Object.entries(modals)) {
    await page.evaluate(`(${fn.toString()})()`);
    await page.waitForTimeout(200);
    await page.screenshot({ path: `${name}.png` });
    await page.evaluate(() => closeM());
  }
  await page.evaluate(() => { G.ls = Date.now() - 9 * 3600000; offline(); });
  await page.waitForTimeout(200);
  await page.screenshot({ path: 'm_offline.png' });
  console.log('errors:', errors.length ? errors : 'none');
  await browser.close();
})();
