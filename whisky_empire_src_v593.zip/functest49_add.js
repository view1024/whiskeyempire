  // ================= v4.9 追加テスト =================
  const STAFF3 = `(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose(); G.cash = 1e12; G.staff = []; G.staffCand = null; G.staffOff = false; staffCandState(); for (let i = 0; i < 3; i++) staffHire(0); G.staff[0].post = 'watch'; G.staff[1].post = 'fill'; G.staff[2].post = 'still'; prodInvalidate(); })()`;
  // ---------- #117 倉庫の景色：職人（最大3人）と目標に近い樽（最大4）・職人がいなければ主人・寝かせるを開いている間だけ動く・動きを減らす設定で止まる ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 200));
      const sc = document.getElementById('wScene'); const o = { wk: sc.querySelectorAll('.wk').length, ck: sc.querySelectorAll('.wcask').length, lbl: sc.querySelectorAll('.wsl').length, names: sc.querySelector('.wsn').textContent };
      const exp = G.lots.filter(l => lotGoalEta(l) > 0).sort((a, b) => lotGoalEta(a) - lotGoalEta(b)).slice(0, 4).map(l => l.id).join();
      o.order = [...sc.querySelectorAll('.wcask')].map(e => e.dataset.lot).join() === exp;
      o.run = _scene.anims.filter(a => a.playState === 'running').length;
      switchTab('tsale'); scenePlay(); o.paused = _scene.anims.length > 0 && _scene.anims.every(a => a.playState === 'paused');
      switchTab('tcel'); scenePlay(); o.again = _scene.anims.some(a => a.playState === 'running');
      G.staff = []; prodInvalidate(); sceneLight(); o.owner = document.querySelectorAll('#wScene .wk').length === 1 && document.querySelector('#wScene .wk').dataset.sid === 'owner';
      opt().motion = 'low'; applyOpt(); sceneMount(); o.low = _scene.anims.length; opt().motion = 'std'; applyOpt();
      o.cells = document.querySelectorAll('#whSummary .ck2[data-id]').length === G.lots.length;
      return o;
    });
    const ok = r.wk === 3 && r.ck === 4 && r.lbl === 4 && r.order && r.run > 0 && r.paused && r.again && r.owner && r.low === 0 && r.cells;
    rec(117, '倉庫の景色：職人（最大3人）が目標に近い樽（最大4つ・残り時間の札）の前で働く・職人がいなければ蒸留所の主・寝かせるを開いている間だけ動く・動きを減らす設定では止まる', ok, JSON.stringify(r));
    if (errors.length) rec('E68', '倉庫の景色テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #118 タップの反応と差し入れ（1日1回・経験+2・その日最初の1回だけ砂時計）・樽を叩くと残り時間（状態は変わらない） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 150));
      G.hg.n = 0; G.hg.src.care = 0; hgDay(); G.hg.src.care = 0;
      const g = document.querySelector('#wScene .wk'); g.dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 80));
      const bub = document.getElementById('wBub'); const o = { open: !bub.classList.contains('h'), txt: bub.textContent.length > 5, care: !!bub.querySelector('[data-act="staffCare"]') };
      const s = G.staff.find(x => x.id === g.dataset.sid); const xp0 = s.xp, lv0 = s.lv;
      bub.querySelector('[data-act="staffCare"]').click(); await new Promise(r => setTimeout(r, 80));
      o.c1 = { hg: G.hg.n, xp: +(s.xp - xp0 + (s.lv - lv0) * 24).toFixed(3), day: s.care === dayKey() };
      o.c2 = staffCare(s.id); const other = G.staff.find(x => x !== s); o.c3 = staffCare(other.id); o.hg2 = G.hg.n;
      const snap = JSON.stringify(G.lots); const c = document.querySelector('#wScene .wcask'); c.dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
      o.knock = document.getElementById('wBub').textContent.includes('コン'); o.same = JSON.stringify(G.lots) === snap;
      document.body.click(); await new Promise(r => setTimeout(r, 30)); o.closed = document.getElementById('wBub').classList.contains('h');
      return o;
    });
    const ok = r.open && r.txt && r.care && r.c1.hg === 1 && Math.abs(r.c1.xp - 2) < 1e-6 && r.c1.day && r.c2 === false && r.c3 === true && r.hg2 === 1 && r.knock && r.same && r.closed;
    rec(118, '職人を押すと吹き出しで一言・差し入れは1人1日1回で経験+2、砂時計はその日最初の1回だけ・樽を押すと叩く音と残り時間（樽の状態は変わらない）・外を押すと閉じる', ok, JSON.stringify(r));
    if (errors.length) rec('E69', 'タップの反応テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #119 タイムラプス：詰めた日から今日まで・年数と液面と風味が進む・動きを減らす設定は最後の状態・保存データは変わらない・放置の報告から開ける ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      const l = G.lots[1]; const now = Date.now(); l.at = now - 5 * 864e5; const r0 = agingRate(l); l.age = 5 * r0; l.L = l.L0 * 0.9; l.gd = 3; l.goal = 8; l.gs = 3;
      const T = tlTimes(l); const o = { a0: +T.a0.toFixed(3), yrs: +T.yrs.toFixed(3), days: +T.days.toFixed(2), ms: T.ms.map(m => m.p).join() };
      const s0 = JSON.stringify(G.lots); tlOpen(l.id); const same1 = JSON.stringify(G.lots) === s0; await new Promise(r => setTimeout(r, 300)); const a1 = parseFloat(document.getElementById('tlAge').textContent);
      await new Promise(r => setTimeout(r, 5400)); const a2 = parseFloat(document.getElementById('tlAge').textContent); const liq = parseFloat(document.getElementById('tlLiq').style.height);
      const t = document.getElementById('mc2').textContent; o.txt = t.includes('振り返る') && t.includes('天使の分け前'); o.run = [a1, a2]; o.liq = liq; o.on = document.querySelectorAll('.tlm.on').length;
      closeM(); opt().motion = 'low'; applyOpt(); tlOpen(l.id); o.low = parseFloat(document.getElementById('tlAge').textContent); closeM(); opt().motion = 'std'; applyOpt();
      o.same = same1;
      // 放置の報告のボタン
      const k = G.lots[2]; k.goal = k.age + 0.2; k.gs = k.age - 0.5; G.ls = Date.now() - 12 * 3600000; offline();
      const btn = document.querySelector('#mc2 [data-act="tlOpen"]'); o.rep = !!btn; if (btn) { btn.click(); await new Promise(r => setTimeout(r, 100)); o.repOpen = document.getElementById('mc2').textContent.includes('振り返る') && !_offlineGate; }
      closeM();
      return o;
    });
    const ok = r.a0 === 0 && Math.abs(r.days - 5) < 0.01 && r.ms === '0.25,0.5,0.75,1' && r.txt && r.run[0] < r.run[1] && Math.abs(r.run[1] - r.yrs) < 0.05 && Math.abs(r.liq - 90) < 0.5 && r.on === 4 && Math.abs(r.low - r.yrs) < 0.05 && r.same && r.rep && r.repOpen;
    rec(119, 'タイムラプス：詰めた日から今日まで年数・液面（天使の分け前）・風味・節目の日付が進む・動きを減らす設定は最後の状態を表示・保存データは変わらない・放置の報告から開ける', ok, JSON.stringify(r));
    if (errors.length) rec('E70', 'タイムラプステスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #120 倉庫日誌に職人の出来事（採用・Lv・研修・解雇・差し入れ・休業）と1日の様子 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.jnl = { cur: null, list: [] }; jnlRoll();
      const s = G.staff[0]; staffCandState(); G.staffCand.free = 1; staffRefresh(); staffHire(0); staffXp(s, 24); staffTrain(s.id); s.train = Date.now() - 1; staffTick(1000); staffFire(G.staff[3].id);
      const cur = jnlCur().staff.slice();
      off = 24 * 3600000; jnlRoll(); const e = G.jnl.list[0];
      Date.now = rn; G.ls = rn(); if (_offlineGate) closeOfflineModal();
      openJnlModal(); const t = document.getElementById('mc2').textContent; closeM();
      return { cur, e: e.staff, t: e.staff.every(x => t.includes(x)) };
    });
    const ok = r.cur.some(x => x.includes('加わった')) && r.cur.some(x => x.includes('Lv2')) && r.cur.some(x => x.includes('研修から戻った')) && r.cur.some(x => x.includes('去った')) && r.e.length >= 4 && r.e.length <= 5 && /は.+。$/.test(r.e[r.e.length - 1]) && r.t;
    rec(120, '倉庫日誌：職人の出来事（採用・Lv・研修・解雇など）と、その日の職人の様子が1行記録され、日誌の小窓に出る', ok, JSON.stringify(r));
    if (errors.length) rec('E71', '日誌の職人テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
