  // ================= v5.4 追加テスト =================
  // ---------- #151 BGM：6曲をシャッフルして1回ずつ・周の境目で同じ曲が続かない・各曲60〜130秒・変奏が毎回変わる・同時に鳴る音は16まで・⚙️に曲名がない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      const rr = Math.random; let seed = 7; Math.random = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      _bgmc.bag = []; _bgmc.i = -1; const seq = []; for (let k = 0; k < 18; k++) { const i = bgmNext(); seq.push(i); _bgmc.i = i; }
      Math.random = rr;
      o.rounds = [0, 1, 2].map(k => new Set(seq.slice(k * 6, k * 6 + 6)).size); o.rep = seq.some((x, j) => j && seq[j - 1] === x); o.seq = seq.join('');
      const poly = N => { let mx = 0; N.forEach((n, j) => { let c = 0; for (let k = Math.max(0, j - 600); k < N.length && N[k][0] <= n[0]; k++) { const m = N[k]; if (m[0] + m[1] + BGM_TAIL[m[4]] > n[0]) c++; } if (c > mx) mx = c; }); return mx; };
      let s2 = 3; const rnd = () => { s2 = (s2 * 16807) % 2147483647; return s2 / 2147483647; };
      o.len = BGM_PIECES.map((p, i) => { let mn = 1e9, mx = 0, pm = 0, bad = 0; for (let k = 0; k < 6; k++) { const N = bgmBuild(i, rnd); const d = bgmDur(N); mn = Math.min(mn, d); mx = Math.max(mx, d); pm = Math.max(pm, poly(N)); bad += N.filter(n => !(n[0] >= 0 && n[1] > 0 && n[2] >= 24 && n[2] <= 108 && n[3] > 0 && n[3] <= 1)).length; } return [p.id, Math.round(mn), Math.round(mx), pm, bad]; });
      // 変奏の組み合わせ：乱数が違えば中身が違う
      o.vary = BGM_PIECES.map((p, i) => JSON.stringify(bgmBuild(i, () => 0.01)) !== JSON.stringify(bgmBuild(i, () => 0.99)));
      o.gap = V54.BGM_GAP;
      switchTab('tp'); rall(); await new Promise(r => setTimeout(r, 50));
      o.noName = !document.getElementById('bgmNow') && !document.getElementById('optBox').textContent.includes('♪') && typeof bgmNowTxt === 'undefined';
      o.tip = (TIPS.find(t => t.id === 'bgm') || {}).b || '';
      return o;
    });
    const ok = r.rounds.every(n => n === 6) && !r.rep && r.len.every(x => x[1] >= 60 && x[2] <= 130 && x[3] <= 16 && x[4] === 0) && r.vary.every(Boolean) && r.gap === 5 && r.noName && r.tip.includes('ボレロ') && r.tip.includes('ランダム');
    rec(151, 'BGM：6曲をシャッフルして1回ずつ流し、全部流したら並べ直す（周の境目でも同じ曲が続かない）・各曲60〜130秒・乱数で変奏の組み合わせが変わる・同時に鳴る音は16まで・曲間5秒・⚙️に曲名を出さない（TIPSに曲の一覧）', ok, JSON.stringify(r));
    if (errors.length) rec('E101', 'BGM（v5.4）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #152 ボレロ：主題 A・B は18小節で各小節3拍・三連符とタイを含む・小太鼓は2小節24打で最後まで・主題 B が A より大きい・音割れしない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      const tot = s => s.replace(/\|/g, ' ').trim().split(/\s+/).reduce((a, tok) => { const d = tok.split(':')[1].replace('~', ''); const f = d.split('/'); return a + (f.length > 1 ? f[0] / f[1] : Number(d)); }, 0);
      o.barsA = BOL_A.split('|').map(b => +tot(b).toFixed(6)); o.barsB = BOL_B.split('|').map(b => +tot(b).toFixed(6));
      const A = bgmSeq(BOL_A), B = bgmSeq(BOL_B);
      o.a0 = A[0]; o.tripB = B.filter(n => Math.abs(n[1] - 1 / 3) < 1e-9).length; o.tieA = A.filter(n => n[1] >= 2).length;
      o.rangeB = [Math.min(...B.map(n => n[2])), Math.max(...B.map(n => n[2]))];
      const bi = BGM_PIECES.findIndex(p => p.id === 'bolero'); const N = bgmBuild(bi, () => 0.5); const sp = 60 / BGM_PIECES[bi].bpm; const dur = bgmDur(N);
      const sn = N.filter(n => n[4] === 5).map(n => n[0] / sp);
      o.sn2 = sn.filter(t => t >= 6 && t < 12).length; o.snEnd = +(dur / sp - sn[sn.length - 1]).toFixed(2);
      let gap = 0; sn.forEach((t, j) => { if (j) gap = Math.max(gap, t - sn[j - 1]); }); o.snGap = +gap.toFixed(3);
      // 主題 A（独奏）と主題 B（重ねる）の大きさ
      const rms = async (b0, b1) => { const s0 = b0 * sp, s1 = b1 * sp; const ctx = new OfflineAudioContext(1, Math.ceil((s1 - s0 + 1) * 8000), 8000); const save = _bgm.master; const m = ctx.createGain(); m.gain.value = 0.22; m.connect(ctx.destination); _bgm.master = m; _bgmNoise = null;
        N.filter(n => n[0] >= s0 && n[0] < s1).forEach(n => bgmPlay(ctx, n[4], n[2], n[0] - s0, n[1], n[3]));
        const buf = await ctx.startRendering(); _bgm.master = save; _bgmNoise = null; const d = buf.getChannelData(0); let ss = 0, pk = 0; for (let k = 0; k < d.length; k++) { ss += d[k] * d[k]; pk = Math.max(pk, Math.abs(d[k])); } return [Math.sqrt(ss / d.length), pk]; };
      const ra = await rms(6, 60), rb = await rms(60, 114), re = await rms(114, 144);
      o.rms = [ra[0], rb[0], re[0]].map(v => +v.toFixed(4)); o.peak = +Math.max(ra[1], rb[1], re[1]).toFixed(3);
      o.min = +(dur / 60).toFixed(2);
      return o;
    });
    const ok = r.barsA.length === 18 && r.barsA.every(x => x === 3) && r.barsB.length === 18 && r.barsB.every(x => x === 3) && r.a0[2] === 72 && r.a0[1] === 1.5 && r.tripB === 6 && r.tieA >= 3 && r.rangeB[0] === 48 && r.rangeB[1] === 73
      && r.sn2 === 24 && r.snEnd < 4 && r.snGap <= 0.51 && r.rms[1] > r.rms[0] && r.rms[2] > r.rms[0] && r.peak < 0.9 && r.min >= 1 && r.min <= 2.2;
    rec(152, 'ボレロ：主題 A・B は18小節で各小節3拍（三連符とタイを含む・A は C5 を1拍半伸ばして始まる・B は Db5〜C3）・小太鼓は2小節で24打、最後まで続く・主題 B と終わりは主題 A より大きい・音割れしない・約2分', ok, JSON.stringify(r));
    if (errors.length) rec('E102', 'ボレロのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #153 売る：タブ全体でスクロール（中に内部スクロールがない）・見出しと切り替えは上に残る・切り替えるとタブの先頭へ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      for (let i = 0; i < 20; i++) { const a = ordGenerate(); if (a) G.orders.push(a); }
      _ui.sellTab = 'ord'; switchTab('tsale'); rShip(); await new Promise(r => setTimeout(r, 80));
      const t = document.getElementById('tsale'); const o = {};
      o.inner = [...t.querySelectorAll('*')].filter(e => { const s = getComputedStyle(e); return (s.overflowY === 'auto' || s.overflowY === 'scroll') && e.scrollHeight > e.clientHeight + 1; }).map(e => e.id || e.className);
      o.scroll = t.scrollHeight > t.clientHeight + 50;
      t.scrollTop = t.scrollHeight; await new Promise(r => setTimeout(r, 50));
      const tr = t.getBoundingClientRect(), hr = t.querySelector('.shead').getBoundingClientRect();
      o.sticky = Math.abs(hr.top - tr.top) <= 2 && !!t.querySelector('.shead #sellChips'); o.last = t.querySelector('#orderNext').getBoundingClientRect().bottom <= tr.bottom + 2;
      const chip = t.querySelector('[data-act="sellTab"][data-id="inv"]'); if (chip) { chip.click(); await new Promise(r => setTimeout(r, 50)); o.top = t.scrollTop === 0; } else o.top = true;
      return o;
    });
    const ok = r.inner.length === 0 && r.scroll && r.sticky && r.last && r.top;
    rec(153, '売る：注文20件でタブ全体がスクロールし、中に内部スクロールがない・見出しと切り替えのチップは上に貼り付く・最後の「次の注文まで」まで届く・切り替えるとタブの先頭へ', ok, JSON.stringify(r));
    if (errors.length) rec('E103', '売るのスクロールのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #154 トースト：豆知識の帯の下に出る・タブバーに重ならない・長い文は2行で全部見える（幅360px・文字「大」でも） ----------
  {
    const out = [];
    for (const [W, H, fs] of [[390, 844, 'm'], [360, 640, 'l']]) {
      const ctx = await browser.newContext({ viewport: { width: W, height: H } }); const page = await ctx.newPage(); const errors = [];
      page.on('pageerror', e => errors.push('pageerror: ' + e.message));
      await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
      await page.goto(FILE); await page.waitForTimeout(1000);
      await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
      const r = await page.evaluate(async (fs) => {
        if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose();
        G.opt.fs = fs; applyOpt(); await new Promise(r => setTimeout(r, 100));
        toast('👤 見学のお客さんが来ました。タップすると試飲代が入ります（12秒で帰ります）', 5000); await new Promise(r => setTimeout(r, 450));
        const e = document.getElementById('toast'); const a = e.getBoundingClientRect(), tk = document.getElementById('ticker').getBoundingClientRect(), nv = document.getElementById('nav').getBoundingClientRect();
        return { top: Math.round(a.top), bottom: Math.round(a.bottom), left: Math.round(a.left), right: Math.round(a.right), tk: Math.round(tk.bottom), nav: Math.round(nv.top), clip: e.scrollHeight > e.clientHeight + 1, lines: Math.round((a.height - 16) / parseFloat(getComputedStyle(e).lineHeight)), vw: innerWidth };
      }, fs);
      out.push({ W, fs, ...r, err: errors.length });
      await ctx.close();
    }
    const ok = out.every(o => o.top >= o.tk && o.top <= o.tk + 14 && o.bottom < o.nav && !o.clip && o.lines <= 2 && o.left >= 10 && o.right <= o.vw - 10 && o.err === 0);
    rec(154, 'トースト：豆知識の帯のすぐ下（帯の下端から14px以内）に出て、タブバーに重ならない・長い文は2行以内で切れずに全部見える・左右に余白（幅390px／幅360px・文字「大」）', ok, JSON.stringify(out));
  }
  // ---------- #155 偶発イベント：帯がない・選ぶイベントはホームの「出来事」から選ぶ・続く効果はアイコンに残り時間・終わると消える ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); switchTab('td');
      const o = { banner: !document.getElementById('eventBanner') };
      const icon = () => { rall(); const b = document.getElementById('hi_ev'); return b ? b.textContent : ''; };
      o.none = icon() === '';
      const ch = RAND_EVENTS.find(e => e.id === 're_partner'); const rep0 = G.reputation;
      showEventBanner(ch); o.ask = [G.randomEvent.ask, icon().includes('!')];
      openEvModal(); const bt = document.querySelector('#mc2 [data-act="evChoose"][data-v="0"]'); o.btns = document.querySelectorAll('#mc2 [data-act="evChoose"]').length; bt.click(); await new Promise(r => setTimeout(r, 30));
      o.chose = [G.randomEvent.ask, +(G.reputation - rep0).toFixed(2) > 0, $('mo').classList.contains('h')];
      const good = RAND_EVENTS.find(e => e.id === 're_festival'); showEventBanner(good); o.active = [!!G.randomEvent.active, /\d+分/.test(icon())];
      G.randomEvent.active.expiresAt = Date.now() - 1; tickActiveEvent(); o.end = [G.randomEvent.active, icon() === ''];
      // 保存：選ぶイベントは保存しても残る。知らない id は消える
      G.randomEvent.ask = 're_buyout'; o.san = [sanitize(JSON.parse(JSON.stringify(G))).randomEvent.ask, sanitize(Object.assign(JSON.parse(JSON.stringify(G)), { randomEvent: { lastAt: 0, sessionCount: 0, active: null, ask: 'x' } })).randomEvent.ask];
      G.randomEvent.ask = null;
      return o;
    });
    const ok = r.banner && r.none && r.ask[0] === 're_partner' && r.ask[1] && r.btns === 2 && r.chose[0] === null && r.chose[1] && r.chose[2] && r.active.join() === 'true,true' && r.end[0] === null && r.end[1] && r.san[0] === 're_buyout' && r.san[1] === null;
    rec(155, '偶発イベント：画面上の帯はない・選ぶイベントはホームのアイコン「出来事（!）」の小窓で選ぶと効果が出て消える・続く効果はアイコンに残り分・終わるとアイコンが消える・選ぶイベントは保存される', ok, JSON.stringify(r));
    if (errors.length) rec('E105', '偶発イベントのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #156 廃止した機能と移行（v16→v17）：等級・差し入れ・TIPS帯の速さがない・砂時計の入手は8種類・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {};
      openBarleyModal(); o.grade = !document.querySelector('#mc2 [data-act="barleyGrade"]') && !$('mc2').textContent.includes('等級'); closeM();
      switchTab('tp'); rall(); await new Promise(r => setTimeout(r, 30)); o.tk = !document.querySelector('#optBox [data-k="tk"]');
      o.hgKeys = Object.keys(V51.HG).join(','); openHgModal(); o.hgList = document.querySelectorAll('#mc2 .hgs').length; o.hgTxt = $('mc2').textContent.includes('差し入れ') || $('mc2').textContent.includes('月の決算'); closeM();
      o.daily = V51.HG.daily.k;
      // v16 の保存から移行
      const old = JSON.parse(JSON.stringify(G)); old.ver = 16; old.barley.grade = 'best'; old.hg.src.care = 1; old.opt.tk = 'fast'; (old.staff || []).forEach(s => s.care = dayKey());
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      o.mig = { ver: m.ver, grade: m.barley.grade, care: 'care' in m.hg.src, tk: m.opt.tk, staffCare: (m.staff || []).some(s => 'care' in s) };
      const key = storageKey(); const bk = 'we_v4_bak16:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.grade && r.tk && r.hgKeys === 'login,daily,ms,ord,tap,streak,tier,prestige' && r.hgList === 8 && !r.hgTxt && r.daily === 3
      && r.mig.ver === SCHEMA && r.mig.grade === 'std' && !r.mig.care && r.mig.tk === 'mid' && !r.mig.staffCare && r.bk && r.loaded === SCHEMA;
    rec(156, '廃止：大麦の等級・TIPS帯の速さの設定がない・砂時計の入手の機会は8種類（デイリー全達成は3個）／v16 からの移行：等級は標準・差し入れの記録を外す・TIPS帯は標準・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E106', '廃止と移行のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
