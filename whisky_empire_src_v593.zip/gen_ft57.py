# v5.6 の生成（try で包む前）まで → v5.6.1・v5.7 の書き換え → 追加 → try で包む
s56=open('gen_ft56.py').read()
exec(s56[:s56.index("exec(src[cut:]")])
exec(open('functest57_fix.py').read())
if os.path.exists('functest57_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest57_add.js').read()+s[a:]
exec(src[cut:].replace("open('functest55.js','w').write(s)","pass"))
open('functest57.js','w').write(s)
