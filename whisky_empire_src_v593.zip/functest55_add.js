  // ================= v5.5 追加テスト =================
  async function pageW(W, H, mode, fsl) {
    const ctx = await browser.newContext({ viewport: { width: W, height: H } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
    await page.evaluate(`(${STATE.toString()})(${JSON.stringify(mode)})`); await page.waitForTimeout(400);
    await page.evaluate((l) => { _celebQ = []; celebClose(); closeM(); if (l) { G.opt.fs = 'l'; applyOpt(); } }, !!fsl);
    return { page, errors, ctx };
  }
  // 画面の外（左右）にはみ出す要素と、横にスクロールできる要素を数える（はみ出しを切っている親の中は数えない）
  const HOVER = `(() => {
    const vw = document.documentElement.clientWidth; const bad = [];
    const clipped = e => { for (let p = e.parentElement; p && p !== document.body; p = p.parentElement) { const cs = getComputedStyle(p); if (/(hidden|clip)/.test(cs.overflowX)) { const r = p.getBoundingClientRect(); if (r.left >= -1 && r.right <= vw + 1) return true; } } return false; };
    for (const e of document.querySelectorAll('#app *, #mo *')) {
      if (!e.getClientRects().length) continue; const cs = getComputedStyle(e);
      if (cs.visibility === 'hidden' || cs.position === 'fixed' && e.id === 'toast') continue;
      if (/(auto|scroll)/.test(cs.overflowX) && e.scrollWidth > e.clientWidth + 1) bad.push('scroll:' + (e.id || e.className));
      const r = e.getBoundingClientRect(); if (r.width === 0) continue;
      if ((r.right > vw + 1 || r.left < -1) && !clipped(e)) bad.push('out:' + (e.id || e.className || e.tagName) + ':' + Math.round(r.left) + '-' + Math.round(r.right));
    }
    if (document.documentElement.scrollWidth > vw + 1) bad.push('doc:' + document.documentElement.scrollWidth);
    return bad.slice(0, 6);
  })()`;
  // ---------- #157 横スクロールなし：全タブ（売るの切り替え・図鑑のアイコンごと）と主な小窓 × 幅360/390 × 開始直後・中盤・終盤＋文字：大 ----------
  {
    const bad = []; const errs = []; let n = 0;
    const runs = [];
    for (const W of [360, 390]) for (const mode of ['fresh', 'mid', 'late']) runs.push([W, mode, false]);
    runs.push([360, 'mid', true], [360, 'late', true]);
    for (const [W, mode, fsl] of runs) {
      const { page, errors, ctx } = await pageW(W, 740, mode, fsl);
      const views = await page.evaluate(() => {
        const v = ['td', 'tb', 'tcel', 'tp'].map(t => ['tab', t]);
        sellTabs().forEach(([k]) => v.push(['sell', k]));
        encTabs().forEach(([k]) => { if (k !== 'fin') v.push(['enc', k]); });
        ['hiMkt', 'hiFin', 'hgOpen', 'hiTier', 'hiChap'].forEach(a => v.push(['modal', a]));
        if (typeof staffOn === 'function' && staffOn()) v.push(['modal', 'staffOpen']);
        return v;
      });
      for (const [k, id] of views) {
        await page.evaluate(async ([k, id]) => {
          closeM();
          if (k === 'tab') switchTab(id);
          else if (k === 'sell') { _ui.sellTab = id; switchTab('tsale'); }
          else if (k === 'enc') { _ui.encTab = id; switchTab('te'); }
          else { switchTab('td'); const b = document.createElement('button'); b.dataset.act = id; document.body.appendChild(b); b.click(); b.remove(); }
          await new Promise(r => setTimeout(r, 120));
        }, [k, id]);
        const b = await page.evaluate(HOVER); n++;
        if (b.length) bad.push(W + mode + (fsl ? 'L' : '') + ':' + k + ':' + id + '→' + b.join(','));
      }
      errs.push(...errors); await ctx.close();
    }
    rec(157, '横スクロールなし（v5.5）：全タブ・売るの切り替え・図鑑の各ページ・主な小窓で、画面の左右にはみ出す要素と横にスクロールできる要素が0（幅360/390 × 開始直後・中盤・終盤、文字：大）', bad.length === 0 && n >= 100, JSON.stringify({ n, bad: bad.slice(0, 8) }));
    if (errs.length) rec('E106', '横スクロールのテスト中のエラー', false, errs.slice(0, 3).join(' | '));
  }
  // ---------- #158 ホーム（v5.5）：アイコン6つ・生産〜注文は2行で高さ52px以下・樽の下は1行・見学ツアーのボタンなし・お客さんは樽に重ならない ----------
  {
    const out = {}; const errs = [];
    for (const [W, H] of [[360, 640], [390, 667], [393, 844]]) {
      const { page, errors, ctx } = await pageW(W, H, 'mid');
      const r = await page.evaluate(async () => {
        switchTab('td'); G.staff = G.staff || []; rdistLight(); await new Promise(r => setTimeout(r, 100));
        const icons = [...document.querySelectorAll('#homeIcons .hi')]; const ir = icons.map(b => b.getBoundingClientRect());
        const oneRow = ir.every(r => Math.abs(r.top - ir[0].top) < 2);
        const lbs = icons.map(b => b.querySelector('.hil').textContent);
        const nodes = [...document.querySelectorAll('#flow .fnode')]; const fh = Math.max(...nodes.map(e => e.getBoundingClientRect().height));
        const lines = nodes.map(e => [e.querySelector('.fl2'), e.querySelector('.fv')].every(Boolean) && e.children.length <= 3);
        const tl = document.getElementById('tapline'); const tr = tl.getBoundingClientRect(); const st = document.getElementById('stage').getBoundingClientRect();
        const txt = tl.textContent;
        // お客さんを左右に1人ずつ出して、樽と重ならないか
        _vis.next = 0; _vis.list = []; document.getElementById('visitors').innerHTML = ''; const rr = Math.random; let k = 0; Math.random = () => [0.9, 0.2, 0.3][k++ % 3];
        visitorTick(); _vis.next = 0; visitorTick(); Math.random = rr;
        const bb = document.getElementById('bb').getBoundingClientRect();
        const vis = [...document.querySelectorAll('#visitors .visitor')].map(v => { const r = v.getBoundingClientRect(); return { l: Math.round(r.left), r: Math.round(r.right), hit: !(r.right <= bb.left || r.left >= bb.right || r.bottom <= bb.top || r.top >= bb.bottom) }; });
        return { n: icons.length, oneRow, lbs, fh: Math.round(fh), lines: lines.every(Boolean), tlH: Math.round(tr.height), below: tr.top >= st.bottom - 1, txt, tap: !document.querySelector('#td .tapcap') && !document.getElementById('cub') && !document.getElementById('td').textContent.includes('樽をタップ') && !document.getElementById('td').textContent.includes('見学ツアー'), vis, scroll: document.getElementById('td').scrollHeight - document.getElementById('td').clientHeight };
      });
      out[W + 'x' + H] = r; errs.push(...errors); await ctx.close();
    }
    const ok = Object.values(out).every(r => r.n <= 6 && r.oneRow && r.lbs.slice(0, 5).join() === '章の目標,デイリー,市況,次のTier,砂時計' && r.fh <= 52 && r.lines && r.tlH <= 40 && r.below && /＋.+\/タップ/.test(r.txt) && r.txt.includes('試飲会まで あと') && r.txt.includes('（今日') && r.tap && r.vis.length === 2 && r.vis.every(v => !v.hit) && r.scroll <= 0);
    rec(158, 'ホーム（v5.5）：アイコンは章の目標・デイリー・市況・次のTier・砂時計・職人の6つまで1段・生産〜注文は名前と値の2行で高さ52px以下・樽の下は「＋$X/タップ　試飲会まで あと◯回（今日n/5）」の1行・「樽をタップ」と見学ツアーのボタンはない・お客さんの吹き出しは樽に重ならない・1画面（360×640・390×667・393×844）', ok, JSON.stringify(out));
    if (errs.length) rec('E107', 'ホームのテスト中のエラー', false, errs.slice(0, 3).join(' | '));
  }
  // ---------- #159 称号（v5.5）：ヘッダーは最後に得た称号・評判の段階は称号でない言い方・称号は28に整理・図鑑は新しい順で「今の称号」・廃止した称号は「過去の称号」 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      o.n = [TT.length, TT.filter(t => !t.ret).length, V55.TITLE_RET.length];
      o.rank = REP_RANKS.map(x => x.label).join();
      o.retCh = TT.filter(t => t.ret).every(t => t.ch(G) === false);
      G.tl = ['t1', 't9', 't22', 't2b']; G.reputation = 30; updHdr(); updateRepBar(); rprof();
      o.hdr = document.querySelector('#hdr .hd-sub').textContent.replace(/\s+/g, ' ').trim();
      o.pt = document.getElementById('ptitle').textContent;
      const tl0 = G.tl.length; chkT(); o.chk = G.tl.slice(tl0).every(id => !TT.find(t => t.id === id).ret); G.tl = ['t1', 't9', 't22', 't2b', 't10']; updHdr(); o.hdr2 = document.getElementById('hdTitle').textContent;
      _ui.encTab = 't'; switchTab('te'); await new Promise(r => setTimeout(r, 50));
      o.cur = document.querySelector('#tlist .tcn').textContent;
      o.list = [...document.querySelectorAll('#tlist .tch:not(.old)')].slice(0, 3).map(e => e.textContent.replace('🏅 ', ''));
      o.old = [...document.querySelectorAll('#tlist .tch.old')].map(e => e.textContent.replace('🏅 ', ''));
      o.rep = document.getElementById('tlist').textContent.includes('評判が広がる');
      G.tl = []; updHdr(); o.none = document.getElementById('hdTitle').textContent;
      return o;
    });
    const t10 = '地方の名士', t22 = '初出荷', t9 = 'クラフト蒸留家';
    const ok = r.n.join() === '54,31,23' && r.chk && r.rank === '無名,地元で知られる,評判が広がる,地域で有名,全国で有名,世界で有名' && r.retCh && r.hdr === 'Tier 3・評判 30・🏅' + t22 && r.pt === t22 && r.hdr2 === t10 && r.cur.includes(t10) && r.list.join() === [t10, t22, t9].join() && r.old.join() === '初打ち,千叩き' && r.rep && r.none === '見習い蒸留家';
    rec(159, '称号（v5.5）：ヘッダーは「Tier n・評判 n・🏅最後に得た称号」（設定の称号も同じ）・評判の段階は「無名〜世界で有名」・称号は54→31（廃止した23は得られない）・図鑑は「今の称号」と新しい順・廃止した称号は「過去の称号」', ok, JSON.stringify(r));
    if (errors.length) rec('E108', '称号のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #160 図鑑（v5.5）：入口は4×2のアイコン（決算書・銘柄・称号・創業地／倉庫日誌・設備の歩み・物語・記録）・それぞれのページ・種類の絞り込みは折り返す ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      switchTab('te'); _ui.encTab = 'w'; renc(); await new Promise(r => setTimeout(r, 50));
      const ic = [...document.querySelectorAll('#encGrid .eic')]; const rs = ic.map(e => e.getBoundingClientRect());
      const o = { lbs: ic.map(e => e.querySelector('.eil').textContent).join(), rows: new Set(rs.map(r => Math.round(r.top))).size, cols: new Set(rs.map(r => Math.round(r.left))).size, chips: !document.getElementById('encChips') };
      const pages = {};
      for (const k of ['w', 't', 'g', 'j', 'f', 's', 'r']) { document.getElementById('ei_' + k).click(); await new Promise(r => setTimeout(r, 40)); const p = document.getElementById('ep_' + k); pages[k] = !!p && p.getClientRects().length > 0 && p.textContent.trim().length > 0 && ['w', 't', 'g', 'j', 'f', 's', 'r'].filter(x => x !== k).every(x => !document.getElementById('ep_' + x).getClientRects().length) && document.getElementById('ei_' + k).classList.contains('on'); }
      o.pages = pages;
      o.g = document.querySelectorAll('#recList .card').length >= 1; document.getElementById('ei_f').click(); o.f = document.querySelectorAll('#facEncEl > div').length === FD.length;
      document.getElementById('ei_r').click(); o.r = document.getElementById('caskHist').textContent.includes('はじまりの一樽') && document.getElementById('blendHist').children.length >= 1;
      document.getElementById('ei_w').click(); const fb = document.getElementById('filterbar'); const cs = getComputedStyle(fb); o.fb = (cs.flexWrap === 'wrap' || cs.display === 'grid') && cs.overflowX !== 'auto' && fb.scrollWidth <= fb.clientWidth + 1;
      document.getElementById('ei_fin').click(); await new Promise(r => setTimeout(r, 50)); o.fin = document.getElementById('mc2').textContent.includes('決算書') && _ui.encTab === 'w'; closeM();
      return o;
    });
    const ok = r.lbs === '決算書,銘柄,称号,創業地,倉庫日誌,設備の歩み,物語,記録' && r.rows === 2 && r.cols === 4 && r.chips && Object.values(r.pages).every(Boolean) && r.g && r.f && r.r && r.fb && r.fin;
    rec(160, '図鑑（v5.5）：入口は4×2のアイコン（決算書・銘柄・称号・創業地／倉庫日誌・設備の歩み・物語・記録）で、押したページだけを出す・決算書は小窓・創業地は気候ごとの記録・記録は名樽とブレンド・種類の絞り込みは折り返す', ok, JSON.stringify(r));
    if (errors.length) rec('E109', '図鑑のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #161 豆知識の帯はホームだけ・トーストは帯の下（帯がないタブではヘッダーの下）・造るの「歩み」・寝かせるの日誌と「③ → 売る」はない・売るの切り替えは等幅 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {}; const tk = () => document.getElementById('ticker').getClientRects().length > 0;
      const tt = () => { toast('テスト'); return Math.round(parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--toastTop'))); };
      switchTab('td'); o.home = [tk(), tt() === Math.round(document.getElementById('ticker').getBoundingClientRect().bottom + 6)];
      const r0 = document.getElementById('tkTxt').textContent;
      switchTab('tb'); o.make = [tk(), tt() === Math.round(document.getElementById('hdr').getBoundingClientRect().bottom + 6), !document.querySelector('#tb [data-act="facHist"]')];
      switchTab('tcel'); o.cel = [tk(), !document.getElementById('celJnl') && !document.querySelector('#tcel .jnl') && !document.querySelector('#tcel .sflow') && !document.querySelector('[data-act="celOpen"]')];
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 50));
      const ch = [...document.querySelectorAll('#sellChips .chip')].map(e => e.getBoundingClientRect());
      o.sell = [tk(), ch.length >= 4, ch.every(c => Math.abs(c.width - ch[0].width) <= 1 && Math.abs(c.top - ch[0].top) <= 1)];
      switchTab('td'); await new Promise(r => setTimeout(r, 300)); o.back = tk() && document.getElementById('tkTxt').textContent.length > 0;
      return o;
    });
    const ok = r.home.join() === 'true,true' && r.make.join() === 'false,true,true' && r.cel.join() === 'false,true' && r.sell.join() === 'false,true,true' && r.back;
    rec(161, '豆知識の帯はホームだけ（v5.5）・トーストは帯の6px下、帯がないタブではヘッダーの6px下・造るの「歩み」、寝かせるの倉庫日誌・①②をたたむ行・「③ → 売る」はない・売るの切り替えは等幅で1段', ok, JSON.stringify(r));
    if (errors.length) rec('E110', '帯とタブのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
