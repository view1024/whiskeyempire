# v5.5 の生成（try で包む前）まで → v5.6 の書き換え（v5.5 で追加したテストも対象）→ 追加 → try で包む
src=open('gen_ft55.py').read()
cut=src.index('# v5.5 1つのテストの例外で')
exec(src[:cut])
import os, re
exec(open('functest56_fix.py').read())
if os.path.exists('functest56_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest56_add.js').read()+s[a:]
exec(src[cut:].replace("open('functest55.js','w').write(s)","pass"))
open('functest56.js','w').write(s)
