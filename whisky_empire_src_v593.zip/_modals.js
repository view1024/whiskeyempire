const { chromium } = require('playwright');const path=require('path');
const v=require('fs').readFileSync('v43.js','utf8');const st=v.slice(v.indexOf('const STATE = function'),v.indexOf('};\n(async () => {')+2);
const STATE=eval('('+st.replace('const STATE = ','').replace(/;\s*$/,'')+')');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:390,height:667},deviceScaleFactor:1.2});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.route(/fonts/,r=>r.abort());await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1000);
await p.evaluate(()=>titleStart(false));await p.waitForTimeout(400);
await p.evaluate(`(${STATE.toString()})('mid')`);await p.waitForTimeout(500);await p.evaluate(()=>{_celebQ=[];celebClose();closeM();});
const shots=[['daily',"hi_daily.click()"],['mkt',"(closeM(),hi_mkt.click())"],['news',"(closeM(),hi_news.click())"],['ord',"(closeM(),_ui.sellTab='ord',switchTab('tsale'),document.querySelector('#orderBoard .oc2 .ocl').click())"],['blend',"(closeM(),G.branch.maturation=0,switchTab('tcel'),btnBlend.click())"],['recipe',"(closeM(),switchTab('tb'),document.querySelector('[data-act=rcpBox]').click())"]];
for(const [n,js] of shots){await p.evaluate(()=>{_celebQ=[];celebClose();});await p.evaluate(js);await p.evaluate(()=>{_celebQ=[];celebClose();});await p.waitForTimeout(300);await p.screenshot({path:'v43_m_'+n+'.png'});}
console.log(errs);await b.close();})();
