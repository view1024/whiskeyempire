exec(open('gen_ft53.py').read().replace("open('functest53.js','w').write(s)","pass"))
import os
exec(open('functest54_fix.py').read())
if os.path.exists('functest54_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest54_add.js').read()+s[a:]
open('functest54.js','w').write(s)
