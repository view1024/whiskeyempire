// ============================================================
// v4.8 職人の採用・配置と人件費
//  - v5.0 で持ち場（POSTS）を廃止し、設備か樽への配置（n22_v50.js）に置き換えた
// ============================================================
const V48={W_BASE:300,SEATS_MAX:3,EXTRA:2,HIRE_H:24,TRAIN_H:12,TRAIN_MS:6*3600000,TRAIN_XP:24,SEV_H:24,REFRESH_H:12,CAND_N:3,DECAY:[1,0.8,0.6],UNLOCK_TIER:2,LV_MAX:10};
const ST_KEYS=['waza','tegiwa','mekiki'];
const ST_LBL={waza:'技',tegiwa:'手際',mekiki:'目利き'};
const STAFF_TRAITS=[{id:'calm',nm:'寡黙'},{id:'cheer',nm:'陽気'},{id:'neat',nm:'几帳面'},{id:'curious',nm:'好奇心旺盛'},{id:'proud',nm:'職人気質'},{id:'dream',nm:'夢見がち'}];
const STAFF_NAMES=['マルコム','アイラ','ユアン','フィオナ','ダンカン','モイラ','ハミッシュ','イーヴィー','カラム','ケイティ','ロス','ニーヴ','フレイザー','エルスペス','ニール','ショーナ','アンガス','キルスティ','ロビー','マイリ','源三','千代','健太','葵','宗次','ハナ','伊織','小春','鉄平','凛'];
ICONS.staff='<circle cx="12" cy="7" r="3.5"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/><path d="M8.5 5.5h7"/>';

function staffOn(){return (G.dl||1)>=V48.UNLOCK_TIER;}
function staffList(){if(!Array.isArray(G.staff))G.staff=[];return G.staff;}
function staffSeats(){return Math.min(V48.SEATS_MAX,G.dl||1);}
function staffCap(){return staffSeats()*5+V48.EXTRA;} // v4.8 の「持ち場5つ×席数＋2」と同じ人数
function stSum(st){return (st&&((st.waza||0)+(st.tegiwa||0)+(st.mekiki||0)))||0;}
function staffTraining(s,now){return !!(s.train&&s.train>(now||Date.now()));}
// 給与の水準：売値の倍率（Tier・再創業。v5.6 販売地域は廃止）× 生産4工程の平均Lvの規模（生産の価値と同じ比率で上がる）
function staffWageScale(){const lv=STAGES.map(x=>facLv(x.fac));const avg=lv.reduce((a,v)=>a+v,0)/lv.length;return priceMultBase()*Math.pow(BALANCE.CAP_MUL,Math.max(0,avg-1));}
function staffWage(s){return V48.W_BASE*staffWageScale()*(0.6+0.08*stSum(s.st))*(1+0.05*((s.lv||1)-1));}
function staffWagesPh(){return staffList().reduce((a,s)=>a+staffWage(s),0);}
function staffInvalidate(){prodInvalidate();if(typeof placeInvalidate==='function')placeInvalidate();}

// ---------- 効果（v5.0：配置先ごとの倍率。n22_v50.js） ----------
function staffGainTxt(s){return placeGainTxt(s);}

// ---------- 給与・経験・研修の終了（毎秒の進行・放置・砂時計から） ----------
function staffNeed(lv){return 24*lv;}
function staffXp(s,x){
  s.xp=(s.xp||0)+x;let up=false;
  while((s.lv||1)<V48.LV_MAX&&s.xp>=staffNeed(s.lv||1)){s.xp-=staffNeed(s.lv||1);s.lv=(s.lv||1)+1;up=true;}
  if(s.lv>=V48.LV_MAX)s.xp=Math.min(s.xp,staffNeed(V48.LV_MAX));
  if(up){staffInvalidate();staffEvent(s,'lv');}
  return up;
}
function staffEvent(s,k){
  if(k==='lv'&&!_offlineRunning)toast('👷 '+s.nm+'が Lv'+s.lv+' になりました',2600);
  if(typeof staffJnl==='function')staffJnl(s,k);
}
function staffTick(dtMs){
  placeSanitize();
  const L=staffList();if(!L.length){if(G.staffOff)G.staffOff=false;return {paid:0,offH:0};}
  const now=Date.now();
  L.forEach(s=>{if(s.train&&s.train<=now){s.train=0;staffXp(s,V48.TRAIN_XP);staffInvalidate();if(typeof staffJnl==='function')staffJnl(s,'train');}});
  const h=dtMs/3600000;const wph=staffWagesPh();
  if(!(h>0)||!(wph>0))return {paid:0,offH:0};
  // 休業中は1時間分の給与が払えるまで戻らない（出たり入ったりを防ぐ）
  if(G.staffOff&&G.cash<wph)return {paid:0,offH:h};
  let payH=h;if(G.cash<wph*h)payH=Math.max(0,Math.floor(G.cash/wph*3600)/3600);
  const paid=wph*payH;
  if(paid>0)pay(paid,'sga','wage');
  if(payH<h-1e-9){if(!G.staffOff){G.staffOff=true;staffInvalidate();if(!_offlineRunning)toast('⚠ 給与が払えず、職人が休業しました（払えるようになると戻ります）',4000);if(typeof staffJnl==='function')staffJnl(null,'off');}}
  else if(G.staffOff){G.staffOff=false;staffInvalidate();if(!_offlineRunning)toast('👷 職人が仕事に戻りました',2500);}
  if(payH>0)L.forEach(s=>{if(s.at&&!staffTraining(s,now))staffXp(s,payH);});
  return {paid,offH:Math.max(0,h-payH)};
}

// ---------- 候補者 ----------
function staffPickName(){
  const used=new Set(staffList().map(s=>s.nm).concat(((G.staffCand&&G.staffCand.list)||[]).map(c=>c.nm)));
  const free=STAFF_NAMES.filter(n=>!used.has(n));const L=free.length?free:STAFF_NAMES;
  return L[Math.floor(Math.random()*L.length)];
}
function staffRoll(){
  const T=G.dl||1;const p3=0.05+0.02*(T-1),p2=0.25+0.03*(T-1);const x=Math.random();
  const r=x<p3?3:x<p3+p2?2:1;const rg=[[9,14],[13,19],[18,24]][r-1];
  const sum=rg[0]+Math.floor(Math.random()*(rg[1]-rg[0]+1));
  const st={waza:1,tegiwa:1,mekiki:1};const w=ST_KEYS.map(()=>0.2+Math.random());let left=sum-3,g=0;
  while(left>0&&g++<200){const open=ST_KEYS.map((k,i)=>st[k]<10?w[i]:0);const tot=open.reduce((a,v)=>a+v,0);if(tot<=0)break;let y=Math.random()*tot,i=0;while(y>open[i]){y-=open[i];i++;}st[ST_KEYS[i]]++;left--;}
  return {nm:staffPickName(),seed:Math.floor(Math.random()*1e6),r,st,tr:STAFF_TRAITS[Math.floor(Math.random()*STAFF_TRAITS.length)].id};
}
function staffCandState(){
  const t=dayKey();let c=G.staffCand;
  if(!c||typeof c!=='object'||c.d!==t||!Array.isArray(c.list)){c=G.staffCand={d:t,list:[],free:1};for(let i=0;i<V48.CAND_N;i++)c.list.push(staffRoll());}
  return c;
}
function staffRefreshCost(){return Math.round(V48.W_BASE*staffWageScale()*V48.REFRESH_H);}
function staffRefresh(){
  const c=staffCandState();
  if(c.free>0)c.free=0;
  else{const cost=staffRefreshCost();if(G.cash<cost){toast('求人の費用が足りません（'+fmt(cost)+'）');return false;}pay(cost,'sga','hire');}
  c.list=[];for(let i=0;i<V48.CAND_N;i++)c.list.push(staffRoll());
  save();return true;
}
function staffHireFee(c){return Math.round(staffWage({st:c.st,lv:1})*V48.HIRE_H);}

// ---------- 採用・配置・研修・解雇 ----------
function staffHire(i){
  if(!staffOn()){toast('職人はTier2から雇えます');return false;}
  const c=staffCandState();const cd=c.list[i];if(!cd)return false;
  if(staffList().length>=staffCap()){toast('これ以上は雇えません（在籍'+staffCap()+'人まで）');return false;}
  const fee=staffHireFee(cd);if(G.cash<fee){toast('採用費が足りません（'+fmt(fee)+'）');return false;}
  pay(fee,'sga','hire');
  const s={id:uid('s'),nm:cd.nm,seed:cd.seed,r:cd.r,st:{...cd.st},tr:cd.tr,lv:1,xp:0,at:null,hired:Date.now(),train:0};
  staffList().push(s);c.list.splice(i,1);
  // 空いている配置先へ（いちばん遅い工程 → 瓶詰めの予約があればボトリング → 目標が近い樽）
  placeHire(s);
  staffInvalidate();save();sndPurchase();
  toast('👷 '+s.nm+'を採用しました（'+placeName(s.at)+'）',2600);
  if(typeof staffJnl==='function')staffJnl(s,'hire');
  return true;
}
function staffTrainFee(s){return Math.round(staffWage(s)*V48.TRAIN_H);}
function staffTrain(id){
  const s=staffList().find(x=>x.id===id);if(!s)return false;
  if(staffTraining(s)){toast('研修中です');return false;}
  if(s.lv>=V48.LV_MAX){toast('これ以上は上がりません');return false;}
  const fee=staffTrainFee(s);if(G.cash<fee){toast('研修費が足りません（'+fmt(fee)+'）');return false;}
  pay(fee,'sga','train');s.train=Date.now()+V48.TRAIN_MS;staffInvalidate();save();
  toast('📚 '+s.nm+'が研修に出ました（6時間・終わると経験+'+V48.TRAIN_XP+'）',2800);return true;
}
function staffSevFee(s){return Math.round(staffWage(s)*V48.SEV_H);}
function staffFire(id){
  const i=staffList().findIndex(x=>x.id===id);if(i<0)return false;const s=staffList()[i];
  const fee=staffSevFee(s);if(G.cash<fee){toast('退職金が足りません（'+fmt(fee)+'）');return false;}
  pay(fee,'sga','sev');staffList().splice(i,1);staffInvalidate();save();
  toast(s.nm+'が蒸留所を去りました',2400);
  if(typeof staffJnl==='function')staffJnl(s,'fire');
  return true;
}
// 再創業では、いちばん熟練した1人だけが一緒に来る
function staffKeepOne(){
  const L=staffList().slice().sort((a,b)=>(b.lv-a.lv)||(b.xp-a.xp));
  return L.length?[Object.assign({},L[0],{at:null,train:0})]:[];
}

// ---------- 画面 ----------
function stars(r){return '★'.repeat(r)+'<span class="sst">'+'★'.repeat(3-r)+'</span>';}
function stBars(st){return ST_KEYS.map(k=>`<div class="stb"><span>${ST_LBL[k]}</span><i><b style="width:${(st[k]||0)*10}%"></b></i><em>${st[k]||0}</em></div>`).join('');}
function traitNm(id){const t=STAFF_TRAITS.find(x=>x.id===id);return t?t.nm:'';}
function staffOffCard(){return G.staffOff?`<div class="card warn"><div class="sm" style="color:var(--red)">⚠ 給与が払えず休業中です。1時間分の給与（${fmt(staffWagesPh())}）が払えるようになると戻ります</div></div>`:'';}
function staffTabs(t){return `<div class="chips">${[['post','配置'],['list','在籍'],['hire','採用']].map(([k,l])=>`<button type="button" class="chip${t===k?' on':''}" data-act="staffTab" data-id="${k}">${l}</button>`).join('')}</div>`;}
function openStaffModal(tab){
  if(!_ui.staff)_ui.staff={tab:'post'};if(tab)_ui.staff.tab=tab;const t=_ui.staff.tab;
  const L=staffList();const lab=acctLaborThisMonth();
  let body='';
  if(t==='post'){
    body=placeRowsHtml();
  }else if(t==='list'){
    body=L.length?L.map(s=>{const now=Date.now();const tr=staffTraining(s,now);
      // v5.0.1 1人2行（名前・Lv・時給／配置先・倍率・効果）。能力・研修・解雇は「詳しく」
      return `<div class="card sfc"><div class="row sb"><span class="tt">${escapeHtml(s.nm)} <span class="sstar">${stars(s.r)}</span> <span class="plv">Lv${s.lv}</span></span><span class="sm">時給 ${fmt(staffWage(s))}</span></div>
        <div class="sm sgn">${s.at?escapeHtml(staffGainTxt(s)):'待機'}${tr?' ・ 研修中 あと'+fmtRemain(s.train-now):''}</div>
        <details class="fold"><summary><span class="sm">詳しく</span></summary><div class="sm">${escapeHtml(traitNm(s.tr))}</div>${stBars(s.st)}
        <div class="stb lvb"><span>Lv${s.lv}</span><i><b style="width:${s.lv>=V48.LV_MAX?100:Math.min(100,(s.xp||0)/staffNeed(s.lv)*100)}%"></b></i><em>${s.lv>=V48.LV_MAX?'最大':Math.floor(s.xp||0)+'/'+staffNeed(s.lv)}</em></div>
        <div class="row" style="gap:6px;margin-top:6px"><button type="button" class="sb2 gh" data-act="staffTrain" data-id="${s.id}" ${tr||s.lv>=V48.LV_MAX?'disabled':''}>研修 ${fmt(staffTrainFee(s))}</button><button type="button" class="sb2 gh" data-act="staffFire" data-id="${s.id}">解雇（退職金 ${fmt(staffSevFee(s))}）</button></div></details></div></div>`;}).join(''):'<div class="sm tc" style="padding:10px">まだ職人はいません。「採用」から雇えます</div>';
  }else{
    const c=staffCandState();
    body=c.list.map((cd,i)=>{
      return `<div class="card sfc"><div class="row sb"><span class="tt">${escapeHtml(cd.nm)} <span class="sstar">${stars(cd.r)}</span></span><span class="sm">${escapeHtml(traitNm(cd.tr))}</span></div>${stBars(cd.st)}
        <div class="row sb" style="margin-top:6px"><span class="sm">向いている配置先：${bestTargetTxt(cd.st)}<br>採用費 ${fmt(staffHireFee(cd))} ・ 時給 ${fmt(staffWage({st:cd.st,lv:1}))}</span><button type="button" class="sb2" data-act="staffHire" data-id="${i}" ${L.length>=staffCap()?'disabled':''}>採用<br>する</button></div></div>`;}).join('')||'<div class="sm tc" style="padding:10px">今日の候補者はいません</div>';
    body+=`<button type="button" class="btn-cancel" style="width:100%" data-act="staffRefresh">求人を出し直す（${c.free>0?'今日は無料':fmt(staffRefreshCost())}）</button><div class="sm tc" style="margin-top:4px">候補者は毎日0時に入れ替わります</div>`;
  }
  openModal(`<div class="mt">👷 職人</div><div class="ms">在籍 ${L.length}/${staffCap()}人 ・ 人件費 ${fmt(staffWagesPh())}/時 ・ 今月の人件費 ${fmt(lab)}</div>${staffOffCard()}${staffTabs(t)}${body}<button type="button" class="cb" data-act="closeM">閉じる</button>`);
}
function acctLaborThisMonth(){const a=G.acct;if(!a||!a.cur)return 0;const s=a.cur.sga||{};return (s.hire||0)+(s.wage||0)+(s.train||0)+(s.sev||0);}
function acctLabor(p){const s=(p&&p.sga)||{};return (s.hire||0)+(s.wage||0)+(s.train||0)+(s.sev||0);}

function extAct48(act,b,id){
  switch(act){
    case 'staffOpen': openStaffModal(); return true;
    case 'staffTab': openStaffModal(id); return true;
    case 'staffBack': openStaffModal('post'); return true;
    case 'staffHire': if(staffHire(Number(id))){openStaffModal('hire');rall();} return true;
    case 'staffRefresh': if(staffRefresh())openStaffModal('hire'); return true;
    case 'staffTrain': if(staffTrain(id)){openStaffModal('list');updHdr();} return true;
    case 'staffFire': {const s=staffList().find(x=>x.id===id);if(!s)return true;
      showConfirm({title:'職人の解雇',msg:`${escapeHtml(s.nm)}（Lv${s.lv}）に辞めてもらいます。<br>退職金 <b>${fmt(staffSevFee(s))}</b> を払います。もう一度雇うことはできません。`,icon:'👷',danger:true,yesLabel:'解雇する',onYes:()=>{if(staffFire(id)){openStaffModal('list');rall();}}});return true;}
  }
  return false;
}
function v48Tick(){try{show('btnStaff',staffOn());const b=$('btnStaff');if(b){const t=G.staffOff?'👷職人⚠':'👷職人';if(b.textContent!==t)b.textContent=t;}}catch(e){}}

TUTS.u_staff={name:'職人',cond:()=>staffOn()&&tutBase(),steps:[
  {tab:'tb',sel:'#btnStaff',text:'<b>職人</b>を雇えます。設備か樽に置くと ×1.10〜×1.50。給与がかかります。'}]};
TIPS.push({id:'staff',cat:'造る',t:'職人',b:'Tier2から雇えます（あなたはTier1から配置できます）。設備か樽に1人ずつ置くと、倍率は ×1.10〜×1.50（製麦室は目利き、ほかの設備は手際、樽は技とLvで決まる。あなたは ×1.10）。設備は工程の能力か瓶詰めの速さ、樽は熟成の速さが上がります。熟成が速くなっても、熟成1年あたりの天使の分け前は同じです。研修中・休業中は効果がありません。給与は決算書の人件費に載ります。工程はいちばん遅い工程に置かないと新酒は増えません。'});
