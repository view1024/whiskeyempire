const { chromium } = require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:740},deviceScaleFactor:1.5});const p=await ctx.newPage();
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.route(/fonts/,r=>r.abort());await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1200);
await p.evaluate(()=>{Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}G.cash=1e6;rall();});
const shots=[['m1',"openUpgModal('malting')"],['m2',"openLotModal(G.lots[0].id)"],['m3',"openTip('line')"],['m4',"openTipBook()"],['m5',"openTierModal()"],['m6',"openWhiskyModal('glenlivid')"],['m7',"(()=>{closeM();G.dl=2;G.tut.done.u_t2=false;tutStart('u_t2',false);})()"]];
for(const [n,js] of shots){await p.evaluate(js);await p.waitForTimeout(600);await p.screenshot({path:n+'.png'});}
console.log(errs);await b.close();})();
