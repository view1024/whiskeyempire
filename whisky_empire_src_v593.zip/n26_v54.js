// ============================================================
// v5.4 トーストの位置・偶発イベントのアイコン・廃止した機能の整理
// ============================================================
// 実装計画：https://claude.ai/code/artifact/e083fa04-9f8f-4cfc-9ee2-bdfbc48bbc15
//  - トーストは豆知識（TIPS）の帯のすぐ下に出す（画面下のタブバーに重ねない）。長い文は2行で折り返す
//  - 偶発イベントの帯（約72px）をやめ、トーストとホームのアイコンにする（v5.5 から「市況」にまとめた）
//  - 廃止：大麦の等級・職人への差し入れ・TIPS帯の速さの設定。砂時計の入手の機会は8種類に（V51.HG）

// ---------- トースト ----------
// v5.5 豆知識の帯はホームだけ。帯が見えないタブではヘッダーの下に出す
let _tst=0;
function toastPos(){
  const t=$('ticker');let r=t?t.getBoundingClientRect():null;
  if(!r||r.height<=0){const h=$('hdr');r=h?h.getBoundingClientRect():null;}
  const y=Math.round((r&&r.height>0?r.bottom:0)+6);
  if(toastPos._y!==y){toastPos._y=y;document.documentElement.style.setProperty('--toastTop',y+'px');}
}
function toast(msg,dur=2200){
  const e=$('toast');if(!e)return;
  toastPos();e.textContent=msg;e.classList.add('on');
  clearTimeout(_tst);_tst=setTimeout(()=>e.classList.remove('on'),dur);
}
window.addEventListener('resize',toastPos);
window.addEventListener('orientationchange',()=>setTimeout(toastPos,200));

// ---------- 偶発イベント：起きたらトーストで知らせ、続く間はホームの「市況」に残り分（v5.5 選ぶイベントは廃止） ----------
function evById(id){return RAND_EVENTS.find(e=>e.id===id)||null;}
function evActive(){const a=G.randomEvent&&G.randomEvent.active;return a&&a.expiresAt>Date.now()?a:null;}
function showEventBanner(ev){
  if(!ev)return;
  applyEventEffect(ev);toast(ev.icon+' '+ev.name+(ev.dur>0?'（'+Math.round(ev.dur/60)+'分間）':''),4500);
  save();try{setHtml($('homeIcons'),homeIconsHtml());}catch(e){}
}
