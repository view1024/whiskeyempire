// ============================================================
// v5.6 創業地（第2回）：販売地域・輸出市場をやめ、再創業ごとに新しい地で蒸留所を経営する
// ============================================================
// 実装計画：https://claude.ai/code/artifact/293b44c8-9442-4602-b501-77ec0f0ad3fe
//  - 創業地（CLIMATES）：スコットランド→アイルランド→ケンタッキー→日本→台湾。再創業のたびに次の1地域が開く
//  - その地の市場：地元の種類の単価×LOCAL・その種類の注文が出やすい（台湾は10年未満の原酒の単価×LOCAL）
//  - 図鑑の「創業地」：経営中・経営した・未開放、気候と市場、その地の記録、再創業のボタン
//  - 買った販売地域・輸出市場の倍率は次の再創業まで残す（saleMult は G.regions・G.regionsEx を読むまま。買う画面はない）
const V56={LOCAL:1.2,LOCAL_W:2};

function originRuns(){return (G.prestige&&G.prestige.totalRuns)||0;}
// 開いているか：再創業の回数が足りる・今の地・経営したことがある地（v5.5 以前の保存で先に開いた地も含む）
function originOpen(c,runs){return (runs===undefined?originRuns():runs)>=c.unlockRun||c.id===G.climate||!!(G.records&&G.records[c.id]&&G.records[c.id].runs>0);}
function originName(c){return c.short||c.name;}
// 単価の倍率（priceUnit から）
function originPriceMult(sp,age){
  const c=climate();let m=1;
  if(c.tp&&sp&&sp.tp===c.tp)m*=V56.LOCAL;
  if(c.young&&age<10)m*=V56.LOCAL;
  return m;
}
// 注文の銘柄・種類を選ぶ：地元の種類は LOCAL_W 倍出やすい
function originPick(arr,tpOf){
  const c=climate();if(!c.tp||!arr.length)return pick(arr);
  const w=arr.map(x=>tpOf(x)===c.tp?V56.LOCAL_W:1);let r=Math.random()*w.reduce((a,b)=>a+b,0);
  for(let i=0;i<arr.length;i++){r-=w[i];if(r<=0)return arr[i];}
  return arr[arr.length-1];
}
function originTraits(c){
  const fl=Object.entries(c.fl||{}).map(([k,v])=>FL_KEY_MAP[k]+'+'+v).join(' ');
  return '熟成×'+c.aging+' ・ 目減り×'+c.angel+(fl?' ・ '+fl:'');
}

// ---------- 図鑑の「創業地」 ----------
function prestigePanelHtml(){
  const ok=canPrestige();const runs=originRuns();
  const nx=CLIMATES.find(c=>c.unlockRun===runs+1);
  return `<div class="row sb"><span class="tt">🌟 再創業</span>${ib('prestige')}</div>
    <div class="sm" style="color:var(--text2);margin:4px 0 8px">再創業 ${runs}回 ・ 収益×${(G.prestige&&G.prestige.bonus||1).toFixed(1)} ・ 条件：Tier5・現金 ${fmt(PRESTIGE_COST)}（借入金と未払の税を除く）${nx?'<br>次の再創業で '+nx.icon+' '+escapeHtml(originName(nx))+' が開きます':''}</div>
    <button type="button" class="btn-ok" style="width:100%" data-act="prestigeOpen" ${ok?'':'disabled'}>${ok?'次の創業地で再創業する':'条件未達（Tier'+DL.length+'・'+fmt(PRESTIGE_COST)+'）'}</button>`;
}
function rencR(){
  const el=$('recList');if(!el)return;
  const pp=$('prestigePanel');if(pp){const h=prestigePanelHtml();if(pp._h!==h){pp.innerHTML=h;pp._h=h;}}
  recCur();const runs=originRuns();
  el.innerHTML=CLIMATES.map(c=>{
    const r=G.records[c.id];const cur=c.id===G.climate;const open=originOpen(c,runs);
    const st=cur?'経営中':r&&(r.runs||0)>0?'経営した':open?'開いている':'未開放';
    if(!open)return `<div class="card org lk"><div class="row sb"><span class="tt">${c.icon} ${escapeHtml(c.name)}</span><span class="sm">🔒 再創業${c.unlockRun}回で開く</span></div></div>`;
    const td=[2,3,4,5].map(t=>r&&r.tierDays&&r.tierDays[t]?'T'+t+' '+r.tierDays[t]+'日':'').filter(Boolean).join(' ・ ');
    const te=((r&&r.te)||0)+(cur?(G.te||0):0);
    return `<div class="card org ${cur?'hl':''}"><div class="row sb"><span class="tt">${c.icon} ${escapeHtml(c.name)}</span><span class="badge ${cur?'b-res':'b-str'}">${st}</span></div>
      <div class="sm" style="color:var(--text2);margin-top:2px">${escapeHtml(c.desc)}（${escapeHtml(originTraits(c))}）</div>
      <div class="sm" style="color:var(--gold2)">市場：${escapeHtml(c.mkt)}</div>
      ${r?`<div class="msr"><div class="msl">最長の熟成</div><div class="msv">${fmtAge(r.maxAge||0)}</div></div>
      <div class="msr"><div class="msl">最高の単価</div><div class="msv">${fmt(r.bestUnit||0)}/本</div></div>
      <div class="msr"><div class="msl">通算の売上</div><div class="msv">${fmt(te)}</div></div>
      <div class="msr"><div class="msl">到達した Tier</div><div class="msv">${Math.max(r.maxTier||1,cur?G.dl:1)}${td?'（'+td+'）':''}</div></div>`:'<div class="sm">まだ経営していません</div>'}</div>`;
  }).join('')+'<div class="sm" style="padding:4px">再創業すると、開いている創業地から次の地を選べます。図鑑・称号・物語・スキル・名樽と創業地ごとの記録・砂時計は引き継ぎます。</div>';
}

// ---------- data-act ----------
function extAct55(act,b,id){
  switch(act){
    case 'prestigeOpen': openPrestigeModal(); return true;
    case 'pickOrigin': if(window._pickCl)window._pickCl(id); return true;
  }
  return false;
}

TIPS.push({id:'origin',cat:'成長',t:'創業地',b:'Tier5 と資金の条件を満たすと再創業でき、そのたびに次の創業地が1つ開きます（スコットランド→アイルランド→ケンタッキー→日本→台湾）。創業地ごとに気候（熟成の速さ・目減り・風味）と市場（地元の種類の単価×1.2・その注文が出やすい。台湾は10年未満の原酒の単価×1.2）が違います。図鑑の「創業地」で、それぞれの記録を見られます。'});
