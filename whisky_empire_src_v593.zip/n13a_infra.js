// ============================================================
// v4.2 基盤（設定・金額表記・TIPS帯・タイトル・音・演出・アイコン・景色）
// ============================================================
function opt(){if(!G.opt)G.opt={...OPT_DEFAULT};return G.opt;}
function seVol(){try{return G&&G.opt?G.opt.se:0;}catch(e){return 0;}}
function bgmVol(){try{return G&&G.opt?G.opt.bgm:0;}catch(e){return 0;}}
// v4.4 動きの方針：状態を伝える動き（流れ・印・TIPS帯・残り時間）は常に動かし、lowMotion のときはゆっくりにする。飾りの動き（紙吹雪・煙・拡大演出）は lowMotion で止める
function lowMotion(){try{if(G&&G.opt&&G.opt.motion==='low')return true;}catch(e){}return reducedMotion();}
function reducedMotion(){try{return window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;}catch(e){return false;}}
function applyOpt(){
  const o=opt();
  document.documentElement.classList.toggle('fs-l',o.fs==='l');
  document.documentElement.classList.toggle('lowmo',lowMotion());
  applyTheme();
  // v5.8 クラシック／ケルト／なし。種類が変わったら止めてから鳴らし直す
  if(_bgm.master&&_bgm.mode!==bgmMode())bgmStop();
  if(o.bgm>0&&bgmMode()!=='off'&&_titleDone)bgmStart();else bgmStop();
  if(_bgm.master&&_audioCtx)_bgm.master.gain.setTargetAtTime(o.bgm*0.22,_audioCtx.currentTime,0.3);
}
function vib(p){try{if(opt().vib&&navigator.vibrate)navigator.vibrate(p);}catch(e){}}

// ---------- v4.4 色の設定（ダーク／ライト／端末に合わせる） ----------
let _themeMq=null;
function themeResolved(){const t=opt().theme;if(t==='auto'){try{return window.matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';}catch(e){return 'dark';}}return t==='light'?'light':'dark';}
function applyTheme(){
  const r=themeResolved();const de=document.documentElement;
  if(de.dataset.theme!==r)de.dataset.theme=r;
  const mc=document.querySelector('meta[name="theme-color"]');if(mc)mc.setAttribute('content',r==='light'?'#f6f0e4':'#0d0a07');
  if(!_themeMq){try{_themeMq=window.matchMedia('(prefers-color-scheme: light)');_themeMq.addEventListener('change',()=>{if(opt().theme==='auto')applyTheme();});}catch(e){}}
}

// ---------- U2 金額の表記 ----------
function fmt(n){
  let ja=false;try{ja=!!(G&&G.opt&&G.opt.money==='ja');}catch(e){}
  if(!ja)return fmtEn(n);
  if(typeof n!=='number'||isNaN(n))return '$0';
  if(!isFinite(n))return '$∞';
  if(n<0)return '-'+fmt(-n);
  const u=(v,s)=>(v>=100?Math.round(v).toLocaleString():(Math.round(v*10)/10).toString())+s;
  if(n>=1e24)return '$'+n.toExponential(2).replace('e+','e');
  if(n>=1e20)return '$'+u(n/1e20,'垓');
  if(n>=1e16)return '$'+u(n/1e16,'京');
  if(n>=1e12)return '$'+u(n/1e12,'兆');
  if(n>=1e8)return '$'+u(n/1e8,'億');
  if(n>=1e4)return '$'+u(n/1e4,'万');
  return '$'+Math.floor(n).toLocaleString();
}

// ---------- S1 TIPS帯 ----------
const TK_LABEL={health:'健康',tips:'TIPS',trivia:'豆知識'};
const TK_SPEED={slow:40,mid:60,fast:90}; // px/秒（文の長さに関係なく同じ速さ）
const TK_GAP_MS=1200;                       // 文が抜けてから次の文までの間
let _tk={hist:[],cur:null,sinceHealth:0,timer:null,paused:false,hold:false,downAt:0,suppress:false};
function tkPool(){return TICKER_MSGS.filter(m=>m.cat!=='tips'||!m.f||feat(m.f));}
function tkPick(){
  const pool=tkPool();if(!pool.length)return null;
  let cand=pool;
  if(_tk.sinceHealth>=5)cand=pool.filter(m=>m.cat==='health');
  let m,tries=0;
  do{m=cand[Math.floor(Math.random()*cand.length)];tries++;}while(_tk.hist.includes(m)&&tries<40);
  _tk.hist.push(m);if(_tk.hist.length>8)_tk.hist.shift();
  _tk.sinceHealth=m.cat==='health'?0:_tk.sinceHealth+1;
  return m;
}
function initTicker(){
  if(!$('tkTxt'))return;
  _tk.hist=[];_tk.sinceHealth=0;
  const bar=$('ticker');
  if(bar&&!bar._bound){
    bar._bound=true;
    // 押している間は止める。長押し（0.4秒以上）の後は一覧を開かない
    bar.addEventListener('pointerdown',()=>{_tk.hold=true;_tk.downAt=Date.now();tkApplyPlay();});
    const up=()=>{if(!_tk.hold)return;_tk.hold=false;_tk.suppress=Date.now()-_tk.downAt>=400;tkApplyPlay();};
    bar.addEventListener('pointerup',up);bar.addEventListener('pointercancel',up);bar.addEventListener('pointerleave',up);
    bar.addEventListener('click',()=>{if(_tk.suppress){_tk.suppress=false;return;}openTickerModal();});
    document.addEventListener('visibilitychange',tkApplyPlay);
  }
  nextTicker();
}
// v4.3：OS の「視差効果を減らす」でも止めずに、ゆっくり流す（全文を読めることを優先）
function tkSpeed(){return TK_SPEED.mid*(lowMotion()?0.65:1);} // v5.4 速さの設定は廃止
function tkApplyPlay(){const el=$('tkTxt');if(!el)return;el.style.animationPlayState=(_tk.paused||_tk.hold||document.hidden)?'paused':'running';}
function nextTicker(){
  const el=$('tkTxt'),lb=$('tkLabel');if(!el||!lb)return;
  clearTimeout(_tk.timer);
  const m=tkPick();if(!m)return;
  _tk.cur=m;
  lb.className='tkl '+m.cat;lb.textContent=TK_LABEL[m.cat]||'';
  el.classList.remove('run','fade');el.textContent=m.text;el.style.transform='';
  el.onanimationend=null;
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    const track=$('tkTrack');const w=track?track.offsetWidth:window.innerWidth;
    const dist=w+el.offsetWidth;
    el.style.setProperty('--tk-start',w+'px');
    el.style.setProperty('--tk-dur',(dist/tkSpeed()).toFixed(2)+'s');
    el.classList.add('run');tkApplyPlay();
    el.onanimationend=()=>{if(_tk.paused)return;clearTimeout(_tk.timer);_tk.timer=setTimeout(nextTicker,TK_GAP_MS);};
  }));
}
function tkResume(){if(!_tk.paused)return;_tk.paused=false;const el=$('tkTxt');if(!el)return;if(el.classList.contains('run'))tkApplyPlay();else nextTicker();}
function openTickerModal(){
  const m=_tk.cur;if(!m)return;
  _tk.paused=true;tkApplyPlay();
  const s=m.src&&SRC[m.src];
  openModal(`<div class="ms" style="margin-bottom:6px">${TK_LABEL[m.cat]||''}</div><div class="tipb" style="font-size:16px;color:var(--cream)">${escapeHtml(m.text)}</div>
    ${s?`<div class="sm" style="margin-top:12px">出典：<a href="${s.u}" target="_blank" rel="noopener" style="color:var(--gold2)">${escapeHtml(s.t)}</a></div>`:m.src==='idea'?'<div class="sm" style="margin-top:12px">楽しみ方の提案です</div>':''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:16px"><button type="button" class="btn-cancel" data-act="tkNext">次を見る</button><button type="button" class="btn-ok" data-act="closeM">閉じる</button></div>`);
}

// ---------- U7 タイトル画面 ----------
let _titleDone=false;
function showTitle(){
  try{applyOpt();}catch(e){}
  const t=$('title');if(!t)return;
  const o=opt();const silent=!(o.se>0||o.bgm>0);
  $('titleBtns').innerHTML=silent
    ?`<button type="button" class="btn-ok tbig" data-act="titleStart">はじめる（音なし）</button><button type="button" class="btn-cancel tbig" data-act="titleStart" data-snd="1">🔊 音ありではじめる</button>`
    :`<button type="button" class="btn-ok tbig" data-act="titleStart">はじめる</button><button type="button" class="btn-cancel tbig" data-act="titleStart" data-snd="0">🔇 音なしではじめる</button>`;
  t.classList.remove('h');
}
function titleStart(snd){
  if(_titleDone)return;
  const o=opt();
  if(snd===true){o.se=0.6;o.bgm=0.35;}else if(snd===false){o.se=0;o.bgm=0;}
  _titleDone=true;
  const t=$('title');if(t)t.classList.add('h');
  applyOpt();save();
  if(o.se>0)sndPurchase();
  if(_celebQ.length&&!_celebOn)setTimeout(celebNext,300);
  setTimeout(()=>{try{tutCheck();}catch(e){}},400);
}

// ---------- U5 BGM（v5.8 クラシック・ケルトとも n24 の bgmClassic* で演奏。環境音楽は廃止） ----------
let _bgm={master:null,filter:null,mode:''};
function bgmStart(){
  if(_bgm.master||!bgmVol()||bgmMode()==='off')return;
  const ctx=_getCtx();if(!ctx)return;
  _bgm.master=ctx.createGain();_bgm.master.gain.value=0;
  _bgm.mode=bgmMode();
  _bgm.filter=ctx.createBiquadFilter();_bgm.filter.type='lowpass';_bgm.filter.frequency.value=2600;
  _bgm.master.connect(_bgm.filter);_bgm.filter.connect(ctx.destination);
  _bgm.master.gain.setTargetAtTime(bgmVol()*0.22,ctx.currentTime,1.2);
  bgmClassicStart();
}
function bgmStop(){
  bgmClassicStop();
  if(_bgm.master&&_audioCtx){try{_bgm.master.gain.setTargetAtTime(0,_audioCtx.currentTime,0.3);const m=_bgm.master,f=_bgm.filter;setTimeout(()=>{try{m.disconnect();f.disconnect();}catch(e){}},1500);}catch(e){}}
  _bgm.master=null;_bgm.filter=null;
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)bgmStop();else if(_titleDone&&bgmVol()>0&&bgmMode()!=='off')bgmStart();});
function sndCoin(){_tone(988,0.06,'square',0.08,0);_tone(1319,0.12,'square',0.08,0.06);}

// ---------- U4 演出 ----------
let _celebQ=[],_celebOn=false;
function celebrate(c){_celebQ.push(c);if(!_celebOn&&_titleDone)celebNext();}
function celebNext(){
  const el=$('celebrate');if(!el)return;
  const c=_celebQ.shift();if(!c){_celebOn=false;el.classList.add('h');return;}
  _celebOn=true;
  const conf=lowMotion()?'':Array.from({length:26},(_,i)=>`<i style="left:${(i*37)%100}%;animation-delay:${(i%9)*0.08}s;background:${['#e8b94a','#d4691e','#f0e6c8','#4a9a6a'][i%4]}"></i>`).join('');
  const card=c.card?`<div class="flipcard"><div class="fc-in"><div class="fc-back">?</div><div class="fc-front"><div style="font-size:30px">${c.card.em}🥃</div><div class="tt" style="font-size:17px;margin-top:6px">${escapeHtml(c.card.name)}</div><div class="sm">${escapeHtml(c.card.rg)}</div></div></div></div>`:`<div class="cl-ic">${c.icon||'🎉'}</div>`;
  el.innerHTML=`<div class="conf">${conf}</div><div class="cl-box">${card}<div class="cl-t">${escapeHtml(c.title)}</div>${c.sub?`<div class="cl-s">${escapeHtml(c.sub)}</div>`:''}<div class="sm" style="margin-top:14px">タップで閉じる</div></div>`;
  el.classList.remove('h');
  vib([40,30,60]);
  clearTimeout(el._t);el._t=setTimeout(celebNext,c.card?4200:3400);
}
function celebClose(){const el=$('celebrate');if(el)clearTimeout(el._t);celebNext();}

// 残高のカウントアップ
let _hcShown=null,_hcAnim=null;
function animCash(){
  const el=$('hc');if(!el)return;
  const target=G.cash;
  if(_hcShown===null||target<_hcShown||lowMotion()||target-_hcShown<Math.max(1000,_hcShown*0.03)){_hcShown=target;if(_hcAnim){cancelAnimationFrame(_hcAnim);_hcAnim=null;}setText('hc',fmt(target));return;}
  if(_hcAnim)return;
  const from=_hcShown,t0=performance.now(),dur=600;
  const step=now=>{const k=Math.min(1,(now-t0)/dur);const v=from+(G.cash-from)*(1-Math.pow(1-k,3));el.textContent=fmt(v);if(k<1)_hcAnim=requestAnimationFrame(step);else{_hcAnim=null;_hcShown=G.cash;el.textContent=fmt(G.cash);}};
  _hcAnim=requestAnimationFrame(step);
}

// ---------- U3 アイコン（自作SVG、currentColorで描く） ----------
const ICONS={
  home:'<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  make:'<path d="M3 20V10l5 3V10l5 3V10l5 3v7z"/><path d="M17 20V5h3v15"/><path d="M3 20h18"/>',
  cask:'<ellipse cx="12" cy="5" rx="6" ry="2"/><path d="M6 5c-1 4-1 10 0 14M18 5c1 4 1 10 0 14"/><ellipse cx="12" cy="19" rx="6" ry="2"/><path d="M5.4 9.5h13.2M5.4 14.5h13.2"/>',
  sell:'<path d="M3 8l9-4 9 4v9l-9 4-9-4z"/><path d="M3 8l9 4 9-4M12 12v9"/>',
  book:'<path d="M12 6c-2-1.5-5-2-8-1.5V19c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5V4.5c-3-.5-6 0-8 1.5z"/><path d="M12 6v14.5"/>',
  gear:'<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  tank:'<rect x="7" y="3" width="10" height="17" rx="3"/><path d="M7 13h10"/><path d="M9 21h6"/>',
  bottle:'<path d="M10 2h4v4l2 3v12H8V9l2-3z"/><path d="M8 13h8"/>',
  order:'<path d="M6 3h9l3 3v15H6z"/><path d="M15 3v3h3M9 10h6M9 14h6M9 18h4"/>',
  malting:'<path d="M12 21V9"/><path d="M12 9c-3-1-4-4-4-6 3 1 4 3 4 6zM12 9c3-1 4-4 4-6-3 1-4 3-4 6zM12 14c-3-1-4-4-4-6 3 1 4 3 4 6zM12 14c3-1 4-4 4-6-3 1-4 3-4 6z"/>',
  mashing:'<path d="M4 9h16l-2 11H6z"/><path d="M15 3l-4 12"/><path d="M8 13h8"/>',
  fermentation:'<path d="M5 6h14v14H5z"/><path d="M5 10h14"/><circle cx="10" cy="15" r="1.3"/><circle cx="14" cy="13.5" r="1"/><circle cx="13" cy="17" r="1.2"/>',
  distillation:'<path d="M9 21c-4 0-5-3-5-6 0-4 3-6 5-7V5h3v3c2 1 4 3 4 7"/><path d="M12 5h5l3 4"/><path d="M4 21h12"/>',
  maturation:'<path d="M3 10l9-6 9 6v11H3z"/><ellipse cx="9" cy="16" rx="2.2" ry="3"/><ellipse cx="15" cy="16" rx="2.2" ry="3"/>',
  bottling:'<path d="M7 3h2v3l1 2v9H6V8l1-2z"/><path d="M15 3h2v3l1 2v9h-4V8l1-2z"/><path d="M3 20h18"/>',
  visitor:'<circle cx="12" cy="7" r="3.2"/><path d="M6 21c0-4 3-7 6-7s6 3 6 7"/>',
  barley:'<path d="M12 22V8"/><path d="M12 8c-2-1-3-3-3-5 2 1 3 3 3 5zM12 8c2-1 3-3 3-5-2 1-3 3-3 5zM12 12c-2.5-.8-4-2.8-4-5 2.4.8 4 2.6 4 5zM12 12c2.5-.8 4-2.8 4-5-2.4.8-4 2.6-4 5zM12 16.5c-2.5-.8-4-2.8-4-5 2.4.8 4 2.6 4 5zM12 16.5c2.5-.8 4-2.8 4-5-2.4.8-4 2.6-4 5z"/>',
  chap:'<path d="M6 21V4"/><path d="M6 4h11l-2 4 2 4H6"/>',
  daily:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/><path d="M9 15l2 2 4-4"/>',
  market:'<path d="M4 20V4"/><path d="M4 20h16"/><path d="M7 15l4-4 3 3 5-6"/>',
  tier:'<path d="M12 3l3 6 6 .8-4.5 4.2 1 6-5.5-3-5.5 3 1-6L3 9.8 9 9z"/>',
  hourglass:'<path d="M6 3h12M6 21h12"/><path d="M8 3c0 4.5 8 5 8 9s-8 4.5-8 9"/><path d="M16 3c0 4.5-8 5-8 9s8 4.5 8 9"/>',
  fin:'<path d="M4 20h16"/><rect x="5.5" y="11" width="3.5" height="6.5" rx=".6"/><rect x="10.3" y="6" width="3.5" height="11.5" rx=".6"/><rect x="15.1" y="9" width="3.5" height="8.5" rx=".6"/>',
  recipe:'<path d="M9 3h6M10 3v6L5 19a1.5 1.5 0 0 0 1.3 2h11.4a1.5 1.5 0 0 0 1.3-2L14 9V3"/><path d="M7.5 15h9"/>',
  blend:'<path d="M5 4h5v6a2.5 2.5 0 0 1-5 0z"/><path d="M14 4h5v6a2.5 2.5 0 0 1-5 0z"/><path d="M7.5 12.5L12 20l4.5-7.5"/>',
};
function ic(name,sz,extra){const p=ICONS[name];if(!p)return '';return `<svg class="ico ${extra||''}" width="${sz||22}" height="${sz||22}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;}
function facIc(id,sz){return ic(id,sz||26,'fic');}
function applyIcons(){document.querySelectorAll('[data-ic]').forEach(el=>{if(!el._ic){el._ic=1;el.innerHTML=ic(el.dataset.ic,Number(el.dataset.sz)||22);}});}
function avatar(cid,sz){const p=CUST_PERSONA[cid];if(!p)return '';const s=sz||34;return `<span class="ava" style="width:${s}px;height:${s}px;background:${p.col};font-size:${Math.round(s*0.46)}px">${escapeHtml(p.ini)}</span>`;}

// ---------- v4.4 蒸留所の景色：1枚の絵を時間帯で明るさと色味を変えて表示 ----------
// 朝 5〜9時／昼 9〜16時／夕 16〜19時／夜 19〜5時（端末の時計）
function sceneTime(h){if(h===undefined)h=new Date().getHours();return h>=5&&h<9?'am':h>=9&&h<16?'day':h>=16&&h<19?'eve':'night';}
const SCENE_TIME_LABEL={am:'朝',day:'昼',eve:'夕方',night:'夜'};
