// ============================================================
// v5.8 BGM「ケルト」5曲（環境音楽の代わり）
// ============================================================
// 実装計画：https://claude.ai/code/artifact/64d327da-f8bd-4631-b3f1-4e9869a6f731
//  - 旋律：アイルランドの伝承曲と O'Carolan（1670〜1738）の曲。The Traditional Tune Archive に載る古い曲集の ABC 譜
//    （Haverty 1858・Petrie 1790・Manson 1846・Hughes の曲集）から音と長さを写したもの。伴奏・編曲はこのゲームで作ったもの
//  - 音色：7 ハープ（はじく音）・8 フィドル・9 ティンホイッスル・10 バウロン（枠太鼓）。クラシックと同じ演奏の仕組み（n24 の bgmClassic*）で鳴らす
//  - 曲は1曲60〜130秒。軽快にするため速めのテンポ・歯切れのよい長さ・2巡目以降は太鼓。乱数で楽器の組み合わせが変わる
const V58={GRACE:.15};

// ---------- ABC 譜の読み取り（このゲームで使う範囲だけ） ----------
// 音名 A〜G・a〜g、オクターブ , '、臨時記号 ^ _ =（小節の中で続く）、長さ 2・/2・3/2・/、付点 > <、タイ -、休み z、
// 前打音 {c}、装飾 T ~（上の音の短い前打音にする）、三連符 (3、小節線 | || |] :| |:。長さの単位は L（8分音符）
const ABC_PC={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
const ABC_KEY={Edor:{F:1,C:1},D:{F:1,C:1},G:{F:1},F:{B:-1},Fsm:{F:1,C:1,G:1}};
const ABC_LET='CDEFGAB';
// → {n:[{t,len,m,g}], seg:[[開始,長さ]…]（小節線で区切った区間）, len}
function abcParse(s,key){
  const K=ABC_KEY[key]||{};const L=s.length;const n=[],bars=[0];
  let t=0,i=0,acc={},last=null,tie=false,gr=[],orn=false,tp=0,tpk=1,brk=1;
  const dur=()=>{let a='';while(i<L&&s[i]>='0'&&s[i]<='9')a+=s[i++];let d=a?+a:1;while(s[i]==='/'){i++;let b='';while(i<L&&s[i]>='0'&&s[i]<='9')b+=s[i++];d/=b?+b:2;}return d;};
  const pitch=()=>{
    let ac=null;while(i<L&&'^_='.includes(s[i])){const c=s[i++];ac=c==='^'?(ac||0)+1:c==='_'?(ac||0)-1:0;}
    const c=s[i++];const up=c.toUpperCase();let m=60+ABC_PC[up]+(c!==up?12:0);
    while(s[i]===','||s[i]==="'"){m+=s[i]===','?-12:12;i++;}
    const kk=up+m;if(ac!==null)acc[kk]=ac;const a=kk in acc?acc[kk]:(K[up]||0);
    return {m:m+a,up,a};
  };
  // 上の隣の音（調の音階で）
  const upper=p=>{const j=ABC_LET.indexOf(p.up),u=ABC_LET[(j+1)%7];return p.m-p.a+((ABC_PC[u]-ABC_PC[p.up]+12)%12)+(K[u]||0);};
  const len3=d=>{d*=brk;brk=1;if(tp){d*=tpk;if(--tp===0)tpk=1;}return d;};
  while(i<L){
    const c=s[i];
    if(c===' '||c==='\n'||c==='\t'){i++;continue;}
    if(c==='|'||c===':'||c===']'||c==='['){while(i<L&&'|:[]'.includes(s[i]))i++;if(t>bars[bars.length-1]+1e-9)bars.push(t);acc={};continue;}
    if(c==='"'){i=s.indexOf('"',i+1)+1;continue;}
    if(c==='('){if(s[i+1]>='2'&&s[i+1]<='9'){tp=+s[i+1];tpk=tp===2?1.5:(tp-1)/tp;i+=2;}else i++;continue;}
    if(c===')'){i++;continue;}
    if(c==='{'){i++;while(i<L&&s[i]!=='}'){if(/[A-Ga-g^_=]/.test(s[i]))gr.push(pitch().m);else i++;}i++;continue;}
    if(c==='T'||c==='~'){orn=true;i++;continue;}
    if(c==='-'){tie=true;i++;continue;}
    if(c==='>'||c==='<'){const k=c==='>'?.5:-.5;if(last){const d=last.d*k;last.len+=d;last.d+=d;t+=d;}brk=1-k;i++;continue;}
    if(c==='z'||c==='x'){i++;t+=len3(dur());last=null;tie=false;continue;}
    if(/[A-Ga-g^_=]/.test(c)){
      const p=pitch();const d=len3(dur());
      if(tie&&last&&last.m===p.m&&!gr.length&&!orn){last.len+=d;last.d+=d;t+=d;tie=false;continue;}
      tie=false;const g=gr.slice();if(orn)g.push(upper(p));gr=[];orn=false;
      let t0=t,len=d;
      if(g.length){const gl=Math.min(V58.GRACE,d/3);g.forEach((gm,k)=>n.push({t:t+k*gl,len:gl,m:gm,g:1,d:gl}));t0+=g.length*gl;len-=g.length*gl;}
      const o={t:t0,len,m:p.m,g:0,d};n.push(o);last=o;t+=d;continue;
    }
    i++;
  }
  if(t>bars[bars.length-1]+1e-9)bars.push(t);
  return {n,seg:bars.slice(0,-1).map((b,j)=>[b,bars[j+1]-b]),len:t};
}

// ---------- 和音と伴奏 ----------
// "Em" "F#m" "Bb" "A7" → {r:根音, iv:[音程]}
function celChord(c){const x=/^([A-G])([#b]?)(m?)(7?)$/.exec(c||'');if(!x)return null;const r=(ABC_PC[x[1]]+(x[2]==='#'?1:x[2]==='b'?-1:0)+12)%12;const iv=x[3]?[0,3,7]:[0,4,7];if(x[4])iv.push(10);return {r,iv};}
const celBass=C=>40+((C.r-4+12)%12);                                   // E2〜D#3
const celTone=(C,k)=>55+(((C.r+C.iv[k])%12-7+12)%12);                 // G3〜F#4
// 伴奏の型：o(t,長さ,MIDI,強さ)。w はその和音の長さ（8分音符の数）
const CEL_PAT={
  // リール・歌：拍の頭に低音、裏に2音
  reel:(o,t,w,C,v)=>{for(let q=0;q<w-.01;q+=4){o(t+q,1.4,celBass(C),v);if(q+2<w-.01){o(t+q+2,1.2,celTone(C,1),v*.62);o(t+q+2,1.2,celTone(C,2),v*.62);}}},
  // ジグ（6/8）：付点4分ごとに低音、3つ目の8分に2音
  jig:(o,t,w,C,v)=>{for(let q=0;q<w-.01;q+=3){o(t+q,1.5,celBass(C),v);if(q+2<w-.01){o(t+q+2,.7,celTone(C,1),v*.58);o(t+q+2,.7,celTone(C,2),v*.58);}}},
  // ワルツ（3/4）：1拍目に低音、2・3拍目に2音
  waltz:(o,t,w,C,v)=>{for(let q=0;q<w-.01;q+=2){if(q%6===0)o(t+q,2,celBass(C),v);else{o(t+q,1.1,celTone(C,1),v*.55);o(t+q,1.1,celTone(C,2),v*.55);}}},
  // ゆっくりした曲：低音から順に上がって下りる分散和音
  arp:(o,t,w,C,v)=>{const b=celBass(C),st=[0,7,12,12+C.iv[1],19,12+C.iv[1],12,7];for(let q=0;q<w-.01;q++)o(t+q,Math.min(3,w-q),b+st[q%8],v*(q===0?1:.7));},
  // 持続する和音（弦）
  pad:(o,t,w,C,v)=>{[0,1,2].forEach(k=>o(t,w*.98,celTone(C,k),v));}
};
// 旋律：P を t0 から。tr は移調（半音）。b は1小節の8分音符の数（強拍を少し強く）
function celMel(out,P,t0,ins,v,tr,b,o){
  o=o||{};const pk=P.seg.length&&P.seg[0][1]<b-1e-9?P.seg[0][1]:0;const last=P.n[P.n.length-1];
  P.n.forEach(x=>{
    const pos=((x.t-pk)%b+b)%b;const a=b===6&&!o.w?(pos%3<.01?1:.74):(pos<.01?1:pos%2<.01?.84:.7);
    let len=x.g?x.len:Math.max(.3,x.len*(o.leg||.82));if(x===last&&o.hold)len=x.len+o.hold;
    out.push([t0+x.t,len,x.m+tr,Math.min(1,v*a*(x.g?.6:1)),ins]);
  });
}
// 伴奏：ch は区間（小節）ごとの和音。"Em D" は区間の前半と後半。'' は鳴らさない
function celAcc(out,P,ch,t0,pat,ins,v){
  const o=(t,l,m,vv)=>out.push([t,l,m,Math.min(1,vv),ins]);
  P.seg.forEach((s,j)=>{const cs=(ch[j]||'').trim().split(/\s+/).filter(Boolean);const w=s[1]/(cs.length||1);
    cs.forEach((cn,k)=>{const C=celChord(cn);if(C)CEL_PAT[pat](o,t0+s[0]+k*w,w,C,v);});});
}
// バウロン：1小節の型 [位置, 強さ, MIDI]。最初の短い区間（弱起）は後ろにそろえ、最後の短い小節は前にそろえる
const CEL_DR={reel:[[0,.9,45],[1,.25,52],[2,.5,50],[3,.3,52],[4,.75,45],[5,.25,52],[6,.5,50],[7,.35,52]],
  jig:[[0,.9,45],[1,.3,52],[2,.45,50],[3,.75,45],[4,.3,52],[5,.45,50]],
  song:[[0,.8,45],[2,.35,50],[3,.3,52],[4,.65,45],[6,.4,50],[7,.3,52]],
  waltz:[[0,.8,45],[2,.4,50],[3,.25,52],[4,.4,50]]};
function celDrum(out,P,t0,pat,b,v){
  const D=CEL_DR[pat];
  P.seg.forEach((s,j)=>{const off=j===0&&s[1]<b-1e-9?b-s[1]:0;D.forEach(([p,vv,m])=>{const q=p-off;if(q>=-1e-9&&q<s[1]-1e-9)out.push([t0+s[0]+q,.25,m,Math.min(1,v*vv),10]);});});
}
// 曲を組み立てる：parts の各区間を順に（mel：[音色, 強さ, 移調]…、acc：伴奏の強さ、dr：太鼓の強さ、pad：弦の強さ）
function celPlay(out,t,parts,b,pat,dpat){
  parts.forEach(x=>{const P=x.P;
    (x.mel||[]).forEach(([ins,v,tr,leg])=>celMel(out,P,t,ins,v,tr,b,{leg,w:pat==='waltz',hold:x.hold}));
    if(x.acc)celAcc(out,P,x.ch,t,x.ap||pat,7,x.acc);
    if(x.pad)celAcc(out,P,x.ch,t,'pad',3,x.pad);
    if(x.dr)celDrum(out,P,t,dpat,b,x.dr);
    t+=P.len;});
  return t;
}
// 終わりの和音（ハープの分散和音＋旋律の楽器で根音を伸ばす）
function celEnd(out,t,c,w,lead){const C=celChord(c);CEL_PAT.arp((tt,l,m,v)=>out.push([tt,l,m,v,7]),t,w,C,.45);(lead||[]).forEach(([ins,v,m])=>out.push([t,w*.9,m,v,ins]));}

// ---------- 曲（旋律の ABC 譜・和音） ----------
// Drowsy Maggie（リール・ホ短調ドリア）：Haverty「300 Irish Airs」1858 の版
const CEL_MAG_A='E2 BE dEBE|E2 BE AFB,F|E2 BE eEBE|BABc dAFB,|E2 BE dEBE|E2 BE AFB,F|E2 BE dEBE|{c}BABc dAFB,|';
const CEL_MAG_B='d2 fd c2 ec|d2 fd ecAc|d2 fd c2 ec|defg afec|d2 fd c2 ec|d2 fd ecAc|d2 fd c2 ec|{c}BABc dAFB,|';
const CEL_MAG_CA=['Em','Em D','Em','Bm D','Em','Em D','Em','Bm D'],CEL_MAG_CB=['D A','D A','D A','D A','D A','D A','D A','Bm D'];
// The Irish Washerwoman（ジグ・ヘ長調）：Petrie 1790 の版
const CEL_WAS_A='c/B/|AFF CFF|AFA cBA|BGG G,GG|BGB dcB|AFF CFF|AFA cBA|TBAB GcB|AFF F2|';
const CEL_WAS_B='c|fcc Acc|fcf agf|ecc Gcc|ece gfe|fcc Acc|fag fcA|TBAB GcB|AFF F2c|fcc Acc|fcf agf|ecc Gcc|ece gfe|dbb caa|Bgg Aff|TBAB GcB|AFF F2|';
const CEL_WAS_CA=['','F','F','C7','C7','F','F','C','F'],CEL_WAS_CB=['','F','F','C','C','F','F','C','F','F','F','C','C','Bb F','Gm F','C','F'];
// Harvest Home（ホーンパイプ・ニ長調・はねるリズム）：Manson「Hamilton's Universal Tune Book」1846 の版
const CEL_HH_A='FE|DAFA DAFA|defe dcBA|eAfA gAfA|edcB AGFE|DAFA DAFD|defe dcBA|eAfA gedc|d2f2d2|';
const CEL_HH_B='cd|eAAA fAAA|gAAA fAAA|eAfA gAfA|edcB AGFE|Dddd cdec|Dddd cdef|gfge cABc|d2f2d2|';
const CEL_HH_CA=['','D','D G','A7','A7','D','D G','A7','D'],CEL_HH_CB=['','A D','A7 D','A7','A7','D A','D A','G A','D'];
// はねるリズム：8分音符2つを長短（s＝0.28 で約 1.28：0.72）にする。t は8分音符の単位、4分音符の頭は偶数
function celSwing(out,sw){const w=x=>{const q=Math.floor(x/2+1e-9)*2,r=x-q;return q+(r<1?r*(1+sw):(1+sw)+(r-1)*(1-sw));};out.forEach(n=>{const a=w(n[0]),e=w(n[0]+n[1]);n[0]=a;n[1]=Math.max(.05,e-a);});return out;}
// Sí Bheag, Sí Mhór（3/4・ニ長調）：O'Carolan
const CEL_SB_A='de|f3ed2|d3ed2|B4A2|F4A2|BABc d2|e4de|f4e2|d4f2|B4e2|A4d2|F4E2|D4f2|B4e2|A4dc|d6|d4|';
const CEL_SB_B='de|f3ed2|edef a2|b4a2|f4ed|e4a2|f4e2|d4B2|B4BA|F4E2|D4f2|B4e2|A4a2|bagfed|e4dc|d6|d4|';
const CEL_SB_CA=['','D','Bm','G','D','G','A','D A','Bm','Em','D','D A','Bm','Em','A','D','D'],CEL_SB_CB=['','D','A','G','D','A','D A','Bm','Em','D A','Bm','Em','A','G D','A','D','D'];
// The Star of the County Down（4/4・嬰ヘ短調）：Herbert Hughes「Irish Country Songs」の版。最初の4小節を2回、後半の2行を続ける（16小節）
const CEL_ST_A='FF FE/F/ AA BA/B/|cB/A/ FE/C/ E3 C/E/|FF FE/F/ AA BA/B/|cB/A/ FF F2 ';
const CEL_ST_B='ec cB/A/ BB BA/B/|cB/A/ FE/C/ E2 z C/E/|FF F/>F/ E/>F/ AA/A/ BA/B/|cB/A/ FF F2 zc|';
const CEL_ST_C='ec cB/A/ BB BA/B/|cB/A/ FE/C/ E3 C/E/|FF FE/F/ AA BA/B/|cB/A/ FF ';
const CEL_ST_CA=['F#m D','F#m A','F#m D','F#m'],CEL_ST_CB=['A E','F#m A','F#m D','F#m'];

const BGM_CELTIC=[
  {id:'maggie',t:'ドラウジー・マギー（Drowsy Maggie）',c:'アイルランド民謡（リール）',bpm:420,lp:4400,build:r=>{
    const out=[];const A=abcParse(CEL_MAG_A,'Edor'),B=abcParse(CEL_MAG_B,'Edor');
    // 6巡：フィドルと太鼓 → ＋ホイッスル → ホイッスルかフルートが旋律 → 全員 → フィドル → 全員（乱数で1巡目と3巡目が変わる）
    const w3=r()<.5,f1=r()<.5;const FW=[[8,.82,0],[9,.52,12]];
    const R=[{mel:f1?[[8,.8,0]]:[[9,.7,12]],acc:.4,dr:.35},{mel:FW,acc:.42,dr:.5},{mel:w3?[[9,.72,12]]:[[1,.62,12]],acc:.45,dr:.45},
      {mel:FW,acc:.46,dr:.58},{mel:[[8,.84,0]],acc:.44,dr:.5},{mel:FW,acc:.46,dr:.58}];
    let t=0;R.forEach(x=>{t=celPlay(out,t,[{P:A,ch:CEL_MAG_CA,...x},{P:B,ch:CEL_MAG_CB,...x}],8,'reel','reel');});
    celEnd(out,t,'Em',8,[[8,.7,64],[9,.45,76]]);out.push([t,.25,45,.85,10]);
    return out;}},
  {id:'washer',t:'アイリッシュ・ウォッシャーウーマン（The Irish Washerwoman）',c:'アイルランド民謡（ジグ）',bpm:372,lp:4400,build:r=>{
    const out=[];const A=abcParse(CEL_WAS_A,'F'),B=abcParse(CEL_WAS_B,'F');
    // 3巡（A A B）：ホイッスルとハープ（後半から太鼓） → フィドル・ホイッスル・太鼓 → フィドル（後半にホイッスル）
    const s=r()<.5;const L1=s?[[9,.7,12]]:[[8,.78,0]],L3=s?[[8,.8,0]]:[[9,.7,12]];const FW=[[8,.8,0],[9,.52,12]];
    const R=[[{mel:L1,acc:.4},{mel:L1,acc:.42,dr:.35},{mel:L1,acc:.42,dr:.45}],
      [{mel:FW,acc:.42,dr:.52},{mel:FW,acc:.42,dr:.52},{mel:FW,acc:.45,dr:.56}],
      [{mel:L3,acc:.42,dr:.48},{mel:L3,acc:.42,dr:.48},{mel:FW,acc:.45,dr:.56,hold:4}]];
    let t=0;R.forEach(x=>{t=celPlay(out,t,[{P:A,ch:CEL_WAS_CA,...x[0]},{P:A,ch:CEL_WAS_CA,...x[1]},{P:B,ch:CEL_WAS_CB,...x[2]}],6,'jig','jig');});
    celEnd(out,t+1,'F',6,[]);out.push([t+1,.25,45,.85,10]);
    return out;}},
  {id:'harvest',t:'ハーベスト・ホーム（Harvest Home）',c:'アイルランド・スコットランドの伝承曲（ホーンパイプ）',bpm:320,lp:4400,build:r=>{
    const out=[];const A=abcParse(CEL_HH_A,'D'),B=abcParse(CEL_HH_B,'D');
    // 2巡（A A B B）：フィドルとハープ → ホイッスルが加わり太鼓 → ハープかホイッスルが旋律 → 全員（乱数で3つ目が変わる）
    const h=r()<.5;const FW=[[8,.8,0],[9,.5,12]];
    const R=[[{mel:[[8,.8,0]],acc:.4},{mel:[[8,.8,0]],acc:.42,dr:.4},{mel:FW,acc:.44,dr:.5},{mel:FW,acc:.44,dr:.5}],
      [{mel:h?[[7,.6,12]]:[[9,.7,12]],acc:.42,dr:.42},{mel:FW,acc:.44,dr:.55},{mel:FW,acc:.45,dr:.56},{mel:FW,acc:.45,dr:.56,hold:4}]];
    let t=0;R.forEach(x=>{t=celPlay(out,t,[{P:A,ch:CEL_HH_CA,...x[0]},{P:A,ch:CEL_HH_CA,...x[1]},{P:B,ch:CEL_HH_CB,...x[2]},{P:B,ch:CEL_HH_CB,...x[3]}],8,'reel','reel');});
    celEnd(out,t+2,'D',8,[]);out.push([t+2,.25,45,.85,10]);
    return celSwing(out,.28);}},
  {id:'sibheag',t:'シー・ベグ・シー・モー（Sí Bheag, Sí Mhór）',c:'ターロック・オキャロラン',bpm:270,lp:4000,build:r=>{
    const out=[];const A=abcParse(CEL_SB_A,'D'),B=abcParse(CEL_SB_B,'D');
    // A A B B：ハープ → フルートと太鼓 → フィドルとフルート → ハープとフルート（乱数で最後をフィドルに）
    const fd=r()<.5;
    const t=celPlay(out,0,[{P:A,ch:CEL_SB_CA,mel:[[7,.58,0,.9]],acc:.36},{P:A,ch:CEL_SB_CA,mel:[[1,.62,0,.85]],acc:.36,dr:.35},
      {P:B,ch:CEL_SB_CB,mel:[[8,.72,0,.85],[1,.4,12,.85]],acc:.38,dr:.42},{P:B,ch:CEL_SB_CB,mel:[[7,.5,0,.9],fd?[8,.55,0,.85]:[1,.5,0,.85]],acc:.38,dr:.42,hold:4}],6,'waltz','waltz');
    celEnd(out,t+2,'D',6,[]);out.push([t+2,.25,45,.8,10]);
    return out;}},
  {id:'star',t:'スター・オブ・ザ・カウンティ・ダウン（The Star of the County Down）',c:'アイルランド民謡',bpm:252,lp:4400,build:r=>{
    const out=[];const I=abcParse('z7 C/E/|','Fsm');
    const A1=abcParse(CEL_ST_A+'z C/E/|','Fsm'),A2=abcParse(CEL_ST_A+'zc|','Fsm'),B=abcParse(CEL_ST_B,'Fsm'),C1=abcParse(CEL_ST_C+'F2 z C/E/|','Fsm'),C2=abcParse(CEL_ST_C+'F4|','Fsm');
    // 前奏の後に3巡：フィドルと太鼓 → ホイッスル → フィドルとホイッスル（乱数で2巡目をフルートに）
    const fl=r()<.5;const L2=fl?[[1,.62,12]]:[[9,.65,12]];
    let t=celPlay(out,0,[{P:I,ch:['F#m'],mel:[[8,.75,0]],acc:.4,ap:'arp',dr:.3}],8,'reel','song');
    const R=[{mel:[[8,.8,0]],acc:.42,dr:.35},{mel:L2,acc:.44,dr:.48},{mel:[[8,.82,0],[9,.52,12]],acc:.46,dr:.55}];
    R.forEach((x,k)=>{t=celPlay(out,t,[{P:A1,ch:CEL_ST_CA,...x},{P:A2,ch:CEL_ST_CA,...x},{P:B,ch:CEL_ST_CB,...x},{P:k===2?C2:C1,ch:CEL_ST_CB,...x,hold:k===2?2:0}],8,'reel','song');});
    celEnd(out,t,'F#m',8,[]);out.push([t,.25,45,.85,10]);
    return out;}}
];

// ---------- 音色 ----------
const celF=m=>440*Math.pow(2,(m-69)/12);
// 7 ハープ：はじく音。三角波＋2倍音、はじいた直後だけ明るく、長さにかかわらず減衰して消える
function bgmHarp(ctx,m,t,dur,vel){
  const f=celF(m);const o1=ctx.createOscillator(),o2=ctx.createOscillator(),g=ctx.createGain(),g2=ctx.createGain(),lp=ctx.createBiquadFilter();
  o1.type='triangle';o2.type='sine';o1.frequency.value=f;o2.frequency.value=f*2;g2.gain.value=.3;
  lp.type='lowpass';lp.Q.value=.6;lp.frequency.setValueAtTime(Math.min(9000,f*10),t);lp.frequency.setTargetAtTime(Math.min(6000,f*3),t+.005,.08);
  o1.connect(lp);o2.connect(g2);g2.connect(lp);lp.connect(g);g.connect(_bgm.master);
  const pk=.3*vel,tau=Math.max(.18,.62-(m-45)*.012),end=t+dur+BGM_TAIL[7];
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+.004);g.gain.setTargetAtTime(0,t+.006,tau);g.gain.setTargetAtTime(0,end-.12,.03);
  o1.start(t);o2.start(t);o1.stop(end);o2.stop(end);
}
// 8 フィドル：のこぎり波2つ（少しずらす）を丸め、弓で弾く立ち上がり、長い音だけ遅れて揺れる
function bgmFiddle(ctx,m,t,dur,vel){
  const f=celF(m);const o1=ctx.createOscillator(),o2=ctx.createOscillator(),lp=ctx.createBiquadFilter(),pe=ctx.createBiquadFilter(),g=ctx.createGain();
  o1.type=o2.type='sawtooth';o1.frequency.value=o2.frequency.value=f;o2.detune.value=6;
  lp.type='lowpass';lp.Q.value=.7;lp.frequency.value=Math.min(5200,f*4.5);pe.type='peaking';pe.frequency.value=2600;pe.Q.value=1.2;pe.gain.value=4;
  o1.connect(lp);o2.connect(lp);lp.connect(pe);pe.connect(g);g.connect(_bgm.master);
  const stop=t+dur+.14;
  if(dur>.3){const l=ctx.createOscillator(),lg=ctx.createGain();l.frequency.value=5.6;lg.gain.setValueAtTime(0,t);lg.gain.setValueAtTime(0,t+.15);lg.gain.linearRampToValueAtTime(f*.006,t+Math.min(.5,dur));l.connect(lg);lg.connect(o1.frequency);lg.connect(o2.frequency);l.start(t);l.stop(stop);}
  const pk=.075*vel;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+.03);g.gain.linearRampToValueAtTime(pk*.85,t+Math.min(.12,dur));g.gain.setValueAtTime(pk*.85,t+dur);g.gain.linearRampToValueAtTime(0,t+dur+.1);
  o1.start(t);o2.start(t);o1.stop(stop);o2.stop(stop);
}
// 9 ティンホイッスル：正弦波＋少しの2倍音、吹き始めの息の音、長い音だけ揺れる
function bgmWhistle(ctx,m,t,dur,vel){
  const f=celF(m);const o1=ctx.createOscillator(),o2=ctx.createOscillator(),g=ctx.createGain(),g2=ctx.createGain();
  o1.type='sine';o2.type='sine';o1.frequency.value=f;o2.frequency.value=f*2;g2.gain.value=.12;
  o1.connect(g);o2.connect(g2);g2.connect(g);g.connect(_bgm.master);
  const stop=t+dur+.08;
  if(dur>.35){const l=ctx.createOscillator(),lg=ctx.createGain();l.frequency.value=5.8;lg.gain.setValueAtTime(0,t);lg.gain.setValueAtTime(0,t+.2);lg.gain.linearRampToValueAtTime(f*.004,t+Math.min(.6,dur));l.connect(lg);lg.connect(o1.frequency);lg.connect(o2.frequency);l.start(t);l.stop(stop);}
  const pk=.17*vel;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+.015);g.gain.setValueAtTime(pk,t+dur);g.gain.linearRampToValueAtTime(0,t+dur+.05);
  o1.start(t);o2.start(t);o1.stop(stop);o2.stop(stop);
  // 息の音（高い音域の雑音を短く）
  const n=ctx.createBufferSource(),bp=ctx.createBiquadFilter(),ng=ctx.createGain();n.buffer=celNoise(ctx);bp.type='bandpass';bp.frequency.value=Math.min(8000,f*2);bp.Q.value=1.5;
  n.connect(bp);bp.connect(ng);ng.connect(_bgm.master);ng.gain.setValueAtTime(.05*vel,t);ng.gain.setTargetAtTime(0,t+.01,.03);n.start(t);n.stop(t+.15);
}
// 10 バウロン：低い音程が下がる正弦波＋短い雑音（m が低いほど深い音）
function bgmBodhran(ctx,m,t,vel){
  const f=celF(m);const o=ctx.createOscillator(),g=ctx.createGain();o.type='sine';o.frequency.setValueAtTime(f*1.8,t);o.frequency.exponentialRampToValueAtTime(f,t+.06);
  o.connect(g);g.connect(_bgm.master);g.gain.setValueAtTime(.45*vel,t);g.gain.setTargetAtTime(0,t+.004,.07);o.start(t);o.stop(t+.3);
  const n=ctx.createBufferSource(),lp=ctx.createBiquadFilter(),ng=ctx.createGain();n.buffer=celNoise(ctx);lp.type='lowpass';lp.frequency.value=1200;
  n.connect(lp);lp.connect(ng);ng.connect(_bgm.master);ng.gain.setValueAtTime(.14*vel,t);ng.gain.setTargetAtTime(0,t+.002,.018);n.start(t);n.stop(t+.12);
}
function celNoise(ctx){if(!_bgmNoise||_bgmNoise.sampleRate!==ctx.sampleRate){const n=Math.floor(ctx.sampleRate*.25);_bgmNoise=ctx.createBuffer(1,n,ctx.sampleRate);const d=_bgmNoise.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;}return _bgmNoise;}
