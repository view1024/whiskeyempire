  // ================= v4.8 追加テスト =================
  // 職人を用意する（Tier と所持金を整え、候補から雇う）
  const STAFF_PREP = `(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose(); G.cash = 1e15; G.staff = []; G.staffCand = null; G.staffOff = false; prodInvalidate(); })()`;
  // ---------- #111 解放・候補者の能力の分布・求人の出し直し ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      const dl0 = G.dl; G.dl = 1; const off1 = staffOn(); v48Tick(); const btn1 = getComputedStyle(document.getElementById('btnStaff')).display;
      G.dl = 2; const on2 = staffOn(); v48Tick(); const btn2 = getComputedStyle(document.getElementById('btnStaff')).display; G.dl = dl0;
      const bad = []; const cnt = { 1: 0, 2: 0, 3: 0 }; const rg = { 1: [9, 14], 2: [13, 19], 3: [18, 24] };
      for (let i = 0; i < 600; i++) { const c = staffRoll(); cnt[c.r]++; const s = stSum(c.st); if (s < rg[c.r][0] || s > rg[c.r][1] || ST_KEYS.some(k => c.st[k] < 1 || c.st[k] > 10)) bad.push(JSON.stringify(c)); }
      const c = staffCandState(); const n = c.list.length; const h0 = G.acct.cur.sga.hire;
      const r1 = staffRefresh(); const h1 = G.acct.cur.sga.hire; const r2 = staffRefresh(); const h2 = G.acct.cur.sga.hire;
      return { off1, btn1, on2, btn2, bad: bad.slice(0, 3), cnt, n, free: [r1, h1 - h0], paid: [r2, Math.round(h2 - h1), staffRefreshCost()] };
    });
    const ok = !r.off1 && r.btn1 === 'none' && r.on2 && r.btn2 !== 'none' && r.bad.length === 0 && r.cnt[1] > r.cnt[2] && r.cnt[2] > r.cnt[3] && r.cnt[3] > 0 && r.n === 3 && r.free[0] && r.free[1] === 0 && r.paid[0] && r.paid[1] === r.paid[2];
    rec(111, '職人：Tier2で解放・候補は3人で★1〜3の能力の合計が決めた範囲（★1 9〜14・★2 13〜19・★3 18〜24、各1〜10）・求人の出し直しは1日1回無料で以降は採用費', ok, JSON.stringify(r));
    if (errors.length) rec('E62', '職人の候補テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #112 採用・定員・配置・採用費の計上 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const o = { seats: staffSeats(), cap: staffCap() };
      const c = staffCandState(); const fee = staffHireFee(c.list[0]); const h0 = G.acct.cur.sga.hire; const cash0 = G.cash;
      o.hire = staffHire(0); o.fee = [Math.round(G.acct.cur.sga.hire - h0), fee, Math.round(cash0 - G.cash)];
      o.post = G.staff[0].post; o.best = staffBestPost(G.staff[0].st);
      // 定員まで雇う
      let g = 0; while (G.staff.length < staffCap() && g++ < 40) { const cc = staffCandState(); if (!cc.list.length) { cc.free = 1; staffRefresh(); } staffHire(0); }
      o.n = G.staff.length; o.over = staffHire(0); o.perPost = POSTS.map(p => G.staff.filter(s => s.post === p.id).length);
      const idle = G.staff.find(s => !s.post); o.full = staffAssign(idle.id, 'still');
      o.moveOk = (() => { const s = G.staff.find(x => x.post === 'still'); return staffAssign(s.id, null) && staffAssign(idle.id, 'still'); })();
      openStaffModal('post'); o.ui = document.querySelectorAll('#mc2 .pst2').length; openStaffModal('list'); o.ui2 = document.querySelectorAll('#mc2 .sfc').length; openStaffModal('hire'); o.ui3 = document.getElementById('mc2').textContent.includes('求人を出し直す'); closeM();
      return o;
    });
    const ok = r.seats === 3 && r.cap === 17 && r.hire && r.fee[0] === r.fee[1] && r.fee[2] === r.fee[1] && r.post === r.best && r.n === 17 && r.over === false && r.perPost.every(v => v === 3) && r.full === false && r.moveOk && r.ui === 5 && r.ui2 === 17 && r.ui3;
    rec(112, '採用：採用費（時給24時間分）を払い、向いている持ち場に就く・定員は持ち場ごとにmin(3,Tier)人・在籍は定員+2人まで・満員の持ち場には入れない・配置/在籍/採用の画面', ok, JSON.stringify(r));
    if (errors.length) rec('E63', '採用テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #113 5つの持ち場の効果・人数による逓減・上限・熟練度・熟成の速さは不変 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post, st, lv) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st, tr: 'calm', lv: lv || 1, xp: 0, post, hired: 0, train: 0, care: '' });
      const base = { cap: stageCap(0), slots: whSlots(), board: boardSize(), bph: botRate(), nm: prodFlows().newmake, kg: prodFlows().p[0], q: staffFx('watch') };
      const l = G.lots[0]; const ar0 = agingRate(l);
      G.staff = [mk('still', { waza: 1, tegiwa: 5, mekiki: 1 })]; prodInvalidate(); const cap1 = stageCap(0) / base.cap;
      G.staff.push(mk('still', { waza: 1, tegiwa: 5, mekiki: 1 })); prodInvalidate(); const cap2 = stageCap(0) / base.cap;
      G.staff.push(mk('still', { waza: 1, tegiwa: 5, mekiki: 1 })); prodInvalidate(); const cap3 = stageCap(0) / base.cap;
      G.staff = [mk('still', { waza: 1, tegiwa: 10, mekiki: 1 }, 10), mk('still', { waza: 1, tegiwa: 10, mekiki: 1 }, 10), mk('still', { waza: 1, tegiwa: 10, mekiki: 1 }, 10)]; prodInvalidate(); const capMax = stageCap(0) / base.cap;
      G.staff = [mk('still', { waza: 1, tegiwa: 5, mekiki: 1 }, 5)]; prodInvalidate(); const capLv = stageCap(0) / base.cap;
      G.staff = [mk('buy', { waza: 1, tegiwa: 1, mekiki: 8 }), mk('fill', { waza: 1, tegiwa: 9, mekiki: 1 }), mk('watch', { waza: 10, tegiwa: 1, mekiki: 1 }), mk('ship', { waza: 1, tegiwa: 7, mekiki: 1 })]; prodInvalidate();
      const fx = { buy: staffFx('yield'), nm: prodFlows().newmake / base.nm, kg: prodFlows().p[0] / base.kg, slots: whSlots() - base.slots, q: staffFx('watch'), board: boardSize() - base.board, bph: botRate() / base.bph, ar: agingRate(l) / ar0 };
      // 大麦の使う量は同じで、とれる新酒が増える（毎秒の進行）
      const kg0 = G.barley.kg = 1e9; const f = prodFlows(); const t0 = G.tank = 0; prodTick(3600000); const used = kg0 - G.barley.kg;
      return { base: { cap: base.cap }, cap1, cap2, cap3, capMax, capLv, fx, used: Math.round(used), expUsed: Math.round(f.p[0]) };
    });
    const ok = Math.abs(r.cap1 - 1.075) < 1e-6 && Math.abs(r.cap2 - (1 + 0.015 * 5 * 1.8)) < 1e-6 && Math.abs(r.cap3 - (1 + 0.015 * 5 * 2.4)) < 1e-6 && Math.abs(r.capMax - 1.45) < 1e-6 && Math.abs(r.capLv - (1 + 0.015 * 5 * 1.4)) < 1e-6
      && Math.abs(r.fx.buy - 1.08) < 1e-9 && Math.abs(r.fx.nm - 1.08) < 1e-9 && Math.abs(r.fx.kg - 1) < 1e-9 && r.fx.slots === 3 && Math.abs(r.fx.q - 1.06) < 1e-9 && r.fx.board === 1 && Math.abs(r.fx.bph - 1.14) < 1e-9 && r.fx.ar === 1 && Math.abs(r.used - r.expUsed) <= 1;
    rec(113, '持ち場の効果：蒸留は4工程の能力（1人+1.5%×手際、2人目80%・3人目60%、上限+45%、Lvで×(1+0.1(Lv−1))）・原料調達は同じ大麦からとれる量（歩留まり、大麦の量は同じ）・樽詰めは樽の枠・熟成監視は品質・出荷は注文枠と瓶詰め・熟成の速さは変わらない', ok, JSON.stringify(r));
    if (errors.length) rec('E64', '持ち場の効果テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #114 給与：毎時計上・払えないと休業（効果なし・所持金は負にならない）・払えれば戻る・放置は24時間分・砂時計は1時間分 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv: 1, xp: 0, post, hired: 0, train: 0, care: '' });
      G.staff = [mk('still'), mk('buy')]; prodInvalidate();
      const wph = staffWagesPh(); const o = { wph };
      const w0 = G.acct.cur.sga.wage; staffTick(3600000); o.hour = [G.acct.cur.sga.wage - w0, wph];
      // 払えない
      const capOn = stageCap(0); G.cash = wph * 0.25; const sw = staffTick(3600000); o.off = { flag: G.staffOff, cash: G.cash, paidH: sw.paid / wph, offH: sw.offH, cap: stageCap(0) / capOn };
      staffTick(3600000); o.stay = G.staffOff && G.cash >= 0;
      G.cash = 1e12; staffTick(1000); o.back = !G.staffOff && Math.abs(stageCap(0) - capOn) < 1e-6;
      // 放置30時間 → 24時間分、砂時計 → 1時間分
      if (_offlineGate) closeOfflineModal(); const w1 = G.acct.cur.sga.wage; G.ls = Date.now() - 30 * 3600000; offline(); o.off30 = (G.acct.cur.sga.wage - w1) / wph; o.rep = document.getElementById('mc2').textContent.includes('職人の給与'); if (_offlineGate) closeOfflineModal();
      const w2 = G.acct.cur.sga.wage; const wph2 = staffWagesPh(); G.hg.n = 1; G.hg.useDay = 0; G.ls = Date.now(); hgUse(); o.hg = (G.acct.cur.sga.wage - w2) / wph2; if (_offlineGate) closeOfflineModal();
      return o;
    });
    const ok = r.wph > 0 && Math.abs(r.hour[0] - r.hour[1]) < 1e-6 * r.wph && r.off.flag && r.off.cash >= 0 && r.off.cash < r.wph * 0.001 && Math.abs(r.off.paidH - 0.25) < 0.001 && Math.abs(r.off.offH - 0.75) < 0.001 && Math.abs(r.off.cap - 1 / 1.075) < 0.001 && r.stay && r.back && Math.abs(r.off30 - 24) < 0.01 && r.rep && Math.abs(r.hg - 1) < 0.01;
    rec(114, '給与：毎時計上・払えない分は休業（効果が止まり所持金は負にならない）・1時間分払えるようになると戻る・放置は生産と同じ24時間分・砂時計は1時間分・放置の報告に給与', ok, JSON.stringify(r));
    if (errors.length) rec('E65', '給与テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #115 熟練度・研修・解雇・再創業で1人だけ残る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post, lv) => ({ id: uid('s'), nm: 'T' + lv, seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv, xp: 0, post, hired: 0, train: 0, care: '' });
      G.staff = [mk('still', 1), mk(null, 1), mk('fill', 4)]; prodInvalidate();
      const a = G.staff[0], b = G.staff[1];
      staffTick(24 * 3600000); const o = { lvA: a.lv, lvB: b.lv, xpA: Math.round(a.xp) };
      // 研修：費用・効果なし・6時間後に経験+24
      const t0 = G.acct.cur.sga.train; const cap0 = stageCap(0); o.tr = staffTrain(a.id); o.fee = [Math.round(G.acct.cur.sga.train - t0), staffTrainFee(a)]; prodInvalidate(); o.capOff = stageCap(0) < cap0;
      const lv0 = a.lv, xp0 = a.xp; a.train = Date.now() - 1; staffTick(1000); o.trEnd = a.train === 0 && (a.lv > lv0 || a.xp >= xp0 + 23.9);
      // 解雇：退職金
      const s0 = G.acct.cur.sga.sev; const sev = staffSevFee(b); o.fire = staffFire(b.id); o.sev = [Math.round(G.acct.cur.sga.sev - s0), sev]; o.n = G.staff.length;
      // 再創業で残る1人
      const keep = staffKeepOne(); o.keep = keep.length === 1 && keep[0].lv === 4 && keep[0].post === null;
      return o;
    });
    const ok = r.lvA === 2 && r.lvB === 1 && r.xpA === 0 && r.tr && r.fee[0] === r.fee[1] && r.capOff && r.trEnd && r.fire && r.sev[0] === r.sev[1] && r.n === 2 && r.keep;
    rec(115, '熟練度：持ち場で1時間1経験（Lv2まで24）・持ち場なしは伸びない／研修は費用（時給12時間分）を払い6時間効果なし、終わると経験+24／解雇は退職金（時給24時間分）／再創業では最も熟練した1人が残る', ok, JSON.stringify(r));
    if (errors.length) rec('E66', '熟練度テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #116 決算書の人件費・整合・v4.7（schema12）からの移行 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(async () => {
      G.dl = 3; G.acct = { prev: [] }; acctEnsure(); const o = {};
      const old = JSON.parse(JSON.stringify(G)); old.ver = 12; delete old.staff; delete old.staffCand; delete old.staffOff;
      const m = parseSave(old); o.mig = [m.ver, Array.isArray(m.staff) && m.staff.length === 0, m.staffOff === false];
      staffCandState(); staffHire(0); staffHire(0); staffTick(5 * 3600000); staffTrain(G.staff[0].id); staffFire(G.staff[1].id);
      const lv = acctLive(); o.lab = [Math.round(acctLabor(lv)), Math.round(lv.sga.hire + lv.sga.wage + lv.sga.train + lv.sga.sev)]; o.unex = Math.abs(lv.unex) < Math.max(1, lv.R * 1e-9);
      const na0 = naOf(lv.o), na1 = naOf(lv.c); o.na = Math.abs(na0 + lv.ni - na1) < Math.max(1, Math.abs(na1) * 1e-9); o.cash = Math.abs(lv.o.cash + lv.opcf + lv.invcf - lv.c.cash) < Math.max(1, Math.abs(lv.c.cash) * 1e-9);
      openFinModal(); await new Promise(r => setTimeout(r, 80)); const t = document.getElementById('mc2').textContent; o.rows = ['うち人件費', '採用費', '給与', '研修費', '退職金'].every(w => t.includes(w)); o.box = t.includes('人件費');
      const cols = [...document.querySelectorAll('#mc2 .fbd .fcol')].map(c => [...c.children].reduce((a, e) => a + parseFloat(e.style.height), 0)); o.eq = cols.length >= 2 && Math.abs(cols[0] - cols[1]) <= 3;
      closeM();
      return o;
    });
    const ok = r.mig[0] === 13 && r.mig[1] && r.mig[2] && r.lab[0] > 0 && r.lab[0] === r.lab[1] && r.unex && r.na && r.cash && r.rows && r.box && r.eq;
    rec(116, '決算書：販管費に「うち人件費」（採用費・給与・研修費・退職金）・ボックス図に人件費・純資産と現金の2つの整合式・v4.7（schema12）から移行すると職人は0人', ok, JSON.stringify(r));
    if (errors.length) rec('E67', '人件費の決算書テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
