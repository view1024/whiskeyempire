exec(open('gen_ft44.py').read().replace("open('functest44.js','w').write(s)","pass"))
import os
exec(open('functest45_fix.py').read())
if os.path.exists('functest45_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest45_add.js').read()+s[a:]
open('functest45.js','w').write(s)
