s=open('functest.js').read()
def R(a,b):
    global s
    assert a in s, a[:70]
    s=s.replace(a,b)
R("""  await page.goto(FILE);
  await page.waitForTimeout(1200);
  return { page, errors, ctx };""","""  await page.goto(FILE);
  await page.waitForTimeout(1200);
  await page.evaluate(() => { _mktOff = true; if (typeof titleStart === 'function') titleStart(false); });
  await page.waitForTimeout(800);
  if (!keepTut) await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose(); });
  return { page, errors, ctx };""")
R("async function newPage(browser, preload) {","async function newPage(browser, preload, keepTut) {")
R("const ok = G.ver === 7 && G.dl === 3","const ok = G.ver === 8 && G.dl === 3")
R("const ok27b = JSON.stringify(G.stats) === before && G.ver === 7;","const ok27b = JSON.stringify(G.stats) === before && G.ver === 8;")
R("const { page, errors } = await newPage(browser, `if(!sessionStorage.getItem('x')){sessionStorage.setItem('x','1');${pre}}`);",
  "const { page, errors } = await newPage(browser, `if(!sessionStorage.getItem('x')){sessionStorage.setItem('x','1');${pre}}`, true);")
R("""      T(25, 'v3.8.0セーブの移行""","""      T('25c', 'v3移行ユーザーは更新案内を待機・自動樽詰めと自動直販はON', G.tut.q.includes('upd') && !G.tut.done.first && G.auto.fill.on && G.auto.spot.on, JSON.stringify(G.tut));
      T(25, 'v3.8.0セーブの移行""")
R("const leftovers = ['G.mg', 'craft(', 'autoSellTick', 'channelMult', 'openMiniGame', 'mgModal'].filter(w => src.includes(w));",
  "const leftovers = ['G.mg', 'craft(', 'autoSellTick', 'channelMult', 'openMiniGame', 'mgModal', 'comboCount', 'COMBO_', 'comboMul', 'CRIT_CHANCE_10000', 'comboMeter', 'id=\"questPanel\"', 'Glenvivid', 'Johnnie Emerald', 'Davalo', 'Kawasaki'].filter(w => src.includes(w));")
R("rec(28, '削除対象の文字列がコードに残っていない'","rec(28, '削除対象（ミニゲーム・コンボ・ティッカー・クエスト表示）がコードに残っていない'")
a=s.index("    // 1. 熟成タブで瓶詰め")
b=s.index("    if (errors.length) rec('E5'")
s=s[:a]+"""    // 1. 売るタブで「詰めて納品」→ 瓶詰め完了 → 自動納品
    await page.click('#nav .nb[data-tab="tsale"]');
    await page.waitForTimeout(200);
    const o0 = await page.evaluate(() => { const o = G.orders.find(x => ordFulfillPlan(x).ok); return o ? { id: o.id, qty: o.qty } : null; });
    await page.click(`[data-act="ordFill"][data-id="${o0.id}"]`);
    const q = await page.evaluate(id => ({ bq: G.bq.length, oid: G.bq[0] && G.bq[0].oid, auto: G.orders.find(o => o.id === id).autoDel, card: document.getElementById('orderBoard').textContent.includes('瓶詰め中') }), o0.id);
    await page.evaluate(() => { botTick(3600000 * (Math.ceil(botQueueBottles() / botRate()) + 1)); ordAutoTick(); rall(); });
    const after = await page.evaluate(id => ({ gone: !G.orders.some(o => o.id === id), orders: G.stats.orders, cash: G.cash, shipped: G.stats.shipped }), o0.id);
    rec(30, 'UI操作: 「詰めて納品」1回で瓶詰め→完了後に自動納品', q.bq === 1 && q.oid === o0.id && q.auto && q.card && after.gone && after.orders === 1 && after.shipped === o0.qty, JSON.stringify({ o0, q, after }));
    await page.screenshot({ path: 'shot_after_deliver.png' });
    // 2. 造るタブの一覧のボタンで直接強化
    await page.evaluate(() => { G.cash = 1e6; rall(); });
    await page.click('#nav .nb[data-tab="tb"]');
    await page.click('#fl [data-act="facUp"][data-id="malting"]');
    const mlv = await page.evaluate(() => G.fac.malting.l);
    rec('30b', 'UI操作: 設備一覧のボタン1回で強化', mlv === 1, mlv);
    await page.screenshot({ path: 'shot_make2.png', fullPage: false });
"""+s[b:]
a=s.index("  await browser.close();\n  let pass = 0;")
_a41=open('functest41_add.js').read(); _a41=_a41[:_a41.index('  // ---------- 情報量 ----------')]
s=s[:a]+_a41+open('functest42_add.js').read()+s[a:]
for a,b in [("G.ver === 8 && G.dl === 3","G.ver === 9 && G.dl === 3"),("G.ver === 8;","G.ver === 9;"),("init.ver === 8","init.ver === 9"),("m.ver === 8","m.ver === 9"),("r.ver === 8","r.ver === 9"),("schema8・","schema9・")]:
    s=s.replace(a,b)
open('functest42.js','w').write(s)
