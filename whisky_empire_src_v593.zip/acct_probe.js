const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1200);
  await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(500);
  const r = await page.evaluate(() => {
    if (_offlineGate) closeOfflineModal(); closeM();
    Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
    _mktOff = true;
    let T = Date.now(); _acctClock = () => T;
    const log = [];
    const chk = (tag) => {
      const a = G.acct; const lv = acctLive();
      const naO = naOf(lv.o), naC = naOf(lv.c);
      log.push({ tag, m: lv.m, unex: lv.unex, dNA: naC - naO - lv.ni, dCash: lv.c.cash - lv.o.cash - lv.opcf - lv.invcf, R: lv.R, cogs: lv.cogs, dep: lv.dep, ni: lv.ni });
    };
    acctEnsure(); chk('start');
    // 手動で色々
    G.cash = 0; for (let i = 0; i < 40; i++) tap(null); chk('tap');
    G.fac.malting.l = 1; prodInvalidate();
    // 時間を進める（1時間×n）
    const adv = (h) => { for (let i = 0; i < h * 36; i++) { T += 100000; prodTick(100000); lotTick(100000); botTick(100000); ordAutoTick(); autoSpotTick(); } };
    // 大金を与えて（その他の収入）設備を揃える
    acOther(5e7); G.cash += 5e7;
    FD.forEach(f => { if (!G.fac[f.id].p && isUL(f.id)) purFac(f.id); });
    for (let k = 0; k < 5; k++) FD.forEach(f => { if (G.fac[f.id].p) upgFac(f.id); });
    FD.forEach(f => { if (!G.fac[f.id].p) { G.fac[f.id].p = true; } });
    for (let k = 0; k < 5; k++) FD.forEach(f => upgFac(f.id));
    chk('capex');
    adv(10); chk('adv10');
    // 樽を手で詰めて瓶詰め・直販・樽ごと売却
    G.tank = 2000; fillCask('bourbon', 'hogshead', false); fillCask('bourbon', 'barrel', false);
    G.lots.forEach(l => l.age += 10);
    const pid = G.uw.find(id => lotsFor(id).length) || 'glenlivid'; if (!G.uw.includes(pid)) G.uw.push(pid);
    botStart(pid, 50, 'young', null, {}); botTick(3600000 * 5); chk('bottled');
    const row = G.bottles[0]; if (row) spotSell(row.id, 10);
    if (G.lots.length) sellLot(G.lots[G.lots.length - 1].id);
    upgClick(); rcpBuy && 0;
    chk('sales');
    // 月をまたぐ
    T += 35 * 864e5; acctEnsure(); chk('newmonth');
    adv(20); chk('adv20');
    // オフライン
    G.ls = T - 6 * 3600000; const realNow = Date.now; offline(); if (_offlineGate) closeOfflineModal(); chk('offline');
    T += 31 * 864e5; acctEnsure(); chk('month3');
    const hist = G.acct.hist.map(h => ({ m: h.m, to: h.to, unex: h.unex, R: h.R, ni: h.ni, dep: h.dep, cogs: h.cogs, P: h.P, dNA: naOf(h.c) - naOf(h.o) - h.ni, dC: h.c.cash - h.o.cash - h.opcf - h.invcf }));
    // チェーン：前月の期末＝当月の期首
    const chain = G.acct.hist.length >= 2 ? Math.abs(naOf(G.acct.hist[0].o) - naOf(G.acct.hist[1].c)) : null;
    return { log, hist, chain, cap: G.acct.cap, fa: G.acct.fa, bAvg: G.acct.bAvg };
  });
  console.log(JSON.stringify(r, null, 1));
  console.log('ERRORS', errors);
  await browser.close();
})();
