const DAILY_POOL=[
  {id:'dm_tap',   label:'タップNOT回',      reward:{type:'rep',value:5},  minTier:1, targets:[20,50,100]},
  {id:'dm_earn',  label:'$X稼ぐ',            reward:{type:'rep',value:8},  minTier:1, targets:'dynamic'},
  {id:'dm_upg',   label:'施設を強化する',     reward:{type:'rep',value:8},  minTier:1, targets:[1]},
  {id:'dm_ship',  label:'瓶をN本出荷',        reward:{type:'rep',value:8},  minTier:1, targets:[20,50,150,400]},
  {id:'dm_order', label:'注文をN件達成',      reward:{type:'rep',value:10}, minTier:1, targets:[1,2,3]},
  {id:'dm_fill',  label:'樽をN樽詰める',      reward:{type:'rep',value:8},  minTier:1, targets:[1,2,4]},
  {id:'dm_bottle',label:'瓶詰めを開始する',   reward:{type:'rep',value:5},  minTier:1, targets:[1]},
  {id:'dm_blend', label:'ブレンドを完成させる', reward:{type:'rep',value:20}, minTier:3, targets:[1]},
  {id:'dm_taste', label:'試飲会をNOT回開く',  reward:{type:'rep',value:5},  minTier:1, targets:[1,2,3]},
  {id:'dm_comp',  label:'品評会に出品する',   reward:{type:'rep',value:25}, minTier:2, targets:[1]},
];
