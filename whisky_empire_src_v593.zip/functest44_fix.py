for a,b in [("G.ver === 9 && G.dl === 3","G.ver === 10 && G.dl === 3"),("G.ver === 9;","G.ver === 10;"),("'新規開始: schema9・","'新規開始: schema10・"),("init.ver === 9","init.ver === 10"),("m.ver === 9 &&","m.ver === 10 &&"),("r.ver === 9","r.ver === 10")]:
    assert a in s, a
    s=s.replace(a,b)
R2("rec(32, '初回案内: 5タップ以内・60秒以内に最初の売上／完了で報酬・デイリー解放', firstSaleTaps !== null && firstSaleTaps <= 5 &&","rec(32, '初回案内: 7タップ以内（樽3回を含む）・60秒以内に最初の売上／完了で報酬・デイリー解放', firstSaleTaps !== null && firstSaleTaps <= 7 &&")
R2("""next: !!document.querySelector('#nextCard [data-act]') }));
    await page.click('#nextCard [data-act]');
    await page.waitForTimeout(300);""","""next: document.getElementById('bd_tsale').textContent !== '' }));
    await page.click('#nav .nb[data-tab="tsale"]'); await page.waitForTimeout(300);
    await page.click('#orderBoard [data-act="ordFill"], #orderBoard [data-act="ordGo"]');
    await page.waitForTimeout(300);""")
R2("rec(34, 'スキップしても操作できる・「次の1手」から最初の注文を処理できる'","rec(34, 'スキップしても操作できる・印の付いた「売る」から最初の注文を処理できる'")
R2("nextH: Math.round(document.getElementById('nextCard').getBoundingClientRect().height) };","nextH: document.getElementById('nextCard') ? 999 : 0 };")
R2("""const fc = (() => { document.querySelector('#fillBox [data-act="fillChoose"]').click(); const ok = document.querySelectorAll('#mc2 select').length === 2; closeM(); return ok; })();""","""const fc = (() => { document.querySelector('#fillBox [data-act="fillPickT"]').click(); const ok = document.querySelectorAll('#mc2 .ccard').length === CASK_TYPES.length; closeM(); return ok; })();""")
R2("const flows = [...document.querySelectorAll('#lineView .pflow .pfl')].map(e => e.textContent);","const flows = [...document.querySelectorAll('#lineView .pflow .pfl')].slice(1).map(e => e.textContent);")
R2("const sur = [...document.querySelectorAll('#lineView .pflow')].map(e =>","const sur = [...document.querySelectorAll('#lineView .pflow')].slice(1).map(e =>")
R2("const bnIdx = [...document.querySelectorAll('#lineView .pst')]","const bnIdx = [...document.querySelectorAll('#lineView .pst:not(#barleyBox)')]")
R2("const caps = [...document.querySelectorAll('#lineView .pst .pcap')]","const caps = [...document.querySelectorAll('#lineView .pst:not(#barleyBox) .pcap')]")
R2("""      const s1 = sceneSvg(); G.fac.mashing.p = true; G.fac.maturation.p = true; G.fac.maturation.l = 12; const s2 = sceneSvg();
      const cnt = s => (s.match(/<rect x="\\d+(\\.\\d+)?" y="\\d+(\\.\\d+)?" width="\\d+" height="\\d+" fill="#2e2216"/g) || []).length;
      T(54, '景色：購入した設備と熟成庫のLvで建物が増える', cnt(s2) > cnt(s1), cnt(s1) + '→' + cnt(s2));""",
"""      const tb = [3, 6, 12, 17, 22].map(h => sceneTime(h)).join(',');
      switchTab('td'); rdistLight(); const sc = document.getElementById('scene'); const cs = getComputedStyle(sc);
      const bgOk = /data:image\\/webp/.test(cs.backgroundImage) && cs.backgroundSize === 'cover';
      const cls = sc.className === 'scene t-' + sceneTime(); const f = getComputedStyle(sc).filter;
      T(54, '景色：蒸留所の絵を表示し、時間帯（朝・昼・夕・夜）で明るさと色味を変える', tb === 'night,am,day,eve,night' && bgOk && cls && f !== 'none', tb + ' / ' + sc.className + ' / ' + f);""")
R2("rec(45, '樽画像を画面中央に大きく（高さ200px以上・押せる範囲は瓶の幅に合わせる・中心が画面中央±10px）', bb.h >= 200 && bb.w >= 100 && bb.w <= bb.h * 0.7 &&","rec(45, '樽の画像を画面中央に大きく（高さ200px以上・押せる範囲は樽の絵の幅・中心が画面中央±10px）', bb.h >= 200 && Math.abs(bb.w / bb.h - 346 / 469) < 0.02 &&")
