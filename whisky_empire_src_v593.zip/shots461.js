const { chromium } = require('playwright');
const path = require('path');
const STATE = require('fs').readFileSync('v43.js', 'utf8').match(/const STATE = (function \(mode\) \{[\s\S]*?\n\});/)[1];
(async () => {
  const browser = await chromium.launch(); const errors = [];
  const ctx = await browser.newContext({ viewport: { width: 393, height: 760 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage(); page.on('pageerror', e => errors.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html')); await page.waitForTimeout(1200);
  await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(300);
  await page.evaluate(`(${STATE})('mid')`); await page.waitForTimeout(300);
  await page.evaluate(() => { celebrate = () => {}; _celebQ = []; celebClose(); toast = () => {}; const tt = document.getElementById('toast'); if (tt) tt.classList.remove('on'); });
  for (const [theme, hour] of [['dark', 12], ['light', 12], ['dark', 22]]) {
    for (const t of ['tb', 'tcel', 'tsale']) {
      await page.evaluate(([theme, hour, t]) => { opt().theme = theme; applyOpt(); const orig = sceneTime; window.sceneTime = h => orig(h === undefined ? hour : h); switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); } }, [theme, hour, t]);
      await page.waitForTimeout(1700);
      await page.screenshot({ path: `v461_${theme}${hour}_${t}.png` });
    }
  }
  console.log('ERRORS', errors); await browser.close();
})();
