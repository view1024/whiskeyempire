// v4.8 の画面確認用スクリーンショット（職人の配置・在籍・採用、決算書の人件費、造るの見出し）
const { chromium } = require('playwright');
const path = require('path');
const STATE = require('fs').readFileSync('v43.js', 'utf8').match(/const STATE = (function \(mode\) \{[\s\S]*?\n\});/)[1];
const OUT = process.argv[2] || '.';
(async () => {
  const b = await chromium.launch(); const errs = [];
  for (const [W, theme] of [[393, 'dark'], [360, 'light']]) {
    const ctx = await b.newContext({ viewport: { width: W, height: 760 }, deviceScaleFactor: 1.5 }); const p = await ctx.newPage();
    p.on('pageerror', e => errs.push(e.message));
    await p.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await p.goto('file://' + path.resolve('whisky_empire.html')); await p.waitForTimeout(1000);
    await p.evaluate(() => titleStart(false)); await p.waitForTimeout(300);
    await p.evaluate(`(${STATE})('mid')`); await p.waitForTimeout(300);
    await p.evaluate(th => { celebrate = () => {}; _celebQ = []; celebClose(); toast = () => {}; Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); opt().theme = th; applyOpt();
      G.cash = 1e10; G.acct = { prev: [] }; acctEnsure(); G.staff = []; G.staffCand = null; staffCandState(); for (let i = 0; i < 3; i++) staffHire(0); G.staffCand.free = 1; staffRefresh(); staffHire(0); staffHire(0); staffTick(20 * 3600000); staffTrain(G.staff[1].id); v48Tick(); rall(); }, theme);
    await p.evaluate(() => { switchTab('tb'); }); await p.waitForTimeout(300); await p.screenshot({ path: `${OUT}/v48_${theme}_tb.png` });
    for (const t of ['post', 'list', 'hire']) { await p.evaluate(t => openStaffModal(t), t); await p.waitForTimeout(200); await p.screenshot({ path: `${OUT}/v48_${theme}_${t}.png` }); }
    await p.evaluate(() => { closeM(); openStaffPick('still', G.staff.find(s => s.post === 'still') ? G.staff.find(s => s.post === 'still').id : null); }); await p.waitForTimeout(200); await p.screenshot({ path: `${OUT}/v48_${theme}_pick.png` });
    await p.evaluate(() => { closeM(); openFinModal(); }); await p.waitForTimeout(300); await p.screenshot({ path: `${OUT}/v48_${theme}_fin.png` });
    await p.evaluate(() => { const m = document.getElementById('mc2'); m.scrollTop = 9999; const mo = document.querySelector('#mo .mc') || m.parentElement; if (mo) mo.scrollTop = 9999; }); await p.waitForTimeout(200); await p.screenshot({ path: `${OUT}/v48_${theme}_fin2.png` });
    await ctx.close();
  }
  console.log('ERRORS', errs); await b.close();
})();
