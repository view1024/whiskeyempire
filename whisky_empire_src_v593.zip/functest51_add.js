  // ================= v5.0.1 追加テスト =================
  // ---------- #130 文字量：各画面の見えている文字数が目標以下（390×844・中盤） ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose(); closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      G.cash = 1e12; G.staff = []; G.staffCand = null; for (let i = 0; i < 3; i++) { staffCandState(); staffHire(0); } placeAuto(true); closeM();
      const vis = e => e.getClientRects().length > 0 && (!e.checkVisibility || e.checkVisibility({ checkVisibilityCSS: true }));
      const count = (root, skip) => { const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n, c = 0; while (n = w.nextNode()) { const p = n.parentElement; if (!p || !vis(p) || (skip && p.closest(skip))) continue; c += n.textContent.replace(/\s/g, '').length; } return c; };
      const o = {};
      for (const t of ['tb', 'tcel', 'tsale']) { switchTab(t); rall(); await new Promise(r => setTimeout(r, 200)); o[t] = count(document.getElementById(t), t === 'tcel' ? '.wsl,.wmore' : null); }
      const M = (k, f) => { f(); o[k] = count(document.getElementById('mc2')); closeM(); };
      M('lot', () => openLotModal(G.lots[0].id)); M('bottle', () => openBottleModal(G.uw[0])); M('staffList', () => openStaffModal('list')); M('hg', () => openHgModal());
      return o;
    });
    const LIM = { tb: 280, tcel: 200, tsale: 400, lot: 250, bottle: 250, staffList: 250, hg: 200 };
    const over = Object.keys(LIM).filter(k => !(r[k] <= LIM[k]));
    rec(130, '文字量：造る280・寝かせる200（棚の札を除く）・売る400・樽の小窓250・瓶詰めの小窓250・職人の一覧250・砂時計200 字以下', over.length === 0, JSON.stringify({ r, over }));
    if (errors.length) rec('E80', '文字量テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #131 版の案内をやめた：案内は1画面60字まで・「追加しました」などの言い方がない・更新のあとは⚙️と「更新履歴」に印だけ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      const steps = Object.entries(TUTS).flatMap(([k, t]) => t.steps.map(s => [k, s.text.replace(/<[^>]+>/g, '')]));
      o.long = steps.filter(([k, t]) => t.length > 60).map(([k, t]) => k + ':' + t.length);
      o.word = steps.filter(([k, t]) => /追加しました|新しく|ようになりました|加えました|変更点/.test(t)).map(([k]) => k);
      o.ver = ['upd', 'u43', 'u_line43', 'u44', 'u45', 'u_cel45', 'u46', 'u_sell46', 'u47', 'u50'].filter(k => TUTS[k]);
      o.n = Object.keys(TUTS).length;
      // 更新のあと（前の版で保存したセーブ）：⚙️と更新履歴に印 → 更新履歴を開くと消える
      G.hs.cl = '5.0.0'; v50Tick(); o.dot1 = document.getElementById('btnGear').classList.contains('cln') && getComputedStyle(document.getElementById('btnGear'), '::after').content !== 'none';
      switchTab('tp'); v50Tick(); o.dotCl = document.querySelector('[data-act="changelog"]').classList.contains('cln');
      document.querySelector('[data-act="changelog"]').click(); await new Promise(r => setTimeout(r, 50));
      o.cl = document.getElementById('mc2').textContent.includes('v' + BALANCE.APP_VERSION); closeM(); v50Tick();
      o.dot2 = !document.getElementById('btnGear').classList.contains('cln') && G.hs.cl === BALANCE.APP_VERSION;
      // 新しく始めた人には印を付けない・保存して読み直しても残る
      o.fresh = defState().hs.cl === BALANCE.APP_VERSION; o.san = sanitize(JSON.parse(JSON.stringify(G))).hs.cl === BALANCE.APP_VERSION && sanitize(Object.assign(JSON.parse(JSON.stringify(G)), { hs: {} })).hs.cl === '';
      return o;
    });
    const ok = r.long.length === 0 && r.word.length === 0 && r.ver.length === 0 && r.n <= 22 && r.dot1 && r.dotCl && r.cl && r.dot2 && r.fresh && r.san;
    rec(131, '案内：版の変更の案内（upd・u43〜u50・u_sell46）がない・1画面60字まで・「追加しました」などの言い方がない／更新のあとは⚙️と更新履歴に印、開くと消える・新規は印なし', ok, JSON.stringify(r));
    if (errors.length) rec('E81', '案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #132 TIPS：年数と日数・寝かせるの流れ・売るの流れ・瓶詰めの選び方。樽の小窓・瓶詰めの小窓のⓘから開ける ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = { ids: ['age', 'celflow', 'sellflow', 'bottle'].filter(id => TIPS.some(t => t.id === id)) };
      openLotModal(G.lots[0].id); const ib1 = document.querySelector('#mc2 .ib[data-id="age"]'); o.lotIb = !!ib1; if (ib1) ib1.click(); await new Promise(r => setTimeout(r, 50));
      o.lotTip = document.getElementById('mc2').textContent.includes('年数と日数'); closeM();
      openBottleModal(G.uw[0]); const ib2 = document.querySelector('#mc2 .ib[data-id="bottle"]'); o.btlIb = !!ib2; if (ib2) ib2.click(); await new Promise(r => setTimeout(r, 50));
      o.btlTip = document.getElementById('mc2').textContent.includes('詰めて納品'); closeM();
      o.book = (() => { openTipBook(); const t = document.getElementById('mc2').textContent; closeM(); return ['年数と日数', '寝かせるの流れ', '売るの流れ', '瓶詰めの選び方'].every(x => t.includes(x)); })();
      return o;
    });
    const ok = r.ids.length === 4 && r.lotIb && r.lotTip && r.btlIb && r.btlTip && r.book;
    rec(132, 'TIPS：年数と日数・寝かせるの流れ・売るの流れ・瓶詰めの選び方がヒント帳にあり、樽の小窓と瓶詰めの小窓のⓘから開ける', ok, JSON.stringify(r));
    if (errors.length) rec('E82', 'TIPSテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #133 寝かせるの吹き出し：画面の下半分の樽は上、上半分の樽は下に出る・見出しに隠れない（84樽） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      G.auto.fill.on = false; switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 100));
      const tc = document.getElementById('tcel'); const o = { n: G.lots.length, cases: [] };
      const hd = () => document.querySelector('#tcel .thead').getBoundingClientRect();
      const nav = document.getElementById('nav').getBoundingClientRect();
      const casks = [...document.querySelectorAll('#wScene .wcask')];
      const mid = casks[Math.floor(casks.length / 2)];
      for (const [pick, pos] of [[mid, 'start'], [mid, 'end'], [casks[casks.length - 1], 'end']]) {
        pick.scrollIntoView({ block: pos }); if (pos === 'start') tc.scrollTop -= 90; await new Promise(r => setTimeout(r, 30));
        const g = pick.getBoundingClientRect(); caskKnock(pick.dataset.id, pick); await new Promise(r => setTimeout(r, 60));
        const g2 = pick.getBoundingClientRect(); const b = document.getElementById('wBub').getBoundingClientRect(); const h = hd();
        const lower = g.top + g.height / 2 > innerHeight / 2;
        o.cases.push({ lower, above: b.bottom <= g2.top + 12, below: b.top >= g2.bottom - 10, inView: b.top >= h.bottom - 1 && b.bottom <= nav.top + 1 });
        bubClose();
      }
      tc.scrollTop = 0; await new Promise(r => setTimeout(r, 30)); casks[0].dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
      o.topRow = (() => { const b = document.getElementById('wBub').getBoundingClientRect(), h = hd(); return b.top >= h.bottom - 1; })();
      return o;
    });
    const ok = r.n >= 40 && r.cases.length === 3 && r.cases.every(c => (c.lower ? !c.below : !c.above) && c.inView) && r.cases.some(c => !c.lower) && r.cases.some(c => c.lower) && r.topRow;
    rec(133, '寝かせるの吹き出し：画面の下半分の樽は上、上半分の樽は下に出る（入りきらなければ樽に重ねる）・見出しやタブに隠れない（タブ全体でスクロール）', ok, JSON.stringify(r));
    if (errors.length) rec('E83', '吹き出しテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.1 第2回 追加テスト =================
  // ---------- #134 売り方：3年未満は売れない・吹き出しの金額が計算と一致・注文がなければ「瓶詰めして在庫へ」が先頭、使える注文があれば「注文に使う」が先頭 ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 100));
      const o = {};
      const young = G.lots.find(l => l.age < 3); const n0 = G.lots.length;
      o.youngSell = sellLot(young.id) === 0 && G.lots.length === n0;
      caskKnock(young.id, document.querySelector(`#wScene .wcask[data-id="${young.id}"]`)); const yb = document.getElementById('wBub');
      o.youngBub = yb.textContent.includes('3年で売れます') && !yb.querySelector('[data-act="lotRoute"]'); bubClose();
      openLotModal(young.id); const ybtn = document.querySelector('#mc2 [data-act="lotSell"]'); o.youngModal = ybtn.disabled && ybtn.textContent.includes('3年で売れます'); closeM();
      // 注文なし：在庫へが先頭・金額
      const saved = G.orders; G.orders = []; const l = G.lots.filter(x => x.age >= 8 && !x.name && !lotSellWarn(x)).sort((a, b) => b.age - a.age)[0];
      caskKnock(l.id, document.querySelector(`#wScene .wcask[data-id="${l.id}"]`));
      const btns = [...document.querySelectorAll('#wBub [data-act="lotRoute"]')]; o.order0 = btns.map(b => b.dataset.r).join(); o.top = btns[0].classList.contains('top');
      const pl = lotBotPlan(l); const txt = r => (btns.find(b => b.dataset.r === r) || {}).textContent || '';
      o.amt = txt('stock').includes(fmt(pl.stockMax)) && txt('stock').includes(fmtN(pl.n) + '本') && txt('spot').includes(fmt(pl.unit * BALANCE.SPOT_MULT * pl.n - (pl.mat.free ? 0 : pl.mat.cost))) && txt('cask').includes(fmt(lotValue(l) * BALANCE.CASK_SPOT_MULT));
      o.best = lotProducts(l).every(p => { const pv = botPreview(p, pl.n, 'manual', [l.id], 0); return !pv.ok || pv.unit <= pl.unit + 1e-9; });
      bubClose(); G.orders = saved;
      // 使える注文（この樽だけで足りる量）を作る → 先頭は「注文に使う」
      G.cash = 1e15; hideConfirm();
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pl.pid; a.minAge = 3; a.qty = 10; a.rq = 10; a.reserve = false; a.dueAt = Date.now() + 36e5 * 30; G.orders = [a];
      G.bottles = G.bottles.filter(b => b.pid !== pl.pid);
      rCellar(); await new Promise(r => setTimeout(r, 50));
      caskKnock(l.id, document.querySelector(`#wScene .wcask[data-id="${l.id}"]`));
      const b2 = [...document.querySelectorAll('#wBub [data-act="lotRoute"]')]; o.order1 = b2.map(b => b.dataset.r).join(); o.mark = !!document.querySelector(`#wScene .wcask[data-id="${l.id}"] .wom`);
      b2[0].click(); await new Promise(r => setTimeout(r, 30)); o.conf = document.getElementById('confirmDlg').classList.contains('on'); o.bq = G.bq.length;
      o.ordBot = G.bq.some(q => q.oid === a.id && q.n === 10) && a.autoDel === true;
      botTick(36e5 * 50); ordAutoTick(); o.delivered = !G.orders.some(x => x.id === a.id);
      return o;
    });
    const ok = r.youngSell && r.youngBub && r.youngModal && r.order0 === 'stock,spot,cask' && r.top && r.amt && r.best && r.order1 === 'ord,stock,spot,cask' && r.mark && r.ordBot && r.delivered;
    rec(134, '売り方：3年未満は売れない（吹き出しは「3年で売れます」、小窓のボタンは押せない）・注文がなければ「瓶詰めして在庫へ」が先頭・金額は計算と一致（銘柄は単価が一番高いもの）・使える注文があれば「注文に使う」が先頭で🧾の印・押すと瓶詰めして自動で納品', ok, JSON.stringify(r));
    if (errors.length) rec('E84', '売り方テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #135 「在庫へ」は瓶が在庫に入り、「瓶で売る」は詰め終わった分が直販される（自動直販の設定に関係なく）・放置中に詰め終わっても同じ ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      G.orders = []; G.bq = []; G.auto.spot.on = false; G.cash = 1e15; G.stats.freeBtl = 1;
      const L = G.lots.filter(x => x.age >= 5 && !x.name).sort((a, b) => b.age - a.age); const a = L[0], b = L[1];
      const pa = lotBotPlan(a), pb = lotBotPlan(b);
      const inv0 = G.bottles.reduce((s, x) => s + x.n, 0);
      lotRoute(a.id, 'stock'); const qa = G.bq[G.bq.length - 1]; const sa = qa && qa.sell === 0 && !G.lots.includes(a);
      botTick(36e5 * 100); const inv1 = G.bottles.reduce((s, x) => s + x.n, 0);
      const o = { sa, stock: inv1 - inv0 === pa.n };
      // 瓶で売る（自動直販 OFF のまま）
      const te0 = G.te; lotRoute(b.id, 'spot'); const qb = G.bq[G.bq.length - 1]; o.sb = qb && qb.sell === 1;
      const unit = priceUnit(qb.pid, qb.age, Math.round(qb.q / BALANCE.INV_Q_STEP) * BALANCE.INV_Q_STEP, qb.fl);
      botTick(36e5 * 100); const inv2 = G.bottles.reduce((s, x) => s + x.n, 0);
      o.spot = inv2 === inv1 && Math.abs((G.te - te0) - unit * BALANCE.SPOT_MULT * pb.n) / (unit * BALANCE.SPOT_MULT * pb.n) < 1e-6;
      // 放置中：瓶で売る → 閉じている間に詰め終わる
      const c = G.lots.filter(x => x.age >= 4 && !x.name)[0]; const pc = lotBotPlan(c); const te1 = G.te; lotRoute(c.id, 'spot');
      G.ls = Date.now() - 24 * 36e5; offline(); if (_offlineGate) closeOfflineModal();
      const inv3 = G.bottles.reduce((s, x) => s + x.n, 0); o.off = inv3 === inv2 && G.bq.length === 0 && G.te - te1 > 0;
      o.n = [pa.n, pb.n, pc.n];
      return o;
    });
    const ok = r.sa && r.stock && r.sb && r.spot && r.off;
    rec(135, '「瓶詰めして在庫へ」は樽1つを丸ごと詰めて在庫に入る・「瓶詰めして瓶で売る」は詰め終わった分を直販（自動直販OFFでも・在庫は増えない）・放置中に詰め終わっても同じ', ok, JSON.stringify(r));
    if (errors.length) rec('E85', '在庫へ・瓶で売るテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #136 確認は名前付き・次のTierの条件に要る・受けた予約注文に使える樽だけ ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      G.orders = []; G.cash = 1e15; const o = {};
      const L = G.lots.filter(x => x.age >= 3).sort((a, b) => a.age - b.age);
      const plain = L.find(l => !l.name && !lotSellWarn(l)); const named = L.find(l => !!l.name) || (() => { const l = L.find(x => x !== plain); l.name = 'テスト'; return l; })();
      const conf = () => document.getElementById('confirmDlg').classList.contains('on') && document.getElementById('confirmMsg').textContent.includes('この樽はなくなります');
      lotRouteAsk(plain.id, 'cask'); o.plain = !conf() && !G.lots.includes(plain); hideConfirm();
      lotRouteAsk(named.id, 'cask'); o.named = conf() && G.lots.includes(named); hideConfirm();
      // 次の Tier の条件に要る樽
      const req = DL_REQ[G.dl]; o.tierWarn = req ? (() => { const keep = G.lots.slice(); const x = G.lots.find(y => !y.name && y.age >= 3); const a0 = x.age; x.age = Math.max(a0, req.casks.age + 0.5); G.lots = [x]; const t = lotSellWarn(x); x.age = a0; G.lots = keep; return t.includes('Tier'); })() : true;
      // 受けた予約注文に使える樽
      const l = G.lots.filter(x => x.age >= 8 && !x.name && lotProducts(x).length)[0]; const pid = lotProducts(l)[0];
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pid; a.minAge = 3; a.qty = 5; a.rq = 5; a.reserve = true; a.accepted = true; a.dueAt = Date.now() + 36e5 * 30; G.orders.push(a); G.bottles = G.bottles.filter(b => b.pid !== pid);
      o.resWarn = lotSellWarn(l).includes('予約') && lotSellWarn(l, a.id) === '';
      return o;
    });
    const ok = r.plain && r.named && r.tierWarn && r.resWarn;
    rec(136, '確認は名前付き・次のTierの条件に要る・受けた予約注文に使える樽のときだけ（その注文に使うときは出さない）。ふつうの樽は1タップで売れる', ok, JSON.stringify(r));
    if (errors.length) rec('E86', '確認テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #137 注文→倉庫：「倉庫の樽で詰められる n樽」から寝かせるへ移り、その樽だけが光る・帯の「やめる」とEscで戻る／倉庫→売る：売れる樽の一覧・売るへの帯 ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      const o = {}; const l = G.lots.filter(x => x.age >= 8 && lotProducts(x).length).sort((a, b) => b.age - a.age)[0]; const pid = lotProducts(l)[0];
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pid; a.minAge = 8; a.qty = 20; a.rq = 20; a.reserve = false; a.dueAt = Date.now() + 36e5 * 30; G.orders = [a]; G.bottles = G.bottles.filter(b => b.pid !== pid);
      _ui.sellTab = 'ord'; switchTab('tsale'); rall(); await new Promise(r => setTimeout(r, 100));
      const chip = document.querySelector(`#orderBoard [data-act="ordLots"][data-id="${a.id}"]`); const exp = G.lots.filter(x => lotServes(x, a)).map(x => x.id).sort().join();
      o.chip = !!chip && chip.textContent.includes(ordLotCount(a) + '樽') && ordLotCount(a) > 0;
      chip.click(); await new Promise(r => setTimeout(r, 120));
      o.tab = document.querySelector('.tab.on').id; o.lit = [...document.querySelectorAll('#wScene .wcask.whl')].map(e => e.dataset.id).sort().join() === exp; o.bar = !!document.getElementById('hlBar');
      const lc = document.querySelector('#wScene .wcask.whl'); caskKnock(lc.dataset.id, lc); const first = document.querySelector('#wBub [data-act="lotRoute"]'); o.first = first && first.dataset.r === 'ord' && first.dataset.oid === a.id; bubClose();
      document.querySelector('#hlBar [data-act="hlEnd"]').click(); await new Promise(r => setTimeout(r, 50)); o.end = !_hl && !document.getElementById('hlBar') && !document.querySelector('#wScene .wcask.whl');
      hlStart(a.id); document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); o.esc = !_hl;
      // 倉庫→売る
      rCellar(); await new Promise(r => setTimeout(r, 50));
      const sb = document.querySelector('#whSummary [data-act="sellList"]'); const n3 = G.lots.filter(x => x.age >= 3).length; o.sellBtn = !!sb && sb.textContent.includes('売れる樽 ' + n3);
      sb.click(); await new Promise(r => setTimeout(r, 50)); const rows = [...document.querySelectorAll('#mc2 [data-act="sellPick"]')];
      const vals = rows.map(e => G.lots.find(x => x.id === e.dataset.id)).map(x => lotValue(x)); o.sorted = rows.length === Math.min(40, n3) && vals.every((v, i) => i === 0 || vals[i - 1] >= v);
      rows[0].click(); await new Promise(r => setTimeout(r, 150)); o.pick = !document.getElementById('wBub').classList.contains('h') && document.getElementById('mo').classList.contains('h');
      bubClose(); const fl = document.querySelector('#whSummary .sflow'); o.flow = !!fl && fl.textContent.includes('売る'); fl.click(); await new Promise(r => setTimeout(r, 50)); o.flowGo = document.querySelector('.tab.on').id === 'tsale';
      return o;
    });
    const ok = r.chip && r.tab === 'tcel' && r.lit && r.bar && r.first && r.end && r.esc && r.sellBtn && r.sorted && r.pick && r.flow && r.flowGo;
    rec(137, '注文の「倉庫の樽で詰められる n樽」→寝かせるへ移り、その樽だけが光る（吹き出しの先頭はその注文）・「やめる」とEscで戻る／倉庫の「売れる樽 n（3年以上）」は金額の高い順で、押すと棚の樽・棚の下の帯から売るへ', ok, JSON.stringify(r));
    if (errors.length) rec('E87', '注文と倉庫テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #138 v5.0（schema14）からの移行：砂時計の記録・大麦の等級・所持数はそのまま・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const old = JSON.parse(JSON.stringify(G)); old.ver = 14; old.hg = { n: 4, got: 9, used: 5, day: dayKey(), useDay: 2, src: { login: 1, daily: 0, ms: 1, care: 0 } }; delete old.barley.grade; old.bq.forEach(q => delete q.sell);
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, n: m.hg.n, src: JSON.stringify(m.hg.src), ordN: m.hg.ordN, streak: JSON.stringify(m.hg.streak), month: m.hg.month === monthKey(), grade: m.barley.grade, bq: m.bq.every(q => q.sell === 0) };
      const key = storageKey(); const bk = 'we_v4_bak14:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.ver === SCHEMA && r.n === 4 && r.src === '{"login":1,"daily":0,"ms":1,"care":0,"ord":0}' && r.ordN === 0 && r.streak === '{"d":"","n":0}' && r.month && r.grade === 'std' && r.bq && r.bk && r.loaded === SCHEMA;
    rec(138, 'v5.0（schema14）からの移行：砂時計の所持数はそのまま・入手の記録（納品・連続ログイン・月）を用意・大麦の等級は標準・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E88', '移行（v15）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #139 「まとめて使う」6個と、1個ずつ6回は同じ結果（熟成・残量・タンク・瓶詰め） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      G.orders = []; G.ordersPaused = true; G.orderClock = Date.now() + 1e12; G.auto.spot.on = false; G.cash = 1e15;
      const snap = JSON.stringify(G); const pick = () => ({ ages: G.lots.map(l => +l.age.toFixed(6)).join(), L: G.lots.reduce((a, l) => a + l.L, 0), tank: G.tank, btl: G.stats.bottled, lots: G.lots.length });
      G.hg.n = 20; G.hg.useDay = 0; G.ls = Date.now(); hgUse(6); if (_offlineGate) closeOfflineModal(); const a = pick();
      G = JSON.parse(snap); G.hg.n = 20; G.hg.useDay = 0; for (let i = 0; i < 6; i++) { G.ls = Date.now(); hgUse(1); if (_offlineGate) closeOfflineModal(); } const b = pick();
      return { a, b };
    });
    const da = r.a.ages.split(',').map(Number), db = r.b.ages.split(',').map(Number);
    const ok = da.length === db.length && da.every((v, i) => Math.abs(v - db[i]) < 1e-4) && Math.abs(r.a.L - r.b.L) / r.a.L < 1e-6 && r.a.lots === r.b.lots && Math.abs(r.a.tank - r.b.tank) <= Math.max(1, r.a.tank * 0.01) && Math.abs(r.a.btl - r.b.btl) <= 1;
    rec(139, '砂時計の「まとめて使う」6個と1個ずつ6回で、熟成の年数・残量・樽の数・タンク・瓶詰めの本数が同じ', ok, JSON.stringify(r));
    if (errors.length) rec('E89', 'まとめて使うテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.1 第3回 追加テスト =================
  // ---------- #140 原材料：Tier1 は v5.0 と同じ価格・Tier2 は半分・Tier3 以降は売値の倍率×K に合わせて動く ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const K = V51.RAW.K; const dl0 = G.dl; const reg0 = JSON.stringify(G.regions); const o = {};
      const old = () => ({ b: STAGES[0].price * BARLEY.RATIO * distMult() * barleyGrainMult() * mktFx('barley') * barleyGrade().p, c: Math.round(caskType('bourbon').costPerL * caskSize('hogshead').litres * (1 - 0.2 * psk('ps_cask_cost')) * getEventMult('caskCost')), t: V45.BTL_UNIT * distMult() });
      G.dl = 1; let e = old(); o.t1 = [Math.abs(barleyPrice() / e.b - 1) < 1e-9, caskCost('bourbon', 'hogshead') === e.c, Math.abs(btlUnit() / e.t - 1) < 1e-9];
      G.dl = 2; e = old(); const s2 = priceMultBase() / distMult(); o.t2 = [Math.abs(barleyPrice() / e.b - Math.sqrt(s2 * K.barley)) < 1e-6, Math.abs(btlUnit() / e.t - Math.sqrt(s2 * K.bottle)) < 1e-6];
      G.dl = 3; e = old(); const s3 = priceMultBase() / distMult(); o.t3 = [Math.abs(barleyPrice() / e.b - s3 * K.barley) < 1e-6, Math.abs(btlUnit() / e.t - s3 * K.bottle) < 1e-6, Math.abs(caskCost('bourbon', 'hogshead') / (e.c * priceMultBase() * K.cask) - 1) < 1e-3];
      // 販売地域を加えて売値の倍率が上がると、原材料も同じ割合で上がる
      const b0 = barleyPrice(), m0 = priceMultBase(); const id = Object.keys(REGIONS).find(k => !G.regions[k]); if (id) G.regions[id] = true; o.reg = !id || Math.abs(barleyPrice() / b0 - priceMultBase() / m0) < 1e-6;
      G.regions = JSON.parse(reg0); G.dl = dl0;
      o.k = [K.barley, K.cask, K.bottle];
      return o;
    });
    const ok = r.t1.every(Boolean) && r.t2.every(Boolean) && r.t3.every(Boolean) && r.reg;
    rec(140, '原材料：Tier1 は v5.0 と同じ価格（大麦・空き樽・瓶の資材）・Tier2 は売値の倍率×K の平方根・Tier3 以降は売値の倍率×K・販売地域で売値の倍率が上がると原材料も同じ割合で上がる', ok, JSON.stringify(r));
    if (errors.length) rec('E90', '原材料テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #141 大麦の等級（価格と詰める樽の品質）・今月の相場の表示・資金不足の警告・決算書の「うち原材料費」 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; G.barley.grade = 'std'; const p0 = barleyPrice(), q0 = newmakeQuality();
      openBarleyModal(); const btn = document.querySelector('#mc2 [data-act="barleyGrade"][data-v="best"]'); o.seg = document.querySelectorAll('#mc2 [data-act="barleyGrade"]').length === 3; btn.click(); await new Promise(r => setTimeout(r, 30));
      o.best = [G.barley.grade, +(barleyPrice() / p0).toFixed(6), +(Math.min(1.5, q0 * 1.08) / newmakeQuality()).toFixed(6)];
      const lot = makeLot(caskType('bourbon'), caskSize('hogshead')); o.lotQ = Math.abs(lot.q - newmakeQuality()) < 1e-9; closeM(); G.barley.grade = 'std';
      // 相場：今月の市場が大麦を上げるとき「今月高い」
      const f0 = mktFx; mktFx = k => k === 'barley' ? 1.2 : f0(k); switchTab('tb'); rMake(); o.mkt = document.getElementById('barleyBox').textContent.includes('今月高い ×1.2'); mktFx = f0; prodInvalidate();
      // 警告：自動仕入れ ON・所持金が大麦1時間分未満・残り2時間未満
      const cash0 = G.cash, kg0 = barleyState().kg; G.cash = barleyCostPh() * 0.5; barleyState().kg = barleyUsePh() * 1; o.warn = actionList().some(x => x.title.includes('所持金が大麦1時間分を下回っています')); G.cash = cash0; barleyState().kg = kg0;
      // 決算書：うち原材料費（売上比）
      const p = acctLive(); p.pur.barley = (p.pur.barley || 0); const raw = sumO(p.pur); const html = finRows(p, 'pl');
      o.pl = raw > 0 && html.includes('うち原材料費') && (p.R > 0.5 ? html.includes((raw / p.R * 100).toFixed(1) + '%') : true);
      return o;
    });
    const ok = r.seg && r.best[0] === 'best' && r.best[1] === 2.5 && r.best[2] === 1 && r.lotQ && r.mkt && r.warn && r.pl;
    rec(141, '大麦の等級（最上は価格×2.5・品質×1.08、詰める樽に反映）・今月の相場を大麦の行に表示・所持金が大麦1時間分を下回ると警告・決算書に「うち原材料費（売上の◯%）」', ok, JSON.stringify(r));
    if (errors.length) rec('E91', '等級・相場テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #142 樽の価値：一番高い銘柄の直販額の55%で樽ごと売れる・樽の注文は v5.0 までの式×倍率と樽ごと売る額の高い方 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const l = G.lots.filter(x => x.age >= 8 && lotProducts(x).length && !x.name).sort((a, b) => b.age - a.age)[0];
      const n = l.L / BALANCE.BOTTLE_L; const best = Math.max(...lotProducts(l).map(p => priceUnit(p, Math.floor(l.age), l.q, lotFlavor(l))));
      const exp = best * BALANCE.SPOT_MULT * n * V51.CASK_RATE; o.sale = lotValue(l) * BALANCE.CASK_SPOT_MULT; o.exp = exp; o.rate = +(o.sale / exp).toFixed(6);
      const te0 = G.te; sellLot(l.id); o.paid = +((G.te - te0) / exp).toFixed(6);
      const l2 = G.lots.filter(x => !x.name && lotProducts(x).length).sort((a, b) => b.age - a.age)[0]; l2.age = Math.max(l2.age, 13); const ord = { id: 'o_t', cid: 'society', kind: 'cask', minAge: 12, qty: 1, rq: 1, mult: 2, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 36e5 };
      G.orders = [ord]; const m = ordMatch(ord, l2.id); o.ord = Math.abs(m.cash / Math.max(lotValueOld(l2) * 2, lotValue(l2) * BALANCE.CASK_SPOT_MULT) - 1) < 1e-9 && m.cash >= lotValue(l2) * BALANCE.CASK_SPOT_MULT - 1e-6;
      return o;
    });
    const ok = Math.abs(r.rate - 1) < 1e-6 && Math.abs(r.paid - 1) < 1e-6 && r.ord;
    rec(142, '樽の価値：樽ごと売ると、その樽で詰められる一番高い銘柄を直販した額の55%・樽の注文の報酬は v5.0 までの式×倍率と樽ごと売る額の高い方', ok, JSON.stringify(r));
    if (errors.length) rec('E92', '樽の価値テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
