# 使い方: python3 ftsub.py 62,84,121 [functest50.js] → _ftsub.js（指定した番号のテストだけを残す。デバッグ用。node _ftsub.js で実行）
import re,sys
keep=set(sys.argv[1].split(','))
s=open(sys.argv[2] if len(sys.argv)>2 else 'functest50.js',encoding='utf-8').read()
out=[];i=0
for m in re.finditer(r'\n  // -{3,} #([0-9]+[a-z]?)(?:[-–][0-9]+)?[^\n]*\n  \{\n',s):
    pass
pos=0;res=''
pat=re.compile(r'\n  // -{3,} #(\d+)(?:-(\d+))?[^\n]*\n  (?:try )?\{\n')
while True:
    m=pat.search(s,pos)
    if not m: res+=s[pos:];break
    a=m.start();res+=s[pos:a]
    # 対応する閉じ括弧（行頭2スペースの "}"）
    mm=re.compile(r'\n  \}(?: catch \(e\) \{[^\n]*\})?\n').search(s,m.end()-1);j=mm.end()-5
    lo=int(m.group(1));hi=int(m.group(2) or lo)
    if any(str(k) in keep for k in range(lo,hi+1)): res+=s[a:j+5]
    pos=j+4
open('_ftsub.js','w').write(res)
