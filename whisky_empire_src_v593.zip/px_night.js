// 背景の絵を透かした状態で、文字の下の実際の画素とのコントラストを測る
const { chromium } = require('playwright');
const path = require('path');
const { PNG } = require('pngjs');
const STATE = require('fs').readFileSync('v43.js', 'utf8').match(/const STATE = (function \(mode\) \{[\s\S]*?\n\});/)[1];
const lin = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
const L = (r, g, b) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
(async () => {
  const browser = await chromium.launch(); const bad = []; let n = 0; const worst = [];
  for (const [W, H] of [[393, 760], [390, 667]]) for (const mode of ['fresh', 'mid', 'late']) for (const theme of ['dark', 'light']) for (const hour of [22]) {
    const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto('file://' + path.resolve(process.env.HTML || 'whisky_empire.html')); await page.waitForTimeout(900);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(200);
    await page.evaluate(`(${STATE})(${JSON.stringify(mode)})`);
    await page.evaluate(([theme, hour]) => { celebrate = () => {}; _celebQ = []; celebClose(); toast = () => {}; const tt = document.getElementById('toast'); if (tt) tt.classList.remove('on'); opt().theme = theme; applyOpt(); const o = sceneTime; window.sceneTime = h => o(h === undefined ? hour : h); _vis && _vis.list && _vis.list.forEach(v => { const e = document.getElementById(v.id); if (e) e.remove(); }); }, [theme, hour]);
    for (const t of ['tb', 'tcel', 'tsale']) {
      await page.evaluate(t => { switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); } document.getElementById(t).scrollTop = 0; }, t);
      await page.waitForTimeout(1700);
      const items = await page.evaluate(t => {
        const out = []; const tab = document.getElementById(t);
        const walk = el => { for (const c of el.children) walk(c); const txt = [...el.childNodes].filter(x => x.nodeType === 3 && x.textContent.trim()); if (!txt.length) return; const cs = getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.5) return;
          // ボタンなど不透明な地の上の文字は対象外（透過の影響を受けない）
          let e = el, opaque = false, card = false; while (e && e !== tab) { const b = getComputedStyle(e).backgroundColor; const m = b.match(/rgba?\(([^)]+)\)/); if (m) { const p = m[1].split(',').map(Number); const al = p[3] === undefined ? 1 : p[3]; if (al >= 0.95 || getComputedStyle(e).backgroundImage.includes('gradient')) { opaque = true; break; } if (al >= 0.5) card = true; } e = e.parentElement; }
          if (opaque) return;
          const eb0 = el.getBoundingClientRect(); const eb = { left: eb0.left, right: eb0.right, top: eb0.top, bottom: eb0.bottom };
          { let a = el.parentElement; while (a && a !== document.body) { const ac = getComputedStyle(a); if (ac.overflow !== 'visible' || ac.overflowX !== 'visible' || ac.overflowY !== 'visible') { const ar = a.getBoundingClientRect(); eb.left = Math.max(eb.left, ar.left); eb.right = Math.min(eb.right, ar.right); eb.top = Math.max(eb.top, ar.top); eb.bottom = Math.min(eb.bottom, ar.bottom); } a = a.parentElement; } }
          const rg = document.createRange(); txt.forEach(x => { rg.selectNodeContents(x); for (const r0 of rg.getClientRects()) { const x0 = Math.max(r0.left, eb.left), x1 = Math.min(r0.right, eb.right), y0 = Math.max(r0.top, eb.top), y1 = Math.min(r0.bottom, eb.bottom); const r = { left: x0, top: y0, width: x1 - x0, height: y1 - y0, bottom: y1 }; if (r.width < 2 || r.height < 8) continue; const tr = tab.getBoundingClientRect(); if (r.bottom < tr.top || r.top > tr.bottom) continue; out.push({ x: r.left, y: r.top, w: r.width, h: r.height, color: cs.color, shadow: cs.textShadow !== 'none', card, cls: (el.className && el.className.baseVal === undefined ? el.className : '') + '|' + (el.parentElement ? el.parentElement.className : ''), txt: x.textContent.trim().slice(0, 12) }); } }); };
        walk(tab); return out; }, t);
      await page.addStyleTag({ content: '#' + t + ' *{color:transparent!important;-webkit-text-fill-color:transparent!important;text-shadow:none!important}' });
      await page.waitForTimeout(100);
      const buf = await page.screenshot();
      await page.evaluate(() => { const s = document.querySelectorAll('style'); s[s.length - 1].remove(); });
      const img = PNG.sync.read(buf);
      for (const it of items) {
        const m = it.color.match(/rgba?\(([^)]+)\)/); const [r, g, b] = m[1].split(',').map(Number); const lt = L(r, g, b);
        const vals = [];
        for (let y = Math.max(0, Math.floor(it.y)); y < Math.min(img.height, Math.ceil(it.y + it.h)); y++) for (let x = Math.max(0, Math.floor(it.x)); x < Math.min(img.width, Math.ceil(it.x + it.w)); x++) { const i = (y * img.width + x) * 4; const lb = L(img.data[i], img.data[i + 1], img.data[i + 2]); vals.push((Math.max(lt, lb) + 0.05) / (Math.min(lt, lb) + 0.05)); }
        if (!vals.length) continue; vals.sort((a, b) => a - b); const p5 = vals[Math.floor(vals.length * 0.05)]; n++;
        const key = `${W}x${H} ${mode} ${theme} ${hour}h ${t}: ${it.txt}`;
        if (p5 < 4.5) bad.push({ key, p5, card: it.card, shadow: it.shadow, cls: it.cls, txt: it.txt, theme, t });
        worst.push(p5);
      }
    }
    await ctx.close();
  }
  worst.sort((a, b) => a - b);
  console.log('checked', n, 'min', worst[0] && worst[0].toFixed(2), 'p1', worst[Math.floor(worst.length * .01)] && worst[Math.floor(worst.length * .01)].toFixed(2), 'below4.5', bad.length);
  const agg = {}; bad.forEach(b => { const k = b.theme + ' ' + b.t + ' ' + (b.card ? '枠' : '絵') + ' ' + b.cls + ' ' + b.txt; if (!agg[k] || agg[k] > b.p5) agg[k] = b.p5; });
  console.log('card', bad.filter(b => b.card).length, 'bare', bad.filter(b => !b.card).length);
  Object.entries(agg).sort((a, b) => a[1] - b[1]).slice(0, 60).forEach(([k, v]) => console.log(v.toFixed(2), k));
  await browser.close();
})();
