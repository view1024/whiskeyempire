
// ---------- v4: 称号・ティッカー・クエストの差し替え ----------
(function(){
  const set=(id,lb,ch)=>{const t=TT.find(x=>x.id===id);if(t){t.lb=lb;t.ch=ch;}};
  set('t16','得意先の信頼',s=>((s.stats&&s.stats.orders)||0)>=50);
  set('t16b','業界の顔',s=>((s.stats&&s.stats.orders)||0)>=200);
  set('t19','初仕込み',s=>((s.stats&&s.stats.filled)||0)>=1||(s.blendHistory||[]).length>=1);
  set('t19c','熟成の芸術家',s=>(s.lots||[]).some(l=>l.age>=5));
  TT.push(
    {id:'t22', lb:'初出荷',         ch:s=>((s.stats&&s.stats.shipped)||0)>=1},
    {id:'t19d',lb:'12年ものの誕生', ch:s=>((s.stats&&s.stats.maxAge)||0)>=12},
    {id:'t19e',lb:'四半世紀',       ch:s=>((s.stats&&s.stats.maxAge)||0)>=25},
    // v4.1 図鑑の収集（出荷した銘柄数）
    {id:'tc5', lb:'銘柄コレクター', ch:s=>Object.keys(s.shipLog||{}).length>=5},
    {id:'tc10',lb:'銘柄の目利き',   ch:s=>Object.keys(s.shipLog||{}).length>=10},
    {id:'tc15',lb:'酒蔵の案内人',   ch:s=>Object.keys(s.shipLog||{}).length>=15},
    {id:'tc20',lb:'ウイスキー博士', ch:s=>Object.keys(s.shipLog||{}).length>=20},
    {id:'tc25',lb:'図鑑の完成者',   ch:s=>Object.keys(s.shipLog||{}).length>=25}
  );
  const drop=['カット','自動製造','麦汁は','製造コスト','販売チャンネル','オークション','施設は購入しただけ','Tier昇格には全施設','Tier昇格直後は','クリティカルタップが発生','熟成庫のLvが上がるほど同時に'];
  for(let i=TICKER_MSGS.length-1;i>=0;i--){if(drop.some(w=>TICKER_MSGS[i].text.includes(w)))TICKER_MSGS.splice(i,1);}
  [
    '樽の年数は実時間1日で1年進む。放置中も最大72時間分熟成する。',
    '生産ラインは最も能力の低い工程で生産量が決まる。赤枠の工程から強化しよう。',
    '余った麦芽・麦汁・もろみは安値で外販される。ボトルネックを解消すると同じ原料から得る価値が上がる。',
    '若い原酒をすぐ売るか、寝かせて高く売るか。倉庫の枠には限りがある。',
    '予約注文は受注すると期限切れで評判が下がる。通常注文は見送っても罰はない。',
    '瓶詰めは「若い順」が既定。古い原酒を温存できる。',
    'Tier昇格の「○年以上の樽」は倉庫に残っている樽で数える。売ると数に入らない。',
    'バーボン銘柄はバーボン樽の原酒でしか瓶詰めできない。',
    '★3銘柄は風味の一致度50%以上の原酒が必要。蒸留所レシピと設備で風味を寄せよう。',
    '施設Lv10で設備を2択から選ぶ。能力を取るか、風味と品質を取るか。',
    'コレクターは18年以上の樽を丸ごと高値で買い取る。',
    'タンクが満杯になると溢れた分は安値で外販される。自動樽詰めを活用しよう。',
    '瓶詰め時の年数表記は、使った原酒の中で最も若いものに合わせる。',
    '品評会で受賞した銘柄は、その後ずっと単価が上がる。'
  ].forEach(t=>TICKER_MSGS.push({cat:'tips',text:t}));
})();
