  // ================= v5.9.2 追加テスト =================
  // ---------- #180 自動の通知の整理・空き席は「＋」だけ・大麦のサイロは24時間分（v5.9.2） ----------
  try {
    const { page, errors, ctx } = await page43(780, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {}; const W = ms => new Promise(r => setTimeout(r, ms)); const ft = () => [...document.querySelectorAll('.fxf')].map(e => e.textContent);
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      // 自動直販：資金欄に「+金額」も光りも出さない／自分で売ったときは出す
      switchTab('td'); rall(); await W(900);
      fxSale(12345, false, null); fxSale(2345, false, null); await W(V52.FX_COALESCE + 150);
      o.auto = [ft().filter(t => t.startsWith('+')).length, !!document.querySelector('#hc.fxgl')];
      await W(800); fxSale(5000, true, document.getElementById('bb')); await W(120);
      o.manual = ft().includes('+' + fmt(5000)); await W(800);
      // 自動の樽詰め（ほかのタブ）：寝かせるのアイコンに「+n樽」を出さない
      const l = G.lots[0]; fxFill(l, true); fxFill(l, true); fxFill(l, false); await W(V52.FX_COALESCE + 150);
      o.fill = ft().filter(t => /樽$/.test(t)).length;
      // 空き席は「＋」だけ（点線の小人の絵はない）
      G.staff = []; G.ownerAt = null; placeInvalidate(); switchTab('tb'); rall(); await W(60);
      const s = document.querySelector('#lineView .wseat');
      o.seat = s ? [s.querySelectorAll('svg').length, (s.querySelector('.seatp') || {}).textContent, Math.round(s.getBoundingClientRect().width), Math.round(s.getBoundingClientRect().height)] : null;
      o.chip = !!document.querySelector('#idleTb .idlec svg'); // 見出しの待機の札は絵と数のまま
      // 大麦：上限は製麦室の24時間分（最低2,400kg）・自動仕入れで戻す量は今までと同じ（0.8時間分/時）
      G.fac.malting.l = 20; prodInvalidate(); const c = stageCap(0);
      o.cap = [barleyCap() === Math.max(2400, Math.round(c * 24)), BARLEY.SILO_H, +(BARLEY.REFILL_PER_H * BARLEY.SILO_H).toFixed(6)];
      openBarleyModal(); o.modal = document.getElementById('mc2').textContent.includes('24時間分'); closeM();
      // 空から満タンまで（自動）：約30時間
      const b = barleyState(); b.auto = true; b.kg = 0; b._used = 0; G.cash = 1e18; barleyAutoRefill(1); o.refill1h = +(b.kg / barleyCap()).toFixed(4);
      return o;
    });
    const ok = r.auto.join() === '0,false' && r.manual && r.fill === 0 && r.seat && r.seat[0] === 0 && r.seat[1] === '＋' && r.seat[2] >= 44 && r.seat[3] >= 44 && r.chip
      && r.cap[0] && r.cap[1] === 24 && r.cap[2] === 0.8 && r.modal && Math.abs(r.refill1h - 1 / 30) < 1e-3;
    rec(180, '通知の整理と大麦（v5.9.2）：自動直販は資金欄に「+金額」も光りも出さない（自分で売ったときは出す）・自動の樽詰めで寝かせるのアイコンに「+n樽」を出さない・空き席は点線の小人なしの「＋」だけ（押す範囲44px）・大麦のサイロは製麦室の24時間分（最低2,400kg）・自動仕入れで戻す量は1時間に0.8時間分（今までと同じ）・仕入れの小窓は「24時間分」', ok, JSON.stringify(r));
    if (errors.length) rec('E125', '通知の整理のテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  } catch (e) { rec('C180', 'テスト中の例外', false, String(e && e.message || e).slice(0, 300)); }
