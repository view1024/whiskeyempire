exec(open('gen_ft51.py').read().replace("open('functest51.js','w').write(s)","pass"))
import os
exec(open('functest52_fix.py').read())
if os.path.exists('functest52_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest52_add.js').read()+s[a:]
open('functest52.js','w').write(s)
