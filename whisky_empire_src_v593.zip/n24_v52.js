// ============================================================
// v5.2 樽タップの小人（砂時計）・受注した予約注文の取り消し・BGM（クラシックのローテーション）
// ============================================================
// 実装計画：https://claude.ai/code/artifact/9c0f27e2-9040-49bc-b6c0-75eb729b7580

// ---------- 樽の小人：v5.5 から試飲会のたびに V55.DWARF_P の確率で砂時計を1個（1日 V51.HG.tap.cap 個まで） ----------
function tapHgCapped(){const h=hgDay();return (h.src.tap||0)>=V51.HG.tap.cap;}
// 試飲会を開いたときに呼ぶ。来たら {msg:トーストの2行目, got:受け取れたか} を返す
function dwarfTaste(){
  if(tapHgCapped()||Math.random()>=V55.DWARF_P)return null;
  const h=hgDay();
  if(h.n>=V47.HG_MAX)return {msg:'🧝 小人が来ましたが、砂時計が'+V47.HG_MAX+'個なので持ち帰りました',got:false};
  if(!hgAdd(V51.HG.tap.k,'樽の小人','tap',true))return null;
  return {msg:'🧝 小人が砂時計を置いていきました（今日 '+h.src.tap+'/'+V51.HG.tap.cap+'）',got:true};
}
// v5.5.1 小人の絵と砂時計が飛ぶ演出はやめた（知らせはトーストだけ）

// ---------- 受注した予約注文の取り消し：評判・関係は期限切れと同じ＋違約金（報酬の見込みの10%） ----------
function ordEstAny(o){
  const m=ordMatch(o);if(m.cash>0)return m.cash;
  const e=ordEstimate(o);if(e>0)return e;
  const c=custById(o.cid);const pm=(Number(c.priceMult)||1)*(1+BALANCE.REL_PRICE_STEP*relLv(o.cid))*o.mult;
  let pids=[];
  if(o.kind==='type')pids=G.uw.filter(id=>{const sp=productSpec(id);return sp&&!sp.blend&&sp.tp===o.tp;});
  else if(o.kind==='flavor')pids=['blend:'+o.target];
  let u=0;pids.forEach(p=>{const sp=productSpec(p);if(sp)u=Math.max(u,priceUnit(p,Math.max(o.minAge||3,sp.minAge||3),1,sp.target));});
  return u*o.qty*pm;
}
function ordCancelCost(o){return {rep:ordRep(o)*0.5,rel:3,fee:Math.round(ordEstAny(o)*V52.CANCEL_FEE)};}
function ordCancel(id){
  const o=G.orders.find(x=>x.id===id);if(!o||!(o.reserve&&o.accepted))return false;
  const k=ordCancelCost(o);
  if(G.cash<k.fee){toast('違約金が足りません（'+fmt(k.fee)+'）',2600);return false;}
  pay(k.fee,'sga','oth');moneyFx(k.fee);
  changeRep(-k.rep,'予約注文の取り消し');relAdd(o.cid,-k.rel);
  G.bq.forEach(q=>{if(q.oid===o.id)q.oid=null;});
  G.orders=G.orders.filter(x=>x!==o);G.stats.cancel=(G.stats.cancel||0)+1;
  toast('📝 予約注文を取り消しました（違約金 −'+fmt(k.fee)+'）',3000);
  save();return true;
}
function ordCancelAsk(id){
  const o=G.orders.find(x=>x.id===id);if(!o)return;const k=ordCancelCost(o);const c=custById(o.cid);
  showConfirm({title:'予約注文の取り消し',msg:`${escapeHtml(c.name)}の予約注文（${escapeHtml(ordLabel(o))}）を取り消します。<br>評判 −${Math.round(k.rep*10)/10} ・ 関係 −${k.rel}回分 ・ 違約金 <b>−${fmt(k.fee)}</b><br><span class="sm">瓶詰め中の分は在庫に入ります</span>`,icon:'📝',danger:true,yesLabel:'取り消す',onYes:()=>{if(ordCancel(id)){closeM();rall();}}});
}

// ---------- BGM：著作権の切れた曲を Web Audio で演奏（簡略な編曲・自作のデータ） ----------
// v5.3 ボレロを追加し、各曲を4〜6分半に（繰り返し・変奏・間奏は組み立てで作る）。音色は6種類
// 音の名前 → MIDI 番号（'C4'＝60、'F#3'、'Bb2'）
function nm(s){const m=/^([A-G])([#b]?)(-?\d)$/.exec(s);if(!m)return 0;return 12*(Number(m[3])+1)+{C:0,D:2,E:4,F:5,G:7,A:9,B:11}[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0);}
function nms(s){return s.trim().split(/\s+/).map(nm);}
// 音色（音符の5番目）：0 ピアノ風・1 フルート・2 クラリネット・3 弦・4 金管・5 小太鼓・6 はじく音（ピアノ風を短く）
// v5.8 ケルト（n30）：7 ハープ・8 フィドル・9 ティンホイッスル・10 バウロン
// 発音の後に音が残る秒数（同時に鳴る数の数え方に使う）
const BGM_TAIL=[0.4,0.15,0.15,0.35,0.2,0.1,0.3,0.9,0.25,0.12,0.2];
// 「C5:1~ C5:.5 Db5:1/3 … R:1 | …」→ [拍, 長さ, MIDI]（R は休み、~ は次の同じ高さの音とつなぐ、1/3 は三連符）
function bgmSeq(s){const out=[];let t=0,tie=null;s.replace(/\|/g,' ').trim().split(/\s+/).forEach(tok=>{const p=tok.split(':');let ds=p[1],tl=false;if(ds.endsWith('~')){tl=true;ds=ds.slice(0,-1);}const f=ds.split('/');const d=f.length>1?Number(f[0])/Number(f[1]):Number(ds);
  if(p[0]!=='R'){const m=nm(p[0]);if(tie&&tie[2]===m)tie[1]+=d;else{tie=[t,d,m];out.push(tie);}if(!tl)tie=null;}else tie=null;t+=d;});return out;}
// v5.4 曲は毎回、変奏の組み合わせを選んで約1〜2分に組み立てる（build(r)：r() は 0〜1 の乱数）
const pickN=(r,a,n)=>{const b=a.slice(),o=[];while(o.length<n&&b.length)o.push(b.splice(Math.floor(r()*b.length),1)[0]);return o;};
// ボレロの主題：フランス語版 Wikipedia「Boléro (Ravel)」の譜例（主題 A・B の前半と後半）で音と拍を確かめ、自分で書き起こしたもの。
// 18小節＝17小節の旋律＋1小節の休み。小太鼓は「2小節・24打」（英語版の譜例と一致）
const BOL_A='C5:1~ C5:.5 B4:.25 C5:.25 D5:.25 C5:.25 B4:.25 A4:.25 | C5:.5 C5:.25 A4:.25 C5:1~ C5:.5 B4:.25 C5:.25 | A4:.25 G4:.25 E4:.25 F4:.25 G4:2~ | G4:.25 F4:.25 E4:.25 D4:.25 E4:.25 F4:.25 G4:.25 A4:.25 G4:1~ | G4:1~ G4:.25 A4:.25 B4:.25 A4:.25 G4:.25 F4:.25 E4:.25 D4:.25 | E4:.25 D4:.25 C4:.5~ C4:.5 C4:.25 D4:.25 E4:.5 F4:.5 | D4:1 G4:2~ | G4:2~ G4:.5 R:.5 | D5:1~ D5:.75 C5:.25 B4:.25 A4:.25 B4:.25 C5:.25 | D5:.25 C5:.25 B4:.5~ B4:.25 C5:.25 B4:.25 A4:.25 C5:.25 B4:.25 A4:.25 F4:.25~ | F4:.5 F4:.25 F4:.25 F4:.5 A4:.5 C5:.25 A4:.25 B4:.25 G4:.25 | F4:.5 F4:.25 F4:.25 F4:.5 A4:.5 B4:.25 G4:.25 A4:.25 F4:.25 | D4:.5 D4:.25 C4:.25 D4:1~ D4:.5 D4:.25 D4:.25 | D4:.5 F4:.5 A4:.25 F4:.25 G4:.25 E4:.25 D4:.5 D4:.25 C4:.25 | D4:1~ D4:.5 D4:.25 C4:.25 D4:.5 E4:.25 F4:.25 | G4:2~ G4:.25 F4:.25 E4:.25 D4:.25 | C4:.5 R:2.5 | R:3';
const BOL_B='Bb4:1~ Bb4:.25 A4:.25 G4:.25 F4:.25 Bb4:.25 C5:.25 A4:.25 G4:.25 | Bb4:.5 A4:.25 G4:.25 Bb4:1 A4:.25 Bb4:.25 A4:.25 G4:.25~ | G4:1 G4:.25 F4:.25 E4:.25 D4:.25 E4:1~ | E4:1 R:.5 Bb4:.5 C5:.5 Db5:.5~ | Db5:.5 Db5:1 Db5:.5 Db5:.5 Db5:.5 | Db5:1/3 Db5:1/3 Db5:1/3 Db5:.5 C5:.25 Bb4:.25 Db5:.5 C5:.25 Bb4:.25 | Db5:.25 C5:.25 Bb4:.25 Ab4:.25 G4:.25 F4:.25 E4:.5~ E4:1~ | E4:2~ E4:.5 R:.5 | D4:1.5 E4:.5 D4:.25 E4:.25 F4:.5~ | F4:1 G4:.5 Ab4:.5 F4:1/3 G4:1/3 E4:1/3 | D4:.25 E4:.25 D4:.25 C4:.25 C4:.5 Bb3:.5~ Bb3:1~ | Bb3:.25 C4:.25 Bb3:.25 C4:.25 D4:.25 E4:.25 D4:.25 C4:.25 D4:.25 C4:.25 Bb3:.25 Ab3:.25 | Bb3:.25 Ab3:.25 G3:.5~ G3:.5 F3:.5~ F3:1~ | F3:1 F3:.25 G3:.25 F3:.25 Eb3:.25~ Eb3:1~ | Eb3:1 F3:.25 Eb3:.25 F3:.25 Db3:.25~ Db3:1~ | Db3:1 Db3:.25 Db3:.25 Eb3:.25 Db3:.25 F3:.25 Eb3:.25 Db3:.25 C3:.25~ | C3:.5 R:2.5 | R:3';
// 曲：拍（bpm の1拍）単位で [開始, 長さ, MIDI番号, 強さ0〜1, 音色]
const BGM_PIECES=[
  {id:'bach846',t:'平均律クラヴィーア曲集 第1巻 第1番 プレリュード',c:'J.S.バッハ',bpm:70,build:r=>{
    const B=['C4 E4 G4 C5 E5','C4 D4 A4 D5 F5','B3 D4 G4 D5 F5','C4 E4 G4 C5 E5','C4 E4 A4 E5 A5','C4 D4 F#4 A4 D5','B3 D4 G4 D5 G5','B3 C4 E4 G4 C5','A3 C4 E4 G4 C5','D3 A3 D4 F#4 C5','G3 B3 D4 G4 B4','G3 Bb3 E4 G4 C#5','F3 A3 D4 A4 D5','F3 Ab3 D4 F4 B4','E3 G3 C4 G4 C5','E3 F3 A3 C4 F4','D3 F3 A3 C4 F4','G2 D3 G3 B3 F4','C3 E3 G3 C4 E4','C3 G3 Bb3 C4 E4','F2 F3 A3 C4 E4','F#2 C3 A3 C4 Eb4','Ab2 F3 B3 C4 D4','G2 F3 G3 B3 D4','G2 E3 G3 C4 E4','G2 D3 G3 C4 F4','G2 D3 G3 B3 F4','G2 Eb3 A3 C4 F#4','G2 E3 G3 C4 G4','G2 D3 G3 C4 F4','G2 D3 G3 B3 F4','C2 C3 G3 Bb3 E4','C2 C3 F3 A3 C4 F4','C2 B2 G4 B4 D5 F5'];
    // 上の3声を、そのままか1オクターブ上（柔らかく）で
    const up=r()<0.5?0:12,vm=up?.8:1;const out=[];
    B.forEach((s,i)=>{const n=nms(s);const t0=i*4;const hi=j=>n[j]+(j>=2?up:0);
      if(n.length===5){for(let h=0;h<2;h++){const t=t0+h*2;out.push([t,2,n[0],.55*vm],[t+.25,1.75,n[1],.45*vm]);[2,3,4,2,3,4].forEach((q,j)=>out.push([t+.5+j*.25,.32,hi(q),.4*vm]));}}
      else{out.push([t0,4,n[0],.5*vm],[t0,4,n[1],.45*vm]);n.slice(2).forEach((m,j)=>{out.push([t0+.5+j*.25,3.5-j*.25,m+up,.38*vm]);});}});
    const T=B.length*4;nms('C2 C3 E4 G4 C5').forEach((m,j)=>out.push([T+j*.06,5,m+(j>=2?up:0),.4]));return out;}},
  {id:'joy',t:'交響曲第9番より「歓喜の歌」（変奏による編曲）',c:'L.v.ベートーヴェン',bpm:80,build:r=>{
    const P=['E4 E4 F4 G4','G4 F4 E4 D4','C4 C4 D4 E4','E4. D4- D4_','E4 E4 F4 G4','G4 F4 E4 D4','C4 C4 D4 E4','D4. C4- C4_','D4 D4 E4 C4','D4 E4/F4/ E4 C4','D4 E4/F4/ E4 D4','C4 D4 G3_','E4 E4 F4 G4','G4 F4 E4 D4','C4 C4 D4 E4','D4. C4- C4_'];
    const H=['C','G','C','G','C','G','C','G','G','G','G','C','C','G','C','G'];
    const HC={C:{b:nm('C3'),c:nms('E3 G3 C4')},G:{b:nm('G2'),c:nms('D3 G3 B3')}};
    const bars=P.map(bar=>{const q=[];let x=0;bar.split(' ').forEach(tok=>{let d=1,n=tok;if(n.endsWith('.')){d=1.5;n=n.slice(0,-1);}else if(n.endsWith('-')){d=.5;n=n.slice(0,-1);}else if(n.endsWith('_')){d=2;n=n.slice(0,-1);}else if(n.includes('/')){n.split('/').filter(Boolean).forEach(z=>{q.push([x,.5,nm(z)+12]);x+=.5;});return;}q.push([x,d,nm(n)+12]);x+=d;});return q;});
    const out=[];let t=0;const o=(a,d,m,v)=>out.push([t+a,d,m,v]);
    [0,2,4,6].forEach(a=>{o(a,1.9,nm('G2'),.3);nms('D3 G3 B3').forEach(m=>o(a+1,.9,m,.18));});t+=8;
    // 5つの変奏（素朴な和音・分散和音・オクターブ・行進曲風・全音域）から2つを、この順で
    pickN(r,[0,1,2,3,4],2).sort((a,b)=>a-b).forEach(v=>{
      bars.forEach((bar,i)=>{const h=HC[H[i]];
        if(v===0){bar.forEach(n=>o(n[0],n[1]*.95,n[2],.4));[0,2].forEach(a=>{o(a,1.9,h.b,.3);h.c.slice(0,2).forEach(m=>o(a,1.9,m,.16));});}
        else if(v===1){bar.forEach(n=>o(n[0],n[1]*.95,n[2],.42));for(let k=0;k<8;k++)o(k*.5,.48,[h.b,h.c[1],h.c[2],h.c[1]][k%4],.22);}
        else if(v===2){bar.forEach(n=>{o(n[0],n[1]*.95,n[2],.4);o(n[0],n[1]*.95,n[2]+12,.3);});[0,1,2,3].forEach(a=>o(a,.9,a%2?h.b+7:h.b,.28));}
        else if(v===3){bar.forEach(n=>o(n[0],Math.min(.6,n[1]*.6),n[2],.45));[0,2].forEach(a=>o(a,.8,h.b,.34));[1,3].forEach(a=>h.c.slice(0,2).forEach(m=>o(a,.6,m,.2)));}
        else{bar.forEach(n=>{o(n[0],n[1]*.95,n[2],.42);o(n[0],n[1]*.95,n[2]-12,.3);});[0,2].forEach(a=>{o(a,1.9,h.b,.32);o(a,1.9,h.b-12,.26);h.c.forEach(m=>o(a+.02,1.8,m,.15));});}
        t+=4;});});
    nms('G2 D3 F3 B3').forEach(m=>o(0,3.8,m,.3));o(0,1,nm('D5'),.4);o(1,1,nm('B4'),.38);o(2,2,nm('G4'),.38);t+=4;
    nms('C2 C3 G3 C4 E4 G4 C5').forEach((m,j)=>o(j*.05,8,m,.36));return out;}},
  {id:'gym1',t:'ジムノペディ第1番（による編曲）',c:'E.サティ',bpm:66,build:r=>{
    const out=[];const G=[nm('G2'),nms('B3 D4 F#4')],D=[nm('D2'),nms('A3 C#4 F#4')];
    const M1=[[],[],[],[],['','F#5','A5'],['G5','F#5','C#5'],['B4','C#5','D5'],['A4'],['F#4'],[],[],[],['','F#5','A5'],['G5','F#5','C#5'],['B4','C#5','D5'],['A4'],['C#5'],['F#5'],[],[],['E5'],['D5','C#5','B4'],['C#5','D5','E5'],['A4'],['F#4'],[],[],[]];
    const M2=[[],[],['','F#5','A5'],['G5','F#5','C#5'],['B4','C#5','D5'],['A4'],['F#4'],[],[],[],['','E5','F#5'],['G5','A5','B5'],['A5'],['F#5'],['E5','D5','C#5'],['D5'],[],[],['','B4','C#5'],['D5','E5','F#5'],['E5'],['C#5'],['B4','A4','F#4'],['G4'],[],[]];
    const M3=M1.map((m,i)=>i<16?m:m.map(n=>n?n.replace(/\d/,d=>String(Number(d)-1)):n));
    // 3つの部分のうち1つ
    const bars=[M1,M2,M3][Math.floor(r()*3)];
    bars.forEach((m,i)=>{const t=i*3;const [b,c]=i%2===0?G:D;out.push([t,3,b,.42]);c.forEach((n,j)=>out.push([t+1+.02*j,2,n,.24]));
      if(m.length===1){let k=i+1;while(k<bars.length&&bars[k].length===0&&k-i<3)k++;out.push([t,(k-i)*3,nm(m[0]),.4]);}
      else m.forEach((n,j)=>{if(n)out.push([t+j,1,nm(n),.4]);});});
    const T=bars.length*3;nms('D2 A2 D3 F#3 A3 D4').forEach((m,j)=>out.push([T+j*.1,6,m,.34]));return out;}},
  {id:'canon',t:'カノン（変奏による編曲）',c:'J.パッヘルベル',bpm:58,build:r=>{
    const bass=nms('D3 A2 B2 F#2 G2 D2 G2 A2');const ch=['D4 F#4 A4','C#4 E4 A4','B3 D4 F#4','A3 C#4 F#4','G3 B3 D4','F#3 A3 D4','G3 B3 D4','A3 C#4 E4'].map(nms);
    const v1=nms('F#5 E5 D5 C#5 B4 A4 B4 C#5'),v2=nms('D5 C#5 B4 A4 G4 F#4 G4 E4');
    const SC=[];for(let o=2;o<=7;o++)[2,4,6,7,9,11,13].forEach(s=>SC.push(12*(o+1)+s));
    const sc=(m,k)=>{let i=SC.indexOf(m);if(i<0)i=SC.findIndex(x=>x>m);return SC[Math.max(0,Math.min(SC.length-1,i+k))];};
    const out=[];let t=0;const o=(a,d,m,v)=>out.push([t+a,d,m,v]);
    // 1回目は和音だけ、続く5回は15種類の変奏から（番号の順に）
    const seq=[0].concat(pickN(r,[1,2,3,4,5,6,7,8,9,10,11,12,13,14],5).sort((a,b)=>a-b));
    seq.forEach(cyc=>{for(let i=0;i<8;i++){const c=ch[i];const busy=[6,7,9,11,12].includes(cyc);
      o(0,2,bass[i],.5);(busy?c.slice(1):c).forEach((m,j)=>o(.02*j,1.9,m,busy?.18:.22));
      switch(cyc){
        case 1:case 14:o(0,2,v1[i],cyc===14?.32:.42);break;
        case 2:o(0,2,v2[i],.42);break;
        case 3:[c[2]+12,c[1]+12,c[0]+12,c[1]+12].forEach((m,j)=>o(j*.5,.55,m,.36));break;
        case 4:case 13:[c[0]+12,c[1]+12,c[2]+12,c[0]+24,c[2]+12,c[1]+12,c[0]+12,c[1]+12].forEach((m,j)=>o(j*.25,.3,m,.32));if(cyc===13)o(0,2,v2[i],.3);break;
        case 5:o(0,2,v1[i],.4);o(0,2,v2[i]-12,.3);break;
        case 6:[0,1,0,-1].forEach((k,j)=>o(j*.5,.5,sc(v1[i],k),.38));break;
        case 7:case 12:for(let j=0;j<8;j++)o(j*.25,.27,sc(c[0]+12,i%2?7-j:j),cyc===12?.26:.32);break;
        case 8:[0,1].forEach(j=>{o(j,.95,v2[i],.36);o(j,.95,v2[i]+12,.3);});break;
        case 9:[c[0],c[2],c[0]+12,c[2]].forEach((m,j)=>o(j*.5,.5,m,.24));o(0,2,v1[i]+12,.3);break;
        case 10:o(0,1.5,v1[i],.4);o(1.5,.5,sc(v1[i],-1),.36);o(0,2,v2[i]-12,.26);break;
        case 11:[0,-1,0,1].forEach((k,j)=>o(j*.5,.5,sc(v2[i],k),.36));o(0,2,v1[i],.34);break;
      }
      t+=2;}});
    nms('D2 D3 F#4 A4 D5').forEach((m,j)=>out.push([t+j*.05,5,m,.4]));return out;}},
  {id:'elise',t:'エリーゼのために（主題と間奏による編曲）',c:'L.v.ベートーヴェン',bpm:132,build:r=>{
    // 1拍＝8分音符（t は16分音符の数）。小節＝16分音符6つ
    const out=[];const s=(t,n,d,v)=>out.push([t/2,(d||1)/2,typeof n==='number'?n:nm(n),v||.42]);
    const turn=t=>{['E5','D#5','E5','B4','D5','C5'].forEach((n,i)=>s(t+i,n));};
    const bar=(t,mel,lh,rh,v)=>{v=v||1;if(mel)s(t,mel,2,.45*v);lh.forEach((n,i)=>s(t+i,n,1,.32*v));(rh||[]).forEach((n,i)=>s(t+3+i,n,1,.42*v));};
    const LA=['A2','E3','A3'],LE=['E2','E3','G#3'];
    let t=0;
    const A=last=>{s(t,'E5');s(t+1,'D#5');t+=2;turn(t);t+=6;bar(t,'A4',LA,['C4','E4','A4']);t+=6;bar(t,'B4',LE,['E4','G#4','B4']);t+=6;bar(t,'C5',LA,['E4','E5','D#5']);t+=6;turn(t);t+=6;bar(t,'A4',LA,['C4','E4','A4']);t+=6;bar(t,'B4',LE,['E4','C5','B4']);t+=6;bar(t,'A4',LA,last);t+=6;};
    const mid=()=>{bar(t,'E5',['C3','G3','C4'],['G4','F5','E5']);t+=6;bar(t,'D5',['G2','G3','B3'],['F4','E5','D5']);t+=6;bar(t,'C5',LA,['E4','D5','C5']);t+=6;bar(t,'B4',LE,[]);t+=4;};
    const block=()=>{A(['B4','C5','D5']);mid();A([]);};
    const CH={F:['F2','C3','A3'],C:['C3','G3','E4'],G:['G2','D3','B3'],Am:['A2','E3','A3'],Dm:['D3','A3','F4'],E:['E2','E3','G#3']};
    const P1=[['F','A4','C5 F5 E5'],['C','G4','E5 D5 C5'],['G','B4','D5 G5 F5'],['C','C5','E5 D5 C5'],['F','A4','C5 F5 A5'],['C','G5','F5 E5 D5'],['G','D5','B4 C5 D5'],['C','C5','G4 E4 C4']];
    const P3=[['Am','E5','D#5 E5 B4'],['E','B4','D5 C5 B4'],['Am','C5','E5 A5 G#5'],['E','B4','G#4 B4 E5'],['Dm','F5','E5 D5 C5'],['Am','E5','C5 B4 A4'],['E','G#4','B4 D5 C5'],['Am','A4','E4 C4 A3']];
    const phr=(P,up,v)=>P.forEach(([c,m,q])=>{bar(t,nm(m)+up,CH[c],nms(q).map(x=>x+up),v);t+=6;});
    // 主題 → 間奏（3つから1つ）→ 主題
    const k=Math.floor(r()*3);
    block();if(k===0){phr(P1,0);phr(P1,12,.85);phr(P3,0);phr(P1,0);}else if(k===1){phr(P3,0);phr(P3,12,.85);phr(P1,0);phr(P3,0);}else{phr(P1,0,.85);phr(P3,0);phr(P1,12,.8);phr(P3,0,.9);}block();
    ['A2','E3','A3','C4','E4','A4'].forEach((n,i)=>s(t+i*.3,n,10,.36));return out;}},
  {id:'bolero',t:'ボレロ（主題による編曲）',c:'M.ラヴェル',bpm:72,lp:6000,build:r=>{
    const A=bgmSeq(BOL_A),B=bgmSeq(BOL_B);
    // 前奏2小節 → 主題 A（独奏：フルート・クラリネット・金管から1つ）→ 主題 B（クラリネット＋弦、2回目は重ねる）→ 転調して全合奏で終わる
    const solo=[[1,0],[2,0],[4,0]][Math.floor(r()*3)];
    const ST=[[A,[[solo[0],solo[1],.42]],.6],[B,[[2,0,.36],[3,0,.3],[1,12,.2]],.8]];
    const out=[];const o=(t,d,m,v,i)=>out.push([t,d,m,v,i]);
    const SN=[[0,.5,2/3,5/6,1,1.5,5/3,11/6,2,2.5],[0,.5,2/3,5/6,1,1.5,5/3,11/6,2,13/6,7/3,2.5,8/3,17/6]];
    const nBar=2+ST.length*18+8+2;const T=nBar*3;const modB=2+ST.length*18;
    for(let b=0;b<nBar-1;b++){const t=b*3;const p=t/T;const tr=b>=modB&&b<modB+4?4:0;
      SN[b%2].forEach(x=>o(t+x,.06,60,.14+.45*p,5));
      o(t,.4,nm('C3')+tr,.3+.25*p,6);o(t+2,.4,nm('G2')+tr,.28+.25*p,6);if(b%2)o(t+2.5,.3,nm('C3')+tr,.24+.2*p,6);
      if(b>=nBar-2)continue;
      if(b>=2+18&&b<modB)[1,2].forEach(a=>nms('G3 C4 E4').forEach((m,j)=>o(t+a+.01*j,.3,m+tr,.12+.12*p,6)));
      if(b>=modB&&b<nBar-4&&b%2===0)nms('G3 E4').forEach(m=>o(t+.05,5.8,m+tr,.1+.08*p,3));}
    let t=6;ST.forEach(([th,vs,dy])=>{vs.forEach(([ins,oc,v])=>th.forEach(n=>o(t+n[0],n[1]*.97,n[2]+oc,v*dy,ins)));t+=54;});
    // 転調（ホ長調）→ハ長調に戻って終える（主題 A の後半による）
    const tail=A.filter(n=>n[0]>=24&&n[0]<48);
    [[1,12,.2],[2,0,.24],[3,0,.24],[4,-12,.24]].forEach(([ins,oc,v])=>tail.forEach(n=>o(t+n[0]-24,n[1]*.97,n[2]+oc+(n[0]<36?4:0),v,ins)));t+=24;
    nms('C3 G3 E4').forEach(m=>{o(t,2.4,m,.26,3);o(t,2.4,m,.22,4);});['G4','F4','Eb4','Db4'].forEach((n,j)=>o(t+2+j*.25,.25,nm(n),.24,4));
    t+=3;nms('C2 G3 C4 E4').forEach(m=>{o(t,2.6,m,.28,3);o(t,2.6,m,.26,4);});o(t,.08,60,.7,5);o(t+.2,.06,60,.5,5);
    return out;}}
];
let _bgmc={i:-1,notes:null,ptr:0,t0:0,timer:null,voices:[],bag:[],mode:''};
// v5.8 クラシック／ケルト／なし（v5.7 までの「環境音楽」はケルトとして扱う）
function bgmMode(){const m=opt().bgmMode;return m==='off'?m:m==='celtic'||m==='ambient'?'celtic':'classic';}
function bgmList(){return bgmMode()==='celtic'?BGM_CELTIC:BGM_PIECES;}
// 曲の音符を組み立てる（秒に直す）。r を渡すと同じ組み合わせになる（試験用）
function bgmBuild(i,r,L){const p=(L||bgmList())[i];const sp=60/p.bpm;return p.build(r||Math.random).filter(n=>n[2]>0).map(n=>[n[0]*sp,Math.max(.05,n[1]*sp),n[2],n[3],n[4]||0]).sort((a,b)=>a[0]-b[0]);}
function bgmLoad(i){const p=bgmList()[i];try{if(_bgm.filter&&_audioCtx)_bgm.filter.frequency.setTargetAtTime(p.lp||2600,_audioCtx.currentTime,0.5);}catch(e){}return bgmBuild(i);}
// 曲の長さ（秒）
function bgmDur(N){let e=0;N.forEach(n=>{if(n[0]+n[1]>e)e=n[0]+n[1];});return e;}
// 今の種類の曲（クラシック6曲・ケルト5曲）をシャッフルして1回ずつ。全部流したら並べ直す（周の境目で同じ曲が続かないように）
function bgmNext(){
  if(!_bgmc.bag.length){const b=bgmList().map((p,i)=>i);for(let k=b.length-1;k>0;k--){const j=Math.floor(Math.random()*(k+1));[b[k],b[j]]=[b[j],b[k]];}
    if(b[0]===_bgmc.i&&b.length>1){const j=1+Math.floor(Math.random()*(b.length-1));[b[0],b[j]]=[b[j],b[0]];}_bgmc.bag=b;}
  return _bgmc.bag.shift();
}
function bgmClassicStart(){
  if(_bgmc.timer)return;const ctx=_audioCtx;if(!ctx||!_bgm.master)return;
  if(_bgmc.mode!==bgmMode()){_bgmc.mode=bgmMode();_bgmc.notes=null;_bgmc.bag=[];_bgmc.i=-1;}
  if(!_bgmc.notes){_bgmc.i=bgmNext();_bgmc.notes=bgmLoad(_bgmc.i);_bgmc.ptr=0;_bgmc.t0=ctx.currentTime+1.0;}
  else{const done=_bgmc.notes[_bgmc.ptr]?_bgmc.notes[_bgmc.ptr][0]:0;_bgmc.t0=ctx.currentTime+0.5-done;}
  _bgmc.timer=setInterval(bgmClassicTick,200);bgmClassicTick();
}
function bgmClassicStop(){if(_bgmc.timer){clearInterval(_bgmc.timer);_bgmc.timer=null;}_bgmc.voices=[];}
function bgmClassicTick(){
  const ctx=_audioCtx;if(!ctx||!_bgm.master||document.hidden)return;
  const now=ctx.currentTime;_bgmc.voices=_bgmc.voices.filter(v=>v[1]>now);
  const N=_bgmc.notes;
  while(_bgmc.ptr<N.length&&_bgmc.t0+N[_bgmc.ptr][0]<now+0.8){
    const n=N[_bgmc.ptr++];const t=Math.max(now+0.01,_bgmc.t0+n[0]);
    // その時刻に鳴っている音（発音中＋余韻）が16あれば、その音は出さない
    if(bgmOn(t)>=V52.BGM_POLY)continue;
    _bgmc.voices.push([t,t+n[1]+BGM_TAIL[n[4]]]);bgmPlay(ctx,n[4],n[2],t,n[1],n[3]);
  }
  if(_bgmc.ptr>=N.length&&now>_bgmc.t0+bgmDur(N)+V54.BGM_GAP){_bgmc.i=bgmNext();_bgmc.notes=bgmLoad(_bgmc.i);_bgmc.ptr=0;_bgmc.t0=now+0.5;}
}
function bgmOn(t){let c=0;_bgmc.voices.forEach(v=>{if(v[0]<=t&&v[1]>t)c++;});return c;}
function bgmPlay(ctx,ins,m,t,dur,vel){
  if(ins===5)return bgmSnare(ctx,t,vel);
  if(ins===6)return bgmPiano(ctx,m,t,Math.min(dur,.3),vel);
  if(ins>=1&&ins<=4)return bgmWind(ctx,ins,m,t,dur,vel);
  if(ins===7)return bgmHarp(ctx,m,t,dur,vel);
  if(ins===8)return bgmFiddle(ctx,m,t,dur,vel);
  if(ins===9)return bgmWhistle(ctx,m,t,dur,vel);
  if(ins===10)return bgmBodhran(ctx,m,t,vel);
  bgmPiano(ctx,m,t,dur,vel);
}
// ピアノ風の音：三角波＋1オクターブ上の正弦波。打鍵で立ち上がり、高い音ほど早く減衰する
function bgmPiano(ctx,m,t,dur,vel){
  const f=440*Math.pow(2,(m-69)/12);const o1=ctx.createOscillator(),o2=ctx.createOscillator(),g=ctx.createGain(),g2=ctx.createGain();
  o1.type='triangle';o2.type='sine';o1.frequency.value=f;o2.frequency.value=f*2;g2.gain.value=0.25;
  o1.connect(g);o2.connect(g2);g2.connect(g);g.connect(_bgm.master);
  const pk=0.28*vel,tau=Math.max(0.25,1.6-(m-40)*0.025);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+0.008);g.gain.setTargetAtTime(pk*0.35,t+0.01,tau*0.35);g.gain.setTargetAtTime(0,t+dur,0.12);
  const stop=t+dur+0.6;o1.start(t);o2.start(t);o1.stop(stop);o2.stop(stop);
}
// 持続する音：1 フルート（正弦波＋揺れ）・2 クラリネット（矩形波を丸める）・3 弦（のこぎり波・ゆっくり立ち上がる）・4 金管（明るいのこぎり波）
const BGM_WIND={1:{w:'sine',a:.06,r:.12,pk:.2,lp:0,vib:.004},2:{w:'square',a:.03,r:.1,pk:.13,lp:3,vib:0},3:{w:'sawtooth',a:.18,r:.3,pk:.1,lp:2200,vib:.003},4:{w:'sawtooth',a:.04,r:.15,pk:.17,lp:5,vib:0}};
function bgmWind(ctx,ins,m,t,dur,vel){
  const P=BGM_WIND[ins];const f=440*Math.pow(2,(m-69)/12);const o=ctx.createOscillator(),g=ctx.createGain();o.type=P.w;o.frequency.value=f;
  let last=o;
  if(P.lp){const lp=ctx.createBiquadFilter();lp.type='lowpass';lp.Q.value=.7;
    if(ins===4){lp.frequency.setValueAtTime(f*1.5,t);lp.frequency.linearRampToValueAtTime(f*P.lp,t+.06);lp.frequency.setTargetAtTime(f*3.5,t+.08,.2);}
    else lp.frequency.value=P.lp>50?P.lp:Math.min(8000,f*P.lp);
    o.connect(lp);last=lp;}
  last.connect(g);g.connect(_bgm.master);
  const stop=t+dur+P.r+.05;
  if(P.vib){const l=ctx.createOscillator(),lg=ctx.createGain();l.frequency.value=5.2;lg.gain.setValueAtTime(0,t);lg.gain.linearRampToValueAtTime(f*P.vib,t+Math.min(.3,dur));l.connect(lg);lg.connect(o.frequency);l.start(t);l.stop(stop);}
  const pk=P.pk*vel,e=t+Math.max(P.a,dur);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+P.a);g.gain.setValueAtTime(pk,e);g.gain.linearRampToValueAtTime(0,e+P.r);
  o.start(t);o.stop(stop);
}
// 小太鼓：雑音を高い音域だけ通して短く
let _bgmNoise=null;
function bgmSnare(ctx,t,vel){
  if(!_bgmNoise){const n=Math.floor(ctx.sampleRate*.25);_bgmNoise=ctx.createBuffer(1,n,ctx.sampleRate);const d=_bgmNoise.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;}
  const s=ctx.createBufferSource(),hp=ctx.createBiquadFilter(),g=ctx.createGain();s.buffer=_bgmNoise;hp.type='highpass';hp.frequency.value=1500;
  s.connect(hp);hp.connect(g);g.connect(_bgm.master);
  g.gain.setValueAtTime(.32*vel,t);g.gain.setTargetAtTime(0,t+.005,.03);s.start(t);s.stop(t+.16);
}
// 小さな弾み（受け取った場所の印）
function fxBump(el){if(!el||lowMotion())return;el.classList.remove('fxb');void el.offsetWidth;el.classList.add('fxb');setTimeout(()=>el.classList.remove('fxb'),450);}

// ---------- 手触り：成果が出たその場所で、0.6秒以内の動きと「+金額」「+%」を見せる ----------
// 決まり：小窓は出さない／同時に6つまで／自動で起きることは種類ごとに1.5秒に1回にまとめる／放置中・砂時計では出さない／
//         「動きを減らす」では動きをやめて数字だけ（CSS の html.lowmo）
let _fxN=0;const _fxAcc={},_fxT={};
function fxOff(){return _offlineRunning||(typeof _hgRun!=='undefined'&&_hgRun)||!_titleDone||document.hidden;}
function fxRect(el){if(!el||!el.getClientRects().length)return null;const r=el.getBoundingClientRect();return r.width||r.height?r:null;}
function fxFloat(text,x,y,cls){
  if(_fxN>=V52.FX_MAX)return null;
  const s=document.createElement('span');s.className='fxf'+(cls?' '+cls:'');s.textContent=text;
  s.style.left=Math.round(Math.max(8,Math.min(innerWidth-8,x)))+'px';s.style.top=Math.round(y)+'px';
  document.body.appendChild(s);_fxN++;
  setTimeout(()=>{s.remove();_fxN--;},V52.FX_MS+80);return s;
}
function fxAt(el,text,cls,dy){const r=fxRect(el);if(!r)return null;return fxFloat(text,r.left+r.width/2,r.top+(dy||0),cls);}
function fxGlow(el){if(!el||lowMotion())return;el.classList.remove('fxgl');void el.offsetWidth;el.classList.add('fxgl');setTimeout(()=>el.classList.remove('fxgl'),V52.FX_MS);}
function fxPill(tab,text){const b=document.querySelector(`#nav .nb[data-tab="${tab}"]`);if(!b||curTabId()===tab)return;fxAt(b,text,'pill',-6);fxBump(b);}
// 所持金への硬貨（3〜5枚）
function fxCoins(fromEl,n){
  if(lowMotion())return;const a=fxRect(fromEl),b=fxRect($('hc'));if(!a||!b)return;
  for(let i=0;i<n&&_fxN<V52.FX_MAX;i++){const c=document.createElement('span');c.className='fxcoin';c.style.left=(a.left+a.width/2-6+(i-n/2)*8)+'px';c.style.top=(a.top+a.height/2-6)+'px';document.body.appendChild(c);_fxN++;
    const dx=b.left+b.width/2-(a.left+a.width/2),dy=b.top+b.height/2-(a.top+a.height/2);
    try{c.animate([{transform:'translate(0,0)',opacity:1},{transform:`translate(${dx*0.4}px,${dy*0.4-30}px)`,opacity:1,offset:.45},{transform:`translate(${dx}px,${dy}px) scale(.6)`,opacity:.3}],{duration:V52.FX_MS-60,delay:i*40,easing:'ease-in'});}catch(e){}
    setTimeout(()=>{c.remove();_fxN--;},V52.FX_MS+i*40);}
}
// 自動で起きたことを種類ごとにまとめる
function fxAuto(kind,v,show){_fxAcc[kind]=(_fxAcc[kind]||0)+v;if(_fxT[kind])return;_fxT[kind]=setTimeout(()=>{const t=_fxAcc[kind];_fxAcc[kind]=0;_fxT[kind]=null;if(t>0&&!fxOff())try{show(t);}catch(e){}},V52.FX_COALESCE);}
function fxCash(v){const h=$('hc');if(!h)return;fxAt(h,'+'+fmt(v),'g',20);fxGlow(h);}
// 設備の Lv アップとボトルネックの解消
function fxProdSnap(){const f=prodFlows();return {bn:f.bottleneck,nm:f.newmake,cap:f.cap.slice(),bph:botRate(),slots:whSlots()};}
function fxUpg(id,s0){
  if(fxOff()||!s0)return;
  setTimeout(()=>{try{
    const f=prodFlows();const i=STAGES.findIndex(st=>st.fac===id);const row=$('fac_'+id);const btn=row&&row.querySelector('[data-act="facUp"],[data-act="brOpen"]');
    let t='';if(i>=0&&s0.cap[i]>0)t='+'+Math.round((f.cap[i]/s0.cap[i]-1)*100)+'%';else if(i>=0&&f.cap[i]>0)t='稼働';
    else if(id==='bottling'&&s0.bph>0)t='+'+Math.round((botRate()/s0.bph-1)*100)+'%';else if(id==='maturation'&&whSlots()>s0.slots)t='+'+(whSlots()-s0.slots)+'樽';
    if(t)fxAt(btn||row,t,'gold',-8);fxGlow(row);
    if(f.bottleneck!==s0.bn&&f.newmake>s0.nm*1.001){
      const nr=f.bottleneck>=0?$('fac_'+STAGES[f.bottleneck].fac):null;fxGlow(nr);
      const pct=s0.nm>0?Math.round((f.newmake/s0.nm-1)*100):0;if(pct>0)fxAt($('tankBox'),'新酒 +'+pct+'%/時','g',-4);
      document.querySelectorAll('#lineView .pflow.run').forEach(e=>{e.classList.add('fxfast');setTimeout(()=>e.classList.remove('fxfast'),V52.FX_MS*2);});
      if(f.bottleneck>=0)toast('⚙️ '+facName(STAGES[f.bottleneck].fac)+'がいちばん遅い工程になりました'+(pct>0?'（新酒 +'+pct+'%）':''),3000);
    }}catch(e){}},60);
}
// 樽詰め：棚に樽が落ちて弾む（寝かせるを開いているときだけ）
function fxFill(lot,auto){
  if(fxOff())return;
  if(curTabId()==='tcel'){setTimeout(()=>{const c=document.querySelector(`#wScene .wcask[data-id="${lot.id}"]`);if(c&&!lowMotion()){c.classList.add('fxdrop');setTimeout(()=>c.classList.remove('fxdrop'),V52.FX_MS);}},120);}
  // v5.9.2 ほかのタブでの「+n樽」（寝かせるのアイコン）はやめた（自動の樽詰めのたびに出てうるさいため）
}
// 瓶詰めの完了：瓶詰めの欄が光り、在庫の数に「+n本」／ほかのタブなら売るに「+n本」
function fxBottled(n){
  if(fxOff())return;
  fxAuto('btl',n,t=>{if(curTabId()==='tsale'){fxGlow($('fac_bottling'));fxAt($('stockRow'),'+'+fmtN(t)+'本','g',4);const p=document.querySelector('#bqBox .pic.pxt');fxBump(p);}else fxPill('tsale','+'+fmtN(t)+'本');});
}
// 売却：自分で売ったときだけ、売った場所から所持金へ硬貨と「+金額」
function fxSale(v,manual,fromEl){
  if(fxOff()||!(v>0))return;
  if(manual){fxCoins(fromEl||$('stockRow')||$('bb'),4);fxCash(v);}
  // v5.9.2 自動直販・瓶で売るの「+金額」（資金欄）はやめた（ほぼ毎秒出てうるさいため）。自分で売ったときだけ出す
}
// 納品：注文カードに「納品済」の印を押して右へ流す。「+金額」「評判 +n」
function fxDeliver(o,cash,rep){
  if(fxOff())return;
  const card=document.querySelector(`#orderBoard .oc2[data-id="${o.id}"]`);const r=fxRect(card);
  if(r&&!lowMotion()&&_fxN<V52.FX_MAX){const g=document.createElement('div');g.className='fxstamp';g.style.left=r.left+'px';g.style.top=r.top+'px';g.style.width=r.width+'px';g.style.height=r.height+'px';g.innerHTML='<span>納品済</span>';document.body.appendChild(g);_fxN++;setTimeout(()=>{g.remove();_fxN--;},V52.FX_MS+60);}
  fxCash(cash);if(rep>0)fxAt($('repVal'),'評判 +'+(Math.round(rep*10)/10),'gold',14);
}

// ---------- data-act ----------
function extAct52(act,b,id){
  switch(act){
    case 'ordCancel': ordCancelAsk(id); return true;
  }
  return false;
}
TIPS.push({id:'dwarf',cat:'成長',t:'樽の小人',b:'樽を30回タップして試飲会を開くたびに、20%の確率で小人が来て熟成の砂時計を1個置いていきます。試飲会は1日5回までなので、小人の砂時計も1日5個までです（0時に戻ります）。来たときはトーストでお知らせします。'});
TIPS.push({id:'cancel',cat:'売る',t:'予約注文の取り消し',b:'受注した予約注文は、注文の小窓の「取り消す」で取り消せます。評判と取引先の関係は期限切れと同じだけ下がり、報酬の見込みの10%を違約金として払います。予約の枠と注文ボードの枠はすぐ空きます。瓶詰め中の分は在庫に入ります。'});
TIPS.push({id:'bgm',cat:'成長',t:'BGM',b:'クラシックは、作曲家の没後70年を過ぎた曲を、このゲームの中で音を合成して演奏しています（簡略な編曲。録音は使っていません）。曲：バッハ「平均律第1巻 第1番 プレリュード」、ベートーヴェン「歓喜の歌」、サティ「ジムノペディ第1番」、パッヘルベル「カノン」、ベートーヴェン「エリーゼのために」、ラヴェル「ボレロ」。6曲をランダムな順に1回ずつ流し、1曲は約1〜2分です。同じ曲でも毎回ちがう変奏の組み合わせになります。ケルトは、アイルランドの伝承曲と、ターロック・オキャロラン（1670〜1738）の曲を、同じように音を合成して演奏しています（旋律は古い曲集の譜から写し、伴奏と編曲はこのゲームのもの）。曲：「ドラウジー・マギー」（リール）、「アイリッシュ・ウォッシャーウーマン」（ジグ）、「ハーベスト・ホーム」（ホーンパイプ）、オキャロラン「シー・ベグ・シー・モー」、「スター・オブ・ザ・カウンティ・ダウン」。楽器はハープ・フィドル・ティンホイッスル・バウロン（枠太鼓）などで、毎回ちがう組み合わせになります。⚙️でクラシック・ケルト・なしを切り替えられます。'});
