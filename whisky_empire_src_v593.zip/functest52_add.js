  // ================= v5.2 第1回 追加テスト =================
  // ---------- #143 樽の小人：300回ごとに抽選・外れ3回で次は必ず・1日6個・日付で戻る・99個のときは受け取らない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); switchTab('td');
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off; const rr = Math.random; let rv = 0.99; Math.random = () => rv;
      const o = {}; G.hg = { n: 0, got: 0, used: 0 }; hgDay(); G.tapHg = { n: 0, miss: 0 };
      for (let i = 0; i < 299; i++) tap(); o.before = [G.tapHg.n, G.hg.n, tapHgLeft()];
      tap(); o.miss1 = [G.tapHg.n, G.tapHg.miss, G.hg.n, !!document.getElementById('dwarf')];
      for (let i = 0; i < 600; i++) tap(); o.miss3 = [G.tapHg.miss, G.hg.n];
      for (let i = 0; i < 300; i++) tap(); o.pity = [G.tapHg.miss, G.hg.n, G.hg.src.tap, document.querySelector('#dwarf .dwb') ? document.querySelector('#dwarf .dwb').textContent : ''];
      rv = 0; for (let i = 0; i < 300 * 6; i++) tap(); o.cap = [G.hg.n, G.hg.src.tap, document.getElementById('tgTxt').textContent.includes('また明日')];
      const n6 = G.hg.n; for (let i = 0; i < 600; i++) tap(); o.capped = G.hg.n === n6;
      off = 24 * 3600000; G.ls = Date.now(); hgDay(); o.day = [G.hg.src.tap, tapHgCapped()];
      G.hg.n = V47.HG_MAX; G.tapHg.n = 299; tap(); o.full = [G.hg.n, G.hg.src.tap];
      Math.random = rr; Date.now = rn;
      o.k = [V52.TAP_N, V52.TAP_P, V52.TAP_PITY, V51.HG.tap.cap];
      return o;
    });
    const ok = r.before.join() === '299,0,1' && r.miss1[0] === 0 && r.miss1[1] === 1 && r.miss1[2] === 0 && r.miss1[3] && r.miss3.join() === '3,0' && r.pity[0] === 0 && r.pity[1] === 1 && r.pity[2] === 1 && r.pity[3].includes('砂時計') && r.cap.join() === '6,6,true' && r.capped && r.day.join() === '0,false' && r.full.join() === '99,0';
    rec(143, '樽の小人：300回ごとに抽選（30%）・外れが3回続いたら次は必ず・1日6個で止まり「また明日」・日付が替わると戻る・砂時計99個のときは受け取らない', ok, JSON.stringify(r));
    if (errors.length) rec('E93', '小人テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #144 受注した予約注文の取り消し：評判・関係は期限切れと同じ・違約金は見込みの10%・枠が空く・瓶詰め中の瓶は在庫へ・所持金不足では取り消せない ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM();
      const o = {}; const pid = G.uw[0];
      const mk = acc => { const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = pid; a.minAge = 3; a.qty = 40; a.rq = 40; a.reserve = true; a.accepted = acc; a.dueAt = Date.now() + 36e5 * 40; G.orders.push(a); return a; };
      const a = mk(true); const b = mk(false);
      o.noAcc = ordCancel(b.id) === false;
      openOrderInfoModal(a.id); const btn = document.querySelector('#mc2 [data-act="ordCancel"]'); o.btn = !!btn; btn.click(); await new Promise(r => setTimeout(r, 30));
      o.conf = document.getElementById('confirmDlg').classList.contains('on') && document.getElementById('confirmMsg').textContent.includes('違約金'); hideConfirm(); closeM();
      const k = ordCancelCost(a); o.k = k; o.feeOk = Math.abs(k.fee - Math.round(ordEstAny(a) * 0.1)) < 1 && Math.abs(k.rep - ordRep(a) * 0.5) < 1e-9;
      G.bq.push({ id: 'q_t', pid, n: 10, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: a.id, c: 0 });
      const cash0 = G.cash, rep0 = G.reputation, rel0 = (G.rel.local || { done: 0 }).done, can0 = G.stats.cancel || 0, oth0 = acctLive().sga.oth || 0;
      G.cash = k.fee - 1; o.poor = ordCancel(a.id) === false && G.orders.includes(a); G.cash = cash0;
      o.done = ordCancel(a.id) && !G.orders.includes(a);
      o.d = { cash: +(cash0 - G.cash).toFixed(2), rep: +(rep0 - G.reputation).toFixed(3), rel: rel0 - G.rel.local.done, cancel: G.stats.cancel - can0, oth: +((acctLive().sga.oth || 0) - oth0).toFixed(2) };
      o.bq = G.bq.find(q => q.id === 'q_t').oid === null;
      return o;
    });
    const ok = r.noAcc && r.btn && r.conf && r.feeOk && r.k.rel === 3 && r.poor && r.done && Math.abs(r.d.cash - r.k.fee) < 1 && r.d.rep > 0 && r.d.rel === 3 && r.d.cancel === 1 && Math.abs(r.d.oth - r.k.fee) < 1 && r.bq;
    rec(144, '受注した予約注文の取り消し：評判（期限切れと同じ）・関係−3・違約金は報酬の見込みの10%（販管費のその他）・注文は消えて枠が空く・瓶詰め中の分は在庫へ・所持金不足では取り消せない・受注前は対象外', ok, JSON.stringify(r));
    if (errors.length) rec('E94', '取り消しテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #145 BGM：クラシック5曲のデータ・順に演奏・同時に鳴る音は16まで・環境音楽となしに切り替わる ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      o.pieces = BGM_PIECES.map((p, i) => { const n = bgmLoad(i); const bad = n.filter(x => !(x[0] >= 0 && x[1] > 0 && x[2] >= 24 && x[2] <= 100 && x[3] > 0 && x[3] <= 1)).length; const sorted = n.every((x, j) => j === 0 || n[j - 1][0] <= x[0]); return { id: p.id, n: n.length, bad, sorted, end: Math.round(Math.max(...n.map(x => x[0] + x[1]))) }; });
      o.def = OPT_DEFAULT.bgmMode;
      const ctxA = _getCtx(); o.audio = !!ctxA;
      opt().bgm = 0.4; opt().bgmMode = 'classic'; applyOpt(); await new Promise(r => setTimeout(r, 900));
      o.classic = [_bgm.mode, !!_bgmc.timer, _bgmc.ptr > 0];
      // 曲の終わりまで進めると次の曲へ
      const i0 = _bgmc.i; _bgmc.ptr = _bgmc.notes.length; _bgmc.t0 = (ctxA ? ctxA.currentTime : 0) - 1e4; bgmClassicTick(); o.next = _bgmc.i === (i0 + 1) % BGM_PIECES.length && _bgmc.ptr === 0;
      let maxV = 0; for (let k = 0; k < 10; k++) { _bgmc.t0 -= 0.5; bgmClassicTick(); maxV = Math.max(maxV, _bgmc.voices.length); } o.poly = maxV;
      opt().bgmMode = 'ambient'; applyOpt(); o.ambient = [_bgm.mode, !!_bgm.timer, !_bgmc.timer];
      opt().bgmMode = 'off'; applyOpt(); o.off = !_bgm.timer && !_bgmc.timer && !_bgm.master;
      opt().bgmMode = 'classic'; applyOpt(); switchTab('tp'); rall(); await new Promise(r => setTimeout(r, 50));
      o.ui = !!document.querySelector('[data-act="optSet"][data-k="bgmMode"][data-v="classic"]');
      bgmStop(); return o;
    });
    const ok = r.pieces.length === 5 && r.pieces.every(p => p.n > 100 && p.bad === 0 && p.sorted && p.end > 25) && r.def === 'classic' && (!r.audio || (r.classic.join() === 'classic,true,true' && r.next && r.poly <= 16 && r.ambient.join() === 'ambient,true,true' && r.off)) && r.ui;
    rec(145, 'BGM：クラシック5曲（バッハ・パッヘルベル・ベートーヴェン2曲・サティ）のデータが正しい・初期値はクラシック・順に演奏し曲が終わると次へ・同時に鳴る音は16まで・⚙️で環境音楽となしに切り替わる', ok, JSON.stringify(r));
    if (errors.length) rec('E95', 'BGMテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #146 v5.1（schema15）からの移行：小人の記録・取り消しの件数・BGM はクラシック・移行前をバックアップ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const old = JSON.parse(JSON.stringify(G)); old.ver = 15; delete old.tapHg; delete old.stats.cancel; old.opt.bgmMode = undefined; delete old.hg.src.tap;
      const raw = JSON.stringify(old); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, tap: JSON.stringify(m.tapHg), cancel: m.stats.cancel, bgm: m.opt.bgmMode, src: m.hg.src.tap };
      const key = storageKey(); const bk = 'we_v4_bak15:' + (LIFF_USER.id || 'guest'); localStorage.setItem(key, raw); localStorage.removeItem(bk); load(); o.bk = localStorage.getItem(bk) === raw; o.loaded = G.ver;
      return o;
    });
    const ok = r.ver === SCHEMA && r.tap === '{"n":0,"miss":0}' && r.cancel === 0 && r.bgm === 'classic' && r.src === 0 && r.bk && r.loaded === SCHEMA;
    rec(146, 'v5.1（schema15）からの移行：小人の記録・予約の取り消しの件数を用意・BGM はクラシック・移行前をバックアップ', ok, JSON.stringify(r));
    if (errors.length) rec('E96', '移行（v16）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.2 第2回 追加テスト =================
  // ---------- #147 手触り：Lvアップ・ボトルネック解消・樽詰め・瓶詰め・売却・納品の動きと「+金額」「+%」・自動はまとめる・同時に6つまで・放置と砂時計では出さない・動きを減らす設定 ----------
  {
    const { page, errors, ctx } = await page43(844, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose();
      const eb = document.getElementById('eventBanner'); if (eb) eb.style.display = 'none';
      const W = ms => new Promise(r => setTimeout(r, ms)); const ft = () => [...document.querySelectorAll('.fxf')].map(e => e.textContent);
      const clear = async () => { await W(800); };
      G.cash = 1e18; Object.keys(FAC_BRANCH).forEach(k => { if (G.branch[k] === null || G.branch[k] === undefined) G.branch[k] = 0; }); const o = {};
      // Lv アップ（いちばん遅い工程を上げてボトルネックを動かす）
      switchTab('tb'); rall(); await W(50);
      const f0 = prodFlows(); const bnFac = STAGES[f0.bottleneck].fac; let tries = 0; while (prodFlows().bottleneck === f0.bottleneck && tries++ < 60) { upgFac(bnFac); closeM(); }
      await W(120); o.upg = ft().some(t => /^\+\d+%$/.test(t)) && !!document.querySelector('#lineView .fxgl'); o.bn = ft().some(t => t.startsWith('新酒 +')) && !!document.querySelector('#lineView .pflow.fxfast'); await clear();
      // 樽詰め：寝かせるを開いているときは棚の樽が落ちる
      switchTab('tcel'); G.tank = 1e7; G.auto.fill.on = false; rall(); await W(50); fillCask('bourbon', 'hogshead', false); rall(); await W(150);
      const nl = G.lots[G.lots.length - 1]; o.drop = !!document.querySelector(`#wScene .wcask.fxdrop[data-id="${nl.id}"]`); await clear();
      // 自動の樽詰め（ホームを開いている）→ 1.5秒後に寝かせるのタブに「+3樽」が1回
      switchTab('td'); for (let i = 0; i < 3; i++) fillCask('bourbon', 'hogshead', true); await W(V52.FX_COALESCE + 100); o.pill = ft().filter(t => t === '+3樽').length === 1; await clear();
      // 瓶詰めの完了（ホーム）→ 売るに「+n本」
      G.bq = [{ id: 'q1', pid: G.uw[0], n: 7, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: null, c: 0 }, { id: 'q2', pid: G.uw[0], n: 5, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: null, c: 0 }];
      botTick(36e5 * 10); await W(V52.FX_COALESCE + 100); o.btl = ft().includes('+12本'); await clear();
      // 売却（手動）：硬貨と「+金額」／自動の直販はまとめて1回
      switchTab('tsale'); rall(); await W(50); const row = G.bottles[0]; spotSell(row.id, 1); await W(80); o.coins = document.querySelectorAll('.fxcoin').length > 0 && ft().some(t => t.startsWith('+$')); await clear();
      const v1 = spotSell(G.bottles[0].id, 1, true), v2 = spotSell(G.bottles[0].id, 1, true); await W(V52.FX_COALESCE + 100); o.autoSale = ft().filter(t => t === '+' + fmt(v1 + v2)).length === 1; await clear();
      // 納品：「納品済」の印と「評判 +n」
      const a = ordGenerate({ cid: 'local' }); a.kind = 'product'; a.pid = G.bottles[0].pid; a.minAge = 0; a.qty = 1; a.rq = 1; a.reserve = false; a.dueAt = Date.now() + 1e8; G.orders.unshift(a); _ui.sellTab = 'ord'; rall(); await W(80);
      const card = !!document.querySelector(`#orderBoard .oc2[data-id="${a.id}"]`); ordDeliver(a.id); await W(60); o.stamp = card && !!document.querySelector('.fxstamp') && ft().some(t => t.startsWith('評判 +')); await clear();
      // 同時に6つまで
      for (let i = 0; i < 20; i++) fxFloat('x' + i, 100, 300); o.max = document.querySelectorAll('.fxf').length; await clear();
      // 砂時計で進めた分（瓶詰め・直販）は出さない
      G.bq = [{ id: 'q3', pid: G.uw[0], n: 9, done: 0, moved: 0, age: 5, q: 1, fl: { ...BASE_FLAVOR }, blend: null, oid: null, c: 0 }]; G.hg.n = 5; G.hg.useDay = 0; G.ls = Date.now(); hgUse(1); if (_offlineGate) closeOfflineModal(); await W(V52.FX_COALESCE + 100); o.hgQuiet = document.querySelectorAll('.fxf,.fxcoin,.fxstamp').length === 0; await clear();
      // 動きを減らす：硬貨・印・落下なし。数字は出る（透明度だけで消える）
      opt().motion = 'low'; applyOpt(); spotSell(G.bottles[0].id, 1); await W(60); o.low = document.querySelectorAll('.fxcoin').length === 0 && ft().some(t => t.startsWith('+$')) && getComputedStyle(document.querySelector('.fxf')).animationName === 'fxFade'; opt().motion = 'std'; applyOpt();
      await clear(); o.left = _fxN;
      return o;
    });
    const ok = r.upg && r.bn && r.drop && r.pill && r.btl && r.coins && r.autoSale && r.stamp && r.max <= 6 && r.hgQuiet && r.low && r.left === 0;
    rec(147, '手触り：Lvアップで「+%」と行の光・ボトルネック解消で「新酒 +%」と流れの加速・樽詰めで棚の樽が落ちる・自動の樽詰め／瓶詰め／直販は1.5秒にまとめて1回・手動の売却で硬貨と「+金額」・納品で「納品済」と「評判 +」・同時に6つまで・砂時計の分は出さない・動きを減らす設定では動きなし', ok, JSON.stringify(r));
    if (errors.length) rec('E97', '手触りテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
