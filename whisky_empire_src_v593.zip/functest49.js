// 詳細設計書 第10章 テスト観点の自動確認
const { chromium } = require('playwright');
const path = require('path');
const SCHEMA = Number((require('fs').readFileSync('n1_constants.js', 'utf8').match(/SCHEMA_VERSION: (\d+)/) || [])[1]);
const FILE = 'file://' + path.resolve('whisky_empire.html');

async function newPage(browser, preload, keepTut) {
  const ctx = await browser.newContext({ viewport: { width: 360, height: 740 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  if (preload) await page.addInitScript(preload);
  await page.goto(FILE);
  await page.waitForTimeout(1200);
  await page.evaluate(() => { _mktOff = true; if (typeof titleStart === 'function') titleStart(false); });
  await page.waitForTimeout(800);
  if (!keepTut) await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose(); });
  return { page, errors, ctx };
}

(async () => {
  const browser = await chromium.launch();
  const results = [];
  const rec = (id, name, ok, detail) => { results.push({ id, name, ok, detail }); };

  // ---------- 新規ゲームでの計算テスト ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: detail === undefined ? '' : String(detail) });
      const near = (a, b, eps) => Math.abs(a - b) <= (eps || 1e-6) * Math.max(1, Math.abs(b));
      if (_offlineGate) closeOfflineModal();
      closeM();
      if (G.randomEvent) G.randomEvent.active = null; // 偶発イベントの倍率を外す
      // #1 製麦Lv1のみ
      G.fac.malting.l = 1; prodInvalidate();
      let f = prodFlows();
      T(1, '製麦Lv1のみ: newmake0・ti=300×0.9(既定の大麦)×$6=$1,620/時', f.newmake === 0 && near(ti(), 1620), 'newmake=' + f.newmake + ' ti=' + ti());
      // #2 4工程Lv3
      ['malting', 'mashing', 'fermentation', 'distillation'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 3; });
      prodInvalidate(); f = prodFlows();
      const capOk = near(f.cap[0], 388.8) && near(f.cap[1], 374.4) && near(f.cap[2], 331.2) && near(f.cap[3], 288);
      T(2, '4工程Lv3: cap・newmake・律速・余剰', capOk && near(f.newmake, 288) && f.bottleneck === 3 && near(f.s[0], 14.4) && near(f.s[1], 43.2) && near(f.s[2], 43.2), JSON.stringify({ cap: f.cap, nm: f.newmake, bn: f.bottleneck, s: f.s }));
      // #3 強化後にキャッシュ破棄
      G.cash = 1e9; const before = prodFlows().cap[3];
      upgFac('distillation');
      T(3, '強化でキャッシュ破棄・能力上昇', prodFlows().cap[3] > before && G.fac.distillation.l === 4, before + '→' + prodFlows().cap[3]);
      // #4 タンク溢れ
      G.tank = tankCap() - 1; const te0 = G.te;
      prodTick(3600000);
      T(4, 'タンク溢れ分を外販・tank=tankCap', near(G.tank, tankCap()) && G.te > te0, 'tank=' + G.tank + ' cap=' + tankCap());
      // #5 樽詰め拒否
      const n0 = G.lots.length;
      G.tank = 0; const r1 = fillCask('bourbon', 'hogshead', true);
      G.tank = 1000; const cash = G.cash; G.cash = 0; const r2 = fillCask('bourbon', 'hogshead', true); G.cash = cash;
      const slots = whSlots(); const saved = G.lots.slice();
      while (G.lots.length < slots) G.lots.push(makeLot(caskType('bourbon'), caskSize('hogshead')));
      const r3 = fillCask('bourbon', 'hogshead', true);
      G.lots = saved;
      T(5, '樽詰めの拒否（タンク不足・資金不足・満杯）', !r1 && !r2 && !r3 && G.lots.length === n0, [r1, r2, r3].join(','));
      // #6 #7 熟成
      const hog = makeLot(caskType('bourbon'), caskSize('hogshead')); lotAdvance(hog, 86400000);
      T(6, 'ホグスヘッド1日: age+1.0・L×0.984', near(hog.age, 1) && near(hog.L, 250 * 0.984), hog.age + ' ' + hog.L);
      const qc = makeLot(caskType('bourbon'), caskSize('quarter')); lotAdvance(qc, 86400000);
      T(7, 'クォーター1日: age+2.0・L×0.975', near(qc.age, 2) && near(qc.L, 50 * 0.975), qc.age + ' ' + qc.L);
      // #8 風味（シェリー樽）
      const sh = makeLot(caskType('sherry'), caskSize('hogshead')); const b0 = sh.fl0.fruity;
      sh.age = 6; const f6 = lotFlavor(sh).fruity - b0; sh.age = 12; const f12 = lotFlavor(sh).fruity - b0; sh.age = 20; const f20 = lotFlavor(sh).fruity - b0;
      T(8, 'シェリー樽の加算 6/12/20年 = 50%/100%/100%', near(f6, 10) && near(f12, 20) && near(f20, 20), [f6, f12, f20].join('/'));
      // #9 混ぜて瓶詰め
      G.uw = ['glenlivid']; G.lots = [];
      const a = makeLot(caskType('bourbon'), caskSize('hogshead')); a.age = 8.5; a.q = 1.0; a.L = 70;
      const b = makeLot(caskType('sherry'), caskSize('hogshead')); b.age = 10.2; b.q = 1.1; b.L = 70;
      G.lots.push(a, b);
      const pv = botPreview('glenlivid', 200, 'young');
      T(9, '8年+10年を混ぜる: 表記8年・品質は量で加重平均', pv.ok && pv.age === 8 && near(pv.q, 1.05, 1e-3), JSON.stringify({ ok: pv.ok, age: pv.age, q: pv.q, reason: pv.reason }));
      // #10 バーボン銘柄はシェリー樽不可
      G.uw.push('jack_d');
      const onlySherry = [b];
      G.lots = onlySherry;
      T(10, 'バーボン銘柄はシェリー樽の原酒を使えない', lotsFor('jack_d').length === 0, lotsFor('jack_d').length);
      // #11 ★3 一致度
      G.uw.push('macallen');
      const lo = makeLot(caskType('bourbon'), caskSize('hogshead')); lo.age = 20; lo.fl0 = { smoky: 100, fruity: 0, spicy: 0, sweet: 0, floral: 100 };
      G.lots = [lo];
      T(11, '★3銘柄は一致度0.5未満を除外', lotsFor('macallen').length === 0 && flavorMatch(lotFlavor(lo), productSpec('macallen').target) < 0.5, flavorMatch(lotFlavor(lo), productSpec('macallen').target).toFixed(3));
      // #12 単価
      const t = productSpec('glenlivid').target;
      // 一致度0.5になる風味: 平均差17.5
      const fl = {}; FL_KEYS.forEach(k => fl[k] = t[k]); fl.floral = t.floral - 87.5;
      const m = flavorMatch(fl, t); const u = priceUnit('glenlivid', 8, 1.0, fl);
      const expect = 100 * 8 / 3 * 1.0 * (0.7 + 0.6 * m) * distMult() * saleMult() * repMult();
      T(12, 'Glenvivid 8年・q1・一致0.5 ≈ $267', near(m, 0.5, 1e-3) && near(u, 266.67, 1e-3) && near(u, expect), 'm=' + m.toFixed(3) + ' unit=' + u.toFixed(2));
      // #13 注文の到着と上限
      G.orders = []; G.orderClock = Date.now() - 1;
      const n1 = ordSpawnTick(Date.now());
      G.orderClock = Date.now() - BALANCE.ORDER_INTERVAL_MS * 10;
      ordSpawnTick(Date.now());
      T(13, '90分ごと1件・ボード上限で停止', n1 === 1 && G.orders.length === boardSize() && G.orderClock > Date.now(), 'n1=' + n1 + ' len=' + G.orders.length + '/' + boardSize());
      // #14 在庫不足で納品拒否
      G.bottles = [];
      const o14 = { id: 'o_t14', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o14]; const c14 = G.cash;
      const d14 = ordDeliver('o_t14');
      T(14, '在庫不足の納品は拒否・状態不変', !d14 && G.orders.length === 1 && G.cash === c14, d14);
      // 正常納品
      invAdd('glenlivid', 12, 9, 1.0, t);
      const rep0 = G.reputation, sh0 = G.stats.shipped;
      const d14b = ordDeliver('o_t14');
      T('14b', '在庫十分なら納品: 資金・評判・出荷・関係', d14b && G.orders.length === 0 && G.reputation > rep0 && G.stats.shipped === sh0 + 10 && G.rel.local.done >= 1 && invTotal('glenlivid') === 2, 'rep ' + rep0 + '→' + G.reputation);
      // #15 予約の期限切れ
      const rr = G.reputation; const dn = G.rel.local.done;
      G.orders = [
        { id: 'o_r1', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: true, createdAt: 0, dueAt: Date.now() - 1 },
        { id: 'o_r2', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 10, mult: 1.3, reserve: true, accepted: false, createdAt: 0, dueAt: Date.now() - 1 },
      ];
      const ex = ordExpireTick(Date.now());
      T(15, '受注済み予約の期限切れだけ罰', ex.failed === 1 && ex.expired === 1 && G.reputation < rr && G.rel.local.done === Math.max(0, dn - 3), JSON.stringify(ex) + ' rep ' + rr + '→' + G.reputation);
      // #16 コレクター
      const y17 = makeLot(caskType('bourbon'), caskSize('hogshead')); y17.age = 17.5;
      const y19 = makeLot(caskType('bourbon'), caskSize('hogshead')); y19.age = 19;
      G.lots = [y17, y19];
      const oc = { id: 'o_c', cid: 'collector', kind: 'cask', minAge: 18, qty: 1, mult: 3, reserve: false, accepted: false, createdAt: 0, dueAt: Date.now() + 3600000 };
      const mc = ordMatch(oc);
      T(16, 'コレクター注文は18年未満の樽を選べない', mc.lots.length === 1 && mc.lots[0] === y19 && ordMatch(oc, y17.id).ok === false, mc.lots.length);
      // #17 分岐未選択
      G.fac.malting.l = 10; G.branch.malting = null; G.dl = 2;
      const pend = brPending('malting'); const lvb = G.fac.malting.l;
      upgFac('malting'); closeM();
      const blocked = G.fac.malting.l === lvb;
      brChoose('malting', 1);
      T(17, 'Lv10で分岐未選択なら強化不可・選択で能力×1.2', pend && blocked && G.branch.malting === 1 && near(stageCap(0), 300 * Math.pow(1.2, 9) * 1.2 * rcpMods().cap[0]), 'pend=' + pend + ' blocked=' + blocked);
      G.dl = 1;
      // #18 Tier条件
      G.stats.shipped = 0; G.reputation = 0; G.lots = []; G.cash = 0;
      const s0 = tierReqStatus(2).filter(o => o.ok).length;
      G.stats.shipped = 300; G.reputation = 15;
      for (let i = 0; i < 5; i++) { const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 3.2; G.lots.push(l); }
      const s1 = tierReqStatus(2).filter(o => o.ok).length; const can1 = canUpgDist();
      G.cash = tierCost(2) + 10;
      const can2 = canUpgDist();
      G.bottles = []; invAdd('glenlivid', 5, 8, 1, t);
      doUpgDist(tierCost(2), 2);
      T(18, 'Tier条件が順にok・全達成で昇格・在庫は残る', s0 === 0 && s1 === 3 && !can1 && can2 && G.dl === 2 && G.lots.length === 5 && invTotal('glenlivid') === 5, [s0, s1, can1, can2, G.dl].join(','));
      // #19 ブレンド
      G.dl = 3; G.lots = [];
      const l1 = makeLot(caskType('sherry'), caskSize('hogshead')); l1.age = 10;
      const l2 = makeLot(caskType('bourbon'), caskSize('hogshead')); l2.age = 8;
      G.lots.push(l1, l2);
      const bh0 = (G.blendHistory || []).length; const L0 = l1.L + l2.L; const bq0 = G.bq.length;
      const ok19 = blendStart('classic_blend', [{ lotId: l1.id, L: 100 }, { lotId: l2.id, L: 100 }]);
      const L1 = G.lots.reduce((a, l) => a + l.L, 0);
      chkT();
      T(19, 'ブレンドで原酒が減り履歴記録・称号「初仕込み」', ok19 && Math.abs(L0 - L1 - 200) < 1e-6 && G.blendHistory.length === bh0 + 1 && G.bq.length === bq0 + 1 && G.tl.includes('t19'), 'ok=' + ok19 + ' used=' + (L0 - L1));
      // #20 品評会（期待値）
      const row = { pid: 'glenlivid', age: 8, q: 1.05, fl: {} };
      FL_KEYS.forEach(k => row.fl[k] = t[k]); row.fl.floral = t.floral - 35; // 一致度0.8
      G.reputation = 0; G.prestige.skills = {};
      const e = compExpected(row);
      T(20, '地域品評会: 8年・q1.05・一致0.8 ⇒ 0.656点（合格0.6超）', Math.abs(e - 0.6556) < 0.001, e.toFixed(4));
      // 実出品
      G.bottles = []; invAdd('glenlivid', 10, 12, 1.2, t); G.cash = 1e7; G.compCooldowns = {};
      const res = enterComp('local_award', G.bottles[0].id);
      T('20b', '出品で6本消費・結果と講評3件・クールダウン1日', res && invTotal('glenlivid') === 4 && res.judges.length === 3 && Math.abs((G.compCooldowns.local_award - Date.now()) - 86400000) < 5000, res ? ('win=' + res.win + ' S=' + res.S.toFixed(3)) : 'null');
      closeM();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E1', '計算テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- オフライン ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const setup = () => {
        if (_offlineGate) closeOfflineModal(); closeM();
        ['malting', 'mashing', 'fermentation', 'distillation', 'maturation', 'bottling'].forEach(id => { G.fac[id].p = true; G.fac[id].l = 5; });
        G.lots = []; G.tank = 0; G.cash = 1e7; G.auto.fill.on = false; prodInvalidate();
      };
      // #21 10時間
      setup();
      const lot = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot);
      const nm = prodFlows().newmake;
      G.ls = Date.now() - 10 * 3600000;
      offline();
      const exp21 = 10 / 24;
      T(21, '10時間不在: 熟成10時間分・生産8時間分', Math.abs(lot.age - exp21) < 1e-3 && Math.abs(G.tank - Math.min(tankCap(), nm * 8)) < 1e-3, 'age=' + lot.age.toFixed(4) + ' tank=' + G.tank.toFixed(1) + ' nm*8=' + (nm * 8).toFixed(1));
      // #22 100時間
      setup();
      const lot2 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot2);
      G.ls = Date.now() - 100 * 3600000;
      const t0 = performance.now(); offline(); const dt = performance.now() - t0;
      T(22, '100時間不在: 熟成72時間分・1秒以内', Math.abs(lot2.age - 3) < 1e-3 && dt < 1000, 'age=' + lot2.age.toFixed(4) + ' ms=' + dt.toFixed(1));
      // #23 自動樽詰め
      setup(); G.auto.fill.on = true; G.auto.fill.cask = 'bourbon'; G.auto.fill.size = 'quarter';
      G.ls = Date.now() - 4 * 3600000;
      offline();
      const ages = G.lots.map(l => l.age).sort((a, b) => b - a);
      const f = prodFlows();
      T(23, '自動樽詰め4時間: 先に詰めた樽ほど年数が大きい', G.lots.length > 1 && ages[0] > ages[ages.length - 1] && ages[0] <= 4 / 24 * 2 + 1e-9, 'lots=' + G.lots.length + ' ages=' + ages.slice(0, 3).map(a => a.toFixed(3)).join(','));
      // #24 同時発火で1回だけ
      setup();
      const lot3 = makeLot(caskType('bourbon'), caskSize('hogshead')); G.lots.push(lot3);
      G.ls = Date.now() - 2 * 3600000;
      offline(); offline(); window.dispatchEvent(new Event('focus')); document.dispatchEvent(new Event('visibilitychange'));
      T(24, '複数経路の同時発火でも補正1回', Math.abs(lot3.age - 2 / 24) < 1e-3, 'age=' + lot3.age.toFixed(5));
      if (_offlineGate) closeOfflineModal();
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E2', 'オフラインテスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 移行 ----------
  const V6 = {
    cash: 123456789, te: 987654321, tt: 5000, dl: 3, cl: 7,
    fac: { malting: { l: 25, p: true }, mashing: { l: 22, p: true }, fermentation: { l: 20, p: true }, distillation: { l: 18, p: true }, maturation: { l: 15, p: true }, bottling: { l: 12, p: true } },
    uw: ['glenlivid', 'jameston', 'jack_d', 'johnnie_em'], cw: { glenlivid: 120, jack_d: 50 },
    am: { glenlivid: true }, inv: { glenlivid: 7, jack_d: 3 }, regions: { scotland: true }, tl: ['t1', 't9'],
    ls: Date.now() - 30 * 60000, ver: 6, dbgMul: 1,
    rawMaterials: { grain: 'optic', water: 'soft_spring', yeast: 'distillery', peat: 'unpeated' },
    casks: [{ id: 'cask_1', type: 'sherry', size: 'hogshead', whiskyId: 'glenlivid', litresFilled: 240, createdAt: Date.now() - 86400000, agingYears: 0.02, qualityMod: 1.3, sold: false },
            { id: 'cask_2', type: 'bourbon', size: 'barrel', whiskyId: 'jack_d', litresFilled: 190, createdAt: Date.now(), agingYears: 0.001, qualityMod: 0.7, sold: false }],
    channels: { active: ['dtc', 'on_trade', 'retail'], autoSellChannel: 'on_trade' },
    reputation: 42, awards: ['local_award'], compCooldowns: { local_award: Date.now() + 5 * 86400000 },
    prestige: { level: 1, bonus: 1.1, skillPoints: 1, skills: { ps_passive: 1, ps_am_slot: 1 }, legacyWhiskies: ['lw_genesis'], totalRuns: 1 },
    mg: { malting: { nextAt: 0, bonusUntil: 0, bonusMult: 1 } }, cut: {}, _cutBonus: 1, facByBrand: {}, wCd: { glenlivid: 0 },
    story: { unlocked: ['ep1'], seenNew: ['ep1'] }, daily: { date: '', missions: [], allCleared: false }, questDone: ['q_tap10']
  };
  {
    const pre = `localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(V6))});`;
    const { page, errors } = await newPage(browser, `if(!sessionStorage.getItem('x')){sessionStorage.setItem('x','1');${pre}}`, true);
    await page.waitForTimeout(600);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      const bk = localStorage.getItem('we_v4_bak6:guest');
      const mig = G.lots.filter(l => l.src === 'migrated');
      const sherry = mig.find(l => l.cask === 'sherry');
      const ok = G.ver === BALANCE.SCHEMA_VERSION && G.dl === 3 && G.cash >= 123456789 && G.fac.malting.l === 25 && G.fac.malting.p
        && mig.length === 2 && sherry && Math.abs(sherry.L - 240) < 1 && sherry.q === 1.3 && mig.find(l => l.cask === 'bourbon').q === 0.8
        && invTotal('glenlivid') === 7 && invTotal('jack_d') === 3 && G.bottles.find(b => b.pid === 'glenlivid').age === 8
        && G.rel.local.lv === 1 && G.rel.bar.lv === 1 && G.rel.retail.lv === 1 && G.rel.dutyfree.lv === 0
        && G.recipe.grain === 'optic' && G.recipeOwned.includes('optic')
        && G.prestige.skills.ps_capacity === 1 && G.prestige.skills.ps_order_slot === 1 && !G.prestige.skills.ps_passive
        && G.compCooldowns.local_award <= Date.now() + 86400000 + 1000
        && G.stats.shipped === 170 && G.stats.awardsWon === 1
        && G.lots.filter(l => l.src === 'starter').length === 3 && G.orders.length >= 1
        && !('mg' in G) && !('casks' in G) && !('inv' in G) && !('channels' in G) && !('am' in G) && !('_cutBonus' in G)
        && !!bk && JSON.parse(bk).ver === 6 && G.tl.includes('t9') && G.migratedFrom === 6;
      T('25c', 'v3移行ユーザーは更新案内を待機・自動樽詰めと自動直販はON', G.tut.q.includes('upd') && !G.tut.done.first && G.auto.fill.on && G.auto.spot.on, JSON.stringify(G.tut));
      T(25, 'v3.8.0セーブの移行（樽・在庫・チャネル・レシピ・スキル・待ち時間・バックアップ）', ok, JSON.stringify({ ver: G.ver, lots: G.lots.map(l => l.src + ':' + l.cask + ':' + l.L.toFixed(0) + ':' + l.q), inv: G.bottles.map(b => b.pid + ':' + b.n + ':' + b.age), rel: G.rel, rc: G.recipe.grain, sk: G.prestige.skills, st: G.stats, bk: !!bk }));
      const modalShown = !$('mo').classList.contains('h') && /生まれ変わり|おかえり/.test($('mc2').textContent);
      T('25b', '移行結果（またはおかえり）モーダルが出る', modalShown, $('mc2').textContent.slice(0, 30));
      // #26 再読込で不変
      save();
      const snap = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      load();
      const snap2 = JSON.stringify({ lots: G.lots.map(l => [l.id, l.cask, Math.round(l.L)]), b: G.bottles.map(r => [r.pid, r.n]), rel: G.rel, st: G.stats.shipped });
      postLoadInit();
      T(26, '移行済みデータの再読込で変化なし（初期在庫も重複しない）', snap === snap2 && G.lots.filter(l => l.src === 'starter').length === 3, snap === snap2);
      // #27 壊れたインポート
      const before = JSON.stringify(G.stats);
      importSave(); $('ioText').value = '@@@broken@@@'; ioApplyAction();
      const ok27a = JSON.stringify(G.stats) === before;
      importSave(); $('ioText').value = btoa(unescape(encodeURIComponent(JSON.stringify({ ver: 99 })))); ioApplyAction();
      const ok27b = JSON.stringify(G.stats) === before && G.ver === BALANCE.SCHEMA_VERSION;
      closeM();
      T(27, '壊れた・新しすぎるセーブのインポートは拒否', ok27a && ok27b, ok27a + ',' + ok27b);
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    await page.screenshot({ path: 'shot_migrate.png' });
    if (errors.length) rec('E3', '移行テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 削除確認・画面 ----------
  {
    const fs = require('fs');
    const src = fs.readFileSync('whisky_empire.html', 'utf8');
    const leftovers = ['G.mg', 'craft(', 'autoSellTick', 'channelMult', 'openMiniGame', 'mgModal', 'comboCount', 'COMBO_', 'comboMul', 'CRIT_CHANCE_10000', 'comboMeter', 'id="questPanel"', 'Glenvivid', 'Johnnie Emerald', 'Davalo', 'Kawasaki'].filter(w => src.includes(w));
    rec(28, '削除対象（ミニゲーム・コンボ・ティッカー・クエスト表示）がコードに残っていない', leftovers.length === 0, leftovers.join(','));
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      if (_offlineGate) closeOfflineModal(); closeM();
      const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 150));
        const el = document.getElementById(t);
        res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth });
      }
      const navWrap = [...document.querySelectorAll('#nav .nb')].some(b => b.getBoundingClientRect().height > 70);
      return { res, navWrap };
    });
    const bad = r.res.filter(x => x.over > 1 || x.doc > 1);
    rec(29, '幅360pxで横スクロールなし・ナビが折り返さない', bad.length === 0 && !r.navWrap, JSON.stringify(r));
    if (errors.length) rec('E4', '画面テスト中のエラー', false, errors.join(' | '));
  }

  // ---------- 実プレイの通し（UI操作） ----------
  {
    const { page, errors } = await newPage(browser);
    await page.evaluate(() => { if (_offlineGate) closeOfflineModal(); closeM(); });
    // 1. 売るタブで「詰めて納品」→ 瓶詰め完了 → 自動納品
    await page.click('#nav .nb[data-tab="tsale"]');
    await page.waitForTimeout(200);
    const o0 = await page.evaluate(() => { const o = G.orders.find(x => ordFulfillPlan(x).ok); return o ? { id: o.id, qty: o.qty } : null; });
    await page.click(`[data-act="ordFill"][data-id="${o0.id}"]`);
    const q = await page.evaluate(id => ({ bq: G.bq.length, oid: G.bq[0] && G.bq[0].oid, auto: G.orders.find(o => o.id === id).autoDel, card: document.getElementById('orderBoard').textContent.includes('瓶詰め中') }), o0.id);
    await page.evaluate(() => { botTick(3600000 * (Math.ceil(botQueueBottles() / botRate()) + 1)); ordAutoTick(); rall(); });
    const after = await page.evaluate(id => ({ gone: !G.orders.some(o => o.id === id), orders: G.stats.orders, cash: G.cash, shipped: G.stats.shipped }), o0.id);
    rec(30, 'UI操作: 「詰めて納品」1回で瓶詰め→完了後に自動納品', q.bq === 1 && q.oid === o0.id && q.auto && q.card && after.gone && after.orders === 1 && after.shipped === o0.qty, JSON.stringify({ o0, q, after }));
    await page.screenshot({ path: 'shot_after_deliver.png' });
    // 2. 造るタブの一覧のボタンで直接強化
    await page.evaluate(() => { G.cash = 1e6; rall(); });
    await page.click('#nav .nb[data-tab="tb"]');
    await page.click('#lineView [data-act="facUp"][data-id="malting"]');
    const mlv = await page.evaluate(() => G.fac.malting.l);
    rec('30b', 'UI操作: 生産ラインのボタン1回で強化', mlv === 1, mlv);
    await page.screenshot({ path: 'shot_make2.png', fullPage: false });
    if (errors.length) rec('E5', '通しテスト中のエラー', false, errors.join(' | '));
  }

  const TUTS_DONE_BEFORE = ['first', 'u_age', 'u_barley', 'u44', 'u45', 'u46', 'u_cel45', 'u_line43', 'u43'];
  // ================= v4.1 追加テスト =================
  // ---------- 初回チュートリアル ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    const init = await page.evaluate(() => ({ q: G.tut.q.slice(), run: _tut && _tut.id, fill: G.auto.fill.on, spot: G.auto.spot.on, ver: G.ver }));
    rec(31, '新規開始: schema11・自動樽詰め/自動直販ON・初回案内が始まる', init.ver === SCHEMA && init.fill && init.spot && init.run === 'first', JSON.stringify(init));
    const t0 = Date.now(); let taps = 0; let firstSaleTaps = null, firstSaleSec = null;
    for (let k = 0; k < 14; k++) {
      const info = await page.evaluate(() => _tut ? { do: !!(tutStep() && tutStep().do) } : null);
      if (!info) break;
      await page.waitForTimeout(350);
      if (info.do) {
        const box = await page.evaluate(() => { const el = tutEl(tutStep()); if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
        if (box) { await page.mouse.click(box.x, box.y); taps++; } else await page.waitForTimeout(1600);
      } else { await page.mouse.click(195, 90); taps++; }
      await page.waitForTimeout(500);
      if (firstSaleTaps === null && await page.evaluate(() => G.stats.orders >= 1)) { firstSaleTaps = taps; firstSaleSec = (Date.now() - t0) / 1000; }
    }
    const end = await page.evaluate(() => ({ done: !!G.tut.done.first, rewarded: !!G.tut.rewarded, orders: G.stats.orders, malt: facLv('malting'), coach: document.getElementById('coach').classList.contains('h'), daily: feat('daily') }));
    rec(32, '初回案内: 7タップ以内（樽3回を含む）・60秒以内に最初の売上／完了で報酬・デイリー解放', firstSaleTaps !== null && firstSaleTaps <= 7 && firstSaleSec <= 60 && end.done && end.rewarded && end.malt >= 1 && end.coach && end.daily, JSON.stringify({ firstSaleTaps, firstSaleSec, end }));
    // 再読込で再表示しない・もう一度見るで再生
    await page.evaluate(() => save());
    await page.reload(); await page.waitForTimeout(1500);
    const again = await page.evaluate(() => ({ run: _tut && _tut.id, done: !!G.tut.done.first }));
    await page.evaluate(() => tutStart('first', true));
    await page.waitForTimeout(400);
    const replay = await page.evaluate(() => ({ run: _tut && _tut.id, next: getComputedStyle(document.getElementById('cNext')).visibility }));
    await page.evaluate(() => tutEnd(false));
    rec(33, '完了済みの案内は再読込で出ない・ヒント帳から再生できる（操作手順も次へで進める）', (!again.run || !TUTS_DONE_BEFORE.includes(again.run)) && again.done && replay.run === 'first' && replay.next === 'visible', JSON.stringify({ again, replay }));
    if (errors.length) rec('E6', 'チュートリアルテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- スキップで進行不能にならない ----------
  {
    const { page, errors } = await newPage(browser, null, true);
    await page.click('#cBub [data-act="tutSkip"]');
    await page.waitForTimeout(300);
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, coach: document.getElementById('coach').classList.contains('h'), rewarded: !!G.tut.rewarded, next: document.getElementById('bd_tsale').textContent !== '' }));
    await page.click('#nav .nb[data-tab="tsale"]'); await page.waitForTimeout(300);
    await page.click('#orderBoard [data-act="ordFill"], #orderBoard [data-act="ordGo"]');
    await page.waitForTimeout(300);
    const r2 = await page.evaluate(() => ({ tab: document.querySelector('.tab.on').id, bq: G.bq.length, orders: G.stats.orders }));
    rec(34, 'スキップしても操作できる・印の付いた「売る」から最初の注文を処理できる', r.done && r.coach && !r.rewarded && r.next && (r2.bq >= 1 || r2.orders >= 1), JSON.stringify({ r, r2 }));
    if (errors.length) rec('E7', 'スキップテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- ロジック（v4.1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      if (_offlineGate) closeOfflineModal(); closeM();
      // #35 コンボ廃止
      const base = tapValue(); const c0 = G.cash; let bad = 0;
      for (let i = 0; i < 60; i++) { const b = G.cash; tap(null); const d = G.cash - b; if (!(Math.abs(d - base) < 1e-6 || Math.abs(d - base * 100) < 1e-6)) bad++; }
      T(35, 'タップ収益は連打しても一定（×1 か クリティカル×100 のみ）', bad === 0 && typeof comboMul === 'undefined', 'bad=' + bad);
      // #36 注文の年数条件を守って詰める
      G.uw = ['glenlivid']; G.lots = []; G.bq = []; G.bottles = [];
      const l8 = makeLot(caskType('bourbon'), caskSize('hogshead')); l8.age = 8.5; l8.L = 100;
      const l11 = makeLot(caskType('bourbon'), caskSize('hogshead')); l11.age = 11.2; l11.L = 100;
      G.lots.push(l8, l11);
      const o = { id: 'o_t36', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 10, qty: 20, rq: 20, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 };
      G.orders = [o];
      const ok36 = ordFulfill('o_t36');
      const usedOld = l11.L < 100 && Math.abs(l8.L - 100) < 1e-9;
      botTick(3600000 * 5); const del = ordAutoTick();
      T(36, '「詰めて納品」は注文の年数以上の樽だけを使い、完了で自動納品', ok36 && usedOld && del === 1 && G.orders.length === 0 && G.stats.orders >= 1, JSON.stringify({ ok36, usedOld, del, left: G.orders.length }));
      // #37 自動直販は注文ボードの分を売らない
      G.orders = [{ id: 'o_t37', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 80, rq: 80, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; invAdd('glenlivid', 100, 9, 1, productSpec('glenlivid').target);
      G.auto.spot.on = true; G.auto.spot.defKeep = 50;
      autoSpotTick();
      T(37, '自動直販は注文に必要な本数を残す（残す本数50・注文80 → 80本残る）', invTotal('glenlivid') === 80, invTotal('glenlivid'));
      // #38 オフライン中に瓶詰めが終わった注文は自動納品
      G.orders = [{ id: 'o_t38', cid: 'local', kind: 'product', pid: 'glenlivid', minAge: 8, qty: 30, rq: 30, mult: 1, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 86400000 }];
      G.bottles = []; G.bq = [];
      const l9 = makeLot(caskType('bourbon'), caskSize('hogshead')); l9.age = 9; l9.L = 200; G.lots = [l9];
      ordFulfill('o_t38');
      const o0 = G.stats.orders;
      G.ls = Date.now() - 3 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      T(38, 'オフライン中に瓶詰めが終わった注文を自動納品', G.stats.orders === o0 + 1 && !G.orders.some(x => x.id === 'o_t38'), 'orders ' + o0 + '→' + G.stats.orders);
      // #39 段階的解放
      G.dl = 1; G.reputation = 0; G.stats.awardsWon = 0; G.awards = []; G.fac.distillation.p = false; G.tank = 0; G.te = 0; G.recipeOwned = ['golden_promise', 'soft_spring', 'distillery', 'unpeated'];
      const f1 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips1 = document.querySelectorAll('#sellChips .chip').length;
      switchTab('tcel'); const blend1 = document.getElementById('btnBlend').style.display;
      G.dl = 3; G.fac.distillation.p = true; G.te = 1e9; rall();
      const f2 = ['tank', 'rel', 'comp', 'regions', 'blend', 'export', 'recipe'].map(k => feat(k));
      switchTab('tsale'); const chips2 = document.querySelectorAll('#sellChips .chip').length;
      const locks = [...document.querySelectorAll('#lineView .pst')].filter(e => e.textContent.includes('🔒')).length;
      T(39, '使えない機能は非表示（Tier1: 売るの切替2つ・ブレンド非表示）→ 条件達成で表示', f1.every(x => !x) && chips1 === 2 && blend1 === 'none' && f2.join() === 'true,true,true,true,true,false,true' && chips2 === 5 && locks === 0, JSON.stringify({ f1, f2, chips1, chips2, blend1 }));
      // #40 v7→v8 の移行
      const v7 = JSON.parse(JSON.stringify(G)); v7.ver = 7; delete v7.tut; delete v7.shipLog; delete v7.encSeen; v7.auto.fill.on = false; v7.auto.spot.on = false; v7.dl = 2; v7.cw = { glenlivid: 30 };
      const m = parseSave(v7);
      T(40, 'v4.0（schema7）からの移行: 自動設定は維持・更新案内3枚・解放済み機能の案内は出さない', m.ver === BALANCE.SCHEMA_VERSION && !m.auto.fill.on && !m.auto.spot.on && m.tut.q.join() === 'upd' && m.tut.seed && m.shipLog.glenlivid && TUTS.upd.steps.length === 3, JSON.stringify({ ver: m.ver, tut: m.tut, auto: m.auto }));
      G = m; tutCheck();
      T('40b', 'seed処理: 条件を満たしている解放案内は既読になる', G.tut.done.u_t2 && G.tut.done.u_still && !G.tut.seed, JSON.stringify(G.tut.done));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E8', 'v4.1ロジックテスト中のエラー', false, errors.join(' | '));
  }
  // ---------- v7 セーブのバックアップ ----------
  {
    const v7 = { ver: 7, cash: 5000, te: 9000, dl: 1, uw: ['glenlivid'], lots: [], bottles: [], orders: [], auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: false, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('y')){sessionStorage.setItem('y','1');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v7))});}`;
    const { page, errors } = await newPage(browser, pre, true);
    await page.waitForTimeout(1500);
    const r = await page.evaluate(() => ({ bk: localStorage.getItem('we_v4_bak7:guest'), run: _tut && _tut.id, ver: G.ver, fill: G.auto.fill.on }));
    rec(41, 'v4.0セーブの読込: 移行前をバックアップ・更新案内が出る', !!r.bk && JSON.parse(r.bk).ver === 7 && r.run === 'upd' && r.ver === SCHEMA && !r.fill, JSON.stringify({ bk: !!r.bk, run: r.run, ver: r.ver }));
    await page.screenshot({ path: 'shot_upd.png' });
    if (errors.length) rec('E9', 'v7読込テスト中のエラー', false, errors.join(' | '));
  }
  // ================= v4.2 追加テスト =================
  // ---------- 表示の基準（P1） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      const out = { small: [], tiny: [], chars: [] };
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
        switchTab(t); await new Promise(r => setTimeout(r, 200));
        const el = document.getElementById(t);
        el.querySelectorAll('button,[data-act],select,input,summary').forEach(b => {
          if (b.getClientRects().length === 0) return;
          const r = b.getBoundingClientRect();
          if (b.classList.contains('ib') || b.classList.contains('visitor')) return; // ⓘは疑似要素で44px、来客は動きのある要素（56px）
          if (r.height < 43.5 || (r.width < 43.5 && b.tagName !== 'INPUT')) out.small.push(t + ':' + (b.dataset.act || b.tagName) + ':' + Math.round(r.width) + 'x' + Math.round(r.height));
        });
        const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n, chars = 0;
        while (n = w.nextNode()) { const p = n.parentElement; if (!p || p.getClientRects().length === 0 || !n.textContent.trim()) continue; const fs = parseFloat(getComputedStyle(p).fontSize); if (fs < 12) out.tiny.push(t + ':' + fs + ':' + n.textContent.trim().slice(0, 10)); chars += n.textContent.replace(/\s/g, '').length; }
        out.chars.push(t + ':' + chars);
      }
      const sm = parseFloat(getComputedStyle(document.querySelector('#tcel .thead .sm')).fontSize);
      const L = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
      const muted = getComputedStyle(document.documentElement).getPropertyValue('--muted').trim();
      const cr = (L(muted) + 0.05) / (L('#241c13') + 0.05);
      const chrome = ['hdr', 'ticker', 'nav'].map(id => document.getElementById(id).getBoundingClientRect().height);
      return { ...out, sm, cr: +cr.toFixed(2), chrome };
    });
    rec(42, '押す対象がすべて44px以上・文字は12px以上（本文14px）・補足色のコントラスト4.5以上', r.small.length === 0 && r.tiny.length === 0 && r.sm >= 14 && r.cr >= 4.5, JSON.stringify({ small: r.small.slice(0, 8), tiny: r.tiny.slice(0, 8), sm: r.sm, cr: r.cr, chrome: r.chrome, chars: r.chars }));
    if (errors.length) rec('E11', '表示基準テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- タイトル・TIPS帯・樽・設定（P1） ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 740 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1500);
    const t0 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id, note: document.querySelector('.t-note').textContent.includes('20歳未満'), se: G.opt.se, bgm: G.opt.bgm }));
    await page.click('#titleBtns .btn-ok'); await page.waitForTimeout(900);
    const t1 = await page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), tut: _tut && _tut.id }));
    rec(43, '起動時にタイトルと注意書き（音なしが既定）→ 閉じると初回案内が始まる', t0.title && !t0.tut && t0.note && t0.se === 0 && t0.bgm === 0 && !t1.title && t1.tut === 'first', JSON.stringify({ t0, t1 }));
    const tk = await page.evaluate(() => {
      const seq = []; _tk.hist = []; _tk.sinceHealth = 0;
      for (let i = 0; i < 120; i++) seq.push(tkPick());
      let maxGap = 0, gap = 0; seq.forEach(m => { if (m.cat === 'health') gap = 0; else { gap++; maxGap = Math.max(maxGap, gap); } });
      const locked = seq.filter(m => m.cat === 'tips' && m.f && !feat(m.f)).length;
      const srcOk = TICKER_MSGS.filter(m => m.cat === 'trivia' && m.src !== 'idea').every(m => SRC[m.src]);
      const bar = document.getElementById('ticker').getBoundingClientRect();
      return { maxGap, locked, srcOk, barTop: Math.round(bar.top), hdrBottom: Math.round(document.getElementById('hdr').getBoundingClientRect().bottom), n: TICKER_MSGS.length, triv: TICKER_MSGS.filter(m => m.cat === 'trivia').length, health: TICKER_MSGS.filter(m => m.cat === 'health').length, wrong: TICKER_MSGS.some(m => /京都・山崎|コンボ|プロフタブ/.test(m.text)) };
    });
    await page.evaluate(() => { if (_tut) { tutEnd(false); } });
    await page.waitForTimeout(200);
    await page.click('#ticker'); await page.waitForTimeout(300);
    const modal = await page.evaluate(() => ({ open: !document.getElementById('mo').classList.contains('h'), paused: _tk.paused, txt: document.getElementById('mc2').textContent }));
    rec(44, 'TIPS帯：ヘッダー直下に常設・健康は6件に1件以上・未解放のTIPSは出ない・豆知識は全件出典つき・誤記修正・タップで全文と出典', tk.barTop === tk.hdrBottom && tk.maxGap <= 5 && tk.locked === 0 && tk.srcOk && !tk.wrong && modal.open && modal.paused && (modal.txt.includes('出典') || modal.txt.includes('提案') || modal.txt.length > 5), JSON.stringify({ tk, modal: { open: modal.open, paused: modal.paused } }));
    await page.evaluate(() => closeM());
    const bb = await page.evaluate(() => { switchTab('td'); const r = document.getElementById('bb').getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height), cx: Math.round(r.left + r.width / 2), vw: window.innerWidth }; });
    rec(45, '樽の画像を画面中央に大きく（高さ200px以上・押せる範囲は樽の絵の幅・中心が画面中央±10px）', bb.h >= 200 && Math.abs(bb.w / bb.h - 346 / 469) < 0.02 && Math.abs(bb.cx - bb.vw / 2) <= 10, JSON.stringify(bb));
    const op = await page.evaluate(() => {
      const a = fmt(1234567); G.opt.money = 'ja'; const b = fmt(1234567), c = fmt(3.2e9), d = fmt(999); G.opt.money = 'en';
      G.opt.fs = 'l'; applyOpt(); const big = document.documentElement.classList.contains('fs-l'); G.opt.fs = 'm'; applyOpt();
      return { a, b, c, d, big };
    });
    rec(46, '設定：金額の表記（$1.23M / $123万 / $32億）と文字：大', op.a === '$1.23M' && op.b === '$123万' && op.c === '$32億' && op.d === '$999' && op.big, JSON.stringify(op));
    await ctx.close();
    if (errors.length) rec('E12', 'P1テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 遊びの厚み（P3）と保全（P2） ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(() => {
      const out = [];
      const T = (id, name, ok, detail) => out.push({ id, name, ok: !!ok, detail: String(detail) });
      // #47 章の目標
      const c0 = G.cash; G.stats.orders = 1; G.fac.distillation.p = true; G.stats.filled = 1; G.stats.shipped = 100;
      checkChapters();
      const st = G.chap; const claimed = !!st.claimed[1]; const gain = G.cash - c0;
      T(47, '章の目標：達成ごとに報酬・4つで章完了（演出を予約）', claimed && Math.abs(gain - 8000) < 1e-6 && _celebQ.length + (_celebOn ? 1 : 0) >= 1, 'gain=' + gain + ' claimed=' + claimed);
      _celebQ = []; celebClose();
      // #48 仕上げの樽
      G.dl = 2; G.cash = 1e7; G.te = 1e9; G.uw = ['jack_d'];
      const l = makeLot(caskType('bourbon'), caskSize('hogshead')); l.age = 6; G.lots = [l];
      const f0 = lotFlavor(l); const elig0 = lotsFor('jack_d').length;
      const ok = lotFinish(l.id, 'sherry'); const f1 = lotFlavor(l);
      l.age = 7; const f2 = lotFlavor(l); l.age = 9; const f3 = lotFlavor(l);
      const again = lotFinish(l.id, 'wine');
      const sh = caskType('sherry').flavorMod.fruity;
      T(48, '仕上げ：風味を引き継ぎ、移した樽の風味が2年で満ちる・1回のみ・バーボン銘柄から外れる', ok && Math.abs(f1.fruity - f0.fruity) < 1e-6 && Math.abs(f2.fruity - (f0.fruity + sh / 2)) < 1e-6 && Math.abs(f3.fruity - Math.min(100, f0.fruity + sh)) < 1e-6 && !again && elig0 === 1 && lotsFor('jack_d').length === 0 && G.stats.finishes === 1, JSON.stringify({ f0: f0.fruity, f1: f1.fruity, f2: f2.fruity, f3: f3.fruity, again }));
      // #49 名樽と愛好会
      const n1 = makeLot(caskType('bourbon'), caskSize('hogshead')); n1.age = 14;
      const n2 = makeLot(caskType('bourbon'), caskSize('hogshead')); n2.age = 14;
      G.lots = [n1, n2]; lotName(n1.id, 'はじまりの一樽'); trackNamed();
      const o = { id: 'o_s', cid: 'society', kind: 'cask', minAge: 12, qty: 1, rq: 1, mult: 2, reserve: false, accepted: false, createdAt: Date.now(), dueAt: Date.now() + 3600000 };
      G.orders = [o]; const m = ordMatch(o);
      const ratio = m.cash / (lotValue(n2) * 2);
      const lim0 = G.stats.limited || 0;
      ordDeliver('o_s', null); trackNamed();
      T(49, '名樽：名前を付けると愛好会が1.2倍で買い取り、蔵出しで記録に残る', m.lot === n1 && Math.abs(ratio - 1.2) < 1e-6 && G.stats.named === 1 && G.stats.limited === lim0 + 1 && G.caskLog.length === 1 && G.caskLog[0].name === 'はじまりの一樽', JSON.stringify({ ratio, log: G.caskLog }));
      // #50 取引先の人物
      G.relEvQ = []; G.rel.local = { lv: 2, done: 14 }; relAdd('local', 1);
      const q = G.relEvQ.slice(); const b0 = G.orders.length;
      relEventApply('local', 3);
      T(50, '取引先：関係★3で人物の会話が予約され、特別な予約注文が届く', q.length === 1 && q[0].lv === 3 && G.orders.length === b0 + 1 && G.orders[G.orders.length - 1].reserve, JSON.stringify(q));
      // #51 月替わりの市場
      _mktOff = false; G.awardMult = {};
      const u = (m) => { _mktForce = m; prodInvalidate(); return priceUnit('glenlivid', 8, 1, productSpec('glenlivid').target); };
      const base = u(2), dec = u(12), jul = u(7), nov = u(11);
      const nov12 = (() => { _mktForce = 11; return priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target); })();
      _mktForce = 2; const nov12b = priceUnit('glenlivid', 12, 1, productSpec('glenlivid').target);
      _mktForce = 4; const tour = cv(); _mktForce = 2; const tour0 = cv();
      _mktForce = 0; _mktOff = true;
      T(51, '月替わりの市場：12月は単価×1.12、7月は10年未満×1.15、11月は12年以上だけ×1.12、4月はツアー×2', Math.abs(dec / base - 1.12) < 1e-9 && Math.abs(jul / base - 1.15) < 1e-9 && Math.abs(nov / base - 1) < 1e-9 && Math.abs(nov12 / nov12b - 1.12) < 1e-9 && Math.abs(tour / tour0 - 2) < 1e-9, [dec / base, jul / base, nov12 / nov12b, tour / tour0].map(x => x.toFixed(3)).join(','));
      // #52 記録
      G.records = {}; G.runStart = Date.now() - 5 * 864e5; recordTier(2); recordUnit(1234);
      const rc = G.records[G.climate];
      T(52, '気候ごとの記録：昇格までの日数と最高単価', rc && rc.tierDays[2] === 5 && rc.bestUnit === 1234, JSON.stringify(rc));
      // #53 来客
      const cash0 = G.cash; const el = document.createElement('button'); el.dataset.vip = ''; el.id = 'vis_t'; document.body.appendChild(el);
      visitorTap(el);
      T(53, '見学ツアーの来客をタップするとチップ（タップ15回分）', Math.abs(G.cash - cash0 - cv() * 15) < 1e-6, G.cash - cash0);
      // #54 景色
      const tb = [3, 6, 12, 17, 22].map(h => sceneTime(h)).join(',');
      switchTab('td'); rdistLight(); const sc = document.getElementById('scene'); const cs = getComputedStyle(sc);
      const bgOk = /data:image\/webp/.test(cs.backgroundImage) && cs.backgroundSize === 'cover';
      const cls = sc.className === 'scene t-' + sceneTime(); const f = getComputedStyle(sc).filter;
      T(54, '景色：蒸留所の絵を表示し、時間帯（朝・昼・夕・夜）で明るさと色味を変える', tb === 'night,am,day,eve,night' && bgOk && cls && f !== 'none', tb + ' / ' + sc.className + ' / ' + f);
      // #55 引き継ぎコード
      const code = encodeCode(JSON.stringify({ a: 1, t: 'ウイスキー' }));
      const back = decodeCode(code);
      let tamper = ''; try { decodeCode(code.slice(0, 10) + (code[10] === 'A' ? 'B' : 'A') + code.slice(11)); } catch (e) { tamper = e.message; }
      let cut = ''; try { decodeCode(code.slice(0, 20)); } catch (e) { cut = e.message; }
      T(55, '引き継ぎコード：往復で一致・改変や欠けは検出して理由を示す', back.t === 'ウイスキー' && /変更|切れ/.test(tamper) && cut.length > 0, tamper + ' / ' + cut);
      // #56 自動バックアップ
      for (let i = 0; i < 3; i++) localStorage.removeItem(bkKey(i));
      const a1 = autoBackup(false), a2 = autoBackup(false), a3 = autoBackup(true), a4 = autoBackup(true), a5 = autoBackup(true);
      const list = bkList();
      T(56, '自動バックアップ：6時間おき・最大3つを入れ替え', a1 && !a2 && a3 && a4 && a5 && list.length === 3, JSON.stringify([a1, a2, a3, a4, a5, list.length]));
      // #57 独自銘柄
      const real = ['Glenlivet', 'Glenfiddich', 'Johnnie Walker', 'Chivas', 'Macallan', 'Laphroaig', 'Ardbeg', 'Talisker', 'Balvenie', 'Dalmore', 'Jameson', 'Bushmills', "Jack Daniel", "Maker's Mark", 'Buffalo Trace', 'Pappy', 'Yamazaki', 'Hakushu', 'Hibiki', 'Nikka', 'Suntory', 'Crown Royal'];
      const names = WL.map(w => w.name + ' ' + w.rg).join('|');
      const hit = real.filter(n => names.toLowerCase().includes(n.toLowerCase()));
      T(57, '25銘柄が独自の名前（実在ブランド名・蒸留所名を含まない）', hit.length === 0 && WL.every(w => WL_RENAME[w.id]), hit.join(','));
      return out;
    });
    r.forEach(x => rec(x.id, x.name, x.ok, x.detail));
    if (errors.length) rec('E13', 'P2/P3テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- schema 8 → 9 の移行 ----------
  {
    const v8 = { ver: 8, cash: 777, te: 5000, dl: 2, uw: ['glenlivid'], lots: [], bottles: [], orders: [], stats: { orders: 3, shipped: 150, filled: 2 }, fac: { malting: { l: 3, p: true }, distillation: { l: 1, p: true } }, tut: { done: { first: true }, q: [], seed: false }, auto: { fill: { on: false, cask: 'bourbon', size: 'hogshead' }, spot: { on: true, defKeep: 50, keep: {} } }, ls: Date.now() };
    const pre = `if(!sessionStorage.getItem('z')){sessionStorage.setItem('z','1');localStorage.setItem('we_sound','off');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v8))});}`;
    const { page, errors } = await newPage(browser, pre);
    await page.waitForTimeout(2600);
    const r = await page.evaluate(() => ({ ver: G.ver, se: G.opt.se, bgm: G.opt.bgm, bk: !!localStorage.getItem('we_v4_bak8:guest'), claimed: G.chap.claimed, done: Object.keys(G.chap.done).length, cash: G.cash, seed: G.chap.seed, fill: G.auto.fill.on }));
    rec(58, 'v4.1（schema8）からの移行：バックアップ・音はOFFを引き継ぐ・達成済みの章目標は報酬なしで既読', r.ver === SCHEMA && r.se === 0 && r.bgm === 0 && r.bk && r.claimed[1] === true && r.cash < 2000 && !r.seed && !r.fill, JSON.stringify(r));
    if (errors.length) rec('E14', '移行テスト中のエラー', false, errors.join(' | '));
  }
  // ---------- 文字：大 で横スクロールしない ----------
  {
    const { page, errors } = await newPage(browser);
    const r = await page.evaluate(async () => {
      G.opt.fs = 'l'; applyOpt(); const res = [];
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); res.push({ t, over: el.scrollWidth - el.clientWidth, doc: document.documentElement.scrollWidth - window.innerWidth }); }
      return res;
    });
    const bad = r.filter(x => x.over > 1 || x.doc > 1);
    rec(59, '文字：大・幅360pxでも横スクロールなし', bad.length === 0, JSON.stringify(bad));
    if (errors.length) rec('E15', '文字：大テスト中のエラー', false, errors.join(' | '));
  }
  // ================= v4.3 追加テスト =================
  const STATE = function (mode) {
    if (_offlineGate) closeOfflineModal(); closeM();
    Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } _celebQ = []; celebClose();
    _mktOff = true;
    if (mode === 'fresh') { prodInvalidate(); rall(); return; }
    const late = mode === 'late';
    G.dl = late ? 5 : 3; G.cash = late ? 5e11 : 8e7; G.te = late ? 5e12 : 5e8; G.reputation = late ? 260 : 60;
    G.stats.shipped = late ? 150000 : 2500; G.stats.orders = late ? 120 : 22;
    FD.forEach((f, i) => { G.fac[f.id].p = true; G.fac[f.id].l = (late ? [48, 46, 49, 45, 40, 38] : [24, 22, 26, 21, 18, 14])[i]; });
    G.branch.malting = 1; G.branch.fermentation = 0; G.branch.distillation = late ? 1 : null;
    G.uw = WL.slice(0, late ? 40 : 14).map(w => w.id);
    const mk = (c, s, age) => { const l = makeLot(caskType(c), caskSize(s)); l.age = age; l.L = l.L0 * Math.pow(0.984, age); return l; };
    G.lots = [mk('sherry', 'hogshead', 12.4), mk('bourbon', 'hogshead', 9.1), mk('bourbon', 'quarter', 4.6), mk('wine', 'barrel', 2.2), mk('bourbon', 'butt', 7.8), mk('sherry', 'hogshead', 0.4)];
    const nl = late ? whSlots() - 6 : 10;
    for (let i = 0; i < nl; i++) G.lots.push(mk('bourbon', 'hogshead', 1 + (i % 25) * 1.1));
    G.tank = late ? tankCap() * 0.7 : 1800;
    const t = productSpec('glenlivid').target;
    invAdd('glenlivid', 140, 9, 1.05, t); invAdd('jack_d', 60, 5, 1.0, productSpec('jack_d').target); invAdd('johnnie_em', 25, 12, 1.1, productSpec('johnnie_em').target);
    if (late) { invAdd('hibikue', 80, 17, 1.12, productSpec('hibikue') ? productSpec('hibikue').target : t); }
    G.orders = [];
    for (let i = 0; i < boardSize(); i++) { const o = ordGenerate(); if (o) G.orders.push(o); }
    if (G.orders[0]) { G.orders[0].reserve = true; G.orders[0].accepted = false; }
    G.rel.local = { lv: 2, done: 9 }; G.rel.bar = { lv: 1, done: 4 };
    G.shipLog = { glenlivid: { t: Date.now(), maxAge: 9 }, jack_d: { t: Date.now(), maxAge: 5 } };
    G.bq = [{ id: 'q_x', pid: 'glenlivid', n: 300, done: 120, moved: 120, age: 9, q: 1.05, fl: t, blend: null, oid: null }];
    G.blendHistory = [{ t: Date.now(), target: 'classic_blend', score: 0.82, n: 120 }];
    G.lots[0].name = 'はじまりの一樽'; G.lots[1].fin = { from: 'bourbon', at: 8 };
    G.chap.seed = true; checkChapters();
    prodInvalidate(); rall();
  };
  async function page43(H, rm, mode) {
    const ctx = await browser.newContext({ viewport: { width: 390, height: H }, reducedMotion: rm || 'no-preference' });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/ERR_FAILED/.test(m.text())) errors.push(m.text()); });
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
    if (mode) { await page.evaluate(`(${STATE.toString()})(${JSON.stringify(mode)})`); await page.waitForTimeout(500); await page.evaluate(() => { _celebQ = []; celebClose(); closeM(); }); }
    return { page, errors, ctx };
  }
  // ---------- #60 よく使う4タブはスクロールなし（2画面×3状態×4タブ） ----------
  {
    const bad = []; const errs = []; let n = 0; const lists = [];
    for (const H of [667, 740]) for (const mode of ['fresh', 'mid', 'late']) {
      const { page, errors, ctx } = await page43(H, null, mode);
      const r = await page.evaluate(async () => { const o = {}; for (const t of ['td', 'tb', 'tcel', 'tsale']) { switchTab(t); await new Promise(r => setTimeout(r, 150)); const el = document.getElementById(t); o[t] = el.scrollHeight - el.clientHeight; }
        switchTab('tcel'); await new Promise(r => setTimeout(r, 100)); const w = document.querySelector('#whSummary .whgw'); w.scrollTop = 1e6; const wEnd = w.scrollTop + w.clientHeight >= w.scrollHeight - 2;
        switchTab('tsale'); await new Promise(r => setTimeout(r, 100)); const ob = document.getElementById('orderBoard'); ob.scrollTop = 1e6; const oEnd = ob.scrollTop + ob.clientHeight >= ob.scrollHeight - 2; const last = ob.lastElementChild; const lr = last && last.getBoundingClientRect(), obr = ob.getBoundingClientRect();
        return { o, wEnd, oEnd, lastVisible: !last || (lr.bottom <= obr.bottom + 1), cards: ob.children.length, casks: document.querySelectorAll('#whSummary .ck2:not(.em)').length }; });
      Object.keys(r.o).forEach(t => { n++; if (r.o[t] > 0) bad.push(mode + H + ':' + t + '+' + r.o[t]); });
      if (mode === 'late') lists.push(r);
      errs.push(...errors); await ctx.close();
    }
    rec(60, 'よく使う4タブはスクロールなし（390×667・390×740 × 開始直後・中盤・終盤 = 24通り）', n === 24 && bad.length === 0, JSON.stringify({ n, bad }));
    rec('60b', '件数が多い一覧（樽・注文）は枠の中で最後までスクロールできる', lists.length === 2 && lists.every(l => l.wEnd && l.oEnd && l.lastVisible && l.casks >= 20), JSON.stringify(lists));
    if (errs.length) rec('E20', '1画面テスト中のエラー', false, errs.slice(0, 3).join(' | '));
  }
  // ---------- #61-62 TIPS帯は常に流れる ----------
  {
    const out = [];
    for (const rm of ['no-preference', 'reduce']) {
      const { page, errors, ctx } = await page43(740, rm);
      await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } });
      await page.evaluate(() => { const L = TICKER_MSGS.slice().sort((a, b) => b.text.length - a.text.length)[0]; tkPick = () => L; nextTicker(); });
      await page.waitForTimeout(300);
      if (rm === 'reduce') {
        const box = await page.locator('#ticker').boundingBox();
        await page.mouse.move(box.x + 200, box.y + 10); await page.mouse.down();
        const h1 = await page.evaluate(() => tkTxt.getBoundingClientRect().left); await page.waitForTimeout(700); const h2 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.up(); await page.waitForTimeout(250); const longOpen = await page.evaluate(() => !mo.classList.contains('h'));
        await page.waitForTimeout(500); const h3 = await page.evaluate(() => tkTxt.getBoundingClientRect().left);
        await page.mouse.click(box.x + 200, box.y + 10); await page.waitForTimeout(250); const tapOpen = await page.evaluate(() => !mo.classList.contains('h'));
        rec(62, 'TIPS帯：押している間は止まり、離すと再開・短いタップで全文、長押しでは開かない', Math.abs(h1 - h2) < 3 && h3 < h2 - 8 && !longOpen && tapOpen, JSON.stringify({ h1, h2, h3, longOpen, tapOpen }));
      }
      const a = await page.evaluate(() => { const el = tkTxt; const tr = tkTrack.getBoundingClientRect(); const an = el.getAnimations()[0]; const x0 = el.getBoundingClientRect().left;
        const dur = an ? an.effect.getComputedTiming().duration : 0; if (an) { an.pause(); an.currentTime = dur - 1; }
        const r = el.getBoundingClientRect(); const res = { run: el.classList.contains('run'), anim: getComputedStyle(el).animationName, ell: getComputedStyle(el).textOverflow, w: Math.round(el.offsetWidth), track: Math.round(tr.width), x0: Math.round(x0), endRight: Math.round(r.right), trackLeft: Math.round(tr.left), dur: Math.round(dur), speed: Math.round((tr.width + el.offsetWidth) / (dur / 1000)) };
        return res; });
      await page.evaluate(() => nextTicker()); await page.waitForTimeout(400);
      out.push({ rm, ...a });
      const opts = await page.evaluate(() => { switchTab('tp'); return [...document.querySelectorAll('#optBox [data-k="tk"]')].map(b => b.dataset.v).join(','); });
      out[out.length - 1].opts = opts;
      if (errors.length) rec('E21', 'TIPS帯テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    const ok = out.every(o => o.run && o.anim === 'tkScroll' && o.ell !== 'ellipsis' && o.w > o.track && o.endRight <= o.trackLeft + 2 && o.opts === 'slow,mid,fast');
    const sp = out.map(o => o.speed);
    rec(61, 'TIPS帯：「視差効果を減らす」の端末でも右から左へ流れ、最後の文字まで表示枠を通過する（減らす設定では約0.65倍の速さ・「流さない」は廃止）', ok && sp[1] < sp[0] && sp[1] >= sp[0] * 0.55, JSON.stringify(out));
    const { page, ctx } = await page43(740);
    const mig = await page.evaluate(() => { const s = JSON.parse(JSON.stringify(G)); s.opt.tk = 'still'; return sanitize(s).opt.tk; });
    rec('61b', '保存済みの「流さない」は読込時に「遅い」へ置き換える', mig === 'slow', mig);
    await ctx.close();
  }
  // ---------- #63 ホームのアイコン列 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      switchTab('td'); G.hg = { n: 2, got: 2, used: 0 }; rdistLight();
      const icons = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id.replace('hi_', '') + '=' + (b.querySelector('.hib') ? b.querySelector('.hib').textContent : ''));
      const c = chapCur(), st = chapState(); const cn = c.goals.filter(g => st.done[g.id]).length;
      const dn = G.daily.missions.filter(m => m.done).length; const ts = tierReqStatus(G.dl + 1); const tok = ts.filter(o => o.ok).length;
      const expect = ['chap=' + cn + '/4', 'daily=' + dn + '/' + G.daily.missions.length, 'mkt=' + mktDaysLeft() + '日', 'tier=' + tok + '/' + ts.length, 'hg=2/' + V47.HG_MAX].concat(staffOn() ? ['staff=' + G.staff.length + '/' + staffCap()] : []);
      const modals = {};
      for (const [k, word] of [['chap', '章の目標'], ['daily', 'デイリーミッション'], ['mkt', '今月の市場'], ['tier', '昇格の条件'], ['hg', '熟成の砂時計']]) {
        closeM(); document.getElementById('hi_' + k).click(); await new Promise(r => setTimeout(r, 80));
        modals[k] = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes(word);
      }
      closeM(); rdistLight();
      const newsAfter = '';
      const gone = ['chapCard', 'mktCard', 'tierCard', 'dailyBox', 'homeNews', 'nextUnlock'].filter(id => document.getElementById(id));
      return { icons, expect, modals, newsAfter, gone, nextH: document.getElementById('nextCard') ? 999 : 0 };
    });
    rec(63, 'ホーム：章・デイリー・市場・Tier・砂時計はアイコン＋バッジ（数字は内部状態と一致）で、押すとそれぞれの詳細が開く', r.icons.join() === r.expect.join() && Object.values(r.modals).every(Boolean) && r.newsAfter === '' && r.gone.length === 0 && r.nextH <= 80, JSON.stringify(r));
    if (errors.length) rec('E22', 'アイコン列テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #64 生産ライン ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      switchTab('tb'); const f = prodFlows();
      const flows = [...document.querySelectorAll('#lineView .pflow .pfl')].slice(1).map(e => e.textContent);
      const expFlows = [0, 1, 2].map(i => STAGES[i].out + ' ' + fmtL(f.p[i + 1]) + '/時').concat(['新酒 ' + fmtL(f.newmake) + '/時']);
      const sur = [...document.querySelectorAll('#lineView .pflow')].slice(1).map(e => { const s = e.querySelector('.psur'); return s ? s.textContent : ''; });
      const pm = priceMultBase() * getEventMult('passive');
      const expSur = [0, 1, 2].map(i => f.s[i] > 0.05 ? '余剰 ' + fmtL(f.s[i]) + ' → +' + fmt(f.s[i] * STAGES[i].price * pm) + '/時' : '').concat(['']);
      const bnIdx = [...document.querySelectorAll('#lineView .pst:not(#barleyBox)')].findIndex(e => e.classList.contains('bn'));
      const caps = [...document.querySelectorAll('#lineView .pst:not(#barleyBox) .pcap')].map(e => e.textContent);
      const tank = document.getElementById('tkAmt').textContent === fmtL(G.tank) + ' / ' + fmtL(tankCap());
      const gone = ['fl', 'recipeWrap', 'facEncEl'].filter(id => document.getElementById(id));
      const mat = document.querySelector('#tb #fac_maturation, #tb #fac_bottling');
      return { flows, expFlows, sur, expSur, bnIdx, bn: f.bottleneck, capOk: caps.every((c, i) => c.startsWith('能力 ' + fmtL(f.cap[i]) + '/時')), tank, gone, mat: !!mat };
    });
    const ok = r.flows.join('|') === r.expFlows.join('|') && r.sur.join('|') === r.expSur.join('|') && r.bnIdx === r.bn && r.capOk && r.tank && r.gone.length === 0 && !r.mat;
    rec(64, '生産ライン：工程間の流量・余剰と外販収入・能力・いちばん遅い工程・タンク量が計算値と一致', ok, JSON.stringify(r));
    // 熟成庫とボトリングは各タブで強化できる
    const r2 = await page.evaluate(async () => {
      G.cash = 1e15; G.branch.maturation = 0; G.branch.bottling = 0; rall(); switchTab('tcel'); await new Promise(r => setTimeout(r, 100));
      const m0 = G.fac.maturation.l; document.querySelector('#tcel #fac_maturation [data-act="facUp"]').click();
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const b0 = G.fac.bottling.l; document.querySelector('#tsale #fac_bottling [data-act="facUp"]').click();
      const rc = (() => { switchTab('tb'); document.querySelector('[data-act="rcpBox"]').click(); const ok = !mo.classList.contains('h') && document.querySelectorAll('#mc2 .rc').length === 4; closeM(); return ok; })();
      const bl = (() => { switchTab('tcel'); document.getElementById('btnBlend').click(); const ok = !mo.classList.contains('h') && !!document.querySelector('#mc2 #blendRadar'); closeM(); return ok; })();
      const fc = (() => { document.querySelector('#fillBox [data-act="fillPickT"]').click(); const ok = document.querySelectorAll('#mc2 .ccard').length === CASK_TYPES.length; closeM(); return ok; })();
      const hist = (() => { switchTab('tb'); document.querySelector('[data-act="facHist"]').click(); const ok = document.querySelectorAll('#mc2 #facEncEl > div').length === FD.length; closeM(); return ok; })();
      return { mat: G.fac.maturation.l - m0, bot: G.fac.bottling.l - b0, rc, bl, fc, hist };
    });
    rec(65, '熟成庫は「寝かせる」、ボトリングは「売る」で強化できる・レシピ・ブレンド・樽の選択・設備の歩みはボタンから開く', r2.mat === 1 && r2.bot === 1 && r2.rc && r2.bl && r2.fc && r2.hist, JSON.stringify(r2));
    if (errors.length) rec('E23', '生産ラインテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #66 見学のお客さん ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('td'); G.hs.vis = 0; _vis.list.forEach(v => { const e = document.getElementById(v.id); if (e) e.remove(); }); _vis.list = []; _vis.next = 0;
      window._tl = []; const _t0 = toast; toast = function (m, d) { _tl.push(m); return _t0(m, d); }; const r0 = Math.random; Math.random = () => 0.5; visitorTick(); Math.random = r0;
      await new Promise(r => setTimeout(r, 600));
      const v = _vis.list[0]; const el = document.getElementById(v.id); const r = el.getBoundingClientRect(); const bb = document.getElementById('bb').getBoundingClientRect();
      const toastTxt = _tl.join('|');
      const txt = el.textContent; const expect = '試飲 +' + fmt(cv() * 15); const tp = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); const onTop = el.contains(tp);
      const c0 = G.cash; el.click(); await new Promise(r => setTimeout(r, 50));
      return { txt, expect, overlap: !onTop, h: Math.round(r.height), gain: G.cash - c0, cv15: cv() * 15, firstToast: toastTxt.includes('見学のお客さん'), seen: G.hs.vis };
    });
    rec(66, '見学のお客さん：吹き出しに「何者か」と報酬額を表示・樽より手前に出て押せる・初回だけ説明が出る', r.txt.includes('見学させて') && r.txt.includes(r.expect) && !r.overlap && r.h >= 44 && Math.abs(r.gain - r.cv15) < 1e-6 && r.firstToast && r.seen === 1, JSON.stringify(r));
    if (errors.length) rec('E24', '見学テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #67 注文カード ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      _ui.sellTab = 'ord'; switchTab('tsale'); await new Promise(r => setTimeout(r, 100));
      const hs = [...document.querySelectorAll('#orderBoard .oc2')].map(e => Math.round(e.getBoundingClientRect().height));
      const o = G.orders.find(x => !(x.reserve && x.accepted)); const n0 = G.orders.length;
      document.querySelector(`#orderBoard .oc2[data-id="${o.id}"] .ocl`).click(); await new Promise(r => setTimeout(r, 50));
      const modal = !mo.classList.contains('h') && document.getElementById('mc2').textContent.includes('見送る') && document.getElementById('mc2').textContent.includes(custById(o.cid).name);
      document.querySelector('#mc2 [data-act="ordDismissM"]').click(); await new Promise(r => setTimeout(r, 50));
      return { hs, modal, removed: G.orders.length === n0 - 1 && !G.orders.some(x => x.id === o.id), closed: mo.classList.contains('h') };
    });
    rec(67, '注文カード：1枚100px以下に圧縮・押すと詳細（人物・会話・見送る）が開き、見送ると消える', r.hs.length > 0 && r.hs.every(h => h <= 100) && r.modal && r.removed && r.closed, JSON.stringify(r));
    if (errors.length) rec('E25', '注文カードテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #68 生産の流れ（ホーム上部）の単位 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => { switchTab('td'); G.bq = []; rdistLight(); return [...document.querySelectorAll('#flow .fnode .fv')].map(e => e.textContent).concat([fmtL(prodFlows().newmake), fmtL(G.tank), G.lots.length + '/' + whSlots(), fmtN(G.bottles.reduce((a, r) => a + r.n, 0)) + '本', G.orders.length + '件']); });
    const got = r.slice(0, 5), exp = r.slice(5);
    rec(68, 'ホーム上部の流れ：生産L/時・タンクL・樽数/上限・瓶の本数・注文件数を単位つきで表示', got.join('|') === exp.join('|'), JSON.stringify({ got, exp }));
    await ctx.close();
  }
  // ---------- #69 v4.2 からの更新案内・金額の単位 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      const s = JSON.parse(JSON.stringify(G)); s.tut.done = { first: true }; s.tut.q = []; delete s.hs;
      const g = sanitize(s); const old = TUTS.u43.cond.call(null);
      const G0 = G; G = g; const condOld = TUTS.u43.cond(); G = G0;
      const fresh = defState(); G = fresh; fresh.tut.done.first = true; const condFresh = TUTS.u43.cond(); G = G0;
      const en = fmtEn(3.1e19), en2 = fmtEn(4.2e15), en3 = fmtEn(5e12);
      G.opt.money = 'ja'; const ja = fmt(3.1e19), ja2 = fmt(2.5e22); G.opt.money = 'en';
      return { condOld, condFresh, en, en2, en3, ja, ja2 };
    });
    rec(69, 'v4.2のセーブには変更点の案内を1回出し、新規には出さない', r.condOld === true && r.condFresh === false, JSON.stringify(r));
    rec(70, '大きな金額の単位（$31.00Qi・$4.20Qa・$5.00T／$3,100京・$250垓）', r.en === '$31.00Qi' && r.en2 === '$4.20Qa' && r.en3 === '$5.00T' && r.ja === '$3,100京' && r.ja2 === '$250垓', JSON.stringify(r));
    if (errors.length) rec('E26', '更新案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.4 追加テスト =================
  // ---------- #71 設定の選択表示 ----------
  {
    const { page, errors, ctx } = await page43(667);
    await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } switchTab('tp'); });
    const keys = await page.evaluate(() => [...document.querySelectorAll('#optBox [data-act="optSet"]')].map(b => b.dataset.k + '|' + b.dataset.v));
    const bad = [];
    for (const kv of keys) {
      const [k, v] = kv.split('|');
      await page.click(`#optBox [data-k="${k}"][data-v="${v}"]`); await page.waitForTimeout(120);
      const r = await page.evaluate(([k, v]) => { const b = document.querySelector(`#optBox [data-k="${k}"][data-v="${v}"]`); const sib = [...document.querySelectorAll(`#optBox [data-k="${k}"]`)].filter(x => x !== b); return { on: b.classList.contains('on') && b.getAttribute('aria-pressed') === 'true' && b.textContent.startsWith('✓'), others: sib.every(x => !x.classList.contains('on') && x.getAttribute('aria-pressed') === 'false'), bg: getComputedStyle(b).backgroundColor, bg2: sib[0] ? getComputedStyle(sib[0]).backgroundColor : '' }; }, [k, v]);
      if (!r.on || !r.others || r.bg === r.bg2) bad.push(kv + JSON.stringify(r));
    }
    await page.evaluate(() => { opt().theme = 'dark'; opt().motion = 'std'; applyOpt(); });
    rec(71, '設定：どの項目も押した直後に選択表示（塗りつぶし・✓・aria-pressed）が切り替わる', keys.length >= 14 && bad.length === 0, JSON.stringify({ n: keys.length, bad: bad.slice(0, 3) }));
    if (errors.length) rec('E30', '設定テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #72-73 クリティカル廃止・歯車・図鑑 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const base = tapValue(); const c0 = G.cash; for (let i = 0; i < 1000; i++) tap(null);
      const gear = document.getElementById('btnGear').textContent.trim();
      switchTab('te'); _ui.encTab = 'w'; renc();
      const cards = document.getElementById('wg').textContent;
      return { gain: G.cash - c0, expect: base * 1000, base, tapBase: BALANCE.TAP_BASE, crit: typeof BALANCE.CRIT_CHANCE, gear, glass: cards.includes('🥃'), q: cards.includes('❓'), n: document.querySelectorAll('#wg .wc').length };
    });
    rec(72, 'タップ：クリティカル廃止（1,000回で常に1回の額×回数）・基本額は1.5倍', Math.abs(r.gain - r.expect) < 1e-6 && r.tapBase === 4.5 && r.crit === 'undefined', JSON.stringify(r));
    rec(73, 'ヘッダーの歯車は絵文字・図鑑のカードにグラスや色の絵文字がない', r.gear === '⚙️' && !r.glass && !r.q && r.n === 25, JSON.stringify(r));
    if (errors.length) rec('E31', '小修正テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #74 タブの印 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      const bd = () => ['td', 'tb', 'tcel', 'tsale'].map(t => t + '=' + document.getElementById('bd_' + t).textContent + (document.querySelector(`#nav .nb[data-tab="${t}"]`).classList.contains('att') ? '*' : '')).join(' ');
      G.tut.q = []; updNavBadges(); const m1 = tabMarks(); const s1 = bd();
      const exp = t => { const x = m1[t]; return x.u ? '!' : x.n ? String(x.n) : ''; };
      const match = ['td', 'tb', 'tcel', 'tsale'].every(t => document.getElementById('bd_' + t).textContent === exp(t));
      // 何もできない状態：印なし
      G.orders = []; G.bq = []; G.cash = 0; G.branch.mashing = 0; G.branch.distillation = 0; G.branch.maturation = 0; G.branch.bottling = 0; G.auto.fill.on = true; G.hs.casks = CASK_TYPES.map(t => t.id).concat(CASK_SIZES.map(z => z.id)); G.lots = G.lots.slice(0, 3); prodInvalidate(); updNavBadges(); const s2 = bd();
      // 大麦切れ：造るに「!」
      barleyState().kg = 0; prodInvalidate(); updNavBadges(); const s3 = bd();
      const noSlotCount = !/tcel=\d/.test(s2);
      return { s1, match, s2, s3, noSlotCount };
    });
    rec(74, 'タブの印：件数は操作候補と一致・待つだけなら印なし（空き枠数は出さない）・大麦切れで造るに「!」', r.match && r.s2 === 'td= tb= tcel= tsale=' && /tb=!\*/.test(r.s3) && r.noSlotCount, JSON.stringify(r));
    if (errors.length) rec('E32', 'タブの印テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #75-76 大麦 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = {};
      o.start = { kg: barleyState().kg, cap: barleyCap(), auto: barleyState().auto };
      G.fac.malting.l = 1; G.cash = 100000; prodInvalidate();
      const f = prodFlows(); const pr = barleyPrice(); const c0 = G.cash, s0 = G.stats.barleyCost;
      prodTick(3600000);
      o.hour = { use: f.p[0], cost: G.stats.barleyCost - s0, expCost: f.p[0] * pr, net: G.cash - c0, expNet: f.surplusPh * getEventMult('passive') - f.p[0] * pr, kg: barleyState().kg };
      barleyState().auto = false; barleyState().kg = f.p[0] / 2; prodInvalidate(); const t0 = G.cash; prodTick(3600000);
      o.half = { gain: G.cash - t0, exp: f.surplusPh * getEventMult('passive') / 2, kg: barleyState().kg, ok: barleyOK(), p0: prodFlows().p[0] };
      barleyState().auto = true; G.cash = 1e6; barleyState().kg = barleyCap(); G.ls = Date.now() - 30 * 3600000; const s1 = G.stats.barleyCost; offline();
      o.off = { cost: G.stats.barleyCost - s1, exp: f.p[0] * BALANCE.OFFLINE_CAP_H * pr, modal: document.getElementById('mc2').textContent.includes('原料費') };
      if (_offlineGate) closeOfflineModal();
      barleyState().auto = false; barleyState().kg = 0; G.cash = 1e6; G.ls = Date.now() - 5 * 3600000; offline();
      o.stop = document.getElementById('mc2').textContent.includes('大麦が切れて止まっていた時間');
      if (_offlineGate) closeOfflineModal();
      const s = JSON.parse(JSON.stringify(G)); s.ver = 9; delete s.barley; s.opt = { fs: 'm', money: 'en', se: 0, bgm: 0, vib: true, tk: 'mid' };
      const g = parseSave(s); o.mig = { ver: g.ver, barley: g.barley, theme: g.opt.theme, motion: g.opt.motion };
      return o;
    });
    const h = r.hour;
    rec(75, '大麦：製麦した量だけ消費し原料費を払う・在庫が半分なら生産も半分・在庫切れで製麦が止まる', r.start.kg === r.start.cap && r.start.auto && Math.abs(h.cost - h.expCost) < 0.01 && Math.abs(h.net - h.expNet) < 0.01 && Math.abs(r.half.gain - r.half.exp) < 0.01 && !r.half.ok && r.half.p0 === 0, JSON.stringify(r));
    rec(76, '大麦：放置は最大24時間分を消費して報告に原料費を出す・在庫切れの停止時間を報告・schema11へ移行（サイロ満タン・色ダーク）', Math.abs(r.off.cost - r.off.exp) / r.off.exp < 0.01 && r.off.modal && r.stop && r.mig.ver === SCHEMA && r.mig.barley.kg === null && r.mig.barley.auto === true && r.mig.theme === 'dark' && r.mig.motion === 'std', JSON.stringify(r));
    if (errors.length) rec('E33', '大麦テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #77-78 案内 ----------
  {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.goto(FILE); await page.waitForTimeout(1000);
    await page.evaluate(() => { _mktOff = true; window._tutSw = 0; const o = switchTab; switchTab = function (id) { if (new Error().stack.includes('tutShow')) window._tutSw++; return o(id); }; });
    await page.evaluate(() => titleStart(false)); await page.waitForTimeout(1200);
    const tabs = [];
    for (let k = 0; k < 16; k++) {
      const st = await page.evaluate(() => _tut ? { i: _tut.i, tab: document.querySelector('.tab.on').id } : null);
      if (!st) break; tabs.push(st.tab);
      const box = await page.evaluate(() => { const s = tutStep(); const el = s && s.sel ? tutEl(s) : null; if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, do: !!s.do }; });
      if (box && box.do) await page.mouse.click(box.x, box.y); else await page.click('#cNext');
      await page.waitForTimeout(450);
    }
    const r = await page.evaluate(() => ({ done: !!G.tut.done.first, sw: window._tutSw, malt: facLv('malting'), orders: G.stats.orders }));
    rec(77, 'はじめての案内：案内がタブを切り替えない（ナビはプレイヤーが押す）・ホーム→売る→造るの順・最後まで進む', r.done && r.sw === 0 && r.malt >= 1 && r.orders >= 1 && tabs[0] === 'td' && tabs.includes('tsale') && tabs[tabs.length - 1] === 'tb', JSON.stringify({ r, tabs: tabs.join('>') }));
    await page.waitForTimeout(2500);
    const w = await page.evaluate(() => ({ q: G.tut.q.slice(), cel: document.getElementById('bd_tcel').textContent, run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    await page.click('#nav .nb[data-tab="tcel"]'); await page.waitForTimeout(900);
    const w2 = await page.evaluate(() => ({ run: _tut && _tut.id, tab: document.querySelector('.tab.on').id }));
    rec(78, '後から出る案内：別のタブにいる間はナビに「新」を付けて待ち、そのタブを開くと始まる', w.q.includes('u_age') && w.cel === '新' && w.run !== 'u_age' && w2.run === 'u_age' && w2.tab === 'tcel', JSON.stringify({ w, w2 }));
    if (errors.length) rec('E34', '案内テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #79 動き ----------
  {
    const { page, errors, ctx } = await page43(667, 'reduce', 'mid');
    const r = await page.evaluate(async () => {
      switchTab('tb'); await new Promise(r => setTimeout(r, 200));
      const band = document.querySelector('#lineView .pflow.run .pband'); const an = band ? getComputedStyle(band).animationName : 'none';
      const dur = band ? getComputedStyle(band).animationDuration : '';
      G.tut.q = []; updNavBadges(); const att = document.querySelector('#nav .nb.att'); const aan = att ? getComputedStyle(att, '::after').animationName : 'none';
      let conf = null; const oc = celebrate; celebrate({ icon: '🎉', title: 't', sub: '' }); await new Promise(r => setTimeout(r, 100)); conf = document.querySelectorAll('#celebrate .conf i').length; _celebQ = []; celebClose();
      return { an, dur, aan, conf, low: lowMotion() };
    });
    rec(79, '動き：「視差効果を減らす」でも生産ラインの矢印とタブの印はゆっくり動き、紙吹雪は出ない', r.an === 'pflow' && parseFloat(r.dur) >= 1 && r.aan === 'attPulse' && r.conf === 0 && r.low, JSON.stringify(r));
    if (errors.length) rec('E35', '動きテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #80 色（コントラスト）と1画面 ----------
  {
    const out = {}; let overs = [];
    for (const th of ['dark', 'light']) {
      const { page, errors, ctx } = await page43(667, null, 'mid');
      const r = await page.evaluate(async th => {
        opt().theme = th; applyOpt(); _celebQ = []; celebClose(); closeM();
        const parse = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
        const lum = c => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
        const bgOf = el => { let e = el; while (e) { const cs = getComputedStyle(e); if (cs.backgroundImage && cs.backgroundImage !== 'none') return null; const c = parse(cs.backgroundColor); if (c && c.a >= 0.9) return c; e = e.parentElement; } return parse(getComputedStyle(document.body).backgroundColor); };
        const low = []; let n = 0; const over = {};
        for (const t of ['td', 'tb', 'tcel', 'tsale', 'te', 'tp']) {
          switchTab(t); await new Promise(r => setTimeout(r, 150)); _celebQ = []; celebClose();
          const el = document.getElementById(t); if (['td', 'tb', 'tcel', 'tsale'].includes(t)) over[t] = el.scrollHeight - el.clientHeight;
          const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let x;
          while (x = w.nextNode()) {
            const p = x.parentElement; if (!p || !x.textContent.trim() || p.getClientRects().length === 0 || p.closest('#stage') || p.closest('button:disabled') || p.closest('.lk') || p.closest('.ca')) continue;
            const cs = getComputedStyle(p); if (parseFloat(cs.opacity) < 1) continue;
            const fg = parse(cs.color); const bg = bgOf(p); if (!fg || !bg) continue; n++;
            const L1 = lum(fg), L2 = lum(bg); const cr = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
            if (cr < 4.5) low.push(t + ':' + cr.toFixed(2) + ':' + x.textContent.trim().slice(0, 10));
          }
        }
        return { n, low: low.slice(0, 10), nLow: low.length, over, theme: document.documentElement.dataset.theme };
      }, th);
      out[th] = r; Object.entries(r.over).forEach(([t, v]) => { if (v > 0) overs.push(th + ':' + t + '+' + v); });
      if (errors.length) rec('E36', '色テスト中のエラー', false, errors.join(' | '));
      await ctx.close();
    }
    rec(80, '色：ダーク・ライトとも全タブの文字のコントラスト4.5以上（ライトでも4タブは1画面）', out.dark.nLow === 0 && out.light.nLow === 0 && out.light.theme === 'light' && out.dark.n > 200 && out.light.n > 200 && overs.length === 0, JSON.stringify({ dark: { n: out.dark.n, low: out.dark.low }, light: { n: out.light.n, low: out.light.low }, overs }));
  }
  // ---------- #81 樽の選択欄 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'fresh');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.fac.distillation.p = true; prodInvalidate(); switchTab('tcel'); rCellar();
      const picks = [...document.querySelectorAll('#fillBox .fpick')].map(b => b.textContent.replace(/\s+/g, ''));
      const newBefore = document.querySelectorAll('#fillBox .fnew').length;
      G.te = 2e7; rCellar(); updNavBadges();
      const newAfter = document.querySelectorAll('#fillBox .fpick.new').length; const mark = document.getElementById('bd_tcel').textContent;
      document.querySelector('#fillBox [data-act="fillPickT"]').click(); await new Promise(r => setTimeout(r, 50));
      const cards = document.querySelectorAll('#mc2 .ccard').length; const locked = document.querySelectorAll('#mc2 .ccard.lk').length;
      document.querySelector('#mc2 .ccard[data-id="sherry"]').click(); await new Promise(r => setTimeout(r, 50));
      rCellar(); updNavBadges();
      return { picks, newBefore, newAfter, mark, cards, locked, cask: G.auto.fill.cask, newGone: document.querySelectorAll('#fillBox .fpick.new').length, mark2: document.getElementById('bd_tcel').textContent };
    });
    rec(81, '樽詰め：「樽の種類▾」「サイズ▾」の選択欄・解禁でNEWとタブの印・カードで選べる', r.picks.length === 2 && r.picks.every(p => p.includes('▾')) && r.newBefore === 0 && r.newAfter >= 1 && r.mark !== '' && r.cards === 5 && r.locked >= 1 && r.cask === 'sherry' && r.newGone === 0, JSON.stringify(r));
    if (errors.length) rec('E37', '樽選択テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.5 追加テスト =================
  // ---------- #81 ホームの並び・お知らせ廃止・次にやることの行の廃止 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      switchTab('td'); rdistLight();
      const order = [...document.getElementById('td').children].map(e => e.id);
      const st = document.getElementById('stage').getBoundingClientRect();
      const hi = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id);
      const gone = ['hintMake', 'hintAge', 'hintSell', 'hi_news', 'nextCard'].filter(id => document.getElementById(id));
      return { order, stageH: Math.round(st.height), stageBottom: Math.round(st.bottom), navTop: Math.round(document.getElementById('nav').getBoundingClientRect().top), hi, gone, nu: typeof nextUnlockText, pn: typeof pushNews };
    });
    rec(81, 'ホーム：上から「生産の流れ → アイコン列 → 景色と樽」・お知らせと各タブ冒頭の「次にやること」の行はない', r.order.join() === 'flow,homeIcons,stage' && r.stageH >= 300 && Math.abs(r.stageBottom - r.navTop) <= 12 && r.hi.includes('hi_hg') && !r.hi.includes('hi_fin') && !r.hi.includes('hi_news') && r.gone.length === 0 && r.nu === 'undefined' && r.pn === 'undefined', JSON.stringify(r));
    if (errors.length) rec('E40', 'ホーム並びテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #82-83 樽タップの額・試飲会 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('td');
      let T = Date.now(); _acctClock = () => T;
      G.taste = { n: 0, cnt: 0, day: '' };
      const expV = cv() + 0.002 * ti(); const v = tapValue();
      const c0 = G.cash; tap(null); const gain = G.cash - c0;
      const o = { expV, v, gain };
      // 29回目までは試飲会なし、30回目で評判+1・注文が30分早まる
      G.taste = { n: 0, cnt: 0, day: tasteToday() };
      const rep0 = G.reputation; const clk0 = G.orderClock = Date.now() + 5 * 3600000;
      for (let i = 0; i < 29; i++) tap(null);
      o.before = { cnt: G.taste.cnt, n: G.taste.n, rep: G.reputation - rep0 };
      tap(null);
      o.after = { cnt: G.taste.cnt, n: G.taste.n, rep: +(G.reputation - rep0).toFixed(6), clk: (clk0 - G.orderClock) / 60000, tastings: G.stats.tastings };
      o.ui = { txt: document.getElementById('tgTxt').textContent, w: document.getElementById('tgFill').style.width };
      for (let i = 0; i < 30 * 6; i++) tap(null);
      o.cap = { cnt: G.taste.cnt, n: G.taste.n, txt: document.getElementById('tgTxt').textContent };
      T += 864e5; tasteUi();
      o.next = { cnt: tasteState().cnt, txt: document.getElementById('tgTxt').textContent };
      _acctClock = () => Date.now();
      const dp = DAILY_POOL.find(p => p.id === 'dm_taste');
      o.daily = dp ? dp.label.replace('NOT回', '2回') : '';
      const tc = document.querySelector('.tgauge .tgtxt'); o.fs = parseFloat(getComputedStyle(tc).fontSize);
      return o;
    });
    rec(82, 'タップ：1回の額＝見学ツアー額＋毎時の外販収入×0.2%', Math.abs(r.v - r.expV) < 1e-9 && Math.abs(r.gain - r.v) < 1e-6 && r.v > 0, JSON.stringify({ v: r.v, expV: r.expV, gain: r.gain }));
    rec(83, '試飲会：30回で評判+1・次の注文が30分早まる・1日5回まで・日が変わると再開・ゲージ表示とデイリー', r.before.cnt === 0 && r.before.n === 29 && r.before.rep === 0 && r.after.cnt === 1 && r.after.n === 0 && Math.abs(r.after.rep - 1) < 1e-6 && Math.abs(r.after.clk - 30) < 0.01 && r.ui.txt.includes('0/30') && r.ui.txt.includes('1/5') && r.cap.cnt === 5 && r.cap.txt.includes('本日終了') && r.next.cnt === 0 && r.next.txt.includes('0/5') && r.daily === '試飲会を2回開く' && r.fs >= 12, JSON.stringify(r));
    if (errors.length) rec('E41', '試飲会テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #84-86 決算書：3表のつながり・現金の照合・原価の流れ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let T = Date.now(); _acctClock = () => T;
      G.acct = null; acctEnsure();
      const tol = v => Math.max(1, Math.abs(v) * 1e-9);
      const checks = []; const chk = tag => { const s = acctLive(); checks.push({ tag, na: naOf(s.c) - naOf(s.o) - s.ni, cash: s.c.cash - s.o.cash - s.opcf - s.invcf, unex: s.unex, tolv: tol(s.c.cash) }); };
      // 原価の流れ：樽に詰める → 瓶詰め → 直販
      G.tank = 5000; G.cash = Math.max(G.cash, 1e7); acctEnsure();
      const bA = acctBAvg(); const cc = caskCost('bourbon', 'hogshead');
      const c0 = G.cash; fillCask('bourbon', 'hogshead', false); const lot = G.lots[G.lots.length - 1];
      const fillOk = Math.abs(c0 - G.cash - cc) < 1e-6 && Math.abs(lot.c - (250 * bA + cc)) < 1e-6;
      chk('fill');
      lot.age = 12; const pid = lotProducts(lot)[0] || 'glenlivid'; if (!G.uw.includes(pid)) G.uw.push(pid);
      const lc0 = lot.c, L0 = lot.L; const n = 20; const unit = btlUnit(); const c1 = G.cash;
      const okB = botStart(pid, n, 'manual', [lot.id], {}); const q = G.bq[G.bq.length - 1];
      const matOk = okB && Math.abs(c1 - G.cash - unit * n) < 1e-6;
      const drawOk = Math.abs((lc0 - lot.c) + unit * n - q.c) < 1e-6 && Math.abs((lc0 - lot.c) / lc0 - (n * BALANCE.BOTTLE_L) / L0) < 1e-9;
      botTick(3600000 * 10);
      const row = G.bottles.find(b => b.pid === pid && b.age === q.age);
      const rowC0 = row ? row.c : -1; const rowN0 = row ? row.n : 0;
      chk('bottled');
      const s0 = acctLive(); spotSell(row.id, 5, true); const s1 = acctLive();
      const saleOk = Math.abs((rowC0 - (row.c || 0)) - rowC0 * 5 / rowN0) < 1e-6 && s1.rev.spot > s0.rev.spot;
      chk('spot');
      // 所持金を動かす処理を一通り
      acOther(1e12 - G.cash); G.cash = 1e12;
      for (const f of FD) { if (!G.fac[f.id].p && isUL(f.id)) purFac(f.id); }
      upgFac('malting'); upgClick(); purchaseRegion(Object.keys(REGIONS).find(id => !G.regions[id]) || 'x');
      const rx = REGIONS_EX.find(x => !G.regionsEx.includes(x.id)); if (rx) buyExRegion(rx.id);
      const rk = RAW_MATERIALS.grain.find(x => !G.recipeOwned.includes(x.id)); if (rk) rcpBuy('grain', rk.id);
      barleyBuyFull(); sellNewmake(100); if (G.lots.length > 3) sellLot(G.lots[0].id);
      applyEventEffect({ type: 'x', effect: { cash: -12345 } }); applyEventEffect({ type: 'x', effect: { cashMult: 1.01 } }); applyEventEffect({ type: 'x', effect: { cashBonus: '2h' }, icon: '' });
      for (let i = 0; i < 10; i++) tap(null);
      for (let i = 0; i < 36; i++) { T += 100000; prodTick(100000); lotTick(100000); botTick(100000); }
      const ol = G.lots.find(l => l.age >= 2 && typeof finishable === 'function' && finishable(l)); if (ol) lotFinish(ol.id, 'sherry');
      chk('ops');
      const dep0 = acctLive().dep;
      // 月をまたぐ
      const fa0 = faNBV(acctMonthF(T)); const faHalf = faNBV(acctMonthF(T) + V45.FA_MONTHS / 2);
      const mBefore = G.acct.cur.m; T += 40 * 864e5; acctEnsure(); const rec0 = G.acct.hist[0];
      chk('newmonth');
      const chain = Math.abs(naOf(rec0.c) - naOf(G.acct.cur.o)) < 1e-6 && Math.abs(rec0.c.cash - G.acct.cur.o.cash) < 1e-6;
      const recOk = Math.abs(naOf(rec0.c) - naOf(rec0.o) - rec0.ni) < tol(rec0.c.cash) && Math.abs(rec0.c.cash - rec0.o.cash - rec0.opcf - rec0.invcf) < tol(rec0.c.cash) && Math.abs(rec0.unex) < tol(rec0.c.cash) && rec0.m === mBefore && rec0.to === mBefore + 1;
      // 償却：耐用年数（実時間10日）で簿価0
      const faEnd = faNBV(acctMonthF(T));
      _acctClock = () => Date.now();
      return { checks, fillOk, matOk, drawOk, saleOk, chain, recOk, rec0: { m: rec0.m, to: rec0.to, R: rec0.R, ni: rec0.ni, dep: rec0.dep, cogs: rec0.cogs, unex: rec0.unex }, dep0, fa0, faHalf, faEnd, cats: Object.keys(rec0.rev).filter(k => rec0.rev[k] > 0).join(',') + '|' + Object.keys(rec0.pur).filter(k => rec0.pur[k] > 0).join(',') + '|' + Object.keys(rec0.sga).filter(k => rec0.sga[k] > 0).join(',') };
    });
    const bad = r.checks.filter(c => Math.abs(c.na) > c.tolv || Math.abs(c.cash) > c.tolv || Math.abs(c.unex) > c.tolv);
    rec(84, '決算書：どの時点でも「期首純資産＋純利益＝期末純資産」「期首現金＋営業CF＋投資CF＝期末現金」、月をまたぐと前月が確定し翌月の期首につながる・設備は実時間10日で償却', bad.length === 0 && r.chain && r.recOk && r.fa0 > 0 && r.faHalf > r.fa0 * 0.3 && r.faHalf < r.fa0 * 0.7 && r.faEnd < 1e-6, JSON.stringify({ bad, chain: r.chain, recOk: r.recOk, rec0: r.rec0, fa0: r.fa0, faHalf: r.faHalf, faEnd: r.faEnd }));
    rec(85, '現金の照合：所持金を動かす全処理に科目が付き、科目のない増減が0', r.checks.every(c => Math.abs(c.unex) <= c.tolv) && r.cats.includes('spot') && r.cats.includes('tap') && r.cats.includes('ext') && r.cats.includes('lot') && r.cats.includes('barley') && r.cats.includes('cask') && r.cats.includes('bottle') && r.cats.includes('rcp') && r.cats.includes('rg'), JSON.stringify({ cats: r.cats, unex: r.checks.map(c => c.tag + ':' + c.unex) }));
    rec(86, '原価：樽＝新酒（大麦単価）＋樽代、瓶詰めで使った量の割合だけ原価が移り資材費が加わる、売れた分だけ在庫の原価が減る', r.fillOk && r.matOk && r.drawOk && r.saleOk, JSON.stringify({ fillOk: r.fillOk, matOk: r.matOk, drawOk: r.drawOk, saleOk: r.saleOk }));
    if (errors.length) rec('E42', '決算書テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #87 瓶の資材費 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = {};
      o.unit = btlUnit(); o.expUnit = 8 * distMult();
      const l = G.lots.find(x => x.age >= 12) || G.lots[0]; const pid = lotProducts(l)[0];
      G.stats.freeBtl = 1; G.bq = []; G.cash = o.unit * 10 - 1;
      const n0 = G.bq.length; o.fail = !botStart(pid, 10, 'manual', [l.id], {}) && G.bq.length === n0;
      G.cash = o.unit * 10 + 5; o.ok = botStart(pid, 10, 'manual', [l.id], {}) && Math.abs(G.cash - 5) < 1e-6;
      // 最初の1回は無料
      G.stats.bottled = 0; G.stats.freeBtl = 0; G.bq = []; G.cash = 0;
      o.free = btlFreeAvail() && botStart(pid, 10, 'manual', [l.id], {}) && G.cash === 0 && G.stats.freeBtl === 1 && !btlFreeAvail();
      switchTab('tsale'); _ui.sellTab = 'ord'; rShip();
      o.bqTxt = document.querySelector('#bqBox .plv') ? document.querySelector('#bqBox .plv').textContent : '';
      const od = G.orders.find(x => x.kind === 'product' && !ordMatch(x).ok && ordFulfillPlan(x).ok);
      if (od) { openOrderInfoModal(od.id); o.modal = document.getElementById('mc2').textContent; closeM(); }
      return o;
    });
    rec(87, '瓶の資材：瓶詰めの開始時に本数×$8×Tier倍率を払う・足りなければ始まらない・最初の1回は無料・売るタブと注文の詳細に表示', Math.abs(r.unit - r.expUnit) < 1e-9 && r.fail && r.ok && r.free && r.bqTxt.includes('/本') && (!r.modal || (r.modal.includes('瓶の資材') && r.modal.includes('差し引き'))), JSON.stringify(r));
    if (errors.length) rec('E43', '資材費テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #88-89 寝かせる：①→③の流れ・樽の見た目 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('tcel'); rCellar();
      const ids = [...document.getElementById('tcel').children].filter(e => e.getClientRects().length).map(e => e.id || e.className);
      const ys = ['celTank', 'fillBox', 'whSummary'].map(id => document.getElementById(id).getBoundingClientRect().top);
      const nos = ['celTank', 'fillBox', 'whSummary'].map(id => (document.querySelector('#' + id + ' .cno') || {}).textContent);
      const cells = [...document.querySelectorAll('#whSummary .ck2[data-id]')];
      const bad = [];
      cells.forEach(c => { const l = G.lots.find(x => x.id === c.dataset.id); const band = c.querySelector('.ckb'); const pct = c.querySelector('[data-lpct]').textContent; const g = parseFloat(c.querySelector('[data-lpg]').style.height);
        if (!band.classList.contains('ct-' + l.cask) || !band.textContent.startsWith(CT_LETTER[l.cask]) || c.querySelector('.cks b').textContent !== SZ_LETTER[l.size] || pct !== Math.round(l.L / l.L0 * 100) + '%' || Math.abs(g - l.L / l.L0 * 100) > 0.06) bad.push(l.id); });
      const cols = getComputedStyle(document.querySelector('#whSummary .whg2')).gridTemplateColumns.split(' ').length;
      const price = document.querySelector('#fillBox .cp1').textContent; const cc = fmt(caskCost(G.auto.fill.cask, G.auto.fill.size));
      const bgs = new Set(cells.map(c => getComputedStyle(c.querySelector('.ckb')).backgroundColor));
      // 熟成で残量が減ると表示も減る
      const l0 = G.lots[0]; const p0 = l0.L / l0.L0; lotTick(864e5 * 2); rCellarLight();
      const c0 = document.querySelector(`[data-lpct="${l0.id}"]`).textContent; const p1 = l0.L / l0.L0;
      return { ids, ys, nos, n: cells.length, lots: G.lots.length, bad, cols, price, cc, dec: p1 < p0, c0, exp: Math.round(p1 * 100) + '%', types: new Set(G.lots.map(l => l.cask)).size, bgs: bgs.size, key: document.querySelector('#whSummary .whkey').textContent };
    });
    rec(88, '寝かせる：上から「① タンクの新酒 → ② 空き樽を仕入れて詰める（仕入れ値を表示）→ ③ 倉庫」を流れる矢印でつなぐ', r.ids.join() === 'thead,celJnl,celTank,celF1,fillBox,celF2,whSummary' && r.ys[0] < r.ys[1] && r.ys[1] < r.ys[2] && r.nos.join() === '①,②,③' && r.price.includes(r.cc), JSON.stringify(r));
    rec(89, '倉庫の樽：色の帯と頭文字で種類・文字でサイズ・液面と％で残量（エンジェルズシェアで減る）・4列', r.n === r.lots && r.bad.length === 0 && r.cols === 4 && r.dec && r.c0 === r.exp && r.bgs === r.types && r.key.includes('残量'), JSON.stringify({ n: r.n, bad: r.bad, cols: r.cols, c0: r.c0, exp: r.exp, bgs: r.bgs, types: r.types }));
    if (errors.length) rec('E44', '寝かせるテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #90 決算書の画面 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let T = Date.now(); _acctClock = () => T;
      G.acct = null; acctEnsure(); G.cash += 1; for (let i = 0; i < 20; i++) tap(null);
      for (let i = 0; i < 36; i++) { T += 100000; prodTick(100000); }
      upgFac('malting');
      T += 35 * 864e5; acctEnsure(); for (let i = 0; i < 5; i++) tap(null);
      switchTab('te'); _ui.encTab = 'r'; renc(); const badge = document.querySelector('#recList .frec') ? '記録' : '';
      document.querySelector('#recList .frec').click(); await new Promise(r => setTimeout(r, 80));
      const o = { badge, title: document.getElementById('mc2').textContent.includes('決算書') };
      const box = () => { const cols = [...document.querySelectorAll('#finBox .fmain .fcol')].map(c => [...c.children].reduce((a, e) => a + e.getBoundingClientRect().height, 0)); return cols.map(Math.round); };
      o.views = {};
      for (const v of ['pl', 'bs', 'cf']) { document.querySelector(`#finBox [data-act="fsView"][data-v="${v}"]`).click(); await new Promise(r => setTimeout(r, 30)); o.views[v] = { cols: box(), rows: document.querySelectorAll('#finBox .frw').length, per: document.querySelector('#finBox .fper').textContent }; }
      // 面積（高さ）が金額に比例：PLの売上高の箱
      document.querySelector('#finBox [data-act="fsView"][data-v="pl"]').click(); await new Promise(r => setTimeout(r, 30));
      const p = finPeriods()[0]; const rev = document.querySelector('#finBox .fmain .b-rev'); const H = 190;
      const tot = Math.max(p.R, p.cogs + p.S + p.dep + Math.max(0, p.ni)); o.revH = rev ? rev.getBoundingClientRect().height : 0; o.revExp = p.R / tot * H;
      document.querySelector('#finBox [data-act="fsPrev"]').click(); await new Promise(r => setTimeout(r, 30));
      o.prevPer = document.querySelector('#finBox .fper').textContent;
      const mc = document.getElementById('mc2'); o.hscroll = mc.scrollWidth - mc.clientWidth;
      o.small = [...document.querySelectorAll('#finBox *')].filter(e => e.childNodes.length && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize) < 12).map(e => e.textContent.slice(0, 10));
      closeM(); o.badgeAfter = document.getElementById('hi_fin') ? 'x' : '';
      _acctClock = () => Date.now();
      return o;
    });
    const eq = c => c.length === 2 && Math.abs(c[0] - c[1]) <= 3;
    rec(90, '決算書の画面：図鑑の「記録」から開き、PL・BS・CFを切り替えてボックス図（左右の合計が一致・高さが金額に比例）と数字の表・月の切替', r.badge === '記録' && r.title && eq(r.views.pl.cols) && eq(r.views.bs.cols) && eq(r.views.cf.cols) && Math.abs(r.revH - r.revExp) <= 2 && r.views.pl.per.includes('途中経過') && r.prevPer.includes('確定') && r.hscroll <= 0 && r.small.length === 0 && r.badgeAfter === '', JSON.stringify(r));
    if (errors.length) rec('E45', '決算書画面テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #91 schema 10 → 11 の移行 ----------
  {
    const p0 = await page43(667, null, 'mid');
    const v10 = await p0.page.evaluate(() => { const s = JSON.parse(JSON.stringify(G)); s.ver = 10; delete s.acct; delete s.taste; delete s.stats.freeBtl; delete s.stats.tastings; if (s.hs) { delete s.hs.fin; delete s.hs.new45; } s.lots.forEach(l => delete l.c); s.bottles.forEach(b => delete b.c); s.bq.forEach(q => delete q.c); s.tut.done = { first: true }; s.tut.q = []; return s; });
    await p0.ctx.close();
    const pre = `if(!sessionStorage.getItem('w')){sessionStorage.setItem('w','1');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v10))});}`;
    const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.addInitScript(pre);
    await page.goto(FILE); await page.waitForTimeout(1500);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(500);
    const r = await page.evaluate(() => {
      if (_offlineGate) closeOfflineModal();
      acctEnsure(); const s = acctLive(); const a = G.acct;
      return { ver: G.ver, bk: !!localStorage.getItem('we_v4_bak10:guest'), mig: a.mig, faMig: a.faMig, faEst: faEstimate(), cap: a.cap, na0: naOf(a.cur.o), free: G.stats.freeBtl, lotsC: G.lots.every(l => l.c > 0), q: G.tut.q.slice(), new45: G.hs.new45, unex: s.unex, dNA: naOf(s.c) - naOf(s.o) - s.ni };
    });
    rec(91, 'v4.4（schema10）からの移行：バックアップ・設備はこれまでの費用から推計・開始時のBSは資産＝元入金・瓶の無料分は使用済み・変更点の案内', r.ver === SCHEMA && r.bk && r.mig && r.faMig > 0 && Math.abs(r.faMig - r.faEst) / r.faEst < 0.001 && Math.abs(r.cap - r.na0) < 1e-6 && r.free === 1 && r.lotsC && r.q.includes('u45') && r.new45 === 0 && Math.abs(r.dNA) < Math.max(1, r.cap * 1e-9), JSON.stringify(r));
    if (errors.length) rec('E46', '移行テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #92 放置中に月をまたぐ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      // 帳簿を「先月」から始めたことにする
      const now = Date.now(); _acctClock = () => now - 20 * 864e5; G.acct = null; acctEnsure(); const m0 = G.acct.cur.m;
      for (let i = 0; i < 10; i++) tap(null);
      const cashBefore = G.cash;
      _acctClock = () => Date.now();
      G.ls = now - 6 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      const h = G.acct.hist[0]; const s = acctLive();
      const tol = Math.max(1, Math.abs(G.cash) * 1e-9);
      return { m0, hm: h && h.m, curm: G.acct.cur.m, closedCash: h && h.c.cash, cashBefore, offRev: s.R, okH: h && Math.abs(naOf(h.c) - naOf(h.o) - h.ni) < tol, okS: Math.abs(naOf(s.c) - naOf(s.o) - s.ni) < tol && Math.abs(s.unex) < tol };
    });
    const sameMonth = r.m0 === r.curm;
    rec(92, '放置中に月をまたいでも、前の月は放置前の状態で確定し、放置中の収益は戻った月に計上される', sameMonth || (r.hm === r.m0 && Math.abs(r.closedCash - r.cashBefore) < 1e-6 && r.offRev > 0 && r.okH && r.okS), JSON.stringify(r));
    if (errors.length) rec('E47', '放置の月またぎテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #93 再創業で事業を区切る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      acctEnsure(); for (let i = 0; i < 10; i++) tap(null);
      const per0 = G.acct.per; const R0 = acctLive().R;
      G.cash = Math.max(G.cash, PRESTIGE_COST + 1); G.dl = DL.length;
      try { execPrestige(null, 'speyside'); } catch (e) { return { err: String(e) }; }
      if (_offlineGate) closeOfflineModal(); closeM();
      for (let i = 0; i < 3; i++) tap(null);
      const a = G.acct;
      return { per0, per1: a.per, prev: a.prev.length, prevR: a.prev[0] && a.prev[0].R, R0, cap: a.cap, hist: a.hist.length };
    });
    rec(93, '再創業：決算書は新しい期として始まり、前の事業の合計が残る', !r.err && r.per1 === r.per0 + 1 && r.prev >= 1 && r.prevR >= r.R0 - 1e-6 && r.hist === 0 && r.cap > 0, JSON.stringify(r));
    if (errors.length) rec('E48', '再創業テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #94 v4.5.1 Tier4の評判条件・償却期間 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => ({ rep4: DL_REQ[3].rep, rep5: DL_REQ[4].rep, days: V45.FA_DAYS, lifeM: V45.FA_MONTHS, tier: (() => { G.dl = 3; return tierReqStatus(4).find(o => o.label === '評判').need; })() }));
    rec(94, 'v4.5.1：Tier4の評判条件は200（Tier5の240より小さい）・設備の耐用年数は実時間10日', r.rep4 === 200 && r.rep5 > r.rep4 && r.tier === 200 && r.days === 10 && Math.abs(r.lifeM - 10 / 30.4375) < 1e-12, JSON.stringify(r));
    if (errors.length) rec('E49', 'v4.5.1テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.6 追加テスト =================
  // ---------- #95-96 樽の大きさ・押せる範囲・タップの反応・見学ツアーの費用 ----------
  {
    const out = {};
    for (const [W, H] of [[393, 760], [390, 667]]) {
      const ctx = await browser.newContext({ viewport: { width: W, height: H } });
      const page = await ctx.newPage();
      await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
      await page.goto(FILE); await page.waitForTimeout(1000);
      await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(300);
      out[W + 'x' + H] = await page.evaluate(async () => {
        if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
        switchTab('td'); await new Promise(r => setTimeout(r, 200));
        const bb = document.getElementById('bb').getBoundingClientRect(); const st = document.getElementById('stage').getBoundingClientRect();
        const pad = getComputedStyle(document.getElementById('bb'), '::before'); const inset = pad.inset || pad.top;
        // 押せる範囲：絵の外側10pxも樽
        const hitOut = document.elementFromPoint(bb.left - 10, bb.top + bb.height / 2); const padHit = !!(hitOut && hitOut.closest && hitOut.closest('#bb'));
        const img = document.getElementById('bottleImg'); const ring = document.getElementById('tring');
        const res = []; for (let i = 0; i < 3; i++) { const h0 = Number(img.dataset.hit || 0), g0 = Number(ring.dataset.hit || 0); tap(null); const an = img.getAnimations ? img.getAnimations().length : 1; res.push(Number(img.dataset.hit) === h0 + 1 && Number(ring.dataset.hit) === g0 + 1 && an >= 1); await new Promise(r => setTimeout(r, 40)); }
        const over = document.getElementById('td').scrollHeight - document.getElementById('td').clientHeight;
        return { h: Math.round(bb.height), stageH: Math.round(st.height), padHit, fx: res.every(Boolean), over };
      });
      await ctx.close();
    }
    const a = out['393x760'], b = out['390x667'];
    rec(95, '樽：393×760で高さ300px・390×667で景色−70px・絵の外16pxまで押せる・押すたびに沈んで光る（連打でも毎回）・ホームは1画面', a.h === 300 && Math.abs(b.h - (b.stageH - 70)) <= 1 && a.padHit && b.padHit && a.fx && b.fx && a.over <= 0 && b.over <= 0, JSON.stringify(out));
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => { const o = []; for (const [dl, cl] of [[1, 0], [1, 3], [2, 4], [2, 7], [3, 8], [3, 9]]) { G.dl = dl; G.cl = cl; o.push(cuc()); } G.dl = 1; G.cl = 4; o.push(cuc()); return o; });
    const exp = [12000, 127776, 773302, 8229000, 39510000, 86920000];
    rec(96, '見学ツアーの費用＝$12,000×2.2^Lv×Tier倍率（上限Lvでは強化不可）', r.slice(0, 6).every((v, i) => Math.abs(v - exp[i]) / exp[i] < 0.002) && r[6] === Infinity, JSON.stringify(r));
    if (errors.length) rec('E50', '樽・ツアーのテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #97 造る・寝かせる・売るに三角の矢印がない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      for (const t of ['tb', 'tcel', 'tsale']) { switchTab(t); if (t === 'tsale') { _ui.sellTab = 'ord'; rShip(); } await new Promise(r => setTimeout(r, 120));
        const fl = [...document.querySelectorAll('#' + t + ' .pflow')]; o[t] = { n: fl.length, tri: fl.filter(e => getComputedStyle(e, '::after').display !== 'none').length, band: fl.filter(e => e.querySelector('.pband')).length }; }
      return o;
    });
    rec(97, '造る・寝かせる・売る：工程の間は動く帯だけ（三角の矢印なし）', Object.values(r).every(x => x.n >= 2 && x.tri === 0 && x.band === x.n), JSON.stringify(r));
    if (errors.length) rec('E51', '矢印テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #98-99 売る：①→②→③・用意の状況・推奨 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = G.orders.find(x => x.kind === 'product' && ordUsable(x) && !ordMatch(x).ok && ordFulfillPlan(x).ok);
      if (o) ordFulfill(o.id);
      switchTab('tsale'); _ui.sellTab = 'ord'; rShip(); await new Promise(r => setTimeout(r, 120));
      const ids = [...document.getElementById('sp_ord').children].filter(e => e.getClientRects().length).map(e => e.id);
      const nos = ['bqBox', 'stockRow'].map(id => (document.querySelector('#' + id + ' .cno') || {}).textContent);
      const bq = G.bq[0]; const bqTxt = bq ? (document.querySelector(`[data-bqd="${bq.id}"]`) || {}).textContent : '';
      const bqExp = bq ? fmtN(Math.floor(bq.done)) + '/' + fmtN(bq.n) + '本' : '';
      const bad = [];
      G.orders.forEach(x => { const el = document.querySelector(`[data-ordq="${x.id}"]`); const rd = ordReady(x); if (!el || el.textContent !== rd.txt) bad.push(x.id);
        if (x.kind === 'product' || x.kind === 'type') { const m = ordMatch(x); const ip = G.bq.filter(q => q.oid === x.id).reduce((a, q) => a + q.n - (q.moved || 0), 0); if (rd.have !== Math.min(x.qty, m.have) || rd.ip !== Math.min(ip, x.qty - rd.have)) bad.push('v' + x.id); } });
      const stock = document.querySelector('#stockRow .vv').textContent; const stockExp = fmtN(G.bottles.reduce((a, b) => a + b.n, 0)) + '本';
      // 推奨：詰めて納品と同じ銘柄・足りない本数
      const recs = ordRecs(); const recOk = recs.every(x => { const pl = ordFulfillPlan(x.o); return pl.ok && pl.pid === x.pid && x.n === x.o.qty - ordMatch(x.o).have && pl.minAge === x.minAge; });
      openBottleModal(''); const mt = document.getElementById('mc2');
      const rec0 = recs[0]; const modalOk = !rec0 || (mt.querySelectorAll('.brr').length === recs.length && _ui.bot.pid === rec0.pid && _ui.bot.n === rec0.n && _ui.bot.minAge === rec0.minAge && mt.querySelector('select option').textContent.startsWith('★注文'));
      closeM();
      return { ids, nos, bqTxt, bqExp, bad, stock, stockExp, recN: recs.length, recOk, modalOk };
    });
    rec(98, '売る：上から「① 瓶詰め → ② 瓶の在庫 → ③ 注文」、瓶詰めは何本できたか、注文ごとに用意の本数（在庫・瓶詰め中）が内部の数と一致', r.ids.join() === 'bqBox,sellF1,stockRow,sellF2,orderBoard,orderNext' && r.nos.join() === '①,②' && r.bqTxt === r.bqExp && r.bad.length === 0 && r.stock === r.stockExp, JSON.stringify(r));
    rec(99, '在庫に詰める：注文に足りない銘柄を「詰めて納品」と同じ選び方で推奨し、本数と年数条件を入れて開く', r.recOk && r.modalOk, JSON.stringify({ recN: r.recN, recOk: r.recOk, modalOk: r.modalOk }));
    if (errors.length) rec('E52', '売るテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #100 読み物は中央・決算書は図鑑の記録 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('te'); const s = STORY_EPISODES[0].id; if (!G.story.unlocked.includes(s)) G.story.unlocked.push(s); openStoryModal(s); await new Promise(r => setTimeout(r, 80));
      const mb = document.querySelector('#mo .mb').getBoundingClientRect(); const cy = mb.top + mb.height / 2; const story = { cy: Math.round(cy), vh: innerHeight, close: !!document.querySelector('#mc2 [data-act="closeM"]') };
      closeM(); const after = document.getElementById('mo').classList.contains('ctr');
      openOrderInfoModal(G.orders[0].id); const mb2 = document.querySelector('#mo .mb').getBoundingClientRect(); const sheet = Math.round(innerHeight - mb2.bottom); closeM();
      openTip('order'); const tip = document.getElementById('mo').classList.contains('ctr'); closeM();
      _ui.encTab = 'r'; renc(); const card = document.querySelector('#recList .frec'); const first = document.getElementById('recList').firstElementChild === card;
      card.click(); await new Promise(r => setTimeout(r, 60)); const fin = document.getElementById('mc2').textContent.includes('決算書') && !!document.getElementById('finBox'); closeM();
      switchTab('td'); rdistLight(); const icons = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id).join();
      return { story, after, sheet, tip, first, fin, icons };
    });
    rec(100, '物語・ヒント・会話の小窓は画面中央（閉じるボタン付き）、操作の小窓は下から・決算書は図鑑の記録の先頭から開き、ホームのアイコンは章・デイリー・市場・Tier・砂時計', Math.abs(r.story.cy - r.story.vh / 2) <= 24 && r.story.close && !r.after && r.sheet <= 1 && r.tip && r.first && r.fin && r.icons.replace(',hi_staff', '') === 'hi_chap,hi_daily,hi_mkt,hi_tier,hi_hg', JSON.stringify(r));
    if (errors.length) rec('E53', '小窓テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #101-102 放置24時間・報告の出し直し・タイトル省略・記録 ----------
  {
    const p0 = await page43(667, null, 'mid');
    const r0 = await p0.page.evaluate(() => {
      if (_offlineGate) closeOfflineModal(); closeM(); Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = [];
      const f = prodFlows(); barleyState().auto = true; G.cash = 1e9; const te0 = G.te; G.ls = Date.now() - 30 * 3600000; offline();
      const shown = _offlineGate; const txt = document.getElementById('mc2').textContent; const pend = offRepGet();
      return { cap: BALANCE.OFFLINE_CAP_H, shown, cap24: txt.includes('24時間分'), pend: !!pend && pend.elapsedMs > 29 * 3600000, notice: txt.includes('20歳未満') };
    });
    // 報告を閉じずに再読込 → 起動時に出し直す・タイトルは出さない
    await p0.page.evaluate(() => { save(); });
    await p0.page.reload(); await p0.page.waitForTimeout(1600);
    const r1 = await p0.page.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), titleDone: _titleDone, gate: _offlineGate, txt: document.getElementById('mc2').textContent.includes('おかえり'), diag: diagText() }));
    await p0.page.evaluate(() => { closeOfflineModal(); save(); });
    const r2 = await p0.page.evaluate(() => ({ pend: offRepGet(), bug: bugReportText().includes('起動と保存の記録') }));
    await p0.page.reload(); await p0.page.waitForTimeout(1600);
    const r3 = await p0.page.evaluate(() => ({ gate: _offlineGate }));
    await p0.ctx.close();
    rec(101, '放置：生産は24時間分まで・報告は閉じるまで保存し、再読込でも出し直す（閉じたら出ない）・注意書き付き', r0.cap === 24 && r0.shown && r0.cap24 && r0.pend && r0.notice && r1.gate && r1.txt && r2.pend === null && !r3.gate, JSON.stringify({ r0, r1: { gate: r1.gate, txt: r1.txt }, r3 }));
    rec(102, '2回目以降の起動はタイトル画面を出さずホームから・起動と保存の記録を「不具合を報告」に表示', !r1.title && r1.titleDone && /load/.test(r1.diag) && /offline/.test(r1.diag) && r2.bug, JSON.stringify({ title: r1.title, diag: r1.diag }));
    const ctx4 = await browser.newContext({ viewport: { width: 390, height: 667 } }); const pg4 = await ctx4.newPage();
    await pg4.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort()); await pg4.goto(FILE); await pg4.waitForTimeout(1500);
    const r4 = await pg4.evaluate(() => ({ title: !document.getElementById('title').classList.contains('h'), done: _titleDone }));
    rec('102b', '新しく始める人にはタイトル画面を出す', r4.title && !r4.done, JSON.stringify(r4));
    await ctx4.close();
  }
  // ---------- #103 熟成の砂時計 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.hg = { n: 0, got: 0, used: 0 };
      const a = [hgAdd(1, 't'), hgAdd(1, 't'), hgAdd(1, 't'), hgAdd(1, 't'), hgAdd(1, 't'), hgAdd(1, 't')]; const n3 = G.hg.n;
      // デイリー全達成・章の目標で入手
      G.hg.n = 0; G.daily.allCleared = false; G.daily.missions.forEach(m => { m.done = false; G._dmProgress[m.id] = m.target; }); tickDailyMissions(); const daily = G.hg.n;
      G.hg.n = 0; const c = chapCur(), st = chapState(); c.goals.forEach(g => { delete st.done[g.id]; }); G.stats.shipped = 1e9; G.stats.orders = 1e6; G.stats.filled = 1e6; checkChapters(); const chap = G.hg.n;
      // 使う：1時間分進む（熟成・注文の期限）
      G.hg.n = 1; const l = G.lots[0]; const age0 = l.age; const due0 = G.orders[0] ? G.orders[0].dueAt : 0; const now = Date.now();
      const due1h = G.orders.filter(o => o.dueAt - now <= 3600000 && (!o.reserve || o.accepted)).length;
      openHgModal(); const warn = document.getElementById('mc2').textContent.includes('期限が1時間以内'); closeM();
      const ok = hgUse(); const title = document.getElementById('mc2').textContent; const dAge = l.age - age0; const dDue = G.orders[0] ? due0 - G.orders[0].dueAt : 3600000;
      const pend = offRepGet(); if (_offlineGate) closeOfflineModal();
      const none = hgUse();
      return { a, n3, daily, chap, ok, used: G.hg.used, dAge, rate: agingRate(l) / 24, dDue, title: title.includes('1時間進めました'), pend, none, warn, due1h, icon: document.querySelector('#hi_hg .hib') ? document.querySelector('#hi_hg .hib').textContent : '' };
    });
    rec(103, '砂時計：デイリー全達成・章の目標で1個ずつ・5個まで・1個で1時間分（熟成と注文の期限が1時間進む）・期限が近い注文を警告・報告は保存しない', r.a.join() === 'true,true,true,true,true,false' && r.n3 === 5 && r.daily >= 1 && r.chap >= 1 && r.ok && r.used === 1 && Math.abs(r.dAge - r.rate) / r.rate < 0.02 && Math.abs(r.dDue - 3600000) < 5000 && r.title && r.pend === null && r.none === false && (r.due1h === 0 || r.warn), JSON.stringify(r));
    if (errors.length) rec('E54', '砂時計テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #104 v4.6.1 造る・寝かせる・売るの背景の絵 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      const o = {};
      for (const t of ['td', 'tb', 'tcel', 'tsale', 'te']) { switchTab(t); await new Promise(r => setTimeout(r, 60)); const el = document.getElementById('tabBg'); const cs = getComputedStyle(el); o[t] = { on: el.classList.contains('on'), time: el.classList.contains('t-' + sceneTime()), img: /data:image\/webp/.test(cs.backgroundImage), disp: cs.display }; }
      return o;
    });
    const ok = ['tb', 'tcel', 'tsale'].every(t => r[t].on && r[t].time && r[t].img && r[t].disp === 'block') && ['td', 'te'].every(t => !r[t].on && r[t].disp === 'none');
    rec(104, '造る・寝かせる・売るの背景にそれぞれの絵を表示し、時間帯の段階をホームと同じにする（ホーム・図鑑には出さない）', ok, JSON.stringify(r));
    if (errors.length) rec('E55', '背景テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #105 v4.6.3 ファイルサイズの削減（画像の再圧縮・最小化・未使用関数の削除） ----------
  {
    const fs = require('fs');
    const dist = fs.readFileSync('whisky_empire.html', 'utf8');
    const dev = fs.existsSync('whisky_empire.dev.html') ? fs.readFileSync('whisky_empire.dev.html', 'utf8') : '';
    const main = h => [...h.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]).reduce((a, b) => (b.length > a.length ? b : a), '');
    const liff = h => (h.match(/<script id="liff-config">[\s\S]*?<\/script>/) || [''])[0];
    const DEAD = ['sceneSvg', 'sndKnock', 'chapCardHtml', 'finNew', 'modalCenter', 'upgDist', 'actAttrs', 'rTank', 'openHistModal', 'nextTicker_old', 'initTicker_old', 'sndAuction', 'toggleSound', 'getPrestigeSkillEffect', 'applyPrestigeSkills', 'currentRegion', 'exRegionMult'];
    const left = DEAD.filter(n => new RegExp('function ' + n + '\\(').test(dist) || new RegExp('function ' + n + '\\(').test(dev));
    const md = main(dist), mv = main(dev);
    const s = { bytes: Buffer.byteLength(dist), left, ratio: +(md.length / Math.max(1, mv.length)).toFixed(3), strict: /^\s*['"]use strict['"]/.test(md), liffSame: !!dev && liff(dist) === liff(dev) && liff(dist).includes('LIFF_ID') };
    const { page, errors, ctx } = await page43(667, null, 'mid');
    s.img = await page.evaluate(async () => {
      const o = {};
      for (const k of ['tb', 'tcel', 'tsale']) {
        const d = document.createElement('div'); d.className = 'tabbg bg-' + k; document.body.appendChild(d);
        const u = getComputedStyle(d).backgroundImage.match(/url\("?(data:[^")]+)"?\)/); d.remove();
        const im = new Image(); im.src = u ? u[1] : ''; try { await im.decode(); } catch (_) {}
        o[k] = im.naturalWidth;
      }
      return o;
    });
    const ok = s.bytes <= 860000 && left.length === 0 && s.ratio < 0.92 && s.strict && s.liffSame && ['tb', 'tcel', 'tsale'].every(k => s.img[k] === 800);
    rec(105, '配布版は860KB以下（v4.7〜v4.9 で各+40KBまで）：タブの背景は幅800px・JSとCSSは最小化（use strict と LIFF 設定はそのまま）・未使用の関数17個は開発版にも残っていない', ok, JSON.stringify(s));
    if (errors.length) rec('E56', 'サイズ削減テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.7 追加テスト =================
  // ---------- #106 砂時計：5個まで・1日4個まで・手段ごとに1日1個・日付で戻る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.hg = { n: 0, got: 0, used: 0 }; hgDay();
      const src = [hgAdd(1, 'l', 'login'), hgAdd(1, 'l', 'login'), hgAdd(1, 'd', 'daily'), hgAdd(1, 'd', 'daily'), hgAdd(1, 'm', 'ms'), hgAdd(1, 'm', 'ms')];
      G.hg.n = 5; const uses = []; for (let i = 0; i < 5; i++) { G.ls = Date.now(); uses.push(hgUse()); if (_offlineGate) closeOfflineModal(); }
      const afterUse = { n: G.hg.n, useDay: G.hg.useDay, left: hgLeftToday() };
      openHgModal(); const t = document.getElementById('mc2').textContent; const btn = document.querySelector('#mc2 [data-act="hgUse"]').disabled; closeM();
      off = 24 * 3600000; G.ls = rn() + off; const d2 = { left: hgLeftToday(), src: JSON.stringify(G.hg.src), again: hgAdd(1, 'l', 'login') };
      Date.now = rn;
      return { src, uses, afterUse, t: t.includes('今日使える数') && t.includes('今日の手に入れ方'), btn, d2, max: V47.HG_MAX, hgMs: V46.HG_MS };
    });
    const ok = r.src.join() === 'true,false,true,false,true,false' && r.uses.join() === 'true,true,true,true,false' && r.afterUse.n === 1 && r.afterUse.useDay === 4 && r.afterUse.left === 0 && r.t && r.btn && r.d2.left === 4 && r.d2.again === true && r.max === 5 && r.hgMs === 3600000;
    rec(106, '砂時計：1個1時間のまま・5個まで・1日4個まで使える・手段（ログイン・デイリー・熟成の節目）ごとに1日1個・日付が替わると戻る', ok, JSON.stringify(r));
    if (errors.length) rec('E57', '砂時計（v4.7）テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #107 熟成の目標：25/50/75/100%・完成で次の節目へ・進み方によらず同じ・熟成の速さは不変 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const ct = caskType('bourbon'), sz = caskSize('hogshead');
      const mk = () => makeLot(ct, sz, { c: 0 });
      const a = mk(), b = mk(); lotGoalInit(a); lotGoalInit(b);
      const g0 = [a.goal, a.gs, lotGoalPct(a)];
      const rate = agingRate(a); const Y = BALANCE.GAME_YEAR_MS / rate; // 1年ぶんの時間
      const goals0 = G.stats.goals || 0; G.hg.src.ms = 0; const hg0 = G.hg.n;
      _goalUI = [];
      // a：1時間刻みで3.2年ぶん / b：一度に3.2年ぶん
      const steps = Math.ceil(3.2 * Y / 3600000); for (let i = 0; i < steps; i++) lotAdvance(a, 3200 * Y / steps / 1000 * 1000 / 3200 * 3.2 > 0 ? 3.2 * Y / steps : 0);
      const qs = _goalUI.filter(x => x.id === a.id).map(x => x.q); _goalUI = [];
      lotAdvance(b, 3.2 * Y); const qb = _goalUI.filter(x => x.id === b.id).map(x => x.q);
      const res = { g0, qs, qb, a: [a.goal, a.gd, +a.gs.toFixed(3), !!a.gt, +a.age.toFixed(4)], b: [b.goal, b.gd, +b.gs.toFixed(3), +b.age.toFixed(4)], goals: (G.stats.goals || 0) - goals0, hg: G.hg.n - hg0, jnl: jnlCur().done.slice(-2).map(d => d.g) };
      // 熟成の速さは目標の有無で変わらない
      const c = mk(), d = mk(); delete d.goal; c.goal = 0; lotAdvance(c, 5 * Y); lotAdvance(d, 5 * Y);
      res.same = Math.abs(c.age - d.age) < 1e-9 && Math.abs(c.age - 5) < 1e-6;
      res.eta = Math.round(lotGoalEta(a) / 3600000); res.etaExp = Math.round((8 - a.age) / rate * 24);
      return res;
    });
    const ok = r.g0.join() === '3,0,0' && r.qs.join() === '0.25,0.5,0.75,1' && r.qb.join() === '1' && r.a[0] === 8 && r.a[1] === 3 && r.a[2] === 3 && r.a[3] && r.b[0] === 8 && r.b[1] === 3 && Math.abs(r.a[4] - r.b[3]) < 1e-3 && r.goals === 2 && r.hg >= 0 && r.hg <= 1 && r.jnl.join() === '3,3' && r.same && Math.abs(r.eta - r.etaExp) <= 1;
    rec(107, '熟成の目標：新しい樽は3年が目標・25/50/75/100%で演出・届くと次の節目（8年）へ・毎秒でも一度でも同じ結果・日誌に記録・熟成の速さは変わらない', ok, JSON.stringify(r));
    if (errors.length) rec('E58', '熟成の目標テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #108 樽のマス：色つや10段階・目標の輪・完成の印・小窓で目標を変える・次の目標までの時間 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('tcel');
      const l0 = G.lots[0], l1 = G.lots[1]; l0.age = 0.5; l0.goal = 3; l0.gs = 0; l1.age = 10.2; l1.goal = 12; l1.gs = 8; l1.gd = 8; l1.gt = Date.now();
      rCellar(); await new Promise(r => setTimeout(r, 50));
      const c0 = document.querySelector(`#whSummary .ck2[data-id="${l0.id}"]`), c1 = document.querySelector(`#whSummary .ck2[data-id="${l1.id}"]`);
      const o = { cls0: c0.className, cls1: c1.className, gp1: c1.querySelector('.cgr').style.getPropertyValue('--gp'), done: !!c1.querySelector('.gdn'), ca0: c0.querySelector('.ca').textContent, bg: getComputedStyle(c1).backgroundImage.includes('gradient'), next: (document.querySelector('[data-lnext]') || {}).textContent };
      openLotModal(l0.id); const mt = document.getElementById('mc2').textContent; o.modal = mt.includes('熟成の目標'); o.noDup = ![...document.querySelectorAll('#mc2 .msl')].some(e => e.textContent === '次の節目');
      const chip = [...document.querySelectorAll('#mc2 [data-act="lotGoal"]')].find(b => b.dataset.v === '8'); chip.click(); await new Promise(r => setTimeout(r, 50));
      o.setGoal = [l0.goal, +l0.gs.toFixed(2)]; closeM();
      return o;
    });
    const ok = /\bag0\b/.test(r.cls0) && /\bag4\b/.test(r.cls1) && /gdone/.test(r.cls1) && Math.abs(parseFloat(r.gp1) - 55) < 1 && r.done && r.ca0 === '0.5/3年' && r.bg && /次の目標まで あと/.test(r.next) && r.modal && r.noDup && r.setGoal[0] === 8 && r.setGoal[1] === 0.5;
    rec(108, '樽のマス：年数で色つやが10段階に変わる・左上の輪が目標までの進み具合・届いた樽に「完成」・小窓で目標を選べる・倉庫の見出しに次の目標までの時間', ok, JSON.stringify(r));
    if (errors.length) rec('E59', '樽のマステスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #109 倉庫日誌：日付が替わると前の日を1件記録・14日分・寝かせるの先頭に「新」・開くと既読・保存しても同じ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.jnl = { cur: null, list: [] }; jnlRoll(); const f0 = G.stats.filled;
      G.stats.filled += 3; G.stats.bottled += 120; G.stats.orders += 2; G.te += 5000; jnlAdd('angel', 1.5);
      const rolledSame = jnlRoll();
      off = 24 * 3600000; const rolled = jnlRoll(); const e = G.jnl.list[0];
      for (let i = 2; i <= 20; i++) { off = i * 24 * 3600000; jnlRoll(); }
      const len = G.jnl.list.length; Date.now = rn; G.ls = rn(); if (_offlineGate) closeOfflineModal();
      switchTab('tcel'); rCellar(); const card = document.getElementById('celJnl'); const newMark = card.textContent.includes('新');
      card.querySelector('.jnl').click(); await new Promise(r => setTimeout(r, 60)); const modal = document.getElementById('mc2').textContent; closeM(); rCellar();
      const newAfter = document.getElementById('celJnl').textContent.includes('新');
      const s2 = sanitize(JSON.parse(JSON.stringify(G))); const same = JSON.stringify(s2.jnl.list) === JSON.stringify(G.jnl.list);
      return { rolledSame, rolled, e: { fill: e.fill, btl: e.btl, ord: e.ord, earn: e.earn, angel: e.angel }, len, newMark, modal: modal.includes('倉庫日誌') && modal.includes('今日のここまで'), newAfter, same };
    });
    const ok = !r.rolledSame && r.rolled && r.e.fill === 3 && r.e.btl === 120 && r.e.ord === 2 && r.e.earn === 5000 && Math.abs(r.e.angel - 1.5) < 1e-9 && r.len === 14 && r.newMark && r.modal && !r.newAfter && r.same;
    rec(109, '倉庫日誌：日付が替わると前の日の出来事（詰めた樽・瓶・納品・売上・天使の分け前）を1件記録・14日分・寝かせるの先頭に「新」・開くと既読・保存しても同じ', ok, JSON.stringify(r));
    if (errors.length) rec('E60', '倉庫日誌テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #110 v4.6（schema11）からの移行・ログインボーナス・放置の報告・変更点の案内 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const old = JSON.parse(JSON.stringify(G)); old.ver = 11; old.lots.forEach(l => { delete l.goal; delete l.gs; delete l.gd; delete l.gt; }); old.hg = { n: 2, got: 4, used: 2 }; delete old.jnl; old.hs.new47 = undefined; delete old.tut.done.u47;
      const m = parseSave(old);
      const o = { ver: m.ver, goals: m.lots.every(l => typeof l.goal === 'number' && l.gs === l.age), g1: m.lots.map(l => [l.age, l.goal]).slice(0, 2), hg: m.hg.n === 2 && m.hg.day === '' && m.hg.src.login === 0, jnl: Array.isArray(m.jnl.list), new47: m.hs.new47 };
      G = m; o.tut = TUTS.u47.cond();
      G.tut.done.u47 = true; G.hs.new47 = 1;
      // ログインボーナス（案内が済んでいてタイトルの後・小窓なし）
      closeM(); G.hg.src.login = 0; G.hg.day = dayKey(); const n0 = G.hg.n; const lb = loginBonus(); const lb2 = loginBonus(); o.login = [lb, lb2, G.hg.n - n0];
      // 放置の報告に「熟成の目標に届いた樽」
      const l = G.lots[0]; l.goal = l.age + 0.2; l.gs = l.age - 0.1; G.ls = Date.now() - 10 * 3600000; offline();
      o.rep = document.getElementById('mc2').textContent.includes('熟成の目標に届いた樽'); if (_offlineGate) closeOfflineModal();
      return o;
    });
    const ok = r.ver === SCHEMA && r.goals && r.hg && r.jnl && r.new47 === 0 && r.tut && r.login.join() === 'true,false,1' && r.rep;
    rec(110, 'v4.6（schema11）からの移行：樽に目標・砂時計の日ごとの記録・日誌を用意・変更点の案内／ログインボーナスは1日1回／放置の報告に目標に届いた樽', ok, JSON.stringify(r));
    if (errors.length) rec('E61', '移行テスト（v4.7）中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.8 追加テスト =================
  // 職人を用意する（Tier と所持金を整え、候補から雇う）
  const STAFF_PREP = `(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose(); G.cash = 1e15; G.staff = []; G.staffCand = null; G.staffOff = false; prodInvalidate(); })()`;
  // ---------- #111 解放・候補者の能力の分布・求人の出し直し ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      const dl0 = G.dl; G.dl = 1; const off1 = staffOn(); v48Tick(); const btn1 = getComputedStyle(document.getElementById('btnStaff')).display;
      G.dl = 2; const on2 = staffOn(); v48Tick(); const btn2 = getComputedStyle(document.getElementById('btnStaff')).display; G.dl = dl0;
      const bad = []; const cnt = { 1: 0, 2: 0, 3: 0 }; const rg = { 1: [9, 14], 2: [13, 19], 3: [18, 24] };
      for (let i = 0; i < 600; i++) { const c = staffRoll(); cnt[c.r]++; const s = stSum(c.st); if (s < rg[c.r][0] || s > rg[c.r][1] || ST_KEYS.some(k => c.st[k] < 1 || c.st[k] > 10)) bad.push(JSON.stringify(c)); }
      const c = staffCandState(); const n = c.list.length; const h0 = G.acct.cur.sga.hire;
      const r1 = staffRefresh(); const h1 = G.acct.cur.sga.hire; const r2 = staffRefresh(); const h2 = G.acct.cur.sga.hire;
      return { off1, btn1, on2, btn2, bad: bad.slice(0, 3), cnt, n, free: [r1, h1 - h0], paid: [r2, Math.round(h2 - h1), staffRefreshCost()] };
    });
    const ok = !r.off1 && r.btn1 === 'none' && r.on2 && r.btn2 !== 'none' && r.bad.length === 0 && r.cnt[1] > r.cnt[2] && r.cnt[2] > r.cnt[3] && r.cnt[3] > 0 && r.n === 3 && r.free[0] && r.free[1] === 0 && r.paid[0] && r.paid[1] === r.paid[2];
    rec(111, '職人：Tier2で解放・候補は3人で★1〜3の能力の合計が決めた範囲（★1 9〜14・★2 13〜19・★3 18〜24、各1〜10）・求人の出し直しは1日1回無料で以降は採用費', ok, JSON.stringify(r));
    if (errors.length) rec('E62', '職人の候補テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #112 採用・定員・配置・採用費の計上 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const o = { seats: staffSeats(), cap: staffCap() };
      const c = staffCandState(); const fee = staffHireFee(c.list[0]); const h0 = G.acct.cur.sga.hire; const cash0 = G.cash;
      o.hire = staffHire(0); o.fee = [Math.round(G.acct.cur.sga.hire - h0), fee, Math.round(cash0 - G.cash)];
      o.post = G.staff[0].post; o.best = staffBestPost(G.staff[0].st);
      // 定員まで雇う
      let g = 0; while (G.staff.length < staffCap() && g++ < 40) { const cc = staffCandState(); if (!cc.list.length) { cc.free = 1; staffRefresh(); } staffHire(0); }
      o.n = G.staff.length; o.over = staffHire(0); o.perPost = POSTS.map(p => G.staff.filter(s => s.post === p.id).length);
      const idle = G.staff.find(s => !s.post); o.full = staffAssign(idle.id, 'still');
      o.moveOk = (() => { const s = G.staff.find(x => x.post === 'still'); return staffAssign(s.id, null) && staffAssign(idle.id, 'still'); })();
      openStaffModal('post'); o.ui = document.querySelectorAll('#mc2 .pst2').length; openStaffModal('list'); o.ui2 = document.querySelectorAll('#mc2 .sfc').length; openStaffModal('hire'); o.ui3 = document.getElementById('mc2').textContent.includes('求人を出し直す'); closeM();
      return o;
    });
    const ok = r.seats === 3 && r.cap === 17 && r.hire && r.fee[0] === r.fee[1] && r.fee[2] === r.fee[1] && r.post === r.best && r.n === 17 && r.over === false && r.perPost.every(v => v === 3) && r.full === false && r.moveOk && r.ui === 5 && r.ui2 === 17 && r.ui3;
    rec(112, '採用：採用費（時給24時間分）を払い、向いている持ち場に就く・定員は持ち場ごとにmin(3,Tier)人・在籍は定員+2人まで・満員の持ち場には入れない・配置/在籍/採用の画面', ok, JSON.stringify(r));
    if (errors.length) rec('E63', '採用テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #113 5つの持ち場の効果・人数による逓減・上限・熟練度・熟成の速さは不変 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post, st, lv) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st, tr: 'calm', lv: lv || 1, xp: 0, post, hired: 0, train: 0, care: '' });
      const base = { cap: stageCap(0), slots: whSlots(), board: boardSize(), bph: botRate(), nm: prodFlows().newmake, kg: prodFlows().p[0], q: staffFx('watch') };
      const l = G.lots[0]; const ar0 = agingRate(l);
      G.staff = [mk('still', { waza: 1, tegiwa: 5, mekiki: 1 })]; prodInvalidate(); const cap1 = stageCap(0) / base.cap;
      G.staff.push(mk('still', { waza: 1, tegiwa: 5, mekiki: 1 })); prodInvalidate(); const cap2 = stageCap(0) / base.cap;
      G.staff.push(mk('still', { waza: 1, tegiwa: 5, mekiki: 1 })); prodInvalidate(); const cap3 = stageCap(0) / base.cap;
      G.staff = [mk('still', { waza: 1, tegiwa: 10, mekiki: 1 }, 10), mk('still', { waza: 1, tegiwa: 10, mekiki: 1 }, 10), mk('still', { waza: 1, tegiwa: 10, mekiki: 1 }, 10)]; prodInvalidate(); const capMax = stageCap(0) / base.cap;
      G.staff = [mk('still', { waza: 1, tegiwa: 5, mekiki: 1 }, 5)]; prodInvalidate(); const capLv = stageCap(0) / base.cap;
      G.staff = [mk('buy', { waza: 1, tegiwa: 1, mekiki: 8 }), mk('fill', { waza: 1, tegiwa: 9, mekiki: 1 }), mk('watch', { waza: 10, tegiwa: 1, mekiki: 1 }), mk('ship', { waza: 1, tegiwa: 7, mekiki: 1 })]; prodInvalidate();
      const fx = { buy: staffFx('yield'), nm: prodFlows().newmake / base.nm, kg: prodFlows().p[0] / base.kg, slots: whSlots() - base.slots, q: staffFx('watch'), board: boardSize() - base.board, bph: botRate() / base.bph, ar: agingRate(l) / ar0 };
      // 大麦の使う量は同じで、とれる新酒が増える（毎秒の進行）
      const kg0 = G.barley.kg = 1e9; const f = prodFlows(); const t0 = G.tank = 0; prodTick(3600000); const used = kg0 - G.barley.kg;
      return { base: { cap: base.cap }, cap1, cap2, cap3, capMax, capLv, fx, used: Math.round(used), expUsed: Math.round(f.p[0]) };
    });
    const ok = Math.abs(r.cap1 - 1.075) < 1e-6 && Math.abs(r.cap2 - (1 + 0.015 * 5 * 1.8)) < 1e-6 && Math.abs(r.cap3 - (1 + 0.015 * 5 * 2.4)) < 1e-6 && Math.abs(r.capMax - 1.45) < 1e-6 && Math.abs(r.capLv - (1 + 0.015 * 5 * 1.4)) < 1e-6
      && Math.abs(r.fx.buy - 1.08) < 1e-9 && Math.abs(r.fx.nm - 1.08) < 1e-9 && Math.abs(r.fx.kg - 1) < 1e-9 && r.fx.slots === 3 && Math.abs(r.fx.q - 1.06) < 1e-9 && r.fx.board === 1 && Math.abs(r.fx.bph - 1.14) < 1e-9 && r.fx.ar === 1 && Math.abs(r.used - r.expUsed) <= 1;
    rec(113, '持ち場の効果：蒸留は4工程の能力（1人+1.5%×手際、2人目80%・3人目60%、上限+45%、Lvで×(1+0.1(Lv−1))）・原料調達は同じ大麦からとれる量（歩留まり、大麦の量は同じ）・樽詰めは樽の枠・熟成監視は品質・出荷は注文枠と瓶詰め・熟成の速さは変わらない', ok, JSON.stringify(r));
    if (errors.length) rec('E64', '持ち場の効果テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #114 給与：毎時計上・払えないと休業（効果なし・所持金は負にならない）・払えれば戻る・放置は24時間分・砂時計は1時間分 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post) => ({ id: uid('s'), nm: 'T', seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv: 1, xp: 0, post, hired: 0, train: 0, care: '' });
      G.staff = [mk('still'), mk('buy')]; prodInvalidate();
      const wph = staffWagesPh(); const o = { wph };
      const w0 = G.acct.cur.sga.wage; staffTick(3600000); o.hour = [G.acct.cur.sga.wage - w0, wph];
      // 払えない
      const capOn = stageCap(0); G.cash = wph * 0.25; const sw = staffTick(3600000); o.off = { flag: G.staffOff, cash: G.cash, paidH: sw.paid / wph, offH: sw.offH, cap: stageCap(0) / capOn };
      staffTick(3600000); o.stay = G.staffOff && G.cash >= 0;
      G.cash = 1e12; staffTick(1000); o.back = !G.staffOff && Math.abs(stageCap(0) - capOn) < 1e-6;
      // 放置30時間 → 24時間分、砂時計 → 1時間分
      if (_offlineGate) closeOfflineModal(); const w1 = G.acct.cur.sga.wage; G.ls = Date.now() - 30 * 3600000; offline(); o.off30 = (G.acct.cur.sga.wage - w1) / wph; o.rep = document.getElementById('mc2').textContent.includes('職人の給与'); if (_offlineGate) closeOfflineModal();
      const w2 = G.acct.cur.sga.wage; const wph2 = staffWagesPh(); G.hg.n = 1; G.hg.useDay = 0; G.ls = Date.now(); hgUse(); o.hg = (G.acct.cur.sga.wage - w2) / wph2; if (_offlineGate) closeOfflineModal();
      return o;
    });
    const ok = r.wph > 0 && Math.abs(r.hour[0] - r.hour[1]) < 1e-6 * r.wph && r.off.flag && r.off.cash >= 0 && r.off.cash < r.wph * 0.001 && Math.abs(r.off.paidH - 0.25) < 0.001 && Math.abs(r.off.offH - 0.75) < 0.001 && Math.abs(r.off.cap - 1 / 1.075) < 0.001 && r.stay && r.back && Math.abs(r.off30 - 24) < 0.01 && r.rep && Math.abs(r.hg - 1) < 0.01;
    rec(114, '給与：毎時計上・払えない分は休業（効果が止まり所持金は負にならない）・1時間分払えるようになると戻る・放置は生産と同じ24時間分・砂時計は1時間分・放置の報告に給与', ok, JSON.stringify(r));
    if (errors.length) rec('E65', '給与テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #115 熟練度・研修・解雇・再創業で1人だけ残る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post, lv) => ({ id: uid('s'), nm: 'T' + lv, seed: 1, r: 1, st: { waza: 5, tegiwa: 5, mekiki: 5 }, tr: 'calm', lv, xp: 0, post, hired: 0, train: 0, care: '' });
      G.staff = [mk('still', 1), mk(null, 1), mk('fill', 4)]; prodInvalidate();
      const a = G.staff[0], b = G.staff[1];
      staffTick(24 * 3600000); const o = { lvA: a.lv, lvB: b.lv, xpA: Math.round(a.xp) };
      // 研修：費用・効果なし・6時間後に経験+24
      const t0 = G.acct.cur.sga.train; const cap0 = stageCap(0); o.tr = staffTrain(a.id); o.fee = [Math.round(G.acct.cur.sga.train - t0), staffTrainFee(a)]; prodInvalidate(); o.capOff = stageCap(0) < cap0;
      const lv0 = a.lv, xp0 = a.xp; a.train = Date.now() - 1; staffTick(1000); o.trEnd = a.train === 0 && (a.lv > lv0 || a.xp >= xp0 + 23.9);
      // 解雇：退職金
      const s0 = G.acct.cur.sga.sev; const sev = staffSevFee(b); o.fire = staffFire(b.id); o.sev = [Math.round(G.acct.cur.sga.sev - s0), sev]; o.n = G.staff.length;
      // 再創業で残る1人
      const keep = staffKeepOne(); o.keep = keep.length === 1 && keep[0].lv === 4 && keep[0].post === null;
      return o;
    });
    const ok = r.lvA === 2 && r.lvB === 1 && r.xpA === 0 && r.tr && r.fee[0] === r.fee[1] && r.capOff && r.trEnd && r.fire && r.sev[0] === r.sev[1] && r.n === 2 && r.keep;
    rec(115, '熟練度：持ち場で1時間1経験（Lv2まで24）・持ち場なしは伸びない／研修は費用（時給12時間分）を払い6時間効果なし、終わると経験+24／解雇は退職金（時給24時間分）／再創業では最も熟練した1人が残る', ok, JSON.stringify(r));
    if (errors.length) rec('E66', '熟練度テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #116 決算書の人件費・整合・v4.7（schema12）からの移行 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(async () => {
      G.dl = 3; G.acct = { prev: [] }; acctEnsure(); const o = {};
      const old = JSON.parse(JSON.stringify(G)); old.ver = 12; delete old.staff; delete old.staffCand; delete old.staffOff;
      const m = parseSave(old); o.mig = [m.ver, Array.isArray(m.staff) && m.staff.length === 0, m.staffOff === false];
      staffCandState(); staffHire(0); staffHire(0); staffTick(5 * 3600000); staffTrain(G.staff[0].id); staffFire(G.staff[1].id);
      const lv = acctLive(); o.lab = [Math.round(acctLabor(lv)), Math.round(lv.sga.hire + lv.sga.wage + lv.sga.train + lv.sga.sev)]; o.unex = Math.abs(lv.unex) < Math.max(1, lv.R * 1e-9);
      const na0 = naOf(lv.o), na1 = naOf(lv.c); o.na = Math.abs(na0 + lv.ni - na1) < Math.max(1, Math.abs(na1) * 1e-9); o.cash = Math.abs(lv.o.cash + lv.opcf + lv.invcf - lv.c.cash) < Math.max(1, Math.abs(lv.c.cash) * 1e-9);
      openFinModal(); await new Promise(r => setTimeout(r, 80)); const t = document.getElementById('mc2').textContent; o.rows = ['うち人件費', '採用費', '給与', '研修費', '退職金'].every(w => t.includes(w)); o.box = t.includes('人件費');
      const cols = [...document.querySelectorAll('#mc2 .fbd .fcol')].map(c => [...c.children].reduce((a, e) => a + parseFloat(e.style.height), 0)); o.eq = cols.length >= 2 && Math.abs(cols[0] - cols[1]) <= 3;
      closeM();
      return o;
    });
    const ok = r.mig[0] === 13 && r.mig[1] && r.mig[2] && r.lab[0] > 0 && r.lab[0] === r.lab[1] && r.unex && r.na && r.cash && r.rows && r.box && r.eq;
    rec(116, '決算書：販管費に「うち人件費」（採用費・給与・研修費・退職金）・ボックス図に人件費・純資産と現金の2つの整合式・v4.7（schema12）から移行すると職人は0人', ok, JSON.stringify(r));
    if (errors.length) rec('E67', '人件費の決算書テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v4.9 追加テスト =================
  const STAFF3 = `(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } closeM(); _celebQ = []; celebClose(); G.cash = 1e12; G.staff = []; G.staffCand = null; G.staffOff = false; staffCandState(); for (let i = 0; i < 3; i++) staffHire(0); G.staff[0].post = 'watch'; G.staff[1].post = 'fill'; G.staff[2].post = 'still'; prodInvalidate(); })()`;
  // ---------- #117 倉庫の景色：職人（最大3人）と目標に近い樽（最大4）・職人がいなければ主人・寝かせるを開いている間だけ動く・動きを減らす設定で止まる ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 200));
      const sc = document.getElementById('wScene'); const o = { wk: sc.querySelectorAll('.wk').length, ck: sc.querySelectorAll('.wcask').length, lbl: sc.querySelectorAll('.wsl').length, names: sc.querySelector('.wsn').textContent };
      const exp = G.lots.filter(l => lotGoalEta(l) > 0).sort((a, b) => lotGoalEta(a) - lotGoalEta(b)).slice(0, 4).map(l => l.id).join();
      o.order = [...sc.querySelectorAll('.wcask')].map(e => e.dataset.lot).join() === exp;
      o.run = _scene.anims.filter(a => a.playState === 'running').length;
      switchTab('tsale'); scenePlay(); o.paused = _scene.anims.length > 0 && _scene.anims.every(a => a.playState === 'paused');
      switchTab('tcel'); scenePlay(); o.again = _scene.anims.some(a => a.playState === 'running');
      G.staff = []; prodInvalidate(); sceneLight(); o.owner = document.querySelectorAll('#wScene .wk').length === 1 && document.querySelector('#wScene .wk').dataset.sid === 'owner';
      opt().motion = 'low'; applyOpt(); sceneMount(); o.low = _scene.anims.length; opt().motion = 'std'; applyOpt();
      o.cells = document.querySelectorAll('#whSummary .ck2[data-id]').length === G.lots.length;
      return o;
    });
    const ok = r.wk === 3 && r.ck === 4 && r.lbl === 4 && r.order && r.run > 0 && r.paused && r.again && r.owner && r.low === 0 && r.cells;
    rec(117, '倉庫の景色：職人（最大3人）が目標に近い樽（最大4つ・残り時間の札）の前で働く・職人がいなければ蒸留所の主・寝かせるを開いている間だけ動く・動きを減らす設定では止まる', ok, JSON.stringify(r));
    if (errors.length) rec('E68', '倉庫の景色テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #118 タップの反応と差し入れ（1日1回・経験+2・その日最初の1回だけ砂時計）・樽を叩くと残り時間（状態は変わらない） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 150));
      G.hg.n = 0; G.hg.src.care = 0; hgDay(); G.hg.src.care = 0;
      const g = document.querySelector('#wScene .wk'); g.dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 80));
      const bub = document.getElementById('wBub'); const o = { open: !bub.classList.contains('h'), txt: bub.textContent.length > 5, care: !!bub.querySelector('[data-act="staffCare"]') };
      const s = G.staff.find(x => x.id === g.dataset.sid); const xp0 = s.xp, lv0 = s.lv;
      bub.querySelector('[data-act="staffCare"]').click(); await new Promise(r => setTimeout(r, 80));
      o.c1 = { hg: G.hg.n, xp: +(s.xp - xp0 + (s.lv - lv0) * 24).toFixed(3), day: s.care === dayKey() };
      o.c2 = staffCare(s.id); const other = G.staff.find(x => x !== s); o.c3 = staffCare(other.id); o.hg2 = G.hg.n;
      const snap = JSON.stringify(G.lots); const c = document.querySelector('#wScene .wcask'); c.dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
      o.knock = document.getElementById('wBub').textContent.includes('コン'); o.same = JSON.stringify(G.lots) === snap;
      document.body.click(); await new Promise(r => setTimeout(r, 30)); o.closed = document.getElementById('wBub').classList.contains('h');
      return o;
    });
    const ok = r.open && r.txt && r.care && r.c1.hg === 1 && Math.abs(r.c1.xp - 2) < 1e-6 && r.c1.day && r.c2 === false && r.c3 === true && r.hg2 === 1 && r.knock && r.same && r.closed;
    rec(118, '職人を押すと吹き出しで一言・差し入れは1人1日1回で経験+2、砂時計はその日最初の1回だけ・樽を押すと叩く音と残り時間（樽の状態は変わらない）・外を押すと閉じる', ok, JSON.stringify(r));
    if (errors.length) rec('E69', 'タップの反応テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #119 タイムラプス：詰めた日から今日まで・年数と液面と風味が進む・動きを減らす設定は最後の状態・保存データは変わらない・放置の報告から開ける ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      const l = G.lots[1]; const now = Date.now(); l.at = now - 5 * 864e5; const r0 = agingRate(l); l.age = 5 * r0; l.L = l.L0 * 0.9; l.gd = 3; l.goal = 8; l.gs = 3;
      const T = tlTimes(l); const o = { a0: +T.a0.toFixed(3), yrs: +T.yrs.toFixed(3), days: +T.days.toFixed(2), ms: T.ms.map(m => m.p).join() };
      const s0 = JSON.stringify(G.lots); tlOpen(l.id); const same1 = JSON.stringify(G.lots) === s0; await new Promise(r => setTimeout(r, 300)); const a1 = parseFloat(document.getElementById('tlAge').textContent);
      await new Promise(r => setTimeout(r, 5400)); const a2 = parseFloat(document.getElementById('tlAge').textContent); const liq = parseFloat(document.getElementById('tlLiq').style.height);
      const t = document.getElementById('mc2').textContent; o.txt = t.includes('振り返る') && t.includes('天使の分け前'); o.run = [a1, a2]; o.liq = liq; o.on = document.querySelectorAll('.tlm.on').length;
      closeM(); opt().motion = 'low'; applyOpt(); tlOpen(l.id); o.low = parseFloat(document.getElementById('tlAge').textContent); closeM(); opt().motion = 'std'; applyOpt();
      o.same = same1;
      // 放置の報告のボタン
      const k = G.lots[2]; k.goal = k.age + 0.2; k.gs = k.age - 0.5; G.ls = Date.now() - 12 * 3600000; offline();
      const btn = document.querySelector('#mc2 [data-act="tlOpen"]'); o.rep = !!btn; if (btn) { btn.click(); await new Promise(r => setTimeout(r, 100)); o.repOpen = document.getElementById('mc2').textContent.includes('振り返る') && !_offlineGate; }
      closeM();
      return o;
    });
    const ok = r.a0 === 0 && Math.abs(r.days - 5) < 0.01 && r.ms === '0.25,0.5,0.75,1' && r.txt && r.run[0] < r.run[1] && Math.abs(r.run[1] - r.yrs) < 0.05 && Math.abs(r.liq - 90) < 0.5 && r.on === 4 && Math.abs(r.low - r.yrs) < 0.05 && r.same && r.rep && r.repOpen;
    rec(119, 'タイムラプス：詰めた日から今日まで年数・液面（天使の分け前）・風味・節目の日付が進む・動きを減らす設定は最後の状態を表示・保存データは変わらない・放置の報告から開ける', ok, JSON.stringify(r));
    if (errors.length) rec('E70', 'タイムラプステスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #120 倉庫日誌に職人の出来事（採用・Lv・研修・解雇・差し入れ・休業）と1日の様子 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      let off = 0; const rn = Date.now.bind(Date); Date.now = () => rn() + off;
      G.jnl = { cur: null, list: [] }; jnlRoll();
      const s = G.staff[0]; staffCandState(); G.staffCand.free = 1; staffRefresh(); staffHire(0); staffXp(s, 24); staffTrain(s.id); s.train = Date.now() - 1; staffTick(1000); staffFire(G.staff[3].id);
      const cur = jnlCur().staff.slice();
      off = 24 * 3600000; jnlRoll(); const e = G.jnl.list[0];
      Date.now = rn; G.ls = rn(); if (_offlineGate) closeOfflineModal();
      openJnlModal(); const t = document.getElementById('mc2').textContent; closeM();
      return { cur, e: e.staff, t: e.staff.every(x => t.includes(x)) };
    });
    const ok = r.cur.some(x => x.includes('加わった')) && r.cur.some(x => x.includes('Lv2')) && r.cur.some(x => x.includes('研修から戻った')) && r.cur.some(x => x.includes('去った')) && r.e.length >= 4 && r.e.length <= 5 && /は.+。$/.test(r.e[r.e.length - 1]) && r.t;
    rec(120, '倉庫日誌：職人の出来事（採用・Lv・研修・解雇など）と、その日の職人の様子が1行記録され、日誌の小窓に出る', ok, JSON.stringify(r));
    if (errors.length) rec('E71', '日誌の職人テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  await browser.close();
  let pass = 0;
  results.forEach(x => { if (x.ok) pass++; console.log((x.ok ? 'PASS' : 'FAIL') + ' #' + x.id + ' ' + x.name + (x.ok ? '' : '  → ' + x.detail)); });
  console.log(`\n${pass}/${results.length} passed`);
  require('fs').writeFileSync('test_results.json', JSON.stringify(results, null, 1));
})();
