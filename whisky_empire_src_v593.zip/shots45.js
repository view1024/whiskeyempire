// v4.5 画面確認：決算書・寝かせる（ライト）・売る・樽の詳細
const { chromium } = require('playwright');
const path = require('path');
const STATE = require('fs').readFileSync('v43.js', 'utf8').match(/const STATE = (function \(mode\) \{[\s\S]*?\n\});/)[1];
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 667 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html')); await page.waitForTimeout(1200);
  await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(400);
  await page.evaluate(`(${STATE})('mid')`); await page.waitForTimeout(400);
  await page.evaluate(() => {
    _celebQ = []; celebClose(); closeM();
    let T = Date.now(); _acctClock = () => T;
    G.acct = null; acctEnsure(); for (let i = 0; i < 40; i++) tap(null);
    for (let i = 0; i < 360; i++) { T += 100000; prodTick(100000); lotTick(100000); botTick(100000); ordAutoTick(); autoSpotTick(); }
    upgFac('malting'); upgFac('mashing'); upgFac('fermentation');
    const o = G.orders.find(x => ordMatch(x).ok); if (o) ordDeliver(o.id);
    T += 35 * 864e5; acctEnsure();
    for (let i = 0; i < 360; i++) { T += 100000; prodTick(100000); lotTick(100000); botTick(100000); autoSpotTick(); }
    G.hs.fin = null; document.querySelectorAll('.toast').forEach(t => t.classList.remove('on'));
  });
  await page.waitForTimeout(300);
  for (const v of ['pl', 'bs', 'cf']) {
    await page.evaluate(v => { openFinModal(); _fin.v = v; finRender(); }, v); await page.waitForTimeout(200);
    await page.screenshot({ path: `v45_fin_${v}.png` });
  }
  await page.evaluate(() => { _fin.i = 1; _fin.v = 'pl'; finRender(); }); await page.waitForTimeout(150);
  await page.screenshot({ path: 'v45_fin_prev.png' });
  await page.evaluate(() => { closeM(); switchTab('td'); }); await page.waitForTimeout(200);
  await page.screenshot({ path: 'v45_td.png' });
  await page.evaluate(() => { opt().theme = 'light'; applyOpt(); switchTab('tcel'); }); await page.waitForTimeout(300);
  await page.screenshot({ path: 'v45_tcel_light.png' });
  await page.evaluate(() => { openFinModal(); _fin.v = 'bs'; finRender(); }); await page.waitForTimeout(200);
  await page.screenshot({ path: 'v45_fin_light.png' });
  await page.evaluate(() => { closeM(); opt().theme = 'dark'; applyOpt(); switchTab('tsale'); _ui.sellTab = 'ord'; rShip(); }); await page.waitForTimeout(300);
  await page.screenshot({ path: 'v45_tsale.png' });
  await page.evaluate(() => { openLotModal(G.lots[1].id); }); await page.waitForTimeout(200);
  await page.screenshot({ path: 'v45_lot.png' });
  await page.evaluate(() => { closeM(); const o = G.orders.find(x => x.kind === 'product' && !ordMatch(x).ok && ordFulfillPlan(x).ok) || G.orders[0]; openOrderInfoModal(o.id); }); await page.waitForTimeout(200);
  await page.screenshot({ path: 'v45_order.png' });
  await page.evaluate(() => { closeM(); openFinModal(); _fin.v = 'pl'; finRender(); const m = document.getElementById('mc2'); m.scrollTop = 1e6; }); await page.waitForTimeout(200);
  await page.screenshot({ path: 'v45_fin_bottom.png' });
  console.log('ERRORS', errors);
  await browser.close();
})();
