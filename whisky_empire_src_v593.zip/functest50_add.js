  // ================= v4.9.1 追加テスト =================
  // ---------- #121 タイムラプス廃止・ドット絵（輪郭がにじまない・見た目は seed で決まる・動きを減らす設定では止まる） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      const o = {};
      o.noTl = typeof tlOpen === 'undefined' && typeof tlTimes === 'undefined' && typeof _tlAnim === 'undefined' && !document.querySelector('[data-act="tlOpen"]') && !document.body.innerText.includes('振り返る');
      openLotModal(G.lots[0].id); o.modal = !document.getElementById('mc2').textContent.includes('振り返る'); closeM();
      switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 200));
      const sv = document.querySelector('#wScene svg'); o.crisp = sv && sv.getAttribute('shape-rendering') === 'crispEdges';
      o.px = document.querySelectorAll('#wScene .wk path').length > 20 && document.querySelectorAll('#wScene .wcask path').length > 3;
      const a = JSON.stringify(pxLook({ seed: 12345 })), b = JSON.stringify(pxLook({ seed: 12345 })), c = JSON.stringify(pxLook({ seed: 777 }));
      o.det = a === b && a !== c; o.owner = pxLook(OWNER).acc === 'pipe';
      o.bg = getComputedStyle(document.getElementById('wScene')).backgroundImage === 'none' && !sv.querySelector('linearGradient');
      o.run = _scene.anims.length > 0;
      opt().motion = 'low'; applyOpt(); sceneMount(); o.low = _scene.anims.length === 0 && document.querySelectorAll('#wScene .wk').length === 3; opt().motion = 'std'; applyOpt();
      return o;
    });
    const ok = r.noTl && r.modal && r.crisp && r.px && r.det && r.owner && r.bg && r.run && r.low;
    rec(121, 'タイムラプスを廃止（関数も「振り返る」もない）・職人と樽はドット絵（輪郭がにじまない・見た目は seed で決まる・主人は固定）・景色の背景は透明・動きを減らす設定では止まる', ok, JSON.stringify(r));
    if (errors.length) rec('E72', 'ドット絵テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ================= v5.0 追加テスト =================
  // ---------- #122 熟成と天使の分け前：担当の倍率で熟成が速くなり、熟成1年あたりの減り方は同じ・残り時間・放置・砂時計にも反映 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const ct = caskType('bourbon'), sz = caskSize('hogshead');
      const a = makeLot(ct, sz, { c: 0 }), b = makeLot(ct, sz, { c: 0 }); G.lots.push(a, b); lotGoalInit(a); lotGoalInit(b);
      const s = { id: uid('s'), nm: 'T', seed: 1, r: 1, st: { waza: 10, tegiwa: 1, mekiki: 1 }, tr: 'calm', lv: 10, xp: 0, at: { k: 'lot', id: a.id }, hired: 0, train: 0, care: '' };
      G.staff = [s]; placeInvalidate();
      const o = { m: lotMult(a), eta: lotGoalEta(a) / lotGoalEta(b) };
      const Y = BALANCE.GAME_YEAR_MS / agingRateBase(a);
      // a は3年、b は2年ぶん（同じ実時間では a が1.5倍）
      lotAdvance(a, 2 * Y); lotAdvance(b, 2 * Y); o.age = [+a.age.toFixed(6), +b.age.toFixed(6)];
      lotAdvance(b, 1 * Y); o.sameL = Math.abs(a.L - b.L) / a.L < 1e-9 && Math.abs(a.age - b.age) < 1e-9;
      o.modal = (() => { openLotModal(a.id); const t = document.getElementById('mc2').textContent; closeM(); return t.includes('うち担当 ×1.50') && t.includes('担当T ×1.50'); })();
      // 放置24時間・砂時計1時間：毎秒進めたのと同じ
      const c = makeLot(ct, sz, { c: 0 }), d = makeLot(ct, sz, { c: 0 }); G.lots.push(c, d); s.at = { k: 'lot', id: c.id }; G.ownerAt = { k: 'lot', id: d.id }; placeInvalidate();
      const c0 = c.age, d0 = d.age; if (_offlineGate) closeOfflineModal(); G.cash = 1e15; G.ls = Date.now() - 24 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      o.off = [+((c.age - c0) / (24 * 3600000 / BALANCE.GAME_YEAR_MS * agingRateBase(c))).toFixed(4), +((d.age - d0) / (24 * 3600000 / BALANCE.GAME_YEAR_MS * agingRateBase(d))).toFixed(4)];
      const c1 = c.age; G.hg.n = 1; G.hg.useDay = 0; G.ls = Date.now(); hgUse(); if (_offlineGate) closeOfflineModal(); o.hg = +((c.age - c1) / (3600000 / BALANCE.GAME_YEAR_MS * agingRateBase(c))).toFixed(4);
      return o;
    });
    const ok = Math.abs(r.m - 1.5) < 1e-9 && Math.abs(r.eta - 1 / 1.5) < 1e-6 && Math.abs(r.age[0] - 3) < 1e-6 && Math.abs(r.age[1] - 2) < 1e-6 && r.sameL && r.modal && Math.abs(r.off[0] - 1.5) < 1e-3 && Math.abs(r.off[1] - 1.1) < 1e-3 && Math.abs(r.hg - 1.5) < 1e-3;
    rec(122, '熟成：担当の倍率だけ速く熟成し（残り時間も短くなる）、同じ年数に達したときの残量は配置しないときと同じ（天使の分け前は熟成1年あたり同じ）・放置24時間と砂時計にも反映・樽の小窓に担当と内訳', ok, JSON.stringify(r));
    if (errors.length) rec('E73', '熟成と配置テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #123 配置の規則：1か所1人・入れ替え・待機・置けない所・樽がなくなると待機・目標に届いても担当のまま・あなたはTier1から×1.10（休業の影響なし） ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      const mk = (st) => ({ id: uid('s'), nm: 'T' + st, seed: st, r: 1, st: { waza: st, tegiwa: st, mekiki: st }, tr: 'calm', lv: 1, xp: 0, at: null, hired: 0, train: 0, care: '' });
      G.dl = 3; const A = mk(5), B = mk(7); G.staff = [A, B]; placeInvalidate();
      const L = G.lots; const o = {};
      placeSet(A, { k: 'fac', id: 'distillation' }, true); placeSet(B, { k: 'lot', id: L[0].id }, true);
      placeSet(B, { k: 'fac', id: 'distillation' }, true); o.swap = [placeKey(A.at), placeKey(B.at)].join();
      placeSet(A, null, true); o.idle = A.at === null;
      G.fac.mashing.p = false; prodInvalidate(); o.ng = placeSet(A, { k: 'fac', id: 'mashing' }, true) === false && placeSet(A, { k: 'lot', id: 'nope' }, true) === false; G.fac.mashing.p = true; prodInvalidate();
      o.bottleLv0 = (() => { const p = G.fac.bottling.p; G.fac.bottling.p = false; const ok = placeOk({ k: 'fac', id: 'bottling' }); G.fac.bottling.p = p; return ok; })();
      // 樽がなくなる：樽ごと売る・天使の分け前で処分
      placeSet(A, { k: 'lot', id: L[1].id }, true); const sold = L[1].id; sellLot(sold); staffTick(1000); o.sold = A.at === null && jnlCur().staff.some(t => t.includes('待機に戻った'));
      placeSet(A, { k: 'lot', id: G.lots[1].id }, true); const tiny = G.lots[1]; tiny.L = 0.1; lotTick(1000); staffTick(1000); o.evap = A.at === null;
      // 目標に届いても担当のまま
      const g = G.lots[2]; placeSet(A, { k: 'lot', id: g.id }, true); g.goal = g.age + 0.0001; lotAdvance(g, 864e5); o.keep = placeKey(A.at) === 'lot:' + g.id && !!g.gd;
      // あなた：Tier1から・×1.10・休業の影響なし
      G.dl = 1; G.staff = []; placeInvalidate(); o.t1 = placeSet(OWNER, { k: 'fac', id: 'malting' }, true) && Math.abs(facMult('malting') - 1.1) < 1e-9;
      G.staff = [mk(3)]; G.staffOff = true; placeInvalidate(); o.ownerOff = Math.abs(facMult('malting') - 1.1) < 1e-9; G.staffOff = false;
      // 再創業：あなたの配置は外れ、残る1人は待機。樽の枠のボーナスは残る
      return o;
    });
    const ok = r.swap.split(',')[1] === 'fac:distillation' && r.swap.split(',')[0].startsWith('lot:') && r.idle && r.ng && r.bottleLv0 && r.sold && r.evap && r.keep && r.t1 && r.ownerOff;
    rec(123, '配置の規則：1か所に1人（先客とは入れ替え）・待機にできる・未所有の設備や無い樽には置けない（ボトリングは手作業でも可）・樽を売る・天使の分け前で処分すると待機に戻り日誌に記録・目標に届いても担当のまま・あなたはTier1から ×1.10（休業の影響なし）', ok, JSON.stringify(r));
    if (errors.length) rec('E74', '配置の規則テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #124 v4.8〜v4.9（schema13）からの移行：持ち場→配置先・樽の枠は減らない（恒久のボーナス）・バックアップ・変更点の案内 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (post, st, lv, extra) => Object.assign({ id: uid('s'), nm: 'T', seed: 1, r: 1, st, tr: 'calm', lv, xp: 0, post, hired: 0, train: 0, care: '' }, extra || {});
      const S = (w, t, m) => ({ waza: w, tegiwa: t, mekiki: m });
      const obj = JSON.parse(JSON.stringify(G)); obj.ver = 13; delete obj.ownerAt; delete obj.whBonus; if (obj.hs) delete obj.hs.new50;
      obj.staff = [mk('buy', S(1, 1, 9), 2), mk('still', S(1, 9, 1), 3), mk('still', S(1, 8, 1), 1), mk('still', S(1, 7, 1), 1), mk('ship', S(1, 6, 1), 1), mk('fill', S(4, 9, 1), 5, { train: Date.now() + 3600000 }), mk('fill', S(3, 8, 1), 1), mk('watch', S(8, 1, 1), 1), mk(null, S(5, 5, 5), 1)];
      obj.staffOff = true;
      // v4.9 の式：樽の枠 = floor((手際×(1+0.1(Lv−1)) の大きい順に100%・80%) / 3)、上限12
      const fp = [9 * 1.4, 8 * 1].sort((a, b) => b - a).reduce((a, v, i) => a + v * [1, 0.8, 0.6][i], 0); const expBonus = Math.min(12, Math.floor(fp / 3));
      const slotsBefore = Math.floor((BALANCE.WH_BASE + BALANCE.WH_PER_LV * facLv('maturation')) * brMod('maturation', 'slots')) + expBonus;
      const raw = JSON.stringify(obj); const m = parseSave(JSON.parse(raw));
      const o = { ver: m.ver, wb: m.whBonus, exp: expBonus, at: m.staff.map(s => placeKey(s.at)), owner: m.ownerAt, new50: m.hs.new50 };
      const keepG = G; G = m; placeSanitize(); o.slots = [whSlots(), slotsBefore]; o.uniq = (() => { const k = m.staff.filter(s => s.at).map(s => placeKey(s.at)); return new Set(k).size === k.length; })(); G = keepG;
      // 読み込み：移行前のデータをバックアップ
      const key = storageKey(); localStorage.setItem(key, raw); localStorage.removeItem('we_v4_bak13:' + (LIFF_USER.id || 'guest')); load(); o.bk = localStorage.getItem('we_v4_bak13:' + (LIFF_USER.id || 'guest')) === raw; o.loaded = G.ver;
      o.tut = typeof TUTS.u50 === 'object' && TUTS.u50.cond();
      return o;
    });
    const ok = r.ver === SCHEMA && r.wb === r.exp && r.wb > 0 && r.at[0] === 'fac:malting' && r.at[1] === 'fac:distillation' && r.at[2] === 'fac:fermentation' && r.at[3] === 'fac:mashing' && r.at[4] === 'fac:bottling' && r.at[5].startsWith('lot:') && r.at[6].startsWith('lot:') && r.at[7].startsWith('lot:') && r.at[8] === '' && r.owner === null && r.new50 === 0 && r.slots[0] === r.slots[1] && r.uniq && r.bk && r.loaded === SCHEMA && r.tut;
    rec(124, 'v4.8〜v4.9（schema13）からの移行：原料調達→製麦室・蒸留→蒸留器・発酵槽・糖化槽・出荷→ボトリング・樽詰めと熟成監視→目標が近い樽・樽の枠は研修中や休業中の人も含めて移行前と同じ（恒久のボーナス）・移行前をバックアップ・変更点の案内', ok, JSON.stringify(r));
    if (errors.length) rec('E75', '移行テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #125 おまかせ配置：いちばん遅い工程→瓶詰めの予約があればボトリング→目標が近い樽・あなたは動かさない・新酒が増えない工程の注意 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF_PREP);
    const r = await page.evaluate(() => {
      G.dl = 3; const mk = (st) => ({ id: uid('s'), nm: 'T', seed: st, r: 1, st: { waza: st, tegiwa: st, mekiki: st }, tr: 'calm', lv: 1, xp: 0, at: null, hired: 0, train: 0, care: '' });
      G.staff = [mk(9), mk(8), mk(7), mk(6)]; G.ownerAt = { k: 'lot', id: G.lots[0].id }; placeInvalidate(); prodInvalidate();
      const bn = STAGES[prodFlows().bottleneck].fac; const n = placeAuto(true);
      const o = { n, first: placeKey(G.staff[0].at), bn, owner: placeKey(G.ownerAt), bott: G.staff.some(s => placeKey(s.at) === 'fac:bottling'), lots: G.staff.filter(s => s.at && s.at.k === 'lot').map(s => s.at.id) };
      const eta = G.lots.filter(l => lotGoalEta(l) > 0 && l.id !== G.lots[0].id).sort((a, b) => lotGoalEta(a) - lotGoalEta(b)).map(l => l.id);
      o.lotOrder = o.lots.every((id, i) => id === eta[i]);
      // 新酒が増えない工程（いちばん遅い工程でない）に置くと注意
      const other = STAGES.map(s => s.fac).find(f => f !== bn && facLv(f) > 0 && !placeWho('fac', f)); placeSet(G.staff[3], { k: 'fac', id: other }, true);
      o.nogain = facNoGain(other) && staffGainTxt(G.staff[3]).includes('新酒は増えません');
      switchTab('tb'); rMake(); o.row = document.getElementById('fac_' + other).textContent.includes('今は増えません');
      o.gain = staffGainTxt(G.staff[0]).includes('効果の見込み +');
      return o;
    });
    const ok = r.n === 4 && r.first === 'fac:' + r.bn && r.owner.startsWith('lot:') && r.bott && r.lotOrder && r.nogain && r.row && r.gain;
    rec(125, 'おまかせ配置：いちばん遅い工程に向いた人→瓶詰めの予約があればボトリング→目標が近い樽の順・あなたの配置は動かさない・いちばん遅い工程でない所は「新酒は増えません」と表示', ok, JSON.stringify(r));
    if (errors.length) rec('E76', 'おまかせ配置テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #126 配置モード：樽を押して「移動」→ 造るタブの設備を押すと配置・やめる・Esc・待機・設備を押すと担当の小窓 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      const w = G.staff[0]; const lid = w.at.id; switchTab('tcel'); rCellar(); await new Promise(r => setTimeout(r, 100));
      document.querySelector(`#wScene .wcask[data-id="${lid}"]`).dispatchEvent(new MouseEvent('click', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
      const bub = document.getElementById('wBub'); const o = { bub: !bub.classList.contains('h') && bub.textContent.includes(w.nm) && !!bub.querySelector('[data-act="pmStart"]') };
      bub.querySelector('[data-act="pmStart"]').click(); await new Promise(r => setTimeout(r, 60));
      o.mode = !!_pm && !!document.getElementById('pmBar') && document.body.classList.contains('pm');
      switchTab('tb'); rMake(); await new Promise(r => setTimeout(r, 60)); o.stay = !!_pm;
      document.querySelector('#fac_mashing .pic').click(); await new Promise(r => setTimeout(r, 60));
      o.placed = placeKey(w.at) === 'fac:mashing' && !_pm && !document.getElementById('pmBar');
      // Esc・やめる・待機
      pmStart(w); document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); o.esc = !_pm;
      pmStart(w); document.querySelector('#pmBar [data-act="pmEnd"]').click(); o.end = !_pm && placeKey(w.at) === 'fac:mashing';
      pmStart(w); document.querySelector('#pmBar [data-act="pmIdle"]').click(); o.idle = !_pm && w.at === null;
      // 設備を押す：担当の小窓 → 職人を呼ぶ
      document.querySelector('#fac_distillation .pic').click(); await new Promise(r => setTimeout(r, 60)); const t = document.getElementById('mc2').textContent; o.fm = t.includes('蒸留器') && t.includes(G.staff[2].nm) && !!document.querySelector('#mc2 [data-act="placePickC"]');
      document.querySelector('#mc2 [data-act="placePickC"]').click(); await new Promise(r => setTimeout(r, 60)); const btn = document.querySelector(`#mc2 [data-act="placeSet"][data-sid="${w.id}"]`); o.pick = !!btn; btn.click(); await new Promise(r => setTimeout(r, 60));
      o.swap = placeKey(w.at) === 'fac:distillation' && G.staff[2].at === null && document.getElementById('mo').classList.contains('h');
      // 売るタブのボトリングにも置ける
      _ui.sellTab = 'ord'; switchTab('tsale'); rall(); pmStart(G.staff[1]); document.querySelector('#fac_bottling .pic').click(); o.bot = placeKey(G.staff[1].at) === 'fac:bottling';
      return o;
    });
    const ok = r.bub && r.mode && r.stay && r.placed && r.esc && r.end && r.idle && r.fm && r.pick && r.swap && r.bot;
    rec(126, '配置モード：樽を押した吹き出しの「移動」→ タブを移っても続き、造るタブの設備の絵を押すと配置・「やめる」とEscで終わる・「待機に」・設備の絵を押すと担当の小窓（職人を呼ぶ・入れ替え）・売るタブのボトリングにも置ける', ok, JSON.stringify(r));
    if (errors.length) rec('E77', '配置モードテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #127 棚の段数：樽0・1・6・7・40・84個・空きは1段＋「あと何樽」・札は重ならない・広げると全画面 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      G.auto.fill.on = false; G.tank = 0; switchTab('tcel'); const all = G.lots.slice(); const slots = whSlots(); const o = { slots, cases: [] };
      for (const n of [0, 1, 6, 7, 40, 84]) {
        G.lots = all.slice(0, n); rCellar(); await new Promise(r => setTimeout(r, 30));
        const sv = document.querySelector('#wScene svg'); const vb = sv ? sv.viewBox.baseVal.height : 0; const aisle = shelfAisle().length ? SH.AISLE : 0;
        const empty = Math.max(0, slots - n), showE = Math.min(empty, n % 6 ? 6 - n % 6 : 6), rows = Math.max(1, Math.ceil((n + showE) / 6));
        const lb = [...document.querySelectorAll('#wScene .wsl')].map(e => e.getBoundingClientRect()); let ov = 0;
        for (let i = 0; i < lb.length; i++) for (let j = i + 1; j < lb.length; j++) { const a = lb[i], b = lb[j]; if (a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1) ov++; }
        const more = (document.querySelector('#wScene .wmore') || {}).textContent || '';
        o.cases.push({ n, cells: document.querySelectorAll('#wScene .wcask').length, rowsOk: Math.abs(vb - (aisle + rows * SH.RH)) < 0.5, ov, more: empty - showE > 0 ? more.includes(String(empty - showE)) : more === '' });
      }
      G.lots = all; rCellar(); document.querySelector('[data-act="whBig"]').click(); await new Promise(r => setTimeout(r, 50));
      const ws = document.getElementById('whSummary').getBoundingClientRect(); o.big = getComputedStyle(document.getElementById('whSummary')).position === 'fixed' && ws.height >= innerHeight - 1 && document.querySelector('[data-act="whBig"]').textContent === '閉じる';
      document.querySelector('[data-act="whBig"]').click(); o.back = getComputedStyle(document.getElementById('whSummary')).position !== 'fixed';
      return o;
    });
    const ok = r.cases.every(c => c.cells === c.n && c.rowsOk && c.ov === 0 && c.more) && r.big && r.back;
    rec(127, '棚：樽が0・1・6・7・40・84個でも段数が正しい（1段6樽）・空きは今の段＋1段まで描き、残りは「空き あとn樽」・札は重ならない・「広げる」で全画面、「閉じる」で戻る', ok, JSON.stringify(r));
    if (errors.length) rec('E78', '棚テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #128 造る・売る：設備の行の左はドット絵の設備と担当（行の高さは変わらない）・動きは開いているタブだけ・描き直しても絵は作り直さない ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    await page.evaluate(STAFF3);
    const r = await page.evaluate(async () => {
      switchTab('tb'); rMake(); await new Promise(r => setTimeout(r, 100));
      const o = {}; const rows = STAGES.map(s => document.getElementById('fac_' + s.fac));
      o.h = rows.map(e => Math.round(e.getBoundingClientRect().height)); o.px = rows.every(e => e.querySelector('.pic .pxs .pxf'));
      o.worker = !!document.querySelector('#fac_distillation .pic .wk[data-sid="' + G.staff[2].id + '"]');
      o.tag = document.getElementById('fac_distillation').textContent.includes(G.staff[2].nm + ' ×');
      const el = document.querySelector('#fac_malting .pxs'); G.tank = (G.tank || 0) + 123; rMake(); o.reuse = document.querySelector('#fac_malting .pxs') === el;
      const an = [..._pxs.values()].flatMap(e => e.anims); o.run = an.some(a => a.playState === 'running');
      switchTab('tcel'); scenePlay(); o.paused = an.filter(a => a._tab === 'tb').every(a => a.playState === 'paused');
      _ui.sellTab = 'ord'; switchTab('tsale'); rall(); o.bot = !!document.querySelector('#fac_bottling .pic .pxs');
      opt().motion = 'low'; applyOpt(); _pxs.clear(); switchTab('tb'); document.getElementById('lineView')._h = null; rMake(); o.low = [..._pxs.values()].every(e => e.anims.length === 0); opt().motion = 'std'; applyOpt();
      return o;
    });
    const ok = r.h.every(v => v <= 52) && r.px && r.worker && r.tag && r.reuse && r.run && r.paused && r.bot && r.low;
    rec(128, '造る：4工程の行の左にドット絵の設備と担当・担当の名前と倍率を表示・行の高さは v4.9 と同じ52px以下・毎秒描き直しても絵は作り直さない・動くのは開いているタブだけ・売るの瓶詰めにボトリングの絵・動きを減らす設定では動かない', ok, JSON.stringify(r));
    if (errors.length) rec('E79', '設備のドット絵テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #129 性能：樽84・職人17人で寝かせるタブの描画（CPUを4倍遅くして）1秒以内 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const cdp = await ctx.newCDPSession(page);
    await page.evaluate(() => { Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); } G.cash = 1e15; G.staff = []; G.staffCand = null;
      for (let i = 0; i < 17; i++) { const c = staffCandState(); if (!c.list.length) { c.free = 1; staffRefresh(); } staffHire(0); } placeAuto(true); closeM(); switchTab('tcel'); rCellar(); });
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
    const r = await page.evaluate(async () => { const n = G.lots.length; const t = []; for (let i = 0; i < 3; i++) { _ui.sig.cel = null; document.getElementById('whSummary')._h = null; const t0 = performance.now(); rCellar(); document.body.offsetHeight; t.push(performance.now() - t0); await new Promise(r => setTimeout(r, 50)); } return { n, staff: G.staff.length, t: t.map(v => Math.round(v)), anims: _scene.anims.length }; });
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: 1 });
    const med = r.t.slice().sort((a, b) => a - b)[1];
    rec(129, '性能：樽84・職人17人で寝かせるタブを描く時間がCPU4倍遅い条件で1秒以内（3回の中央値。v4.9の樽のマス一覧は同じ条件で約0.6秒）', r.n >= 80 && r.staff === 17 && med <= 1000, JSON.stringify(r));
    if (errors.length) rec('E80', '性能テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
