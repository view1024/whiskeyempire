#!/bin/bash
# usage: runb.sh NAME N PLACE HG [env...]   (8 並列)
NAME=$1; N=$2; ST=$3; HG=$4; shift 4
O=/tmp/claude-0/$NAME; rm -rf $O; mkdir -p $O
cd /home/claude/we
i=1
while [ $i -le $N ]; do
  for j in 1 2 3 4 5 6; do
    [ $i -le $N ] || break
    ( env "$@" NODE_PATH=/home/claude/.npm-global/lib/node_modules timeout 600 node balance51.js 100 50 x $HG $ST > $O/raw_$i.txt 2>&1 ) &
    i=$((i+1))
  done
  wait
done
