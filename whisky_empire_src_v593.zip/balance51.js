// v5.1 簡易ボット（環境変数 RAWOFF=1・KB/KC/KT=原材料の係数・HGM=day|hoard・SELL=cask3|btl3・GRADE=std|good|best）：1時間刻みに進め、Tier到達日・利益・人件費を確認する（配置の方針 none/owner/fac/faclot/full）
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext()).newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(e.message));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  await page.goto('file://' + path.resolve('whisky_empire.html'));
  await page.waitForTimeout(1500);
  await page.evaluate(()=>{_mktOff=true;titleStart(false);});
  await page.waitForTimeout(600);
  const ENV = { rawOff: process.env.RAWOFF === '1', kb: Number(process.env.KB || 0), kc: Number(process.env.KC || 0), kt: Number(process.env.KT || 0), hgm: process.env.HGM || '', sell: process.env.SELL || '', grade: process.env.GRADE || 'std', ramp: process.env.RAMP === undefined ? -1 : Number(process.env.RAMP) };
  const log = await page.evaluate(([__DAYS__,__TAPS__,__DAILY__,__HG__,__ST__,__W__,ENV]) => {
    if (_offlineGate) closeOfflineModal(); closeM(); if(typeof TUTS!=="undefined"){Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}}
    toast = () => {}; celebrate = () => {}; sndPurchase = sndUpgrade = sndTierUp = sndQuest = sndError = () => {};
    let off = 0; const realNow = Date.now.bind(Date); Date.now = () => realNow() + off;
    const out = []; const H = 3600000;
    G.auto.fill.on = true; if (__W__) V48.W_BASE = __W__;
    if (ENV.rawOff) G._rawOff = true; if (ENV.kb) V51.RAW.K.barley = ENV.kb; if (ENV.kc) V51.RAW.K.cask = ENV.kc; if (ENV.kt) V51.RAW.K.bottle = ENV.kt; if (ENV.ramp >= 0) V51.RAW.RAMP2 = ENV.ramp; G.barley.grade = ENV.grade; let hoard = ENV.hgm === 'hoard';
    const DAYS=__DAYS__;let act={up:0,del:0};const daily=[];
    for (let h = 0; h < 24 * DAYS; h++) {
      // プレイヤーの行動（1日3回だけ能動的に動く想定: 8時・13時・21時）
      const hod = h % 24; const active = __DAILY__ ? hod === 20 : (hod === 8 || hod === 13 || hod === 21);
      if (active) {
        if (__DAILY__) { offline(); if (_offlineGate) closeOfflineModal(); checkChapters(); _celebQ=[]; generateDailyMissions(); tickDailyMissions(); }
        if (__HG__) { v47Tick(); if (_offlineGate) closeOfflineModal(); closeM();
          // day：手に入っただけ使う（1日24個まで）／hoard：99個たまるまで使わず、たまったら毎日24個
          if (hoard && G.hg.n >= V47.HG_MAX) hoard = false;
          const k = Math.min(G.hg.n, hgLeftToday()); if (!hoard && k > 0) { G.ls = Date.now(); hgUse(k); if (_offlineGate) closeOfflineModal(); } }
        for (let k = 0; k < __TAPS__; k++) tap();
        // 施設: 購入→律速工程→熟成庫→ボトリングの順で強化
        let guard = 0;
        const saving = G.dl < DL.length && tierReqStatus(G.dl + 1).filter(o => !o.money).every(o => o.ok || o.label.includes('年以上'));
        while (!saving && guard++ < 200) {
          const cand = [];
          FD.forEach(f => { if (isUL(f.id) && !G.fac[f.id].p) cand.push({ c: fpc(f.id), fn: () => purFac(f.id) }); });
          FD.forEach(f => { if (brPending(f.id)) brChoose(f.id, ['malting','mashing','fermentation'].includes(f.id) ? 1 : f.id === 'maturation' ? 1 : f.id === 'bottling' ? 1 : 0); });
          const fl = prodFlows(); let bn = fl.bottleneck >= 0 ? STAGES[fl.bottleneck].fac : null;
          if (!bn) { const st = STAGES.filter(s => G.fac[s.fac].p).sort((a, b) => G.fac[a.fac].l - G.fac[b.fac].l)[0]; bn = st ? st.fac : 'malting'; }
          const targets = [bn, 'maturation', 'bottling'];
          targets.forEach(id => { if (G.fac[id].p && G.fac[id].l < facMaxLv() && !brPending(id)) cand.push({ c: fuc(id) * (id === bn ? 1 : 1.5), real: fuc(id), fn: () => upgFac(id) }); });
          if (G.cl < tapMaxLv()) cand.push({ c: cuc() * 3, real: cuc(), fn: upgClick });
          cand.sort((a, b) => a.c - b.c);
          const best = cand[0]; if (!best) break;
          const need = best.real || best.c; if (G.cash < need * 1.02) break;
          best.fn(); closeM(); act.up++;
        }
        // v5.0 配置：none=誰も置かない / owner=あなただけ（いちばん遅い工程） / fac=設備5つに職人＋あなたは樽
        //          faclot=fac＋目標が近い樽に職人5人 / full=在籍の上限まで雇っておまかせ配置＋あなたは樽
        if (__ST__ !== 'none') {
          const want = __ST__ === 'fac' ? 5 : __ST__ === 'faclot' ? 10 : __ST__ === 'full' ? 99 : 0;
          let g = 0;
          while (staffOn() && want > 0 && g++ < 20) {
            if (G.staff.length >= Math.min(want, staffCap())) break;
            const c = staffCandState(); let best = -1, bv = -1;
            c.list.forEach((cd, i) => { const v = Math.max(cd.st.waza, cd.st.tegiwa, cd.st.mekiki) + (cd.st.waza + cd.st.tegiwa + cd.st.mekiki) / 10; if (v > bv) { bv = v; best = i; } });
            if (best < 0) { if (c.free > 0) { staffRefresh(); continue; } break; }
            const fee = staffHireFee(c.list[best]); if (G.cash < fee + staffWagesPh() * 12 + staffWage({ st: c.list[best].st, lv: 1 }) * 12) break;
            if (!staffHire(best)) break;
          }
          const lotsByEta = () => G.lots.filter(l => lotGoalEta(l) > 0).sort((a, b) => lotGoalEta(a) - lotGoalEta(b));
          if (__ST__ === 'owner') { const f = prodFlows(); const bn = f.bottleneck >= 0 ? STAGES[f.bottleneck].fac : null; if (bn && placeKey(G.ownerAt) !== 'fac:' + bn) placeSet(OWNER, { k: 'fac', id: bn }, true); }
          else {
            G.staff.forEach(s => s.at = null); G.ownerAt = null; placeInvalidate();
            if (__ST__ === 'full') placeAuto(true);
            else {
              const pool = G.staff.slice(); const taken = new Set();
              V50.FACS.filter(f => placeOk({ k: 'fac', id: f })).forEach(f => { if (!pool.length) return; const at = { k: 'fac', id: f }; const w = placeBest(pool, at); placeSetRaw(w, at); taken.add(placeKey(at)); pool.splice(pool.indexOf(w), 1); });
              lotsByEta().forEach(l => { if (!pool.length) return; const at = { k: 'lot', id: l.id }; const w = placeBest(pool, at); placeSetRaw(w, at); taken.add(placeKey(at)); pool.splice(pool.indexOf(w), 1); });
            }
            placeInvalidate();
            const used = new Set(Object.keys(placeMap())); const ol = lotsByEta().find(l => !used.has('lot:' + l.id)); if (ol) G.ownerAt = { k: 'lot', id: ol.id };
            placeInvalidate(); staffInvalidate();
          }
        }

        const rq0 = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 99, n: 0 };
        const prot0 = new Set(G.lots.slice().sort((x, y) => y.age - x.age).slice(0, rq0.n + 2).map(l => l.id));
        const pvOk = o => { const ids = lotsFor(o.pid).filter(l => !prot0.has(l.id) && l.age >= o.minAge).map(l => l.id); return botPreview(o.pid, o.qty, 'manual', ids, o.minAge).ok; };
        G.orders.slice().forEach(o => { const feas = o.kind==='product' ? (pvOk(o) || ordMatch(o).ok) : ordMatch(o).ok;
          if (o.reserve && !o.accepted) { if (feas) ordAccept(o.id); else ordDismiss(o.id); }
          else if (!o.reserve && !feas && o.kind !== 'product') ordDismiss(o.id);
          else if (!o.reserve && o.kind === 'product' && !feas && o.minAge > maxStockAge()) ordDismiss(o.id); });
        const rqp = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 99, n: 0 };
        const prot = new Set(G.lots.slice().sort((x, y) => y.age - x.age).slice(0, rqp.n + 2).map(l => l.id));
        G.orders.forEach(o => {
          if (o.kind === 'product' && !ordMatch(o).ok) { const ids = lotsFor(o.pid).filter(l => !prot.has(l.id) && l.age >= o.minAge).map(l => l.id); const pv = botPreview(o.pid, o.qty, 'manual', ids, o.minAge); if (pv.ok) botStart(o.pid, o.qty, 'manual', ids, { minAge: o.minAge }); }
        });
        G.orders.slice().forEach(o => { const m = ordMatch(o);
          if (o.kind === 'cask' && m.ok) { const rq = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 99, n: 0 }; const cnt = G.lots.filter(l => l.age >= rq.age).length; const young = m.lots.filter(l => l.age < rq.age).sort((a, b) => lotValue(b) - lotValue(a))[0]; if (young) { if (ordDeliver(o.id, young.id)) act.del++; return; } if (cnt - 1 < rq.n + 2) { ordDismiss(o.id); return; } }
          if (m.ok && (!o.reserve || o.accepted)) { if(ordDeliver(o.id, m.lot ? m.lot.id : null))act.del++; } });
        // 若い樽(3年以上・倉庫の半分超過分)を瓶詰めして直販 → Tier条件用に年代を残す
        const keepAge = (G.dl < DL.length && DL_REQ[G.dl]) ? DL_REQ[G.dl].casks : { age: 25, n: 0 };
        const sorted = G.lots.slice().sort((a, b) => a.age - b.age);
        const protect = new Set(G.lots.slice().sort((a, b) => b.age - a.age).slice(0, keepAge.n + 6).map(l => l.id));
        const spare = ENV.sell ? sorted.filter(l => l.age >= 3 && !protect.has(l.id)) : sorted.filter(l => l.age >= 3 && !protect.has(l.id)).slice(0, Math.max(0, G.lots.length - Math.floor(whSlots() * 0.6)));
        if (ENV.sell === 'cask3') spare.forEach(l => sellLot(l.id)); else if (ENV.sell === 'caskold') spare.filter(l => l.age >= 20).forEach(l => sellLot(l.id)); else if (ENV.sell === 'btl3') spare.forEach(l => { if (G.bq.length < 15) lotRoute(l.id, 'spot'); }); else spare.forEach(l => { const ps = lotProducts(l).sort((a, b) => priceUnit(b, l.age, l.q, lotFlavor(l)) - priceUnit(a, l.age, l.q, lotFlavor(l))); if (ps[0] && G.bq.length < 15) { const n = Math.floor(l.L / 0.7); botStart(ps[0], n, 'manual', [l.id]); } });
        G.bottles.slice().forEach(r => { const keep = 30; if (invTotal(r.pid) > keep) spotSell(r.id, Math.min(r.n, invTotal(r.pid) - keep), true); });
        // 地域パスポート
        Object.keys(REGIONS).forEach(id => { if (!G.regions[id] && G.cash > REGIONS[id].cost * 3) purchaseRegion(id); });
        REGIONS_EX.forEach(r => { if (!G.regionsEx.includes(r.id) && G.dl >= r.unlockTier && G.cash > r.cost * 3) buyExRegion(r.id); });
        // 品評会
        COMPETITIONS.forEach(c => { const row = G.bottles.filter(r => r.n >= 6).sort((a, b) => compExpected(b) - compExpected(a))[0]; if (row && G.reputation >= c.unlockRep && G.cash > c.entryCost * 3 && !(Date.now() < (G.compCooldowns[c.id] || 0)) && compExpected(row) >= c.qualThreshold) enterComp(c.id, row.id); });
        closeM();
        if (canUpgDist()) { const t = G.dl + 1; doUpgDist(tierCost(t), t); out.push({ day: +(h / 24).toFixed(2), ev: 'Tier' + t, cash: G.cash }); }
      }
      // 時間を1時間進める
      off += H; if (!__DAILY__) { prodTick(H); lotTick(H); botTick(H); ordAutoTick(); ordExpireTick(Date.now()); ordSpawnTick(Date.now()); tickActiveEvent(); checkChapters(); _celebQ=[]; generateDailyMissions(); tickDailyMissions(); if(G.reputation>0&&!psk('ps_rep_decay'))G.reputation=Math.max(0,G.reputation-0.05); } else if (hod === 20) { G.ls = Date.now(); }
      if (h % 24 === 23) { daily.push({up:act.up,del:act.del,dl:G.dl}); act={up:0,del:0}; }
      if (h % 24 === 23 && ((h+1)/24)%5===0) out.push({ day: (h + 1) / 24, dl: G.dl, cash: Math.round(G.cash), te: Math.round(G.te), nm: Math.round(prodFlows().newmake), lots: G.lots.length + '/' + whSlots(), maxAge: +G.stats.maxAge.toFixed(1), shipped: G.stats.shipped, orders: G.stats.orders, rep: Math.round(G.reputation), c12: G.lots.filter(l=>l.age>=12).length, ages: G.lots.map(l=>Math.floor(l.age)).sort((a,b)=>b-a).slice(0,14).join(','), rels: CUSTOMERS.map(c=>(G.rel[c.id]||{}).lv||0).join(''), uw: G.uw.length, req: G.dl < 5 ? tierReqStatus(G.dl + 1).map(o => (o.ok ? '✓' : '✗') + o.label.slice(0, 6)).join(' ') : '' });
    }
    let gap=0,maxGap=0,prevDl=1;daily.forEach(d=>{if(d.up===0&&d.del===0&&d.dl===prevDl)gap++;else gap=0;prevDl=d.dl;maxGap=Math.max(maxGap,gap);});
    const ps=[acctLive()].concat(G.acct.hist);const sm=f=>Math.round(ps.reduce((a,p)=>a+f(p),0));out.push({rev:Object.fromEntries(['ord','spot','ext','lot','tap','oth'].map(k=>[k,sm(p=>p.rev[k]||0)])),hgUsed:G.hg.used,hgGot:G.hg.got});out.push({acc:{R:sm(p=>p.R),barley:sm(p=>p.pur.barley),cask:sm(p=>p.pur.cask),bottle:sm(p=>p.pur.bottle),S:sm(p=>p.S),capex:sm(p=>p.capex),dep:sm(p=>p.dep),cogs:sm(p=>p.cogs),ni:sm(p=>p.ni),inv:Math.round(ps[0].c.inv),lotInv:Math.round(ps[0].c.ib.lot),fa:Math.round(ps[0].c.fa),cash:Math.round(G.cash)},months:ps.slice().reverse().map(p=>({R:+(p.R/1e8).toFixed(1),capex:+(p.capex/1e8).toFixed(1),dep:+(p.dep/1e8).toFixed(1),ni:+(p.ni/1e8).toFixed(1),opm:p.R>0?Math.round(p.ni/p.R*100):null,fa:+(p.c.fa/1e8).toFixed(1)}))});out.push({tastings:G.stats.tastings||0,rep:Math.round(G.reputation),acctHist:(G.acct&&G.acct.hist.length)||0,maxUnex:Math.max(0,...((G.acct&&G.acct.hist)||[]).map(h=>Math.abs(h.unex))),maxIdleDays:maxGap,barleyCost:Math.round(G.stats.barleyCost||0),barleyKg:Math.round(G.stats.barleyKg||0),te:Math.round(G.te),starved:!barleyOK()});
    { const ps2 = [acctLive()].concat(G.acct.hist); out.push({ staff: { n: G.staff.length, wb: G.whBonus || 0, maxAge: +G.stats.maxAge.toFixed(1), lab: Math.round(ps2.reduce((a, p) => a + acctLabor(p), 0)), ni: Math.round(ps2.reduce((a, p) => a + p.ni, 0)), R: Math.round(ps2.reduce((a, p) => a + p.R, 0)), op30: Math.round(ps2.slice(0, 2).reduce((a, p) => a + p.ni, 0)) } }); }
    return out;
  }, [Number(process.argv[2]||90),Number(process.argv[3]||50),process.argv[4]==='daily',process.argv[5]==='hg',process.argv[6]||'none',Number(process.argv[7]||0),ENV]);
  log.forEach(x => console.log(JSON.stringify(x)));
  console.log('errors', errs);
  await browser.close();
})();
