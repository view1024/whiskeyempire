function canPrestige(){
  if(G.dl<DL.length)return false;
  return prestigeCash()>=PRESTIGE_COST; // v5.7 借入金と未払法人税を除いた現金
}
function openPrestigeModal(){
  if(!canPrestige()){toast('再創業の条件を満たしていません',3000);return;}
  const mo=document.getElementById('mo'),mc2=document.getElementById('mc2');
  if(!mo||!mc2)return;
  const gainPts=3;
  const prevPts=(G.prestige&&G.prestige.skillPoints)||0;
  const totalPts=prevPts+gainPts;
  const runs=(G.prestige&&G.prestige.totalRuns)||0;
  // v5.6 次の創業地：開いている地から選ぶ（新しく開く地を初期選択）
  const nxo=CLIMATES.find(c=>c.unlockRun===runs+1);
  let selSkills={},usedPts=0,climateSel=nxo?nxo.id:(G.climate||'speyside');

  function renderPModal(){
    const treeLabel={basic:'基礎強化',craft:'製造特化',rep:'評判特化',speed:'速攻'};
    const trees=[...new Set(PRESTIGE_SKILLS.map(s=>s.tree))];
    let sh='';
    trees.forEach(tr=>{
      sh+=`<div style="font-family:var(--fm);font-size:10px;color:var(--gold);margin:10px 0 5px;letter-spacing:.06em">${treeLabel[tr]||tr}</div>`;
      PRESTIGE_SKILLS.filter(s=>s.tree===tr).forEach(sk=>{
        const own=(G.prestige&&G.prestige.skills&&G.prestige.skills[sk.id])||0;
        const sel=selSkills[sk.id]||0;
        const canAdd=usedPts+sk.cost<=totalPts;
        sh+=`<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;padding:8px;background:var(--bg3);border-radius:6px;border:1px solid ${sel?'var(--gold)':'var(--border)'}">
 <div style="flex:1;min-width:0">
 <div style="font-family:var(--fd);font-size:12px;color:var(--cream)">${sk.name}${own?' <span style="color:var(--amber);font-size:10px">取得済×'+own+'</span>':''}${sel?' <span style="color:var(--gold2);font-size:10px">+'+sel+'</span>':''}</div>
 <div class="uf f10 um">${sk.desc} | ${sk.cost}pt</div>
 </div>
 ${sel?`<button onclick="window._rmSk('${sk.id}',${sk.cost})" style="background:var(--bg2);border:1px solid var(--red);border-radius:4px;padding:2px 8px;color:var(--red);font-size:12px;cursor:pointer">-</button>`:''}
 <button onclick="window._addSk('${sk.id}',${sk.cost})" ${canAdd?'':'disabled'} style="background:${canAdd?'var(--amber)':'var(--bg2)'};border:none;border-radius:4px;padding:2px 8px;color:${canAdd?'#1a1208':'var(--muted)'};font-size:12px;cursor:${canAdd?'pointer':'default'}">+</button>
 </div>`;
      });
    });
    let ch='';
    CLIMATES.forEach(c=>{
      const ok=originOpen(c,runs+1);
      const on=climateSel===c.id;const isNew=c.unlockRun===runs+1;
      if(!ok){ch+=`<div class="pcl lk"><div class="tt" style="font-size:13px">${c.icon} ${escapeHtml(c.name)} <span class="sm">🔒 再創業${c.unlockRun}回で開く</span></div></div>`;return;}
      ch+=`<div class="pcl${on?' on':''}" data-act="pickOrigin" data-id="${c.id}" role="button">
 <div class="tt" style="font-size:13px">${c.icon} ${escapeHtml(c.name)} ${isNew?'<span class="badge b-res">新しく開く</span>':''}${on?' <span style="color:var(--gold2);font-size:12px">選択中</span>':''}</div>
 <div class="sm" style="margin-top:2px">${escapeHtml(c.desc)}（${escapeHtml(originTraits(c))}）</div>
 <div class="sm" style="color:var(--gold2)">市場：${escapeHtml(c.mkt)}</div>
 </div>`;
    });
    mc2.innerHTML=`<div class="mt">🌟 再創業</div>
 <div class="ms">次の創業地で再創業 — 引き継ぎボーナス付き</div>
 <div style="font-family:var(--fm);font-size:12px;background:var(--bg3);border-radius:6px;padding:10px;margin-bottom:10px;color:var(--text2)">
 <div>再創業: ${G.prestige&&G.prestige.level||0} → <span style="color:var(--gold2)">${(G.prestige&&G.prestige.level||0)+1}</span></div>
 <div>収益ボーナス: ×${(G.prestige&&G.prestige.bonus||1).toFixed(1)} → <span style="color:var(--gold2)">×${(1+((G.prestige&&G.prestige.level||0)+1)*0.1).toFixed(1)}</span></div>
 <div>スキルポイント: 既存 ${prevPts}pt + 今回 +${gainPts}pt = <span style="color:var(--gold2)">${totalPts-usedPts}</span>pt 残り</div>
 <div style="margin-top:4px;color:var(--muted)">引き継ぐ：図鑑・銘柄ごとの出荷本数・称号・物語・スキル・創業地ごとの記録・開いた創業地・砂時計。資金・設備・原酒・瓶・取引先・Tier の実績・買った販売地域の倍率は引き継ぎません</div>
 </div>
 <div style="font-family:var(--fd);font-size:13px;color:var(--cream);margin-bottom:4px">次の創業地</div>
 ${ch}
 <div style="font-family:var(--fd);font-size:13px;color:var(--cream);margin:10px 0 4px">スキルを選択（残りptで購入）</div>
 ${sh}
 <button onclick="execPrestige(window._selSk,window._clSel)" style="width:100%;margin-top:14px;padding:13px;background:var(--gb);border:none;border-radius:10px;font-family:var(--fd);font-size:15px;font-weight:700;color:#1a1208;cursor:pointer">✓ 再創業する</button>`;
  }
  window._selSk=selSkills;window._clSel=climateSel;
  window._addSk=function(id,cost){if(usedPts+cost>totalPts)return;selSkills[id]=(selSkills[id]||0)+1;usedPts+=cost;window._selSk=selSkills;renderPModal();};
  window._rmSk=function(id,cost){if(!selSkills[id])return;selSkills[id]--;if(!selSkills[id])delete selSkills[id];usedPts-=cost;window._selSk=selSkills;renderPModal();};
  window._pickCl=function(id){const c=CLIMATES.find(x=>x.id===id);if(!c||!originOpen(c,runs+1))return;climateSel=id;window._clSel=id;renderPModal();};
  mo.classList.remove('h');
  renderPModal();
}
function execPrestige(selectedSkills,climateId){
  if(!canPrestige()){toast('プレステージ条件未達成',3000);return;}
  const nextLv=(G.prestige&&G.prestige.level||0)+1;
  const bonus=1+nextLv*0.1;
  const prevSkills=G.prestige&&G.prestige.skills||{};
  const prevSP=(G.prestige&&G.prestige.skillPoints)||0;
  const prevLW=(G.prestige&&G.prestige.legacyWhiskies)||[];
  const prevRuns=(G.prestige&&G.prestige.totalRuns)||0;
  const newSkills={...prevSkills};
  let usedHere=0;
  if(selectedSkills){
    Object.entries(selectedSkills).forEach(([id,lv])=>{
      if(lv>0){newSkills[id]=(newSkills[id]||0)+lv;const sk=PRESTIGE_SKILLS.find(s=>s.id===id);if(sk)usedHere+=sk.cost*lv;}
    });
  }
  const newLW=[...prevLW];
  const lw=LEGACY_WHISKIES.find(w=>w.unlockRun===nextLv);
  if(lw&&!newLW.includes(lw.id)){newLW.push(lw.id);toast('🥃 引き継ぎ銘柄解禁: '+lw.name,5000);}
  const cl=CLIMATES.find(c=>c.id===climateId&&originOpen(c,prevRuns+1))||CLIMATES[0];
  {const rc=recCur();rc.te=(rc.te||0)+(G.te||0);rc.maxTier=Math.max(rc.maxTier||1,G.dl||1);if(!(rc.runs>0))rc.runs=1;} // v5.6 その地の通算の売上・到達した Tier
  const keep={story:G.story,uw:[...(G.uw||[])],cw:{...(G.cw||{})},tl:[...(G.tl||[])],questDone:[...(G.questDone||[])],shipped:G.stats.shipped,awardsWon:G.stats.awardsWon||0,awards:[...(G.awards||[])],blendHistory:G.blendHistory||[],tut:G.tut,shipLog:G.shipLog||{},encSeen:G.encSeen||[],opt:G.opt,chap:G.chap,records:G.records||{},jnl:G.jnl,staff:staffKeepOne()};
  const accPrev=acctPrevSummary();
  const s=defState();
  s.acct={prev:accPrev};
  s.prestige={level:nextLv,bonus,skillPoints:Math.max(0,prevSP+3-usedHere),skills:newSkills,legacyWhiskies:newLW,totalRuns:prevRuns+1};
  s.story=keep.story;s.uw=keep.uw;s.cw=keep.cw;s.tl=keep.tl;s.questDone=keep.questDone;s.awards=keep.awards;s.blendHistory=keep.blendHistory;s.tut=keep.tut;s.shipLog=keep.shipLog;s.encSeen=keep.encSeen;s.opt=keep.opt;s.chap=keep.chap;s.records=keep.records;s.jnl=keep.jnl;s.staff=keep.staff;s.whBonus=G.whBonus||0;s.ownerAt=null;s.runStart=Date.now(); // v5.0 樽の枠の恒久ボーナスは再創業でも残す
  {const k=cl.id;if(!s.records[k])s.records[k]={bestUnit:0,maxAge:0,tierDays:{},runs:0,te:0,maxTier:1};s.records[k].runs=(s.records[k].runs||0)+1;}
  s.climate=cl.id;
  const hgKeep=hgState();s.hg=Object.assign({},s.hg,{n:Math.min(V47.HG_MAX,hgKeep.n||0),got:hgKeep.got||0,used:hgKeep.used||0,streak:hgKeep.streak,month:hgKeep.month});
  Object.assign(G,s);
  hgAdd(V51.HG.prestige.k,'再創業','prestige',true);
  prodInvalidate();
  postLoadInit();
  const mo=document.getElementById('mo');if(mo)mo.classList.add('h');
  save();rall();
  toast('🌟 '+cl.icon+' '+cl.name+'で再創業（'+nextLv+'回目） / 収益×'+bonus.toFixed(1),8000);
}
