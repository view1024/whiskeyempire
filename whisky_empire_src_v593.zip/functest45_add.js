  // ================= v4.5 追加テスト =================
  // ---------- #81 ホームの並び・お知らせ廃止・次にやることの行の廃止 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      switchTab('td'); rdistLight();
      const order = [...document.getElementById('td').children].map(e => e.id);
      const st = document.getElementById('stage').getBoundingClientRect();
      const hi = [...document.querySelectorAll('#homeIcons .hi')].map(b => b.id);
      const gone = ['hintMake', 'hintAge', 'hintSell', 'hi_news', 'nextCard'].filter(id => document.getElementById(id));
      return { order, stageH: Math.round(st.height), stageBottom: Math.round(st.bottom), navTop: Math.round(document.getElementById('nav').getBoundingClientRect().top), hi, gone, nu: typeof nextUnlockText, pn: typeof pushNews };
    });
    rec(81, 'ホーム：上から「生産の流れ → アイコン列 → 景色と樽」・お知らせと各タブ冒頭の「次にやること」の行はない', r.order.join() === 'flow,homeIcons,stage' && r.stageH >= 300 && Math.abs(r.stageBottom - r.navTop) <= 12 && r.hi.includes('hi_fin') && !r.hi.includes('hi_news') && r.gone.length === 0 && r.nu === 'undefined' && r.pn === 'undefined', JSON.stringify(r));
    if (errors.length) rec('E40', 'ホーム並びテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #82-83 樽タップの額・試飲会 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('td');
      let T = Date.now(); _acctClock = () => T;
      G.taste = { n: 0, cnt: 0, day: '' };
      const expV = cv() + 0.002 * ti(); const v = tapValue();
      const c0 = G.cash; tap(null); const gain = G.cash - c0;
      const o = { expV, v, gain };
      // 29回目までは試飲会なし、30回目で評判+1・注文が30分早まる
      G.taste = { n: 0, cnt: 0, day: tasteToday() };
      const rep0 = G.reputation; const clk0 = G.orderClock = Date.now() + 5 * 3600000;
      for (let i = 0; i < 29; i++) tap(null);
      o.before = { cnt: G.taste.cnt, n: G.taste.n, rep: G.reputation - rep0 };
      tap(null);
      o.after = { cnt: G.taste.cnt, n: G.taste.n, rep: +(G.reputation - rep0).toFixed(6), clk: (clk0 - G.orderClock) / 60000, tastings: G.stats.tastings };
      o.ui = { txt: document.getElementById('tgTxt').textContent, w: document.getElementById('tgFill').style.width };
      for (let i = 0; i < 30 * 6; i++) tap(null);
      o.cap = { cnt: G.taste.cnt, n: G.taste.n, txt: document.getElementById('tgTxt').textContent };
      T += 864e5; tasteUi();
      o.next = { cnt: tasteState().cnt, txt: document.getElementById('tgTxt').textContent };
      _acctClock = () => Date.now();
      const dp = DAILY_POOL.find(p => p.id === 'dm_taste');
      o.daily = dp ? dp.label.replace('NOT回', '2回') : '';
      const tc = document.querySelector('.tgauge .tgtxt'); o.fs = parseFloat(getComputedStyle(tc).fontSize);
      return o;
    });
    rec(82, 'タップ：1回の額＝見学ツアー額＋毎時の外販収入×0.2%', Math.abs(r.v - r.expV) < 1e-9 && Math.abs(r.gain - r.v) < 1e-6 && r.v > 0, JSON.stringify({ v: r.v, expV: r.expV, gain: r.gain }));
    rec(83, '試飲会：30回で評判+1・次の注文が30分早まる・1日5回まで・日が変わると再開・ゲージ表示とデイリー', r.before.cnt === 0 && r.before.n === 29 && r.before.rep === 0 && r.after.cnt === 1 && r.after.n === 0 && Math.abs(r.after.rep - 1) < 1e-6 && Math.abs(r.after.clk - 30) < 0.01 && r.ui.txt.includes('0/30') && r.ui.txt.includes('1/5') && r.cap.cnt === 5 && r.cap.txt.includes('本日終了') && r.next.cnt === 0 && r.next.txt.includes('0/5') && r.daily === '試飲会を2回開く' && r.fs >= 12, JSON.stringify(r));
    if (errors.length) rec('E41', '試飲会テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #84-86 決算書：3表のつながり・現金の照合・原価の流れ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let T = Date.now(); _acctClock = () => T;
      G.acct = null; acctEnsure();
      const tol = v => Math.max(1, Math.abs(v) * 1e-9);
      const checks = []; const chk = tag => { const s = acctLive(); checks.push({ tag, na: naOf(s.c) - naOf(s.o) - s.ni, cash: s.c.cash - s.o.cash - s.opcf - s.invcf, unex: s.unex, tolv: tol(s.c.cash) }); };
      // 原価の流れ：樽に詰める → 瓶詰め → 直販
      G.tank = 5000; G.cash = Math.max(G.cash, 1e7); acctEnsure();
      const bA = acctBAvg(); const cc = caskCost('bourbon', 'hogshead');
      const c0 = G.cash; fillCask('bourbon', 'hogshead', false); const lot = G.lots[G.lots.length - 1];
      const fillOk = Math.abs(c0 - G.cash - cc) < 1e-6 && Math.abs(lot.c - (250 * bA + cc)) < 1e-6;
      chk('fill');
      lot.age = 12; const pid = lotProducts(lot)[0] || 'glenlivid'; if (!G.uw.includes(pid)) G.uw.push(pid);
      const lc0 = lot.c, L0 = lot.L; const n = 20; const unit = btlUnit(); const c1 = G.cash;
      const okB = botStart(pid, n, 'manual', [lot.id], {}); const q = G.bq[G.bq.length - 1];
      const matOk = okB && Math.abs(c1 - G.cash - unit * n) < 1e-6;
      const drawOk = Math.abs((lc0 - lot.c) + unit * n - q.c) < 1e-6 && Math.abs((lc0 - lot.c) / lc0 - (n * BALANCE.BOTTLE_L) / L0) < 1e-9;
      botTick(3600000 * 10);
      const row = G.bottles.find(b => b.pid === pid && b.age === q.age);
      const rowC0 = row ? row.c : -1; const rowN0 = row ? row.n : 0;
      chk('bottled');
      const s0 = acctLive(); spotSell(row.id, 5, true); const s1 = acctLive();
      const saleOk = Math.abs((rowC0 - (row.c || 0)) - rowC0 * 5 / rowN0) < 1e-6 && s1.rev.spot > s0.rev.spot;
      chk('spot');
      // 所持金を動かす処理を一通り
      acOther(1e12 - G.cash); G.cash = 1e12;
      for (const f of FD) { if (!G.fac[f.id].p && isUL(f.id)) purFac(f.id); }
      upgFac('malting'); upgClick(); purchaseRegion(Object.keys(REGIONS).find(id => !G.regions[id]) || 'x');
      const rx = REGIONS_EX.find(x => !G.regionsEx.includes(x.id)); if (rx) buyExRegion(rx.id);
      const rk = RAW_MATERIALS.grain.find(x => !G.recipeOwned.includes(x.id)); if (rk) rcpBuy('grain', rk.id);
      barleyBuyFull(); sellNewmake(100); if (G.lots.length > 3) sellLot(G.lots[0].id);
      applyEventEffect({ type: 'x', effect: { cash: -12345 } }); applyEventEffect({ type: 'x', effect: { cashMult: 1.01 } }); applyEventEffect({ type: 'x', effect: { cashBonus: '2h' }, icon: '' });
      for (let i = 0; i < 10; i++) tap(null);
      for (let i = 0; i < 36; i++) { T += 100000; prodTick(100000); lotTick(100000); botTick(100000); }
      const ol = G.lots.find(l => l.age >= 2 && typeof finishable === 'function' && finishable(l)); if (ol) lotFinish(ol.id, 'sherry');
      chk('ops');
      const dep0 = acctLive().dep;
      // 月をまたぐ
      const fa0 = faNBV(acctMonthF(T)); const faHalf = faNBV(acctMonthF(T) + V45.FA_MONTHS / 2);
      const mBefore = G.acct.cur.m; T += 40 * 864e5; acctEnsure(); const rec0 = G.acct.hist[0];
      chk('newmonth');
      const chain = Math.abs(naOf(rec0.c) - naOf(G.acct.cur.o)) < 1e-6 && Math.abs(rec0.c.cash - G.acct.cur.o.cash) < 1e-6;
      const recOk = Math.abs(naOf(rec0.c) - naOf(rec0.o) - rec0.ni) < tol(rec0.c.cash) && Math.abs(rec0.c.cash - rec0.o.cash - rec0.opcf - rec0.invcf) < tol(rec0.c.cash) && Math.abs(rec0.unex) < tol(rec0.c.cash) && rec0.m === mBefore && rec0.to === mBefore + 1;
      // 償却：耐用年数（実時間10日）で簿価0
      const faEnd = faNBV(acctMonthF(T));
      _acctClock = () => Date.now();
      return { checks, fillOk, matOk, drawOk, saleOk, chain, recOk, rec0: { m: rec0.m, to: rec0.to, R: rec0.R, ni: rec0.ni, dep: rec0.dep, cogs: rec0.cogs, unex: rec0.unex }, dep0, fa0, faHalf, faEnd, cats: Object.keys(rec0.rev).filter(k => rec0.rev[k] > 0).join(',') + '|' + Object.keys(rec0.pur).filter(k => rec0.pur[k] > 0).join(',') + '|' + Object.keys(rec0.sga).filter(k => rec0.sga[k] > 0).join(',') };
    });
    const bad = r.checks.filter(c => Math.abs(c.na) > c.tolv || Math.abs(c.cash) > c.tolv || Math.abs(c.unex) > c.tolv);
    rec(84, '決算書：どの時点でも「期首純資産＋純利益＝期末純資産」「期首現金＋営業CF＋投資CF＝期末現金」、月をまたぐと前月が確定し翌月の期首につながる・設備は実時間10日で償却', bad.length === 0 && r.chain && r.recOk && r.fa0 > 0 && r.faHalf > r.fa0 * 0.3 && r.faHalf < r.fa0 * 0.7 && r.faEnd < 1e-6, JSON.stringify({ bad, chain: r.chain, recOk: r.recOk, rec0: r.rec0, fa0: r.fa0, faHalf: r.faHalf, faEnd: r.faEnd }));
    rec(85, '現金の照合：所持金を動かす全処理に科目が付き、科目のない増減が0', r.checks.every(c => Math.abs(c.unex) <= c.tolv) && r.cats.includes('spot') && r.cats.includes('tap') && r.cats.includes('ext') && r.cats.includes('lot') && r.cats.includes('barley') && r.cats.includes('cask') && r.cats.includes('bottle') && r.cats.includes('rcp') && r.cats.includes('rg'), JSON.stringify({ cats: r.cats, unex: r.checks.map(c => c.tag + ':' + c.unex) }));
    rec(86, '原価：樽＝新酒（大麦単価）＋樽代、瓶詰めで使った量の割合だけ原価が移り資材費が加わる、売れた分だけ在庫の原価が減る', r.fillOk && r.matOk && r.drawOk && r.saleOk, JSON.stringify({ fillOk: r.fillOk, matOk: r.matOk, drawOk: r.drawOk, saleOk: r.saleOk }));
    if (errors.length) rec('E42', '決算書テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #87 瓶の資材費 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      const o = {};
      o.unit = btlUnit(); o.expUnit = 8 * distMult();
      const l = G.lots.find(x => x.age >= 12) || G.lots[0]; const pid = lotProducts(l)[0];
      G.stats.freeBtl = 1; G.bq = []; G.cash = o.unit * 10 - 1;
      const n0 = G.bq.length; o.fail = !botStart(pid, 10, 'manual', [l.id], {}) && G.bq.length === n0;
      G.cash = o.unit * 10 + 5; o.ok = botStart(pid, 10, 'manual', [l.id], {}) && Math.abs(G.cash - 5) < 1e-6;
      // 最初の1回は無料
      G.stats.bottled = 0; G.stats.freeBtl = 0; G.bq = []; G.cash = 0;
      o.free = btlFreeAvail() && botStart(pid, 10, 'manual', [l.id], {}) && G.cash === 0 && G.stats.freeBtl === 1 && !btlFreeAvail();
      switchTab('tsale'); _ui.sellTab = 'ord'; rShip();
      o.bqTxt = document.querySelector('#bqBox .bmat') ? document.querySelector('#bqBox .bmat').textContent : '';
      const od = G.orders.find(x => x.kind === 'product' && !ordMatch(x).ok && ordFulfillPlan(x).ok);
      if (od) { openOrderInfoModal(od.id); o.modal = document.getElementById('mc2').textContent; closeM(); }
      return o;
    });
    rec(87, '瓶の資材：瓶詰めの開始時に本数×$8×Tier倍率を払う・足りなければ始まらない・最初の1回は無料・売るタブと注文の詳細に表示', Math.abs(r.unit - r.expUnit) < 1e-9 && r.fail && r.ok && r.free && r.bqTxt.includes('/本') && (!r.modal || (r.modal.includes('瓶の資材') && r.modal.includes('差し引き'))), JSON.stringify(r));
    if (errors.length) rec('E43', '資材費テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #88-89 寝かせる：①→③の流れ・樽の見た目 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      switchTab('tcel'); rCellar();
      const ids = [...document.getElementById('tcel').children].filter(e => e.getClientRects().length).map(e => e.id || e.className);
      const ys = ['celTank', 'fillBox', 'whSummary'].map(id => document.getElementById(id).getBoundingClientRect().top);
      const nos = ['celTank', 'fillBox', 'whSummary'].map(id => (document.querySelector('#' + id + ' .cno') || {}).textContent);
      const cells = [...document.querySelectorAll('#whSummary .ck2[data-id]')];
      const bad = [];
      cells.forEach(c => { const l = G.lots.find(x => x.id === c.dataset.id); const band = c.querySelector('.ckb'); const pct = c.querySelector('[data-lpct]').textContent; const g = parseFloat(c.querySelector('[data-lpg]').style.height);
        if (!band.classList.contains('ct-' + l.cask) || !band.textContent.startsWith(CT_LETTER[l.cask]) || c.querySelector('.cks b').textContent !== SZ_LETTER[l.size] || pct !== Math.round(l.L / l.L0 * 100) + '%' || Math.abs(g - l.L / l.L0 * 100) > 0.06) bad.push(l.id); });
      const cols = getComputedStyle(document.querySelector('#whSummary .whg2')).gridTemplateColumns.split(' ').length;
      const price = document.querySelector('#fillBox .cp1').textContent; const cc = fmt(caskCost(G.auto.fill.cask, G.auto.fill.size));
      const bgs = new Set(cells.map(c => getComputedStyle(c.querySelector('.ckb')).backgroundColor));
      // 熟成で残量が減ると表示も減る
      const l0 = G.lots[0]; const p0 = l0.L / l0.L0; lotTick(864e5 * 2); rCellarLight();
      const c0 = document.querySelector(`[data-lpct="${l0.id}"]`).textContent; const p1 = l0.L / l0.L0;
      return { ids, ys, nos, n: cells.length, lots: G.lots.length, bad, cols, price, cc, dec: p1 < p0, c0, exp: Math.round(p1 * 100) + '%', types: new Set(G.lots.map(l => l.cask)).size, bgs: bgs.size, key: document.querySelector('#whSummary .whkey').textContent };
    });
    rec(88, '寝かせる：上から「① タンクの新酒 → ② 空き樽を仕入れて詰める（仕入れ値を表示）→ ③ 倉庫」を流れる矢印でつなぐ', r.ids.join() === 'thead,celTank,celF1,fillBox,celF2,whSummary' && r.ys[0] < r.ys[1] && r.ys[1] < r.ys[2] && r.nos.join() === '①,②,③' && r.price.includes(r.cc), JSON.stringify(r));
    rec(89, '倉庫の樽：色の帯と頭文字で種類・文字でサイズ・液面と％で残量（エンジェルズシェアで減る）・4列', r.n === r.lots && r.bad.length === 0 && r.cols === 4 && r.dec && r.c0 === r.exp && r.bgs === r.types && r.key.includes('残量'), JSON.stringify({ n: r.n, bad: r.bad, cols: r.cols, c0: r.c0, exp: r.exp, bgs: r.bgs, types: r.types }));
    if (errors.length) rec('E44', '寝かせるテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #90 決算書の画面 ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(async () => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      let T = Date.now(); _acctClock = () => T;
      G.acct = null; acctEnsure(); G.cash += 1; for (let i = 0; i < 20; i++) tap(null);
      for (let i = 0; i < 36; i++) { T += 100000; prodTick(100000); }
      upgFac('malting');
      T += 35 * 864e5; acctEnsure(); for (let i = 0; i < 5; i++) tap(null);
      G.hs.fin = null; switchTab('td'); rdistLight();
      const badge = document.querySelector('#hi_fin .hib') ? document.querySelector('#hi_fin .hib').textContent : '';
      document.getElementById('hi_fin').click(); await new Promise(r => setTimeout(r, 80));
      const o = { badge, title: document.getElementById('mc2').textContent.includes('決算書') };
      const box = () => { const cols = [...document.querySelectorAll('#finBox .fmain .fcol')].map(c => [...c.children].reduce((a, e) => a + e.getBoundingClientRect().height, 0)); return cols.map(Math.round); };
      o.views = {};
      for (const v of ['pl', 'bs', 'cf']) { document.querySelector(`#finBox [data-act="fsView"][data-v="${v}"]`).click(); await new Promise(r => setTimeout(r, 30)); o.views[v] = { cols: box(), rows: document.querySelectorAll('#finBox .frw').length, per: document.querySelector('#finBox .fper').textContent }; }
      // 面積（高さ）が金額に比例：PLの売上高の箱
      document.querySelector('#finBox [data-act="fsView"][data-v="pl"]').click(); await new Promise(r => setTimeout(r, 30));
      const p = finPeriods()[0]; const rev = document.querySelector('#finBox .fmain .b-rev'); const H = 190;
      const tot = Math.max(p.R, p.cogs + p.S + p.dep + Math.max(0, p.ni)); o.revH = rev ? rev.getBoundingClientRect().height : 0; o.revExp = p.R / tot * H;
      document.querySelector('#finBox [data-act="fsPrev"]').click(); await new Promise(r => setTimeout(r, 30));
      o.prevPer = document.querySelector('#finBox .fper').textContent;
      const mc = document.getElementById('mc2'); o.hscroll = mc.scrollWidth - mc.clientWidth;
      o.small = [...document.querySelectorAll('#finBox *')].filter(e => e.childNodes.length && [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()) && parseFloat(getComputedStyle(e).fontSize) < 12).map(e => e.textContent.slice(0, 10));
      closeM(); rdistLight(); o.badgeAfter = document.querySelector('#hi_fin .hib') ? document.querySelector('#hi_fin .hib').textContent : '';
      _acctClock = () => Date.now();
      return o;
    });
    const eq = c => c.length === 2 && Math.abs(c[0] - c[1]) <= 3;
    rec(90, '決算書の画面：PL・BS・CFを切り替えてボックス図（左右の合計が一致・高さが金額に比例）と数字の表・月の切替・前の月が確定すると「新」', r.badge === '新' && r.title && eq(r.views.pl.cols) && eq(r.views.bs.cols) && eq(r.views.cf.cols) && Math.abs(r.revH - r.revExp) <= 2 && r.views.pl.per.includes('途中経過') && r.prevPer.includes('確定') && r.hscroll <= 0 && r.small.length === 0 && r.badgeAfter === '', JSON.stringify(r));
    if (errors.length) rec('E45', '決算書画面テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #91 schema 10 → 11 の移行 ----------
  {
    const p0 = await page43(667, null, 'mid');
    const v10 = await p0.page.evaluate(() => { const s = JSON.parse(JSON.stringify(G)); s.ver = 10; delete s.acct; delete s.taste; delete s.stats.freeBtl; delete s.stats.tastings; if (s.hs) { delete s.hs.fin; delete s.hs.new45; } s.lots.forEach(l => delete l.c); s.bottles.forEach(b => delete b.c); s.bq.forEach(q => delete q.c); s.tut.done = { first: true }; s.tut.q = []; return s; });
    await p0.ctx.close();
    const pre = `if(!sessionStorage.getItem('w')){sessionStorage.setItem('w','1');localStorage.setItem('we_v4:guest', ${JSON.stringify(JSON.stringify(v10))});}`;
    const ctx = await browser.newContext({ viewport: { width: 390, height: 667 } });
    const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
    await page.addInitScript(pre);
    await page.goto(FILE); await page.waitForTimeout(1500);
    await page.evaluate(() => { titleStart(false); }); await page.waitForTimeout(500);
    const r = await page.evaluate(() => {
      if (_offlineGate) closeOfflineModal();
      acctEnsure(); const s = acctLive(); const a = G.acct;
      return { ver: G.ver, bk: !!localStorage.getItem('we_v4_bak10:guest'), mig: a.mig, faMig: a.faMig, faEst: faEstimate(), cap: a.cap, na0: naOf(a.cur.o), free: G.stats.freeBtl, lotsC: G.lots.every(l => l.c > 0), q: G.tut.q.slice(), new45: G.hs.new45, unex: s.unex, dNA: naOf(s.c) - naOf(s.o) - s.ni };
    });
    rec(91, 'v4.4（schema10）からの移行：バックアップ・設備はこれまでの費用から推計・開始時のBSは資産＝元入金・瓶の無料分は使用済み・変更点の案内', r.ver === 11 && r.bk && r.mig && r.faMig > 0 && Math.abs(r.faMig - r.faEst) / r.faEst < 0.001 && Math.abs(r.cap - r.na0) < 1e-6 && r.free === 1 && r.lotsC && r.q.includes('u45') && r.new45 === 0 && Math.abs(r.dNA) < Math.max(1, r.cap * 1e-9), JSON.stringify(r));
    if (errors.length) rec('E46', '移行テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #92 放置中に月をまたぐ ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'mid');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      // 帳簿を「先月」から始めたことにする
      const now = Date.now(); _acctClock = () => now - 20 * 864e5; G.acct = null; acctEnsure(); const m0 = G.acct.cur.m;
      for (let i = 0; i < 10; i++) tap(null);
      const cashBefore = G.cash;
      _acctClock = () => Date.now();
      G.ls = now - 6 * 3600000; offline(); if (_offlineGate) closeOfflineModal();
      const h = G.acct.hist[0]; const s = acctLive();
      const tol = Math.max(1, Math.abs(G.cash) * 1e-9);
      return { m0, hm: h && h.m, curm: G.acct.cur.m, closedCash: h && h.c.cash, cashBefore, offRev: s.R, okH: h && Math.abs(naOf(h.c) - naOf(h.o) - h.ni) < tol, okS: Math.abs(naOf(s.c) - naOf(s.o) - s.ni) < tol && Math.abs(s.unex) < tol };
    });
    const sameMonth = r.m0 === r.curm;
    rec(92, '放置中に月をまたいでも、前の月は放置前の状態で確定し、放置中の収益は戻った月に計上される', sameMonth || (r.hm === r.m0 && Math.abs(r.closedCash - r.cashBefore) < 1e-6 && r.offRev > 0 && r.okH && r.okS), JSON.stringify(r));
    if (errors.length) rec('E47', '放置の月またぎテスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #93 再創業で事業を区切る ----------
  {
    const { page, errors, ctx } = await page43(667, null, 'late');
    const r = await page.evaluate(() => {
      Object.keys(TUTS).forEach(id => G.tut.done[id] = true); G.tut.q = []; if (_tut) { _tut = null; tutHide(); }
      acctEnsure(); for (let i = 0; i < 10; i++) tap(null);
      const per0 = G.acct.per; const R0 = acctLive().R;
      G.cash = Math.max(G.cash, PRESTIGE_COST + 1); G.dl = DL.length;
      try { execPrestige(null, 'speyside'); } catch (e) { return { err: String(e) }; }
      if (_offlineGate) closeOfflineModal(); closeM();
      for (let i = 0; i < 3; i++) tap(null);
      const a = G.acct;
      return { per0, per1: a.per, prev: a.prev.length, prevR: a.prev[0] && a.prev[0].R, R0, cap: a.cap, hist: a.hist.length };
    });
    rec(93, '再創業：決算書は新しい期として始まり、前の事業の合計が残る', !r.err && r.per1 === r.per0 + 1 && r.prev >= 1 && r.prevR >= r.R0 - 1e-6 && r.hist === 0 && r.cap > 0, JSON.stringify(r));
    if (errors.length) rec('E48', '再創業テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
  // ---------- #94 v4.5.1 Tier4の評判条件・償却期間 ----------
  {
    const { page, errors, ctx } = await page43(667);
    const r = await page.evaluate(() => ({ rep4: DL_REQ[3].rep, rep5: DL_REQ[4].rep, days: V45.FA_DAYS, lifeM: V45.FA_MONTHS, tier: (() => { G.dl = 3; return tierReqStatus(4).find(o => o.label === '評判').need; })() }));
    rec(94, 'v4.5.1：Tier4の評判条件は200（Tier5の240より小さい）・設備の耐用年数は実時間10日', r.rep4 === 200 && r.rep5 > r.rep4 && r.tier === 200 && r.days === 10 && Math.abs(r.lifeM - 10 / 30.4375) < 1e-12, JSON.stringify(r));
    if (errors.length) rec('E49', 'v4.5.1テスト中のエラー', false, errors.join(' | '));
    await ctx.close();
  }
