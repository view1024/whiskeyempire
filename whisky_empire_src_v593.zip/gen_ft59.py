# v5.8 の生成（try で包む前）まで → v5.9 の書き換え → 追加 → try で包む
s58=open('gen_ft58.py').read()
exec(s58[:s58.rindex("exec(src[cut:]")])
exec(open('functest59_fix.py').read())
if os.path.exists('functest59_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest59_add.js').read()+s[a:]
exec(src[cut:].replace("open('functest55.js','w').write(s)","pass"))
open('functest59.js','w').write(s)
