const { chromium } = require('playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:740}});const p=await ctx.newPage();
await p.route(/fonts/,r=>r.abort());await p.goto('file://'+path.resolve('whisky_empire.html'));await p.waitForTimeout(1500);
await p.evaluate(()=>{titleStart(false);_mktOff=true;});await p.waitForTimeout(800);
await p.evaluate(()=>{Object.keys(TUTS).forEach(id=>G.tut.done[id]=true);G.tut.q=[];if(_tut){_tut=null;tutHide();}_celebQ=[];celebClose();});
const meas=async()=>await p.evaluate(async()=>{const o={};for(const t of ['td','tb','tcel','tsale','te','tp']){switchTab(t);await new Promise(r=>setTimeout(r,200));const el=document.getElementById(t);o[t]={h:el.clientHeight,sh:el.scrollHeight,scr:+(el.scrollHeight/el.clientHeight).toFixed(2)};}
 switchTab('td');await new Promise(r=>setTimeout(r,200));const blocks=[...document.getElementById('td').children].filter(e=>e.getClientRects().length).map(e=>(e.id||e.className).slice(0,14)+':'+Math.round(e.getBoundingClientRect().height));o.homeBlocks=blocks;
 switchTab('tb');await new Promise(r=>setTimeout(r,200));o.makeBlocks=[...document.getElementById('tb').children].filter(e=>e.getClientRects().length).map(e=>(e.id||e.className).slice(0,14)+':'+Math.round(e.getBoundingClientRect().height));
 switchTab('tsale');await new Promise(r=>setTimeout(r,200));o.sellBlocks=[...document.getElementById('tsale').children].filter(e=>e.getClientRects().length).map(e=>(e.id||e.className).slice(0,14)+':'+Math.round(e.getBoundingClientRect().height));
 switchTab('tcel');await new Promise(r=>setTimeout(r,200));o.celBlocks=[...document.getElementById('tcel').children].filter(e=>e.getClientRects().length).map(e=>(e.id||e.className).slice(0,14)+':'+Math.round(e.getBoundingClientRect().height));
 o.chrome=['hdr','ticker','nav'].map(id=>Math.round(document.getElementById(id).getBoundingClientRect().height));return o;});
console.log('FRESH',JSON.stringify(await meas()));
await p.evaluate(()=>{G.dl=3;G.cash=8e7;G.te=5e8;G.reputation=60;FD.forEach((f,i)=>{G.fac[f.id].p=true;G.fac[f.id].l=[24,22,26,21,18,14][i];});FD.forEach(f=>G.branch[f.id]=0);G.uw=WL.slice(0,14).map(w=>w.id);
 for(let i=0;i<24;i++){const l=makeLot(caskType('bourbon'),caskSize('hogshead'));l.age=1+i;G.lots.push(l);}G.tank=1800;
 const t=productSpec('glenlivid').target;invAdd('glenlivid',140,9,1.05,t);invAdd('jack_d',60,5,1,productSpec('jack_d').target);
 G.orders=[];for(let i=0;i<5;i++){const o=ordGenerate();if(o)G.orders.push(o);} G.bq=[{id:'q',pid:'glenlivid',n:300,done:100,moved:100,age:9,q:1,fl:t,blend:null,oid:null}];prodInvalidate();G.chap.claimed={1:true,2:true};});
await p.waitForTimeout(300);_=0;
console.log('MID',JSON.stringify(await meas()));
await b.close();})();
