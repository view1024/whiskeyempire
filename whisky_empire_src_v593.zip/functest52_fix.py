# v5.2 の変更に合わせて v5.1 までのテストを置き換える
def BLOCK(start, end, new):
    global s
    a = s.index(start); b = s.index(end, a)
    s = s[:a] + new + s[b:]
# #105：BGM（クラシック5曲）と手触りの動きを足したので上限を900KBに（計画の U5）
R2("const ok = s.bytes <= 860000 && left.length === 0", "const ok = s.bytes <= 900000 && left.length === 0")
R2("rec(105, '配布版は860KB以下（v4.7〜v5.0 で各+40KBまで）：", "rec(105, '配布版は900KB以下（v5.2 で上限を860KBから引き上げ）：")
# #138：砂時計の入手の記録に「樽の小人（tap）」が加わった
R2("r.src === '{\"login\":1,\"daily\":0,\"ms\":1,\"care\":0,\"ord\":0}'", "r.src === '{\"login\":1,\"daily\":0,\"ms\":1,\"care\":0,\"ord\":0,\"tap\":0}'")
