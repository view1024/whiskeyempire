exec(open('gen_ft48.py').read().replace("open('functest48.js','w').write(s)","pass"))
import os
exec(open('functest49_fix.py').read())
if os.path.exists('functest49_add.js'):
    a=s.index("  await browser.close();\n  let pass = 0;")
    s=s[:a]+open('functest49_add.js').read()+s[a:]
open('functest49.js','w').write(s)
